// Окно «Сугроба» (интерфейс на WebView2), живые обои и совместимость с Wallpaper Engine.
// Подключается в конце sugrob.cpp.
#pragma once
#include <shobjidl.h>
#include <shlobj.h>
#include "json.h"
#include "webview.h"

#define WM_WPPROGRESS (WM_APP + 5)
#define WM_WPREADY    (WM_APP + 6)
#define WM_EXTMEDIA   (WM_APP + 7)
#define IDR_UI_HTML     101
#define IDR_PLAYER_HTML 102
#define IDR_SCENE_HTML  103
#define IDR_WWGL_HTML   104
#define IDR_WWGL_JS     105
#define IDR_WWGL_LIC    106

static std::wstring gDataDir;                 // %LOCALAPPDATA%\Sugrob
static std::wstring dataPath(const wchar_t* sub) { return gDataDir + L"\\" + sub; }

static void alog(const char* fmt, ...) {
    if (gDataDir.empty()) return;
    FILE* f = _wfopen(dataPath(L"app.log").c_str(), L"a");
    if (!f) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    fprintf(f, "%02d:%02d:%02d ", st.wHour, st.wMinute, st.wSecond);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static std::string U8(const std::wstring& w) { return wv::toUtf8(w.c_str()); }
static std::wstring W16(const std::string& s) { return wv::toWide(s); }

// file:///C:/a%20b/c.html
static std::wstring fileUrl(const std::wstring& path) {
    std::string u = U8(path), out = "file:///";
    for (unsigned char c : u) {
        if (c == '\\') out += '/';
        else if (isalnum(c) || strchr("-._~/:!$&'()*+,;=@", c)) out += (char)c;
        else { char b[4]; snprintf(b, sizeof b, "%%%02X", c); out += b; }
    }
    return W16(out);
}

static std::string urlEncode(const std::string& s) {
    std::string o;
    for (unsigned char c : s) {
        if (isalnum(c) || strchr("-._~", c)) o += (char)c;
        else { char b[4]; snprintf(b, sizeof b, "%%%02X", c); o += b; }
    }
    return o;
}

static bool readFile(const std::wstring& p, std::string& out) {
    FILE* f = _wfopen(p.c_str(), L"rb");
    if (!f) return false;
    out.clear();
    char buf[65536];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) out.append(buf, n);
    fclose(f);
    return true;
}
static bool writeFile(const std::wstring& p, const std::string& data) {
    FILE* f = _wfopen(p.c_str(), L"wb");
    if (!f) return false;
    fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return true;
}
static bool fileExists(const std::wstring& p) {
    DWORD a = GetFileAttributesW(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
static ULONGLONG fileSize(const std::wstring& p) {
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExW(p.c_str(), GetFileExInfoStandard, &fa)) return 0;
    return ((ULONGLONG)fa.nFileSizeHigh << 32) | fa.nFileSizeLow;
}

static std::string resourceText(int id) {
    HRSRC r = FindResourceW(nullptr, MAKEINTRESOURCEW(id), RT_RCDATA);
    if (!r) return "";
    HGLOBAL g = LoadResource(nullptr, r);
    if (!g) return "";
    return std::string((const char*)LockResource(g), SizeofResource(nullptr, r));
}
static void extractResource(int id, const std::wstring& path) {
    std::string data = resourceText(id), old;
    if (data.empty()) return;
    if (readFile(path, old) && old == data) return;
    writeFile(path, data);
}

// ================================================================ каталог обоев
struct WpItem {
    std::string id, title, kind, source, thumb, author, license, note, propsJson;
    int season = -1;
    std::wstring path;      // файл (видео/картинка/страница)
    std::wstring folder;    // папка проекта Wallpaper Engine
    bool scene = false;     // сцена, которую умеет играть наш проигрыватель
    std::wstring urlPath;   // путь на upload.wikimedia.org (встроенные)
    DWORD size = 0;
    int progress = -1;      // загрузка, %
    std::string features = "[]";   // что умеют обои (для подписи в галерее)
    bool audio = false, mouse = false;
};

// готовые видео со свободной лицензией (Wikimedia Commons), скачиваются по выбору
struct BuiltinWp { const char* title; int season; const wchar_t* path; DWORD size; const char* thumb; const char* author; const char* license; };
#define TC "https://upload.wikimedia.org/wikipedia/commons/transcoded/"
#define TH "https://upload.wikimedia.org/wikipedia/commons/thumb/"
static const BuiltinWp kBuiltin[] = {
    {"Снегопад в сосновом лесу", 0, L"/wikipedia/commons/transcoded/5/56/Snow_falling_in_Charlton_MA_2025-12-14.webm/Snow_falling_in_Charlton_MA_2025-12-14.webm.1080p.vp9.webm", 11371854,
     TH "5/56/Snow_falling_in_Charlton_MA_2025-12-14.webm/330px--Snow_falling_in_Charlton_MA_2025-12-14.webm.jpg", "Peter Cooper Jr.", "CC0"},
    {"Снег за окном", 0, L"/wikipedia/commons/transcoded/f/f3/Snow_falling_in_Tuntorp.webm/Snow_falling_in_Tuntorp.webm.1080p.vp9.webm", 6805243,
     TH "f/f3/Snow_falling_in_Tuntorp.webm/330px--Snow_falling_in_Tuntorp.webm.jpg", "W.carter", "CC BY-SA 4.0"},
    {"Заснеженный каньон", 0, L"/wikipedia/commons/transcoded/e/e3/Fresh_Powder_coats_the_forests_of_Gallagher%27s_Canyon%2C_British_Columbia.webm/Fresh_Powder_coats_the_forests_of_Gallagher%27s_Canyon%2C_British_Columbia.webm.1080p.vp9.webm", 19155400,
     TH "e/e3/Fresh_Powder_coats_the_forests_of_Gallagher%27s_Canyon%2C_British_Columbia.webm/330px--Fresh_Powder_coats_the_forests_of_Gallagher%27s_Canyon%2C_British_Columbia.webm.jpg", "Extemporalist", "CC0"},
    {"Сакура в парке", 1, L"/wikipedia/commons/transcoded/1/12/JP_Park_Sakura_C_20180330.webm/JP_Park_Sakura_C_20180330.webm.1080p.vp9.webm", 9032180,
     TH "1/12/JP_Park_Sakura_C_20180330.webm/330px--JP_Park_Sakura_C_20180330.webm.jpg", "Stefan Lins", "CC BY 3.0"},
    {"Сакура у реки", 1, L"/wikipedia/commons/transcoded/c/c7/Cherry_blossoms_near_Sengawa_Toho_Studio.webm/Cherry_blossoms_near_Sengawa_Toho_Studio.webm.1080p.vp9.webm", 5924107,
     TH "c/c7/Cherry_blossoms_near_Sengawa_Toho_Studio.webm/330px--Cherry_blossoms_near_Sengawa_Toho_Studio.webm.jpg", "Kirin7739", "CC BY-SA 4.0"},
    {"Весенний снег и сакура", 1, L"/wikipedia/commons/transcoded/e/ec/Snow_with_Blossom_20200329.webm/Snow_with_Blossom_20200329.webm.1080p.vp9.webm", 39458905,
     TH "e/ec/Snow_with_Blossom_20200329.webm/330px--Snow_with_Blossom_20200329.webm.jpg", "Osumi Akari", "CC BY-SA 4.0"},
    {"Ромашки на ветру", 2, L"/wikipedia/commons/transcoded/1/15/Calmly_waving_grass_and_flowers.ogv/Calmly_waving_grass_and_flowers.ogv.1080p.vp9.webm", 6076001,
     TH "1/15/Calmly_waving_grass_and_flowers.ogv/330px--Calmly_waving_grass_and_flowers.ogv.jpg", "Pixelmaniac pictures", "Общественное достояние"},
    {"Солнечный луг", 2, L"/wikipedia/commons/transcoded/9/96/Wind_blowing_into_grass_and_plants_on_a_sunny_day_2024-05-09.webm/Wind_blowing_into_grass_and_plants_on_a_sunny_day_2024-05-09.webm.1080p.vp9.webm", 18860594,
     TH "9/96/Wind_blowing_into_grass_and_plants_on_a_sunny_day_2024-05-09.webm/330px--Wind_blowing_into_grass_and_plants_on_a_sunny_day_2024-05-09.webm.jpg", "GolhaMedia", "CC BY-SA 4.0"},
    {"Морские волны", 2, L"/wikipedia/commons/transcoded/2/29/Sunny_waves_at_Cattle_Point_%2840789227201%29.webm/Sunny_waves_at_Cattle_Point_%2840789227201%29.webm.1080p.vp9.webm", 7984075,
     TH "2/29/Sunny_waves_at_Cattle_Point_%2840789227201%29.webm/330px--Sunny_waves_at_Cattle_Point_%2840789227201%29.webm.jpg", "BLM Oregon & Washington", "Общественное достояние"},
    {"Бабочки на бархатцах", 2, L"/wikipedia/commons/0/0e/Peacock_butterflies_on_blooming_orange_marigold_flowers.webm", 1369845,
     TH "0/0e/Peacock_butterflies_on_blooming_orange_marigold_flowers.webm/330px--Peacock_butterflies_on_blooming_orange_marigold_flowers.webm.jpg", "Andrew Siwiec", "CC BY 4.0"},
    {"Листопад", 3, L"/wikipedia/commons/transcoded/f/f9/Falling_autumn_leaves.webm/Falling_autumn_leaves.webm.1080p.vp9.webm", 5139073,
     TH "f/f9/Falling_autumn_leaves.webm/330px--Falling_autumn_leaves.webm.jpg", "The Nature Box; фон: saihanul (Seongho Kwon)", "CC BY-SA 3.0"},
    {"Осень в Канагаве", 3, L"/wikipedia/commons/transcoded/4/4e/Autumnleavesfalling-kanagawa-2022Dec5.webm/Autumnleavesfalling-kanagawa-2022Dec5.webm.1080p.vp9.webm", 8948121,
     TH "4/4e/Autumnleavesfalling-kanagawa-2022Dec5.webm/330px--Autumnleavesfalling-kanagawa-2022Dec5.webm.jpg", "Nesnad", "CC BY-SA 4.0"},
    {"Осенняя река", 3, L"/wikipedia/commons/transcoded/c/c9/Little_Applegate_River_%2850982975823%29.webm/Little_Applegate_River_%2850982975823%29.webm.1080p.vp9.webm", 15294126,
     TH "c/c9/Little_Applegate_River_%2850982975823%29.webm/330px--Little_Applegate_River_%2850982975823%29.webm.jpg", "BLM Oregon & Washington", "Общественное достояние"},
};
static const int kBuiltinCount = (int)(sizeof(kBuiltin) / sizeof(kBuiltin[0]));

static std::vector<WpItem> gWpItems;       // всё, что показываем в галерее
static std::vector<std::wstring> gUserWp;  // добавленные пользователем файлы/папки
static std::string gWpCurrent;             // id текущих обоев (на всех мониторах)
static std::vector<std::string> gWpMon;    // свои обои на отдельных мониторах (пусто — как на всех)
static bool gWpUserPause = false;          // пауза по горячей клавише
static std::string gWpPending;             // ждём загрузки, чтобы включить
static bool gWeFound = false;

static std::wstring builtinFile(int i) {
    wchar_t b[32];
    swprintf(b, 32, L"\\video%02d.webm", i + 1);
    return dataPath(L"videos") + b;
}

static std::string lowerExt(const std::wstring& p) {
    size_t d = p.find_last_of(L'.');
    if (d == std::wstring::npos) return "";
    std::string e = U8(p.substr(d + 1));
    for (auto& c : e) c = (char)tolower((unsigned char)c);
    return e;
}
static std::string kindOfFile(const std::wstring& p) {
    std::string e = lowerExt(p);
    if (e == "mp4" || e == "webm" || e == "m4v" || e == "mov" || e == "ogv") return "video";
    if (e == "wmv" || e == "avi" || e == "mkv" || e == "flv" || e == "mpg" || e == "mpeg" || e == "3gp" || e == "asf" || e == "ts" || e == "m2ts") return "video";
    if (e == "gif" || e == "jpg" || e == "jpeg" || e == "png" || e == "bmp" || e == "webp") return "image";
    if (e == "html" || e == "htm") return "web";
    return "";
}
static std::wstring baseName(const std::wstring& p) {
    size_t s = p.find_last_of(L"\\/");
    std::wstring n = s == std::wstring::npos ? p : p.substr(s + 1);
    size_t d = n.find_last_of(L'.');
    return d == std::wstring::npos ? n : n.substr(0, d);
}

#include <tuple>
#include "wpinfo.h"
static std::map<std::wstring, WpInfo> gInfoCache;

static bool videoNeedsConvertExt(const std::wstring& p) {
    std::string e = lowerExt(p);
    return e == "wmv" || e == "avi" || e == "mkv" || e == "flv" || e == "mpg" || e == "mpeg" || e == "3gp" || e == "asf" || e == "ts" || e == "m2ts";
}

// папка проекта Wallpaper Engine (project.json)
static bool readWeProject(const std::wstring& folder, WpItem& it) {
    std::string txt;
    if (!readFile(folder + L"\\project.json", txt)) return false;
    bool ok = false;
    js::Value pj = js::parse(txt, &ok);
    if (pj.type != js::Value::Obj) return false;
    std::string type = pj.str("type");
    for (auto& c : type) c = (char)tolower((unsigned char)c);
    it.source = "we";
    it.folder = folder;
    it.id = "we:" + U8(folder);
    it.title = pj.str("title", U8(baseName(folder)));
    std::string file = pj.str("file");
    std::string prev = pj.str("preview");
    if (!prev.empty() && fileExists(folder + L"\\" + W16(prev))) it.thumb = U8(fileUrl(folder + L"\\" + W16(prev)));
    if (type == "video") { it.kind = "video"; it.path = folder + L"\\" + W16(file); }
    else if (type == "web") { it.kind = "web"; it.path = folder + L"\\" + W16(file.empty() ? "index.html" : file); }
    else if (type == "scene" && (fileExists(folder + L"\\scene.pkg") || fileExists(folder + L"\\" + W16(file.empty() ? "scene.json" : file)) ||
                                 fileExists(folder + L"\\" + baseName(W16(file.empty() ? "scene.json" : file)) + L".pkg"))) {
        it.kind = "scene";   // сцена: играет наш проигрыватель (параллакс, частицы, эффекты)
        it.scene = true;
        it.note = "Сцена Wallpaper Engine";
        it.path = folder + L"\\project.json";
    }
    else {
        it.kind = "scene";   // приложения Wallpaper Engine — только превью
        it.note = type == "application" ? "Приложение Wallpaper Engine — ставится только превью" : "Сцена Wallpaper Engine — ставится только превью-картинка";
        if (!prev.empty()) it.path = folder + L"\\" + W16(prev);
    }
    if (const js::Value* g = pj.get("general")) if (const js::Value* pr = g->get("properties")) it.propsJson = js::dump(*pr);
    if (it.propsJson.empty()) it.propsJson = "{}";
    // что должно происходить в этих обоях
    auto ci = gInfoCache.find(folder);
    if (ci == gInfoCache.end()) {
        WpInfo info;
        js::Value props = js::parse(it.propsJson);
        if (it.scene) info = analyzeScene(folder, file, props);
        else if (it.kind == "web") info = analyzeWeb(folder);
        else if (it.kind == "video") { addFeature(info, "Видео"); if (videoNeedsConvertExt(it.path)) addFeature(info, "Один раз переводится в MP4"); }
        ci = gInfoCache.emplace(folder, info).first;
    }
    it.features = infoJson(ci->second);
    it.audio = ci->second.audio;
    it.mouse = ci->second.mouse;
    return true;
}

static void scanWeFolder(const std::wstring& root, std::vector<WpItem>& out) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((root + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == L'.') continue;
        WpItem it;
        if (readWeProject(root + L"\\" + fd.cFileName, it)) out.push_back(it);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

static std::vector<std::wstring> steamLibraries() {
    std::vector<std::wstring> libs;
    wchar_t sp[MAX_PATH * 2] = {0};
    DWORD sz = sizeof(sp);
    if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\Valve\\Steam", L"SteamPath", RRF_RT_REG_SZ, nullptr, sp, &sz) != ERROR_SUCCESS)
        return libs;
    std::wstring steam = sp;
    for (auto& c : steam) if (c == L'/') c = L'\\';
    libs.push_back(steam);
    std::string vdf;
    if (readFile(steam + L"\\steamapps\\libraryfolders.vdf", vdf)) {
        size_t p = 0;
        while ((p = vdf.find("\"path\"", p)) != std::string::npos) {
            size_t a = vdf.find('"', p + 6);
            if (a == std::string::npos) break;
            size_t b = a + 1;
            std::string val;
            while (b < vdf.size() && vdf[b] != '"') {
                if (vdf[b] == '\\' && b + 1 < vdf.size()) { val += vdf[b + 1]; b += 2; }
                else val += vdf[b++];
            }
            std::wstring w = W16(val);
            bool dup = false;
            for (auto& l : libs) if (_wcsicmp(l.c_str(), w.c_str()) == 0) dup = true;
            if (!dup) libs.push_back(w);
            p = b + 1;
        }
    }
    return libs;
}

static void loadUserWp() {
    gUserWp.clear();
    std::string txt;
    if (!readFile(dataPath(L"wallpapers.json"), txt)) return;
    js::Value v = js::parse(txt);
    if (v.type == js::Value::Arr)
        for (auto& e : v.a) if (e.type == js::Value::Str) gUserWp.push_back(W16(e.s));
}
static void saveUserWp() {
    js::Value v;
    v.type = js::Value::Arr;
    for (auto& p : gUserWp) { js::Value s; s.type = js::Value::Str; s.s = U8(p); v.a.push_back(s); }
    writeFile(dataPath(L"wallpapers.json"), js::dump(v));
}

static void rebuildCatalog() {
    std::vector<WpItem> items;
    for (int i = 0; i < kBuiltinCount; ++i) {
        const BuiltinWp& b = kBuiltin[i];
        WpItem it;
        it.id = "builtin:" + std::to_string(i);
        it.title = b.title;
        it.kind = "video";
        it.source = "builtin";
        it.season = b.season;
        it.thumb = b.thumb;
        it.author = b.author;
        it.license = b.license;
        it.path = builtinFile(i);
        it.urlPath = b.path;
        it.features = "[\"Видео\"]";
        it.size = b.size;
        for (auto& o : gWpItems) if (o.id == it.id) it.progress = o.progress;
        items.push_back(it);
    }
    // Wallpaper Engine из Steam
    gWeFound = false;
    for (auto& lib : steamLibraries()) {
        size_t before = items.size();
        scanWeFolder(lib + L"\\steamapps\\workshop\\content\\431960", items);
        scanWeFolder(lib + L"\\steamapps\\common\\wallpaper_engine\\projects\\myprojects", items);
        if (items.size() > before) gWeFound = true;
        if (GetFileAttributesW((lib + L"\\steamapps\\common\\wallpaper_engine").c_str()) != INVALID_FILE_ATTRIBUTES) gWeFound = true;
    }
    // свои файлы и папки
    for (auto& p : gUserWp) {
        WpItem it;
        DWORD a = GetFileAttributesW(p.c_str());
        if (a == INVALID_FILE_ATTRIBUTES) continue;
        if (a & FILE_ATTRIBUTE_DIRECTORY) {
            if (!readWeProject(p, it)) continue;
            it.source = "file";
            it.id = "we:" + U8(p);
        } else {
            it.kind = kindOfFile(p);
            if (it.kind.empty()) continue;
            it.source = "file";
            it.id = "file:" + U8(p);
            it.title = U8(baseName(p));
            it.path = p;
            if (it.kind == "video") it.features = videoNeedsConvertExt(p) ? "[\"Видео\",\"Один раз переводится в MP4\"]" : "[\"Видео\"]";
            else if (it.kind == "image") it.features = "[\"Картинка\"]";
            else if (it.kind == "web") { WpInfo wi = analyzeWeb(p.substr(0, p.find_last_of(L"\\/"))); it.features = infoJson(wi); it.audio = wi.audio; it.mouse = wi.mouse; }
            if (it.kind == "image") it.thumb = U8(fileUrl(p));
            it.propsJson = "{}";
        }
        bool dup = false;
        for (auto& o : items) if (o.id == it.id) dup = true;
        if (!dup) items.push_back(it);
    }
    gWpItems.swap(items);
}

static WpItem* findItem(const std::string& id) {
    for (auto& it : gWpItems) if (it.id == id) return &it;
    return nullptr;
}
static bool itemReady(const WpItem& it) {
    if (it.source == "builtin") return fileExists(it.path) && fileSize(it.path) > 100000;
    return fileExists(it.path);
}

// ================================================================ загрузка видео
static volatile LONG gVidQuit = 0;
static HANDLE gVidThread = nullptr, gVidEvent = nullptr;
static CRITICAL_SECTION gVidLock;
static std::vector<int> gVidQueue;   // номера встроенных видео

static bool httpGetToFile(const wchar_t* path, const std::wstring& dst, DWORD expect, int idx) {
    HINTERNET ses = WinHttpOpen(L"Sugrob/2.0 (desktop wallpaper app; +https://commons.wikimedia.org)", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) ses = WinHttpOpen(L"Sugrob/2.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) return false;
    WinHttpSetTimeouts(ses, 15000, 15000, 20000, 60000);
    DWORD proto = 0x00000800 | 0x00002000;
    if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) {
        proto = 0x00000800;
        WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto));
    }
    bool ok = false;
    HINTERNET con = WinHttpConnect(ses, L"upload.wikimedia.org", INTERNET_DEFAULT_HTTPS_PORT, 0);
    HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", path, nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE) : nullptr;
    if (req && WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(req, nullptr)) {
        DWORD status = 0, sz = sizeof(status), clen = 0;
        WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
        sz = sizeof(clen);
        WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_LENGTH | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &clen, &sz, WINHTTP_NO_HEADER_INDEX);
        if (!clen) clen = expect;
        if (status == 200) {
            std::wstring part = dst + L".part";
            HANDLE f = CreateFileW(part.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
            if (f != INVALID_HANDLE_VALUE) {
                std::vector<char> buf(256 * 1024);
                DWORD got = 0, total = 0, lastPct = 0;
                bool err = false;
                for (;;) {
                    if (gVidQuit) { err = true; break; }
                    if (!WinHttpReadData(req, buf.data(), (DWORD)buf.size(), &got)) { err = true; alog("video read err=%lu", GetLastError()); break; }
                    if (got == 0) break;
                    DWORD wr = 0;
                    if (!WriteFile(f, buf.data(), got, &wr, nullptr) || wr != got) { err = true; break; }
                    total += got;
                    DWORD pct = clen ? (DWORD)((ULONGLONG)total * 100 / clen) : 0;
                    if (pct != lastPct) { lastPct = pct; PostMessageW(gMsgWnd, WM_WPPROGRESS, idx, pct); }
                }
                CloseHandle(f);
                if (!err && total > 100000 && (!clen || total == clen)) ok = MoveFileExW(part.c_str(), dst.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
                else alog("video size mismatch got=%lu expected=%lu", total, clen);
                if (!ok) DeleteFileW(part.c_str());
            }
        } else alog("video http status %lu", status);
    } else alog("video request failed err=%lu", GetLastError());
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    if (!ok && !gVidQuit) {   // запасной способ — системный загрузчик
        typedef HRESULT (WINAPI *Fn)(void*, LPCWSTR, LPCWSTR, DWORD, void*);
        HMODULE m = LoadLibraryW(L"urlmon.dll");
        Fn fn = m ? (Fn)(void*)GetProcAddress(m, "URLDownloadToFileW") : nullptr;
        if (fn) {
            std::wstring url = std::wstring(L"https://upload.wikimedia.org") + path, part = dst + L".part";
            PostMessageW(gMsgWnd, WM_WPPROGRESS, idx, 1);
            HRESULT hr = fn(nullptr, url.c_str(), part.c_str(), 0, nullptr);
            if (SUCCEEDED(hr) && fileSize(part) > 100000) ok = MoveFileExW(part.c_str(), dst.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
            else alog("video urlmon hr=0x%08lx", (unsigned long)hr);
            if (!ok) DeleteFileW(part.c_str());
        }
    }
    return ok;
}

static DWORD WINAPI VideoThread(LPVOID) {
    while (!gVidQuit) {
        int idx = -1;
        EnterCriticalSection(&gVidLock);
        if (!gVidQueue.empty()) { idx = gVidQueue.front(); gVidQueue.erase(gVidQueue.begin()); }
        LeaveCriticalSection(&gVidLock);
        if (idx < 0) { WaitForSingleObject(gVidEvent, INFINITE); continue; }
        std::wstring dst = builtinFile(idx);
        if (fileExists(dst)) { PostMessageW(gMsgWnd, WM_WPREADY, idx, 1); continue; }
        alog("video %d download start", idx + 1);
        bool ok = httpGetToFile(kBuiltin[idx].path, dst, kBuiltin[idx].size, idx);
        alog("video %d %s", idx + 1, ok ? "OK" : "FAILED");
        PostMessageW(gMsgWnd, WM_WPREADY, idx, ok ? 1 : 0);
    }
    return 0;
}

static void queueVideo(int idx) {
    if (!gVidThread) {
        gVidEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        gVidThread = CreateThread(nullptr, 0, VideoThread, nullptr, 0, nullptr);
    }
    EnterCriticalSection(&gVidLock);
    gVidQueue.erase(std::remove(gVidQueue.begin(), gVidQueue.end(), idx), gVidQueue.end());
    gVidQueue.insert(gVidQueue.begin(), idx);   // выбранное — первым
    LeaveCriticalSection(&gVidLock);
    SetEvent(gVidEvent);
}

// ================================================================ живые обои на рабочем столе
struct WpWin { std::string id; HWND hwnd = nullptr; wv::Host* host = nullptr; RECT mon{}; bool paused = false; bool scene = false; bool web = false; float mx = -1, my = -1; };
static bool gWpBtn = false;
static std::vector<WpWin> gWpWins;

static LRESULT CALLBACK WpProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_SIZE) {
        for (auto& w : gWpWins) if (w.hwnd == h) wv::fit(w.host);
        return 0;
    }
    if (msg == WM_ERASEBKGND) {
        RECT rc;
        GetClientRect(h, &rc);
        FillRect((HDC)wp, &rc, (HBRUSH)GetStockObject(BLACK_BRUSH));
        return 1;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

static HWND gWpParent = nullptr;

// встраиваем окно между картинкой рабочего стола и значками
static bool attachToDesktop(HWND w, const RECT& mon) {
    HWND progman = FindWindowW(L"Progman", nullptr);
    if (!progman) { alog("Progman not found"); return false; }
    DWORD_PTR res = 0;
    SendMessageTimeoutW(progman, 0x052C, 0xD, 0x1, SMTO_NORMAL, 1000, &res);
    SendMessageTimeoutW(progman, 0x052C, 0, 0, SMTO_NORMAL, 1000, &res);
    HWND childWorker = FindWindowExW(progman, nullptr, L"WorkerW", nullptr);   // Windows 11 24H2+
    HWND defView = FindWindowExW(progman, nullptr, L"SHELLDLL_DefView", nullptr);
    HWND parent = nullptr, after = HWND_TOP;
    bool newShell = childWorker != nullptr;
    if (newShell) {
        if (gWpMode == 2) parent = childWorker;
        else { parent = progman; if (defView) after = defView; }
    } else {
        HWND workerw = nullptr;
        HWND top = nullptr;
        while ((top = FindWindowExW(nullptr, top, L"WorkerW", nullptr)) != nullptr) {
            if (FindWindowExW(top, nullptr, L"SHELLDLL_DefView", nullptr)) {
                workerw = FindWindowExW(nullptr, top, L"WorkerW", nullptr);
                break;
            }
        }
        if (!workerw && defView) workerw = FindWindowExW(nullptr, progman, L"WorkerW", nullptr);
        parent = workerw ? workerw : progman;
        if (parent == progman && defView) after = defView;
    }
    LONG_PTR st = GetWindowLongPtrW(w, GWL_STYLE);
    SetWindowLongPtrW(w, GWL_STYLE, (st & ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME)) | WS_CHILD);
    SetParent(w, parent);
    if (newShell && gWpMode == 0) {
        SetWindowLongPtrW(w, GWL_EXSTYLE, GetWindowLongPtrW(w, GWL_EXSTYLE) | WS_EX_LAYERED);
        SetLayeredWindowAttributes(w, 0, 255, LWA_ALPHA);
    }
    POINT p{mon.left, mon.top};
    ScreenToClient(parent, &p);
    SetWindowPos(w, after, p.x, p.y, mon.right - mon.left, mon.bottom - mon.top, SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_FRAMECHANGED);
    if (newShell && gWpMode != 2 && childWorker)
        SetWindowPos(childWorker, w, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    gWpParent = parent;
    alog("wallpaper attached: newShell=%d mode=%d parent=%p defView=%p", newShell, gWpMode, (void*)parent, (void*)defView);
    return true;
}

static void refreshDesktopWallpaper() {
    wchar_t cur[MAX_PATH] = {0};
    SystemParametersInfoW(SPI_GETDESKWALLPAPER, MAX_PATH, cur, 0);
    SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, cur, 0);
}

static double gWpTickLast = -1;
static HWINEVENTHOOK gWpHook = nullptr;
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include "audio.h"
// ---------------- звук: включаем захват, только когда текущие обои его слушают и видны
static bool gAudioWanted = false;
static void audioUpdate() {
    bool want = false;
    for (auto& w : gWpWins) {
        if (w.paused) continue;
        WpItem* it = findItem(w.id);
        if (it && it->audio) want = true;
    }
    if (want == gAudioWanted) return;
    gAudioWanted = want;
    if (want) aud::start(); else aud::stop();
}

static void wpDestroyWindows() {
    for (auto& w : gWpWins) {
        wv::destroy(w.host);   // сам Host не удаляем: на него могут ссылаться асинхронные обработчики
        if (w.hwnd) DestroyWindow(w.hwnd);
    }
    gWpWins.clear();
    KillTimer(gMsgWnd, 2);
    if (gAudioWanted) { gAudioWanted = false; aud::stop(); }
    if (gWpHook) { UnhookWinEvent(gWpHook); gWpHook = nullptr; }
}

static void wpTick();
// окно закрыли, свернули или переключились — проверяем паузу обоев сразу, а не через четверть секунды
static void CALLBACK WpWinEvent(HWINEVENTHOOK, DWORD, HWND, LONG idObject, LONG, DWORD, DWORD) {
    if (idObject != OBJID_WINDOW || gWpWins.empty()) return;
    gWpTickLast = -1;
    wpTick();
}
static void wpHookEvents(bool on) {
    if (on && !gWpHook) {
        gWpHook = SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_MINIMIZEEND, nullptr, WpWinEvent, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
    } else if (!on && gWpHook) {
        UnhookWinEvent(gWpHook);
        gWpHook = nullptr;
    }
}

// сцене нужна мышь (параллакс), а окно обоев под значками её не получает — передаём сами
// курсор над рабочим столом (а не над окном программы)?
static bool cursorOnDesktop(POINT pt) {
    HWND h = WindowFromPoint(pt);
    for (int i = 0; h && i < 4; ++i, h = GetParent(h)) {
        wchar_t cls[64] = {0};
        GetClassNameW(h, cls, 64);
        if (!wcscmp(cls, L"SysListView32") || !wcscmp(cls, L"SHELLDLL_DefView") || !wcscmp(cls, L"WorkerW") || !wcscmp(cls, L"Progman") || !wcscmp(cls, L"SugrobWallpaper")) return true;
    }
    return false;
}

static void wpMouseTick() {
    POINT pt;
    GetCursorPos(&pt);
    // нажатия по рабочему столу передаём веб-обоям (жидкость, интерактивные страницы)
    bool btn = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    if (btn != gWpBtn) {
        bool desk = cursorOnDesktop(pt);
        if (desk || !btn) for (auto& w : gWpWins) {
            if ((!w.web && !w.scene) || w.paused || !w.host || !PtInRect(&w.mon, pt)) continue;
            float mw = (float)std::max(1L, w.mon.right - w.mon.left), mh = (float)std::max(1L, w.mon.bottom - w.mon.top);
            char b[96];
            snprintf(b, sizeof b, "{\"cmd\":\"%s\",\"x\":%.4f,\"y\":%.4f}", btn ? "down" : "up", (pt.x - w.mon.left) / mw, (pt.y - w.mon.top) / mh);
            wv::post(w.host, b);
        }
        gWpBtn = btn;
    }
    for (auto& w : gWpWins) {
        if ((!w.scene && !w.web) || w.paused || !w.host) continue;
        if (w.web && !PtInRect(&w.mon, pt)) continue;
        float mw = (float)std::max(1L, w.mon.right - w.mon.left), mh = (float)std::max(1L, w.mon.bottom - w.mon.top);
        float x = clampf((pt.x - w.mon.left) / mw, 0.0f, 1.0f), y = clampf((pt.y - w.mon.top) / mh, 0.0f, 1.0f);
        if (std::fabs(x - w.mx) < 0.0008f && std::fabs(y - w.my) < 0.0008f) continue;
        w.mx = x; w.my = y;
        char b[96];
        snprintf(b, sizeof b, "{\"cmd\":\"mouse\",\"x\":%.4f,\"y\":%.4f}", x, y);
        wv::post(w.host, b);
    }
}

static void appPushState();
static void appPushWallpapers();

static void saveWpMon();
static void wpStop() {
    bool had = !gWpWins.empty();
    wpDestroyWindows();
    gWpCurrent.clear();
    gWpMon.clear();
    saveWpMon();
    gWpPending.clear();
    RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, L"Wallpaper", REG_SZ, L"", sizeof(wchar_t));
    if (had) refreshDesktopWallpaper();
}

static std::wstring weShim(const std::string& props) {
    std::string js =
        "(function(){var props=" + props + ";"
        "var zero=new Array(128).fill(0);"
        // звук компьютера приходит от программы ~30 раз в секунду; пока его нет — тишина
        "var aud=[],lastA=0;window.wallpaperRegisterAudioListener=function(cb){aud.push(cb);};"
        "setInterval(function(){if(Date.now()-lastA>300)aud.forEach(function(cb){try{cb(zero);}catch(e){}});},33);"
        "['wallpaperRegisterMediaStatusListener','wallpaperRegisterMediaPropertiesListener','wallpaperRegisterMediaThumbnailListener',"
        "'wallpaperRegisterMediaPlaybackListener','wallpaperRegisterMediaTimelineListener','wallpaperRequestRandomFileForProperty']"
        ".forEach(function(n){window[n]=function(){};});"
        "var done=0;function apply(){var l=window.wallpaperPropertyListener;if(!l)return;"
        "try{if(l.applyGeneralProperties)l.applyGeneralProperties({fps:30});}catch(e){}"
        "try{if(l.applyUserProperties&&!done){done=1;l.applyUserProperties(props);}}catch(e){}}"
        "window.addEventListener('DOMContentLoaded',function(){setTimeout(apply,0);});"
        "window.addEventListener('load',function(){setTimeout(apply,150);});"
        "if(window.chrome&&chrome.webview)chrome.webview.addEventListener('message',function(e){var m=e.data||{};"
        "if(m.cmd==='audio'&&m.a){lastA=Date.now();aud.forEach(function(cb){try{cb(m.a);}catch(err){}});return;}"
        "if(m.cmd==='props'&&m.props){var l=window.wallpaperPropertyListener;try{if(l&&l.applyUserProperties)l.applyUserProperties(m.props);}catch(err){}return;}"
        "document.querySelectorAll('video,audio').forEach(function(v){if(m.cmd==='pause')v.pause();if(m.cmd==='play')v.play();if(m.cmd==='mute')v.muted=!!m.value;});"
        // мышь с рабочего стола: окно обоев само событий не получает
        "if(m.cmd==='mouse'||m.cmd==='down'||m.cmd==='up'){var x=m.x*innerWidth,y=m.y*innerHeight,t=document.elementFromPoint(x,y)||document.body;"
        "var o={clientX:x,clientY:y,screenX:x,screenY:y,pageX:x,pageY:y,bubbles:true,cancelable:true,view:window,button:0,buttons:m.cmd==='down'?1:0};"
        "var fire=function(el,n,b){try{el.dispatchEvent(n.indexOf('pointer')===0?new PointerEvent(n,Object.assign({pointerId:1,pointerType:'mouse',isPrimary:true},o,{bubbles:b})):new MouseEvent(n,Object.assign({},o,{bubbles:b})));}catch(e){}};"
        "if(t!==window.__weT){if(window.__weT){fire(window.__weT,'mouseout',true);fire(window.__weT,'mouseleave',false);}fire(t,'mouseover',true);fire(t,'mouseenter',false);fire(t,'pointerenter',false);window.__weT=t;}"
        "if(m.cmd==='mouse'){fire(t,'pointermove',true);fire(t,'mousemove',true);}"
        "if(m.cmd==='down'){fire(t,'pointerdown',true);fire(t,'mousedown',true);}"
        "if(m.cmd==='up'){fire(t,'pointerup',true);fire(t,'mouseup',true);fire(t,'click',true);}}"
        "});"
        "})();";
    return W16(js);
}

static void appToast(const std::string& text);
#include "convert.h"

// ---------------- настройки пака: что пользователь поменял (хранится отдельно от самого пака)
static std::wstring propsPath(const std::string& id) {
    unsigned long long h = 1469598103934665603ULL;
    for (unsigned char c : id) { h ^= c; h *= 1099511628211ULL; }
    wchar_t b[40];
    swprintf(b, 40, L"\\%016llx.json", h);
    CreateDirectoryW(dataPath(L"props").c_str(), nullptr);
    return dataPath(L"props") + b;
}
static js::Value loadOverrides(const std::string& id) {
    std::string t;
    js::Value v;
    if (readFile(propsPath(id), t)) v = js::parse(t);
    if (v.type != js::Value::Obj) { v = js::Value(); v.type = js::Value::Obj; }
    return v;
}
// свойства пака с учётом того, что поменял пользователь
static std::string mergedProps(const WpItem& it) {
    js::Value p = js::parse(it.propsJson.empty() ? "{}" : it.propsJson);
    if (p.type != js::Value::Obj) return "{}";
    js::Value ov = loadOverrides(it.id);
    for (auto& kv : ov.o)
        for (auto& pr : p.o)
            if (pr.first == kv.first && pr.second.type == js::Value::Obj) {
                bool set = false;
                for (auto& f : pr.second.o) if (f.first == "value") { f.second = kv.second; set = true; }
                if (!set) pr.second.o.emplace_back("value", kv.second);
            }
    return js::dump(p);
}


// адрес страницы для обоев; false — обои ещё не готовы (видео переводится в MP4)
static bool wpUrlFor(const WpItem& it, std::wstring& url, std::vector<std::wstring>& scripts) {
    std::wstring player = fileUrl(dataPath(L"ui\\player.html"));
    if (it.kind == "web") {
        url = fileUrl(it.path);
        scripts.push_back(weShim(mergedProps(it)));
    } else if (it.kind == "video") {
        std::wstring path = it.path;
        if (videoNeedsConvert(path)) {   // WMV, AVI… — один раз переводим в MP4
            std::wstring mp4 = convertedPath(path);
            if (!fileExists(mp4)) {
                if (convertStart(it.id, path)) {
                    appToast(T8("Готовлю видео: этот формат нужно один раз перевести в MP4. Обои включатся сами.",
                                "Preparing the video: this format is converted to MP4 once. The wallpaper will start by itself."));
                } else appToast(T8("Уже перевожу другое видео — подожди немного", "Another video is being converted — please wait"));
                return false;
            }
            path = mp4;
        }
        url = player + L"?kind=video&muted=" + (gWpMuted ? L"1" : L"0") + L"&src=" + W16(urlEncode(U8(fileUrl(path))));
    } else if (it.scene) {
        // WebWallGL — основной (скрипты, анимации, «куклы»); свой — запасной или по выбору в настройках
        std::string pl = loadOverrides(it.id).str("__player", "auto");
        url = fileUrl(dataPath(pl == "own" ? L"ui\\scene.html" : L"ui\\wwgl.html")) + L"?hz=" + std::to_wstring(gMonitorHz) +
              L"&muted=" + (gWpMuted ? L"1" : L"0") + L"&fps=" + std::to_wstring(wpFps()) + L"&lite=" + (liteNow() ? L"1" : L"0") +
              L"&dir=" + W16(urlEncode(U8(fileUrl(it.folder)))) + L"&props=" + W16(urlEncode(js::dump(loadOverrides(it.id))));
    } else {
        if (it.path.empty()) return false;
        url = player + L"?kind=image&src=" + W16(urlEncode(U8(fileUrl(it.path))));
    }
    return true;
}

static void wpCreateOn(const WpItem& it, size_t mi) {
    std::wstring url;
    std::vector<std::wstring> scripts;
    if (mi >= gMons.size() || !wpUrlFor(it, url, scripts)) return;
    static bool reg = false;
    if (!reg) {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = WpProc;
        wc.hInstance = gInst;
        wc.lpszClassName = L"SugrobWallpaper";
        wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
        RegisterClassExW(&wc);
        reg = true;
    }
    const RECT& m = gMons[mi];
    WpWin w;
    w.id = it.id;
    w.mon = m;
    w.hwnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"SugrobWallpaper", L"Подоконник — обои", WS_POPUP,
                             m.left, m.top, m.right - m.left, m.bottom - m.top, nullptr, nullptr, gInst, nullptr);
    if (!w.hwnd) return;
    attachToDesktop(w.hwnd, m);
    w.scene = it.scene;
    w.web = it.kind == "web";
    w.host = new wv::Host();
    w.host->hwnd = w.hwnd;
    if (it.scene) w.host->onMessage = [](const std::string& msg) {   // журнал проигрывателя сцен
        js::Value mm = js::parse(msg);
        if (mm.str("cmd") == "log") alog("scene: %s", mm.str("text").substr(0, 300).c_str());
    };
    wv::create(w.host, dataPath(L"WebView2"), url, scripts, false, [](bool ok) {
        if (!ok) alog("wallpaper webview failed");
    });
    gWpWins.push_back(w);
    alog("wallpaper started: %s (%s) on monitor %zu", it.id.c_str(), it.kind.c_str(), mi + 1);
}

static void saveWpMon() {
    js::Value v; v.type = js::Value::Arr;
    for (auto& id : gWpMon) { js::Value x; x.type = js::Value::Str; x.s = id; v.a.push_back(x); }
    std::wstring w = W16(js::dump(v));
    RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, L"WallpaperMon", REG_SZ, w.c_str(), (DWORD)((w.size() + 1) * sizeof(wchar_t)));
}
static std::string wpIdOn(size_t mi) { return mi < gWpMon.size() && !gWpMon[mi].empty() ? gWpMon[mi] : gWpCurrent; }

// пересоздать обои на всех мониторах: на каждом — свои или общие
static void wpRebuild() {
    wpDestroyWindows();
    bool any = false, input = false;
    for (size_t i = 0; i < gMons.size(); ++i) {
        WpItem* it = findItem(wpIdOn(i));
        if (!it || !itemReady(*it)) continue;
        wpCreateOn(*it, i);
        any = true;
        if (it->scene || it->kind == "web") input = true;
    }
    if (input) SetTimer(gMsgWnd, 2, 15, nullptr);   // мышь для параллакса и веб-обоев — 60 раз в секунду
    if (any) wpHookEvents(true);
    audioUpdate();
}

static void wpStartItem(const WpItem& it) {
    if (it.kind == "video" && videoNeedsConvert(it.path) && !fileExists(convertedPath(it.path))) {
        std::wstring u; std::vector<std::wstring> sc;
        if (!gConvBusy) gWpPending = it.id;
        wpUrlFor(it, u, sc);   // запустит перевод в MP4; обои включатся, когда он закончится
        return;
    }
    gWpCurrent = it.id;
    RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, L"Wallpaper", REG_SZ, W16(it.id).c_str(), (DWORD)((W16(it.id).size() + 1) * sizeof(wchar_t)));
    wpRebuild();
}

static void wpApplyOn(const std::string& id, int mon);
static void wpApply(const std::string& id) {
    WpItem* it = findItem(id);
    if (!it) return;
    if (it->source == "builtin" && !itemReady(*it)) {
        gWpPending = id;
        int idx = atoi(id.c_str() + 8);
        it->progress = 0;
        queueVideo(idx);
        appPushWallpapers();
        return;
    }
    gWpPending.clear();
    wpStartItem(*it);
    appPushState();
}

static void wpRestart() { if (!gWpWins.empty() || !gWpCurrent.empty()) wpRebuild(); }

// обои на одном мониторе (mon >= 0) или на всех (mon < 0 — заодно сбрасывает «свои» мониторы)
static void wpApplyOn(const std::string& id, int mon) {
    if (mon < 0 || gMons.size() < 2) {
        if (!gWpMon.empty()) { gWpMon.clear(); saveWpMon(); }
        wpApply(id);
        return;
    }
    WpItem* it = findItem(id);
    if (!it) return;
    if (it->source == "builtin" && !itemReady(*it)) { wpApply(id); return; }   // сначала скачаем
    if (gWpMon.size() < gMons.size()) gWpMon.resize(gMons.size());
    gWpMon[mon] = id;
    saveWpMon();
    wpRebuild();
    appPushState();
}

static void wpSetMuted(bool m) {
    gWpMuted = m;
    std::string js = std::string("{\"cmd\":\"mute\",\"value\":") + (m ? "true" : "false") + "}";
    for (auto& w : gWpWins) wv::post(w.host, js);
}

// пауза, когда обоев не видно (игра на весь экран или развёрнутое окно)
static void wpTick() {
    if (gWpWins.empty()) return;
    if (gTime - gWpTickLast < 0.25 && gWpTickLast >= 0) return;   // 4 раза в секунду достаточно
    gWpTickLast = gTime;
    HWND fg = GetForegroundWindow();
    RECT fgMon{};
    bool zoomed = false;
    if (fg && gWpPauseMax) {
        MONITORINFO mi{};
        mi.cbSize = sizeof(mi);
        wchar_t cls[64] = {0};
        GetClassNameW(fg, cls, 63);
        bool desktop = !wcscmp(cls, L"Progman") || !wcscmp(cls, L"WorkerW") || !wcscmp(cls, L"Shell_TrayWnd");
        if (!desktop && GetMonitorInfoW(MonitorFromWindow(fg, MONITOR_DEFAULTTONEAREST), &mi)) {
            bool covers = IsZoomed(fg) != 0;
            RECT r, x;
            if (!covers && !IsIconic(fg) && GetWindowRect(fg, &r) && IntersectRect(&x, &r, &mi.rcWork)) {
                // окно почти во весь экран (не развёрнуто, но закрывает обои) — тоже пауза
                double a = (double)(x.right - x.left) * (x.bottom - x.top);
                double m = (double)(mi.rcWork.right - mi.rcWork.left) * (mi.rcWork.bottom - mi.rcWork.top);
                covers = m > 0 && a >= 0.9 * m;
            }
            if (covers) { fgMon = mi.rcMonitor; zoomed = true; }
        }
    }
    for (auto& w : gWpWins) {
        if (!w.host || !w.host->ctl) continue;
        bool pause = gHiddenFS || (zoomed && EqualRect(&fgMon, &w.mon)) || (gOnBattery && gBatteryMode == 2) || gWpUserPause;
        if (pause == w.paused) continue;
        w.paused = pause;
        // видео прячем совсем (не тратит декодер); сцена сама перестаёт рисовать и продолжает без задержки
        if (!w.scene) w.host->ctl->put_IsVisible(pause ? FALSE : TRUE);
        wv::post(w.host, pause ? "{\"cmd\":\"pause\"}" : "{\"cmd\":\"play\"}");
    }
    audioUpdate();
}

// обои меняются вместе с сезоном, если стоят встроенные
static void onSeasonChanged() {
    musicFollowSeason();
    appPushState();
    if (!gWpFollowSeason || gWpCurrent.rfind("builtin:", 0) != 0) return;
    WpItem* cur = findItem(gWpCurrent);
    if (cur && cur->season == gSeason) return;
    for (auto& it : gWpItems)
        if (it.source == "builtin" && it.season == gSeason) { wpApply(it.id); return; }
}

// ================================================================ окно приложения
static HWND gAppWnd = nullptr;
static wv::Host* gAppHost = nullptr;
static bool gAppFull = false;
static WINDOWPLACEMENT gAppPlace{sizeof(WINDOWPLACEMENT)};

static std::string stateJson() {
    js::Value v;
    v.type = js::Value::Obj;
    auto num = [&](const char* k, double n) { js::Value x; x.type = js::Value::Num; x.n = n; v.o.emplace_back(k, x); };
    auto bl = [&](const char* k, bool b) { js::Value x; x.type = js::Value::Bool; x.b = b; v.o.emplace_back(k, x); };
    auto st = [&](const char* k, const std::string& s) { js::Value x; x.type = js::Value::Str; x.s = s; v.o.emplace_back(k, x); };
    st("type", "state");
    bl("effects", gSnowOn);
    num("seasonMode", gSeasonMode);
    num("season", gSeason);
    num("intensity", gIntensityPct);
    num("wind", gWindPct);
    bl("caps", gCapsOn);
    bl("hideFullscreen", gHideFullscreen);
    bl("capsTaskbar", gCapsTaskbar);
    bl("interact", gInteract);
    bl("snowmen", gMenOn);
    bl("dozer", gDozerOn);
    st("appVersion", kAppVersion);
    num("updState", gUpdState);
    num("updPct", gUpdPct);
    st("updVersion", gUpdVersion);
    st("updNotes", gUpdNotes);
    num("dozerEvery", gDozerEvery);
    num("fps", gFps);
    num("monitorHz", gMonitorHz);
    num("rain", gRainMode);
    bl("critters", gCrittersOn);
    num("fireflies", gFireflyMode);
    bl("autostart", autostartOn());
    bl("musicOn", gMusicOn);
    num("musicVol", gMusicVol);
    num("track", gTrack);
    num("musicPl", gPl);
    num("playingPl", gMusicOn && gPlaying >= 0 ? gPlayingPl : -1);
    num("playingIdx", gMusicOn ? gPlaying : -1);
    bl("musicFollow", gMusicFollow);
    st("playing", gMusicOn && gPlaying >= 0 && gPlaying < plCount(gPlayingPl) ? U8(plName(gPlayingPl, gPlaying)) : "");
    js::Value pls;
    pls.type = js::Value::Arr;
    for (int pl = 0; pl <= PL_MY; ++pl) {
        js::Value list;
        list.type = js::Value::Arr;
        for (int i = 0; i < plCount(pl); ++i) {
            js::Value t;
            t.type = js::Value::Obj;
            js::Value n; n.type = js::Value::Str; n.s = U8(plName(pl, i));
            js::Value r; r.type = js::Value::Bool; r.b = plReady(pl, i);
            t.o.emplace_back("name", n);
            t.o.emplace_back("ready", r);
            list.a.push_back(t);
        }
        pls.a.push_back(list);
    }
    v.o.emplace_back("playlists", pls);

    st("wpCurrent", gWpCurrent);
    num("monitors", (double)gMons.size());
    num("lang", gLang);
    num("battery", gBatteryMode);
    bl("light", gLightMode);
    bl("onBattery", gOnBattery);
    num("rotMin", gRotMin);
    bl("rotRandom", gRotRandom);
    bl("hotkeys", gHotkeys);
    bl("weatherOn", gWeatherOn);
    st("weatherCity", U8(gWeatherCity));
    st("weatherText", weatherText());
    num("holiday", gHolidayMode);
    num("holidayNow", gHoliday);
    bl("countdown", gCountdownOn);
    bl("wpUserPause", gWpUserPause);
    {
        js::Value a; a.type = js::Value::Arr;
        for (size_t i = 0; i < gMons.size(); ++i) { js::Value x; x.type = js::Value::Str; x.s = wpIdOn(i); a.a.push_back(x); }
        v.o.emplace_back("wpMon", a);
    }
    st("wpPending", gWpPending);
    bl("wpMuted", gWpMuted);
    num("wpMode", gWpMode);
    bl("wpPauseMax", gWpPauseMax);
    bl("wpFollowSeason", gWpFollowSeason);
    bl("fullscreen", gAppFull);
    return js::dump(v);
}

static std::string wallpapersJson() {
    std::string o = "{\"type\":\"wallpapers\",\"weFound\":";
    o += gWeFound ? "true" : "false";
    o += ",\"items\":[";
    bool first = true;
    for (auto& it : gWpItems) {
        if (!first) o += ",";
        first = false;
        o += "{\"id\":" + js::esc(it.id) + ",\"title\":" + js::esc(it.title) + ",\"kind\":" + js::esc(it.kind) +
             ",\"source\":" + js::esc(it.source) + ",\"season\":" + std::to_string(it.season) +
             ",\"thumb\":" + js::esc(it.thumb) + ",\"author\":" + js::esc(it.author) + ",\"license\":" + js::esc(it.license) +
             ",\"note\":" + js::esc(it.note) + ",\"ready\":" + (itemReady(it) ? "true" : "false") +
             ",\"progress\":" + std::to_string(it.progress) +
             ",\"sizeMb\":" + std::to_string((it.size + 500000) / 1000000) +
             ",\"file\":" + js::esc(it.kind == "video" && it.source != "builtin" ? U8(fileUrl(it.path)) : "") +
             ",\"features\":" + it.features + ",\"props\":" + (it.source == "builtin" ? std::string("{}") : mergedProps(it)) +
             ",\"player\":" + js::esc(it.scene ? loadOverrides(it.id).str("__player", "auto") : "") +
             ",\"fav\":" + (isFav(it.id) ? "true" : "false") +
             ",\"preview\":" + js::esc(it.kind == "video" && itemReady(it) ? U8(fileUrl(videoNeedsConvertExt(it.path) ? std::wstring() : it.path)) : "") + "}";
    }
    return o + "]}";
}

static void appPushState() { if (gAppHost) wv::post(gAppHost, stateJson()); updateTip(); }
static void appPushWallpapers() { if (gAppHost) wv::post(gAppHost, wallpapersJson()); }
static void appToast(const std::string& text) { if (gAppHost) wv::post(gAppHost, "{\"type\":\"toast\",\"text\":" + js::esc(text) + "}"); }

static void appSetFullscreen(bool on) {
    if (!gAppWnd || on == gAppFull) return;
    gAppFull = on;
    if (on) {
        GetWindowPlacement(gAppWnd, &gAppPlace);
        MONITORINFO mi{};
        mi.cbSize = sizeof(mi);
        GetMonitorInfoW(MonitorFromWindow(gAppWnd, MONITOR_DEFAULTTONEAREST), &mi);
        SetWindowLongPtrW(gAppWnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowPos(gAppWnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left,
                     mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    } else {
        SetWindowLongPtrW(gAppWnd, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
        SetWindowPlacement(gAppWnd, &gAppPlace);
        SetWindowPos(gAppWnd, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
    }
    appPushState();
}

// диалог выбора файлов/папки
// mode: 0 — обои (файлы), 1 — папка обоев Wallpaper Engine, 2 — музыка (файлы), 3 — папка с музыкой
static std::vector<std::wstring> pickPaths(int mode) {
    bool folder = mode == 1 || mode == 3;
    std::vector<std::wstring> out;
    IFileOpenDialog* dlg = nullptr;
    if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_IFileOpenDialog, (void**)&dlg)) || !dlg)
        return out;
    DWORD opts = 0;
    dlg->GetOptions(&opts);
    if (folder) {
        dlg->SetOptions(opts | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        dlg->SetTitle(mode == 3 ? L"Папка с музыкой" : L"Папка обоев Wallpaper Engine (с файлом project.json)");
    } else {
        dlg->SetOptions(opts | FOS_ALLOWMULTISELECT | FOS_FORCEFILESYSTEM | FOS_FILEMUSTEXIST);
        COMDLG_FILTERSPEC spec[] = {
            {L"Обои: паки .zip, видео, картинки, страницы", L"*.zip;*.mp4;*.webm;*.m4v;*.mov;*.wmv;*.avi;*.mkv;*.flv;*.mpg;*.mpeg;*.gif;*.jpg;*.jpeg;*.png;*.bmp;*.webp;*.html;*.htm;project.json;scene.pkg"},
            {L"Все файлы", L"*.*"}};
        COMDLG_FILTERSPEC mspec[] = {
            {L"Музыка (mp3, wav, wma, m4a, midi)", L"*.mp3;*.wav;*.wma;*.m4a;*.aac;*.mid;*.midi"},
            {L"Все файлы", L"*.*"}};
        dlg->SetFileTypes(2, mode == 2 ? mspec : spec);
        dlg->SetTitle(mode == 2 ? L"Выбери музыку" : L"Выбери пак обоев (.zip), видео, картинку или project.json");
    }
    if (SUCCEEDED(dlg->Show(gAppWnd))) {
        IShellItemArray* arr = nullptr;
        if (SUCCEEDED(dlg->GetResults(&arr)) && arr) {
            DWORD n = 0;
            arr->GetCount(&n);
            for (DWORD i = 0; i < n; ++i) {
                IShellItem* si = nullptr;
                if (SUCCEEDED(arr->GetItemAt(i, &si)) && si) {
                    PWSTR p = nullptr;
                    if (SUCCEEDED(si->GetDisplayName(SIGDN_FILESYSPATH, &p)) && p) { out.push_back(p); CoTaskMemFree(p); }
                    si->Release();
                }
            }
            arr->Release();
        }
    }
    dlg->Release();
    return out;
}

// запустить программу без окна и дождаться её
static bool runHidden(std::wstring cmd, DWORD timeoutMs) {
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) return false;
    DWORD code = 1;
    if (WaitForSingleObject(pi.hProcess, timeoutMs) == WAIT_OBJECT_0) GetExitCodeProcess(pi.hProcess, &code);
    else TerminateProcess(pi.hProcess, 1);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return code == 0;
}

// папка с project.json внутри распакованного архива (в корне или на уровень-два глубже)
static std::wstring findProjectFolder(const std::wstring& root, int depth = 0) {
    if (GetFileAttributesW((root + L"\\project.json").c_str()) != INVALID_FILE_ATTRIBUTES) return root;
    if (depth >= 2) return L"";
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((root + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return L"";
    std::wstring found;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) || fd.cFileName[0] == L'.') continue;
        found = findProjectFolder(root + L"\\" + fd.cFileName, depth + 1);
    } while (found.empty() && FindNextFileW(h, &fd));
    FindClose(h);
    return found;
}

// самое большое видео (или картинка) в распакованном архиве без project.json
static void findMediaRec(const std::wstring& root, int depth, std::wstring& best, ULONGLONG& bestSize, int& bestRank) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((root + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (fd.cFileName[0] == L'.') continue;
        std::wstring p = root + L"\\" + fd.cFileName;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (depth < 3) findMediaRec(p, depth + 1, best, bestSize, bestRank); continue; }
        std::string k = kindOfFile(p);
        int rank = k == "video" ? 2 : k == "image" ? 1 : 0;
        ULONGLONG sz = ((ULONGLONG)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
        if (rank && (rank > bestRank || (rank == bestRank && sz > bestSize))) { best = p; bestSize = sz; bestRank = rank; }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}
static std::wstring findMediaFile(const std::wstring& root) {
    std::wstring best; ULONGLONG sz = 0; int rank = 0;
    findMediaRec(root, 0, best, sz, rank);
    return best;
}

// пак обоев в .zip: распаковываем к себе в папку данных
static std::wstring unpackZip(const std::wstring& zip) {
    std::wstring name = baseName(zip);
    for (auto& c : name) if (wcschr(L"<>:\"/\\|?*", c)) c = L'_';
    CreateDirectoryW(dataPath(L"packs").c_str(), nullptr);
    std::wstring dst = dataPath(L"packs") + L"\\" + name;
    CreateDirectoryW(dst.c_str(), nullptr);
    wchar_t sys[MAX_PATH] = {0};
    GetSystemDirectoryW(sys, MAX_PATH);
    bool ok = runHidden(L"\"" + std::wstring(sys) + L"\\tar.exe\" -xf \"" + zip + L"\" -C \"" + dst + L"\"", 120000);
    if (!ok || findProjectFolder(dst).empty()) {   // запасной способ — PowerShell
        std::wstring q1 = zip, q2 = dst;
        for (std::wstring* q : {&q1, &q2}) { std::wstring r; for (wchar_t c : *q) { if (c == L'\'') r += L"''"; else r += c; } *q = r; }
        ok = runHidden(L"powershell.exe -NoProfile -NonInteractive -Command \"Expand-Archive -LiteralPath '" + q1 + L"' -DestinationPath '" + q2 + L"' -Force\"", 180000);
    }
    std::wstring proj = findProjectFolder(dst);
    if (proj.empty()) proj = findMediaFile(dst);   // в архиве просто видео или картинка
    alog("unpack %s -> %s", U8(zip).c_str(), proj.empty() ? "nothing" : U8(proj).c_str());
    return proj;
}

static void addUserPaths(const std::vector<std::wstring>& paths) {
    int added = 0;
    std::string lastId;
    for (std::wstring p : paths) {
        // выбрали project.json — берём его папку
        size_t sl = p.find_last_of(L"\\/");
        if (sl != std::wstring::npos && (_wcsicmp(p.c_str() + sl + 1, L"project.json") == 0 || _wcsicmp(p.c_str() + sl + 1, L"scene.pkg") == 0)) p = p.substr(0, sl);
        if (lowerExt(p) == "zip") {
            std::wstring f = unpackZip(p);
            if (f.empty()) { appToast("В архиве нет обоев: ни project.json, ни видео, ни картинки"); continue; }
            p = f;
        }
        DWORD a = GetFileAttributesW(p.c_str());
        if (a == INVALID_FILE_ATTRIBUTES) continue;
        if (a & FILE_ATTRIBUTE_DIRECTORY) {
            WpItem tmp;
            if (!readWeProject(p, tmp)) { appToast("В этой папке нет project.json — это не обои Wallpaper Engine"); continue; }
            lastId = "we:" + U8(p);
        } else {
            if (kindOfFile(p).empty()) continue;
            lastId = "file:" + U8(p);
        }
        bool dup = false;
        for (auto& u : gUserWp) if (_wcsicmp(u.c_str(), p.c_str()) == 0) dup = true;
        if (!dup) { gUserWp.push_back(p); added++; }
    }
    saveUserWp();
    rebuildCatalog();
    appPushWallpapers();
    if (added) appToast(added == 1 ? "Обои добавлены" : "Добавлено обоев: " + std::to_string(added));
}

static void handleUi(const std::string& msg) {
    js::Value m = js::parse(msg);
    std::string cmd = m.str("cmd");
    if (cmd == "ready") {
        appPushState();
        appPushWallpapers();
    } else if (cmd == "set") {
        std::string k = m.str("key");
        double v = m.num("value");
        bool b = v != 0;
        if (k == "effects") gSnowOn = b;
        else if (k == "seasonMode") { gSeasonMode = (int)v; int sea = effectiveSeason(); if (sea != gSeason) { applySeason(sea); onSeasonChanged(); } }
        else if (k == "intensity") gIntensityPct = (int)clampf((float)v, 0, 100);
        else if (k == "wind") gWindPct = (int)clampf((float)v, 0, 100);
        else if (k == "caps") gCapsOn = b;
        else if (k == "hideFullscreen") gHideFullscreen = b;
        else if (k == "capsTaskbar") gCapsTaskbar = b;
        else if (k == "interact") { gInteract = b; setHook(gInteract); }
        else if (k == "snowmen") gMenOn = b;
        else if (k == "dozer") gDozerOn = b;
        else if (k == "dozerEvery") { gDozerEvery = (int)v; gDozerTimer = 0; }
        else if (k == "fps") {
            gFps = (int)v; if (!validFps(gFps)) gFps = 30; gStaticFrames = 0; applyActivePace();
            for (auto& w : gWpWins) if (w.scene) wv::post(w.host, "{\"cmd\":\"fps\",\"value\":" + std::to_string(gFps) + "}");
        }
        else if (k == "rain") gRainMode = (int)v;
        else if (k == "critters") gCrittersOn = b;
        else if (k == "fireflies") gFireflyMode = (int)v;
        else if (k == "autostart") setAutostart(b);
        else if (k == "wpMuted") wpSetMuted(b);
        else if (k == "wpPauseMax") gWpPauseMax = b;
        else if (k == "wpFollowSeason") gWpFollowSeason = b;
        else if (k == "wpMode") { gWpMode = (int)v; wpRestart(); }
        else if (k == "lang") { gLang = (int)v ? 1 : 0; updateTip(); }
        else if (k == "battery") { gBatteryMode = (int)clampf((float)v, 0, 2); powerApply(); }
        else if (k == "light") { gLightMode = b; powerApply(); }
        else if (k == "rotMin") { gRotMin = (int)v; gRotLast = gTime; }
        else if (k == "rotRandom") gRotRandom = b;
        else if (k == "hotkeys") { gHotkeys = b; hotkeysApply(); }
        else if (k == "weatherOn") { gWeatherOn = b; if (b) weatherRequest(false); else { int sea = effectiveSeason(); if (sea != gSeason) { applySeason(sea); onSeasonChanged(); } } }
        else if (k == "holiday") { gHolidayMode = (int)clampf((float)v, 0, 5); gHolChk = 99; }
        else if (k == "countdown") gCountdownOn = b;
        saveSettings();
        appPushState();
    } else if (cmd == "applyWp") {
        wpApplyOn(m.str("id"), (int)m.num("mon", -1));
        saveSettings();
    } else if (cmd == "stopWp") {
        wpStop();
        appPushState();
    } else if (cmd == "addFile") {
        addUserPaths(pickPaths(0));
    } else if (cmd == "addFolder") {
        addUserPaths(pickPaths(1));
    } else if (cmd == "removeWp") {
        std::string id = m.str("id");
        if (id == gWpCurrent) wpStop();
        else {
            bool on = false;
            for (auto& x : gWpMon) if (x == id) { x.clear(); on = true; }
            if (on) { saveWpMon(); wpRebuild(); }
        }
        std::wstring p = W16(id.substr(id.find(':') + 1));
        gUserWp.erase(std::remove_if(gUserWp.begin(), gUserWp.end(), [&](const std::wstring& u) { return _wcsicmp(u.c_str(), p.c_str()) == 0; }), gUserWp.end());
        saveUserWp();
        rebuildCatalog();
        appPushWallpapers();
        appPushState();
    } else if (cmd == "wpProp") {
        std::string id = m.str("id"), key = m.str("key");
        const js::Value* v = m.get("value");
        WpItem* it = findItem(id);
        if (it && v && !key.empty()) {
            js::Value ov = loadOverrides(id);
            bool set = false;
            for (auto& kv : ov.o) if (kv.first == key) { kv.second = *v; set = true; }
            if (!set) ov.o.emplace_back(key, *v);
            writeFile(propsPath(id), js::dump(ov));
            bool shown = false;
            for (auto& w : gWpWins) if (w.id == id) shown = true;
            if (shown) {
                if (it->kind == "web") {   // веб-обои меняются на лету
                    js::Value pv; pv.type = js::Value::Obj;
                    js::Value one; one.type = js::Value::Obj; one.o.emplace_back("value", *v);
                    pv.o.emplace_back(key, one);
                    std::string msg = "{\"cmd\":\"props\",\"props\":" + js::dump(pv) + "}";
                    for (auto& w : gWpWins) if (w.id == id) wv::post(w.host, msg);
                } else if (it->scene) {
                    if (key == "__player") wpRestart();   // другой проигрыватель — перезапуск
                    else {   // сцена меняет свойства на лету
                        js::Value pv; pv.type = js::Value::Obj;
                        js::Value one; one.type = js::Value::Obj; one.o.emplace_back("value", *v);
                        pv.o.emplace_back(key, one);
                        std::string msg = "{\"cmd\":\"props\",\"props\":" + js::dump(pv) + "}";
                        for (auto& w : gWpWins) if (w.id == id) wv::post(w.host, msg);
                    }
                }
            }
            appPushWallpapers();
        }
    } else if (cmd == "fav") {
        toggleFav(m.str("id"));
        appPushWallpapers();
    } else if (cmd == "rotNext") {
        rotNext(1);
    } else if (cmd == "weatherCity") {
        gWeatherCity = W16(m.str("name"));
        gWeatherOn = true;
        saveSettings();
        weatherRequest(true);
        appPushState();
    } else if (cmd == "rescan") {
        rebuildCatalog();
        appPushWallpapers();
    } else if (cmd == "music") {
        std::string a = m.str("action");
        if (a == "toggle") { if (!gMusicOn) musicEnsureDownloader(); musicSetOn(!gMusicOn); }
        else if (a == "next") musicPlay(gTrack + 1);
        else if (a == "prev") musicPlay(gTrack - 1);
        else if (a == "play") {
            int pl = (int)m.num("pl", gPl);
            if (pl != gSeason) gMusicFollow = false;
            musicEnsureDownloader();
            gMusicOn = true;
            musicSelect(pl, (int)m.num("index"));
        }
        else if (a == "follow") { gMusicFollow = m.boolean("value"); musicFollowSeason(); }
        else if (a == "addFiles" || a == "addFolder") {
            std::vector<std::wstring> got = pickPaths(a == "addFiles" ? 2 : 3), files;
            static const char* exts[] = {"mp3", "wav", "wma", "m4a", "aac", "mid", "midi"};
            auto isAudio = [](const std::wstring& p) {
                std::string e = lowerExt(p);
                for (auto x : exts) if (e == x) return true;
                return false;
            };
            for (auto& p : got) {
                DWORD at = GetFileAttributesW(p.c_str());
                if (at == INVALID_FILE_ATTRIBUTES) continue;
                if (at & FILE_ATTRIBUTE_DIRECTORY) {   // папка — берём музыку из неё (и из вложенных на 1 уровень)
                    std::vector<std::wstring> dirs{p};
                    for (size_t di = 0; di < dirs.size() && di < 64; ++di) {
                        WIN32_FIND_DATAW fd;
                        HANDLE h = FindFirstFileW((dirs[di] + L"\\*").c_str(), &fd);
                        if (h == INVALID_HANDLE_VALUE) continue;
                        do {
                            if (fd.cFileName[0] == L'.') continue;
                            std::wstring full = dirs[di] + L"\\" + fd.cFileName;
                            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (di == 0) dirs.push_back(full); }
                            else if (isAudio(full)) files.push_back(full);
                        } while (FindNextFileW(h, &fd));
                        FindClose(h);
                    }
                } else if (isAudio(p)) files.push_back(p);
            }
            int added = 0;
            for (auto& f : files) {
                bool dup = false;
                for (auto& x : gMyMusic) if (_wcsicmp(x.c_str(), f.c_str()) == 0) dup = true;
                if (!dup) { gMyMusic.push_back(f); added++; }
            }
            saveMyMusic();
            if (added) appToast("Добавлено в «Мою музыку»: " + std::to_string(added));
            else if (!got.empty()) appToast("Музыки в mp3, wav, wma, m4a или midi там не нашлось");
        }
        else if (a == "remove") {
            int i = (int)m.num("index");
            if (i >= 0 && i < (int)gMyMusic.size()) {
                bool cur = gPl == PL_MY && gPlaying == i;
                gMyMusic.erase(gMyMusic.begin() + i);
                saveMyMusic();
                if (gPl == PL_MY) {
                    if (cur) musicPlay(i);
                    else if (gPlaying > i) { gPlaying--; gTrack = gPlaying; }
                }
            }
        }
        saveSettings();
        appPushState();
    } else if (cmd == "volume") {
        gMusicVol = (int)clampf((float)m.num("value"), 0, 100);
        musicApplyVolume();
        regSet(L"MusicVolume", (DWORD)gMusicVol);
    } else if (cmd == "fullscreen") {
        appSetFullscreen(m.get("value") ? m.boolean("value") : !gAppFull);
    } else if (cmd == "shake") {
        for (auto& kv : gCaps) shakeAll(kv.second);
    } else if (cmd == "dozer") {
        gDozerRequested = true;
        gDozer.cooldown = 0;
    } else if (cmd == "open") {
        std::string u = m.str("url");
        if (u.rfind("https://", 0) == 0) ShellExecuteW(nullptr, L"open", W16(u).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    } else if (cmd == "updCheck") {
        updCheck(true);
        appPushState();
    } else if (cmd == "updInstall") {
        updInstall();
        appPushState();
    } else if (cmd == "openData") {
        ShellExecuteW(nullptr, L"open", gDataDir.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    } else if (cmd == "quit") {
        DestroyWindow(gMsgWnd);
    }
}

static LRESULT CALLBACK AppProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_SIZE:
        wv::fit(gAppHost);
        return 0;
    case WM_GETMINMAXINFO: {
        auto* mm = (MINMAXINFO*)lp;
        mm->ptMinTrackSize.x = (LONG)(860 * S);
        mm->ptMinTrackSize.y = (LONG)(560 * S);
        return 0;
    }
    case WM_DPICHANGED: {
        RECT* r = (RECT*)lp;
        SetWindowPos(h, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top, SWP_NOZORDER | SWP_NOACTIVATE);
        return 0;
    }
    case WM_ERASEBKGND: {
        RECT rc;
        GetClientRect(h, &rc);
        HBRUSH b = CreateSolidBrush(RGB(11, 16, 30));
        FillRect((HDC)wp, &rc, b);
        DeleteObject(b);
        return 1;
    }
    case WM_CLOSE:
        DestroyWindow(h);
        return 0;
    case WM_DESTROY:
        if (gAppHost) wv::destroy(gAppHost);
        gAppHost = nullptr;
        gAppWnd = nullptr;
        gAppFull = false;
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

static void showApp() {
    if (gAppWnd) {
        if (IsIconic(gAppWnd)) ShowWindow(gAppWnd, SW_RESTORE);
        SetForegroundWindow(gAppWnd);
        return;
    }
    static bool reg = false;
    if (!reg) {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = AppProc;
        wc.hInstance = gInst;
        wc.lpszClassName = L"SugrobApp";
        wc.hIcon = LoadIconW(gInst, MAKEINTRESOURCEW(IDI_APP));
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        RegisterClassExW(&wc);
        reg = true;
    }
    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    int W = std::min((int)(1200 * S), (int)(wa.right - wa.left) - 40);
    int H = std::min((int)(780 * S), (int)(wa.bottom - wa.top) - 40);
    gAppWnd = CreateWindowExW(0, L"SugrobApp", L"Подоконник", WS_OVERLAPPEDWINDOW,
                              wa.left + (wa.right - wa.left - W) / 2, wa.top + (wa.bottom - wa.top - H) / 2, W, H,
                              nullptr, nullptr, gInst, nullptr);
    if (!gAppWnd) return;
    BOOL dark = TRUE;
    DwmSetWindowAttribute(gAppWnd, 20 /*DWMWA_USE_IMMERSIVE_DARK_MODE*/, &dark, sizeof(dark));
    ShowWindow(gAppWnd, SW_SHOW);
    SetForegroundWindow(gAppWnd);
    gAppHost = new wv::Host();
    gAppHost->hwnd = gAppWnd;
    gAppHost->onMessage = handleUi;
    wv::Host* host = gAppHost;
    wv::create(host, dataPath(L"WebView2"), fileUrl(dataPath(L"ui\\index.html")), {}, true, [host](bool ok) {
        if (ok || host->closed) return;
        int r = MessageBoxW(gAppWnd,
            L"Для окна настроек нужен компонент Microsoft Edge WebView2 Runtime.\n\n"
            L"Обычно он уже есть в Windows 10/11. Открыть страницу загрузки?",
            L"Подоконник", MB_ICONWARNING | MB_YESNO);
        if (r == IDYES) ShellExecuteW(nullptr, L"open", L"https://go.microsoft.com/fwlink/p/?LinkId=2124703", nullptr, nullptr, SW_SHOWNORMAL);
        if (gAppWnd) DestroyWindow(gAppWnd);
    });
}

static void appInit() {
    wchar_t base[MAX_PATH] = {0};
    if (!GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH)) GetTempPathW(MAX_PATH, base);
    gDataDir = std::wstring(base) + L"\\Sugrob";
    CreateDirectoryW(gDataDir.c_str(), nullptr);
    CreateDirectoryW(dataPath(L"ui").c_str(), nullptr);
    CreateDirectoryW(dataPath(L"videos").c_str(), nullptr);
    extractResource(IDR_UI_HTML, dataPath(L"ui\\index.html"));
    extractResource(IDR_PLAYER_HTML, dataPath(L"ui\\player.html"));
    extractResource(IDR_SCENE_HTML, dataPath(L"ui\\scene.html"));
    extractResource(IDR_WWGL_HTML, dataPath(L"ui\\wwgl.html"));
    extractResource(IDR_WWGL_JS, dataPath(L"ui\\webwallgl.global.min.js"));
    extractResource(IDR_WWGL_LIC, dataPath(L"ui\\webwallgl-LICENSE.txt"));
    InitializeCriticalSection(&gVidLock);
    wv::gLog = [](const char* s) { alog("%s", s); };
    loadUserWp();
    rebuildCatalog();
    alog("start: Windows build %lu, monitors %zu, WE found %d", windowsBuild(), gMons.size(), (int)gWeFound);
    // восстановить обои
    wchar_t cur[1024] = {0};
    DWORD sz = sizeof(cur);
    if (RegGetValueW(HKEY_CURRENT_USER, kRegKey, L"Wallpaper", RRF_RT_REG_SZ, nullptr, cur, &sz) == ERROR_SUCCESS && cur[0]) {
        std::string id = U8(cur);
        if (findItem(id)) gWpCurrent = id;
    }
    {
        wchar_t mon[8192] = {0};
        DWORD ms = sizeof(mon);
        if (RegGetValueW(HKEY_CURRENT_USER, kRegKey, L"WallpaperMon", RRF_RT_REG_SZ, nullptr, mon, &ms) == ERROR_SUCCESS) {
            js::Value v = js::parse(U8(mon));
            for (auto& x : v.a) gWpMon.push_back(x.type == js::Value::Str ? x.s : "");
            if (gWpMon.size() > gMons.size()) gWpMon.resize(gMons.size());
        }
    }
    if (!gWpCurrent.empty() || !gWpMon.empty()) wpRebuild();
}

static void appShutdown() {
    gVidQuit = 1;
    if (gVidEvent) SetEvent(gVidEvent);
    if (gAppWnd) DestroyWindow(gAppWnd);
    // окна обоев закрываем — рабочий стол вернётся к обычной картинке
    bool had = !gWpWins.empty();
    wpDestroyWindows();
    if (had) refreshDesktopWallpaper();
}

// сообщения главного скрытого окна, относящиеся к приложению; true — обработано
static bool appMsg(UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_AUDIOFRAME) {
        if (!gAudioWanted) return true;
        std::string j = aud::json();
        for (auto& w : gWpWins) if (!w.paused && w.host) wv::post(w.host, j);
        return true;
    }
    if (msg == WM_CONVPROGRESS) {
        if (WpItem* it = findItem(gConvId)) it->progress = (int)wp;
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"progress\",\"id\":" + js::esc(gConvId) + ",\"pct\":" + std::to_string((int)wp) + "}");
        return true;
    }
    if (msg == WM_CONVDONE) {
        if (WpItem* it = findItem(gConvId)) it->progress = -1;
        if (wp == 1 && gWpPending == gConvId) { gWpPending.clear(); if (WpItem* it = findItem(gConvId)) wpStartItem(*it); }
        else if (wp == 1) { for (auto& x : gWpMon) if (x == gConvId) { wpRebuild(); break; } }
        else if (wp != 1) {
            if (gWpPending == gConvId) gWpPending.clear();
            appToast("Не получилось перевести видео. Windows не знает этот формат — попробуй MP4.");
        }
        appPushWallpapers();
        appPushState();
        return true;
    }
    if (msg == WM_WPPROGRESS) {
        std::string id = "builtin:" + std::to_string((int)wp);
        if (WpItem* it = findItem(id)) it->progress = (int)lp;
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"progress\",\"id\":" + js::esc(id) + ",\"pct\":" + std::to_string((int)lp) + "}");
        return true;
    }
    if (msg == WM_WPREADY) {
        std::string id = "builtin:" + std::to_string((int)wp);
        if (WpItem* it = findItem(id)) it->progress = -1;
        if (lp == 1 && gWpPending == id) { gWpPending.clear(); if (WpItem* it = findItem(id)) wpStartItem(*it); }
        if (lp == 0) { if (gWpPending == id) gWpPending.clear(); appToast("Не получилось скачать видео. Проверь интернет и попробуй ещё раз."); }
        appPushWallpapers();
        appPushState();
        return true;
    }
    return false;
}
