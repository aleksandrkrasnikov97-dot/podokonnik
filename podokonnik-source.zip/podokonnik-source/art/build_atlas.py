# Собирает атлас частей питомца из листов, нарисованных ChatGPT (art/src/*.png).
# Фон — зелёный #00FF00. Цветовые метки:
#   серый #C8C8C8 / тень #A0A0A0 -> основной цвет (c1), яркость = множитель
#   пурпурный #FF00FF -> второй цвет (c2), жёлтый #FFFF00 -> цвет глаз / шапочки птицы (c3),
#   бирюзовый #00FFFF -> цвет украшения (c4), остальное (розовый нос, золото, чёрный, белый) — как есть.
# Результат: petatlas.png — три полосы RGB одна под другой:
#   полоса 0: (c1·k, c2·k, c3·k)   полоса 1: (c4·k, alpha, 0)   полоса 2: свой цвет (premultiplied)
# и petatlas.json с прямоугольниками и точками крепления.
import json, sys, os
import numpy as np
from PIL import Image
from scipy import ndimage

SRC = os.path.join(os.path.dirname(__file__), 'src')
KMAX = 1.3

def key_green(rgb):
    r, g, b = [rgb[..., i].astype(np.float32) for i in range(3)]
    green = g - np.maximum(r, b)
    a = np.clip(1 - (green - 25) / 190, 0, 1)
    bg = np.array([3, 249, 3], np.float32)
    col = rgb.astype(np.float32)
    aa = np.maximum(a, 1e-3)[..., None]
    col = np.clip((col - (1 - a)[..., None] * bg) / aa, 0, 255)
    col[a < 0.02] = 0
    a[a < 0.02] = 0
    return col, a

def classify(col, a, keys):
    """-> каналы (c1,c2,c3,c4,fr,fg,fb) на пиксель, уже умноженные на покрытие alpha"""
    r, g, b = col[..., 0], col[..., 1], col[..., 2]
    mx = np.maximum(np.maximum(r, g), b); mn = np.minimum(np.minimum(r, g), b)
    sat = np.where(mx > 1, (mx - mn) / np.maximum(mx, 1), 0)
    L = 0.299 * r + 0.587 * g + 0.114 * b
    # тон
    d = np.maximum(mx - mn, 1e-3)
    h = np.where(mx == r, ((g - b) / d) % 6, np.where(mx == g, (b - r) / d + 2, (r - g) / d + 4)) * 60
    out = np.zeros(col.shape[:2] + (7,), np.float32)
    grey = sat < 0.2
    is_c1 = grey & (L >= 70) & (L <= 236)
    out[..., 0] = np.where(is_c1, L / 200.0, 0)
    used = is_c1.copy()
    def hue_near(c, w): return (~grey) & (np.abs(((h - c + 180) % 360) - 180) < w) & (sat > 0.55)
    for ch, hue, width in keys:      # (канал, тон, ширина)
        m = hue_near(hue, width) & ~used
        out[..., ch] = np.where(m, mx / 255.0, out[..., ch])
        used |= m
    fixed = ~used
    for i in range(3):
        out[..., 4 + i] = np.where(fixed, col[..., i] / 255.0, 0)
    return out * a[..., None]

def items(a, rows):
    m = a > 0.35
    lab, n = ndimage.label(ndimage.binary_dilation(m, iterations=14))
    boxes = []
    for i, sl in enumerate(ndimage.find_objects(lab)):
        sub = (lab[sl] == i + 1) & (a[sl] > 0.02)
        ys, xs = np.nonzero(sub)
        if len(xs) < 150: continue
        y0, y1, x0, x1 = sl[0].start + ys.min(), sl[0].start + ys.max() + 1, sl[1].start + xs.min(), sl[1].start + xs.max() + 1
        boxes.append([x0, y0, x1, y1, i + 1])
    # в строки по высоте
    boxes.sort(key=lambda b: (b[1] + b[3]) / 2)
    out_rows, cur = [], []
    for b in boxes:
        if cur and (b[1] + b[3]) / 2 - np.mean([(c[1] + c[3]) / 2 for c in cur]) > np.median([c[3] - c[1] for c in boxes]) * 0.55:
            out_rows.append(cur); cur = []
        cur.append(b)
    if cur: out_rows.append(cur)
    for r in out_rows: r.sort(key=lambda b: b[0])
    counts = [len(r) for r in out_rows]
    if counts != rows:
        print('  !! ожидалось', rows, 'нашлось', counts); sys.exit(1)
    return out_rows, lab

SHEETS = [
    # файл, строки, имена (по строкам), макс. размер стороны, метки
    ('heads.png', [4, 4, 4, 4], [[f'head{f}_{p}' for f in range(4)] for p in (0, 1, 2, 4)], 120, [(1, 300, 30)]),
    ('torso.png', [4, 4, 4, 4], [[f'torso{t}_{p}' for t in range(4)] for p in (0, 1, 2, 4)], 170, [(1, 300, 30)]),
    ('sit.png', [4, 4, 4, 4, 4], [[f'sit{t}_{p}' for t in range(4)] for p in (0, 1, 2, 4, 3)], 150, [(1, 300, 30)]),
    ('sleep.png', [4, 4, 4, 4], [[f'sleep{t}_{p}' for t in range(4)] for p in (0, 1, 2, 4)], 170, [(1, 300, 30)]),
    ('parts.png', [5, 2, 4], [['ear0', 'ear1', 'ear2', 'ear3', 'ear4'], ['leg0', 'leg3'], ['tail0', 'tail1', 'tail2', 'tail3']], 110, [(1, 300, 30)]),
    ('eyes_acc.png', [5, 5], [['eye0', 'eye1', 'eye2', 'eye3', 'eyeC'], ['acc1', 'acc2', 'acc3', 'acc4', 'acc5']], 90, [(2, 60, 12), (3, 180, 25)]),
    ('birds.png', [3], [['bird_stand', 'bird_peck', 'bird_fly']], 150, [(1, 300, 30), (2, 60, 12)]),
]

def pivots(name, alpha):
    """точки крепления в долях ширины/высоты спрайта"""
    h, w = alpha.shape
    m = alpha > 0.5
    ys, xs = np.nonzero(m)
    def span_center(row):
        xx = np.nonzero(m[row])[0]; return (xx.min() + xx.max()) / 2 if len(xx) else w / 2
    P = {}
    if name.startswith('head'):
        P['c'] = [(h / 2) / w, 0.5]                     # центр «черепа» — круг слева
    elif name.startswith('sit'):
        top = ys.min(); rows = [r for r in range(top, min(top + 6, h))]
        P['neck'] = [np.mean([span_center(r) for r in rows]) / w, top / h]
        P['c'] = [0.5, 1.0]
    elif name.startswith(('torso', 'sleep')):
        P['c'] = [0.5, 0.5]
    elif name == 'ear1':
        P['c'] = [span_center(ys.min() + 2) / w, 0.0]  # висячее ухо крепится сверху
    elif name.startswith('ear'):
        P['c'] = [span_center(ys.max() - 2) / w, 1.0]
    elif name.startswith('leg'):
        P['c'] = [span_center(ys.min() + 2) / w, 0.0]
    elif name == 'tail2':
        P['c'] = [0.5, 0.5]
    elif name.startswith('tail'):
        bottom = ys.max(); xx = np.nonzero(m[bottom - 2])[0]
        P['c'] = [(xx.min() + xx.max()) / 2 / w, 1.0]     # основание — внизу слева
    elif name in ('acc2', 'acc4'):
        top = ys.min(); P['c'] = [0.5, (top + 0.12 * h) / h]
    elif name in ('acc3', 'acc5', 'bird_stand', 'bird_peck'):
        P['c'] = [0.5, 1.0]
    else:
        P['c'] = [0.5, 0.5]
    return P

def main():
    sprites = []
    for fn, rows, names, maxside, keys in SHEETS:
        im = np.array(Image.open(os.path.join(SRC, fn)).convert('RGB'))
        col, a = key_green(im)
        print(fn)
        rws, lab = items(a, rows)
        ch = classify(col, a, keys)
        for ri, row in enumerate(rws):
            for ci, (x0, y0, x1, y1, li) in enumerate(row):
                name = names[ri][ci]
                pad = 3
                x0 = max(0, x0 - pad); y0 = max(0, y0 - pad); x1 = min(im.shape[1], x1 + pad); y1 = min(im.shape[0], y1 + pad)
                own = (lab[y0:y1, x0:x1] == li).astype(np.float32)     # только этот предмет (соседей не цеплять)
                own = ndimage.maximum_filter(own, 3)
                crop = ch[y0:y1, x0:x1] * own[..., None]
                al = a[y0:y1, x0:x1] * own
                sc = min(1.0, maxside / max(x1 - x0, y1 - y0))
                W, H = max(1, round((x1 - x0) * sc)), max(1, round((y1 - y0) * sc))
                chans = [np.array(Image.fromarray(crop[..., i]).resize((W, H), Image.BOX)) for i in range(7)]
                alr = np.array(Image.fromarray(al).resize((W, H), Image.BOX))
                sprites.append(dict(name=name, w=W, h=H, ch=np.stack(chans, -1), a=alr, piv=pivots(name, alr)))
    # упаковка полками
    sprites.sort(key=lambda s: -s['h'])
    AW = 1024; x = y = shelf = 0
    for s in sprites:
        if x + s['w'] + 2 > AW: x = 0; y += shelf + 2; shelf = 0
        s['x'], s['y'] = x, y; x += s['w'] + 2; shelf = max(shelf, s['h'])
    AH = y + shelf
    atlas = np.zeros((AH * 3, AW, 3), np.float32)
    for s in sprites:
        X, Y, W, H, c = s['x'], s['y'], s['w'], s['h'], s['ch']
        atlas[Y:Y + H, X:X + W, 0] = c[..., 0] / KMAX
        atlas[Y:Y + H, X:X + W, 1] = c[..., 1] / KMAX
        atlas[Y:Y + H, X:X + W, 2] = c[..., 2] / KMAX
        atlas[AH + Y:AH + Y + H, X:X + W, 0] = c[..., 3] / KMAX
        atlas[AH + Y:AH + Y + H, X:X + W, 1] = s['a']
        atlas[2 * AH + Y:2 * AH + Y + H, X:X + W, :] = c[..., 4:7]
    out = os.path.dirname(__file__)
    Image.fromarray(np.clip(atlas * 255 + 0.5, 0, 255).astype(np.uint8)).save(os.path.join(out, 'petatlas.png'), optimize=True)
    meta = {'kmax': KMAX, 'band': AH, 'w': AW,
            'sprites': {s['name']: dict(x=s['x'], y=s['y'], w=s['w'], h=s['h'], **{k: [round(v, 4) for v in p] for k, p in s['piv'].items()}) for s in sprites}}
    json.dump(meta, open(os.path.join(out, 'petatlas.json'), 'w'), ensure_ascii=False, indent=0)
    with open(os.path.join(out, '..', 'pet_atlas.h'), 'w') as f:
        f.write('// создано art/build_atlas.py — части питомца, нарисованные ChatGPT\n#pragma once\n')
        f.write('struct PetSpriteDef { const char* name; int x, y, w, h; float px, py, nx, ny; };\n')
        f.write(f'static const int kPetAtlasW = {AW}, kPetAtlasBand = {AH};\nstatic const float kPetAtlasKmax = {KMAX}f;\n')
        f.write('static const PetSpriteDef kPetSprites[] = {\n')
        for sp in sprites:
            c = sp['piv']['c']; n = sp['piv'].get('neck', [0.5, 0])
            f.write(f'    {{"{sp["name"]}", {sp["x"]}, {sp["y"]}, {sp["w"]}, {sp["h"]}, {c[0]:.4f}f, {c[1]:.4f}f, {n[0]:.4f}f, {n[1]:.4f}f}},\n')
        f.write('};\n')
    print('atlas', AW, 'x', AH * 3, len(sprites), 'sprites', os.path.getsize(os.path.join(out, 'petatlas.png')) // 1024, 'KB')

main()
