# Домики питомца, нарисованные ChatGPT (art/src/pethouses.png, фон #00FF00)
# → art/houseatlas.png (RGBA, ресурс 117) и art/houseatlas.h.
#   точка крепления — середина нижнего края, size — ширина; door — центр входа (доли ширины и высоты)
import os
import numpy as np
from PIL import Image
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
W_OUT = 200
PAD = 4


def key_green(rgb):
    r, g, b = [rgb[..., i].astype(np.float32) for i in range(3)]
    green = g - np.maximum(r, b)
    a = np.clip(1 - (green - 25) / 190, 0, 1)
    bg = np.array([3, 249, 4], np.float32)
    col = rgb.astype(np.float32)
    col = np.clip((col - (1 - a)[..., None] * bg) / np.maximum(a, 1e-3)[..., None], 0, 255)
    col[..., 1] = np.minimum(col[..., 1], np.maximum(col[..., 0], col[..., 2]) + 6)
    col[a < 0.02] = 0
    a[a < 0.02] = 0
    return col, a


def resize_rgba(img, k):
    pm = img.astype(np.float32)
    pm[..., :3] *= pm[..., 3:4] / 255
    h, w = img.shape[:2]
    W2, H2 = max(1, round(w * k)), max(1, round(h * k))
    st = np.dstack([np.array(Image.fromarray(pm[..., j]).resize((W2, H2), Image.LANCZOS)) for j in range(4)])
    st[..., 3] = np.clip(st[..., 3], 0, 255)
    st[..., :3] = np.clip(st[..., :3] * 255 / np.maximum(st[..., 3:4], 1e-3), 0, 255)
    st[st[..., 3] < 1] = 0
    return st.astype(np.uint8)


rgb = np.array(Image.open(os.path.join(HERE, 'src', 'pethouses.png')).convert('RGB'))
col, a = key_green(rgb)
lab, n = ndimage.label(ndimage.binary_closing(a > 0.5, iterations=3))
sizes = ndimage.sum(np.ones_like(a), lab, range(1, n + 1))
boxes = []
for i in [i + 1 for i, s in enumerate(sizes) if s > 20000]:
    ys, xs = np.where(lab == i)
    boxes.append([xs.min(), ys.min(), xs.max(), ys.max(), i])
rowh = rgb.shape[0] / 2
boxes.sort(key=lambda b: (int(((b[1] + b[3]) / 2) // rowh), b[0]))
assert len(boxes) == 6, len(boxes)
sprites = []
for x0, y0, x1, y1, i in boxes:
    m = lab == i
    X0, Y0, X1, Y1 = max(0, x0 - 6), max(0, y0 - 6), min(rgb.shape[1], x1 + 7), min(rgb.shape[0], y1 + 7)
    mm = ndimage.binary_dilation(m, iterations=5)[Y0:Y1, X0:X1]
    img = np.dstack([col[Y0:Y1, X0:X1], a[Y0:Y1, X0:X1] * mm * 255]).astype(np.uint8)
    # вход — самое большое тёмное пятно внутри домика
    c = col[y0:y1, x0:x1]
    L = 0.299 * c[..., 0] + 0.587 * c[..., 1] + 0.114 * c[..., 2]
    dark, dn = ndimage.label((L < 75) & m[y0:y1, x0:x1])
    ds = ndimage.sum(np.ones_like(L), dark, range(1, dn + 1))
    dm = dark == (int(np.argmax(ds)) + 1)
    dy, dx = ndimage.center_of_mass(dm)
    dys, dxs = np.where(dm)
    k = W_OUT / (x1 - x0)
    sprites.append((resize_rgba(img, k), ((x0 + x1) / 2 - X0) * k, (y1 - Y0) * k, dx / (x1 - x0), dy / (y1 - y0), (y1 - y0) / (x1 - x0),
                    (dxs.max() - dxs.min()) / (x1 - x0), dys.min() / (y1 - y0), dys.max() / (y1 - y0)))
Wt = sum(s[0].shape[1] + PAD for s in sprites) + PAD
Ht = max(s[0].shape[0] for s in sprites) + 2 * PAD
atlas = np.zeros((Ht, Wt, 4), np.uint8)
x = PAD
rows = []
for img, ax, ay, ddx, ddy, asp, dw, dt, db in sprites:
    h, w = img.shape[:2]
    atlas[PAD:PAD + h, x:x + w] = img
    rows.append((x, PAD, w, h, ax, ay, ddx, ddy, asp, dw, dt, db))
    x += w + PAD
Image.fromarray(atlas, 'RGBA').save(os.path.join(HERE, 'houseatlas.png'), optimize=True)
with open(os.path.join(HERE, 'houseatlas.h'), 'w', encoding='utf-8') as f:
    f.write('// создано art/build_house.py — не править руками\n#pragma once\n')
    f.write('// 0 деревянный, 1 коробка, 2 иглу, 3 пряничный, 4 палатка, 5 скворечник\n')
    f.write('// door* — вход в долях ширины/высоты домика: центр, ширина, верх и низ\n')
    f.write('struct HouseDef { int x, y, w, h; float ax, ay, size, doorX, doorY, aspect, doorW, doorTop, doorBottom; };\n')
    f.write('static const HouseDef kHouse[6] = {\n')
    for x0, y0, w, h, ax, ay, ddx, ddy, asp, dw, dt, db in rows:
        f.write(f'    {{{x0}, {y0}, {w}, {h}, {ax:.1f}f, {ay:.1f}f, {W_OUT}.0f, {ddx:.3f}f, {ddy:.3f}f, {asp:.3f}f, {dw:.3f}f, {dt:.3f}f, {db:.3f}f}},\n')
    f.write('};\n')
print('atlas', Wt, Ht, os.path.getsize(os.path.join(HERE, 'houseatlas.png')))
