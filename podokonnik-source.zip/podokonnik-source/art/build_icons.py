# Свои паки значков «Зимний» и «Новогодний», нарисованные ChatGPT (art/src/icons-*.png, сетка 4×3 на #00FF00)
# → <папка>/<пак>/<значок>.png 256×256 (как паки из tools/iconpacks.py) и превью.
# Запуск: python3 art/build_icons.py <папка сайта>/icons
import os, sys
import numpy as np
from PIL import Image
from scipy import ndimage
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_snow import key_green, resize_rgba

HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["folder", "folder-open", "folder-download", "folder-documents",
         "folder-music", "folder-pictures", "folder-videos", "folder-desktop",
         "user-home", "computer", "trash", "trash-full"]
PACKS = [("winter", "Зимний — свой", "Winter — our own", "icons-winter.png"),
         ("newyear", "Новогодний — свой", "New Year — our own", "icons-newyear.png")]


def cut(name):
    rgb = np.array(Image.open(os.path.join(HERE, "src", name)).convert("RGB"))
    col, a = key_green(rgb)
    H, W = a.shape
    out = []
    for r in range(3):
        for c in range(4):
            y0, y1, x0, x1 = H * r // 3, H * (r + 1) // 3, W * c // 4, W * (c + 1) // 4
            m = a[y0:y1, x0:x1] > 0.5
            lab, n = ndimage.label(ndimage.binary_closing(m, iterations=3))
            sizes = ndimage.sum(np.ones_like(m), lab, range(1, n + 1))
            keep = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 300])
            keep = ndimage.binary_dilation(keep, iterations=4)
            ys, xs = np.where(keep)
            by0, by1, bx0, bx1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
            img = np.dstack([col[y0:y1, x0:x1], a[y0:y1, x0:x1] * keep * 255]).astype(np.uint8)[by0:by1, bx0:bx1]
            side = max(img.shape[0], img.shape[1])
            k = 240 / side
            sm = resize_rgba(img, k)
            canvas = np.zeros((256, 256, 4), np.uint8)
            oy, ox = (256 - sm.shape[0]) // 2, (256 - sm.shape[1]) // 2
            canvas[oy:oy + sm.shape[0], ox:ox + sm.shape[1]] = sm
            out.append(Image.fromarray(canvas, "RGBA"))
    return out


def tiles():
    """рамки для программ без своего значка: слева зимняя, справа новогодняя"""
    rgb = np.array(Image.open(os.path.join(HERE, "src", "icons-tiles.png")).convert("RGB"))
    col, a = key_green(rgb)
    H, W = a.shape
    out = []
    for c in range(2):
        x0, x1 = W * c // 2, W * (c + 1) // 2
        m = a[:, x0:x1] > 0.5
        lab, n = ndimage.label(ndimage.binary_closing(m, iterations=3))
        sizes = ndimage.sum(np.ones_like(m), lab, range(1, n + 1))
        keep = ndimage.binary_dilation(np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 2000]), iterations=4)
        ys, xs = np.where(keep)
        img = np.dstack([col[:, x0:x1], a[:, x0:x1] * keep * 255]).astype(np.uint8)[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        k = 248 / max(img.shape[:2])
        sm = resize_rgba(img, k)
        canvas = np.zeros((256, 256, 4), np.uint8)
        oy, ox = (256 - sm.shape[0]) // 2, (256 - sm.shape[1]) // 2
        canvas[oy:oy + sm.shape[0], ox:ox + sm.shape[1]] = sm
        out.append(Image.fromarray(canvas, "RGBA"))
    return out


def main():
    dst = sys.argv[1]
    tl = tiles()
    lines = []
    for pid, name, en, src in PACKS:
        d = os.path.join(dst, pid)
        os.makedirs(d, exist_ok=True)
        imgs = cut(src)
        for n, im in zip(ORDER, imgs):
            im.save(os.path.join(d, n + ".png"), optimize=True)
        tl[0 if pid == "winter" else 1].save(os.path.join(d, "tile.png"), optimize=True)
        open(os.path.join(d, "style.txt"), "w").write("inner 0.54\noffy 0.07\n")
        open(os.path.join(d, "list.txt"), "w").write("\n".join(ORDER + ["tile"]) + "\n")
        prev = Image.new("RGBA", (6 * 44, 44), (0, 0, 0, 0))
        for i, n in enumerate(["folder", "folder-download", "computer", "folder-music", "folder-pictures", "trash"]):
            im = Image.open(os.path.join(d, n + ".png")).resize((40, 40), Image.LANCZOS)
            prev.paste(im, (i * 44 + 2, 2), im)
        prev.save(os.path.join(d, "preview.png"), optimize=True)
        lines.append("pack\t%s\t%s\t%s\tПодоконник (нарисовано нейросетью)\tбесплатно\thttps://aleksandrkrasnikov97-dot.github.io/podokonnik/\t12\t0\t0\t%s\t%s" % (pid, name, en, pid, "#9fd4ff" if pid == "winter" else "#d32f2f"))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
