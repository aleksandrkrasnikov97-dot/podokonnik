# Снежки, головы, руки и шапки снеговика, нарисованные ChatGPT (art/src/snow*.png, фон #00FF00)
# → art/snowatlas.png (RGBA, ресурс 116) и art/snowatlas.h (прямоугольники и точки крепления).
#   шары и головы: точка — центр шара, size — радиус шара (головы смотрят вправо)
#   руки: точка — срез ветки (крепится к телу), size — ширина спрайта (рука смотрит вправо и вверх)
#   шапки: точка — середина нижнего края, size — ширина спрайта
import os
import numpy as np
from PIL import Image
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'src')
BALL_R = 112     # радиус шара в атласе
ARM_W = 220      # ширина руки в атласе
HAT_W = 220      # ширина шапки в атласе
PAD = 4
ROW_W = 2048


def key_green(rgb):
    r, g, b = [rgb[..., i].astype(np.float32) for i in range(3)]
    green = g - np.maximum(r, b)
    a = np.clip(1 - (green - 25) / 190, 0, 1)
    bg = np.array([3, 249, 4], np.float32)
    col = rgb.astype(np.float32)
    aa = np.maximum(a, 1e-3)[..., None]
    col = np.clip((col - (1 - a)[..., None] * bg) / aa, 0, 255)
    col[..., 1] = np.minimum(col[..., 1], np.maximum(col[..., 0], col[..., 2]) + 6)   # зелёная кайма
    col[a < 0.02] = 0
    a[a < 0.02] = 0
    return col, a


def resize_rgba(img, k):
    pm = img.astype(np.float32)
    pm[..., :3] *= pm[..., 3:4] / 255
    h, w = img.shape[:2]
    W2, H2 = max(1, round(w * k)), max(1, round(h * k))
    st = np.dstack([np.array(Image.fromarray(pm[..., j]).resize((W2, H2), Image.LANCZOS)) for j in range(4)])
    st[..., 3] = np.clip(st[..., 3], 0, 255)
    st[..., :3] = np.clip(st[..., :3] * 255 / np.maximum(st[..., 3:4], 1e-3), 0, 255)
    st[st[..., 3] < 1] = 0
    return st.astype(np.uint8)


def pieces(name, kind, count):
    rgb = np.array(Image.open(os.path.join(SRC, name)).convert('RGB'))
    col, a = key_green(rgb)
    lab, n = ndimage.label(ndimage.binary_closing(a > 0.5, iterations=3))
    sizes = ndimage.sum(np.ones_like(a), lab, range(1, n + 1))
    big = [i + 1 for i, s in enumerate(sizes) if s > 4000]
    boxes = []
    for i in big:
        ys, xs = np.where(lab == i)
        boxes.append([xs.min(), ys.min(), xs.max(), ys.max(), i])
    rowh = rgb.shape[0] / 2
    boxes.sort(key=lambda b: (int(((b[1] + b[3]) / 2) // rowh), b[0]))   # по рядам, слева направо
    assert len(boxes) == count, (name, len(boxes))
    out = []
    for x0, y0, x1, y1, i in boxes:
        m = lab == i
        X0, Y0 = max(0, x0 - 6), max(0, y0 - 6)
        X1, Y1 = min(rgb.shape[1], x1 + 7), min(rgb.shape[0], y1 + 7)
        mm = ndimage.binary_dilation(m, iterations=5)[Y0:Y1, X0:X1]
        img = np.dstack([col[Y0:Y1, X0:X1], a[Y0:Y1, X0:X1] * mm * 255]).astype(np.uint8)
        if kind == 'ball':   # круг: сверху, снизу и слева шар касается рамки (справа может торчать морковка)
            rr = (y1 - y0) / 2
            ax, ay, k = x0 + rr - X0, (y0 + y1) / 2 - Y0, BALL_R / rr
            size = BALL_R
        elif kind == 'arm':  # срез ветки — самый левый край
            ys, xs = np.where(m[:, x0:x0 + 10])
            ax, ay = x0 - X0 + 4, ys.mean() - Y0
            k = ARM_W / (x1 - x0)
            size = ARM_W
        else:                # шапка: середина низа
            ax, ay = (x0 + x1) / 2 - X0, y1 - Y0
            k = HAT_W / (x1 - x0)
            size = HAT_W
        out.append((resize_rgba(img, k), ax * k, ay * k, size))
    return out


def main():
    groups = [
        ('BALL', pieces('snowballs.png', 'ball', 3)),
        ('HEAD', pieces('snowheads.png', 'ball', 3) + pieces('snowheads2.png', 'ball', 6)),
        ('ARM', pieces('snowarms.png', 'arm', 6)),
        ('HAT', pieces('snowhats.png', 'hat', 8)),
    ]
    sprites = [s for _, g in groups for s in g]
    # раскладка полками
    x, y, shelf = PAD, PAD, 0
    place = []
    for img, *_ in sprites:
        h, w = img.shape[:2]
        if x + w + PAD > ROW_W:
            x, y, shelf = PAD, y + shelf + PAD, 0
        place.append((x, y))
        x += w + PAD
        shelf = max(shelf, h)
    W, H = ROW_W, y + shelf + PAD
    atlas = np.zeros((H, W, 4), np.uint8)
    for (img, *_), (px, py) in zip(sprites, place):
        h, w = img.shape[:2]
        atlas[py:py + h, px:px + w] = img
    Image.fromarray(atlas, 'RGBA').save(os.path.join(HERE, 'snowatlas.png'), optimize=True)
    with open(os.path.join(HERE, 'snowatlas.h'), 'w', encoding='utf-8') as f:
        f.write('// создано art/build_snow.py — не править руками\n#pragma once\n')
        f.write('struct SnowSprDef { int x, y, w, h; float ax, ay, size; };\n')
        start = 0
        for nm, g in groups:
            f.write(f'static const int kSnow{nm.title()}0 = {start}, kSnow{nm.title()}N = {len(g)};\n')
            start += len(g)
        f.write('static const SnowSprDef kSnowSpr[] = {\n')
        for (img, ax, ay, size), (px, py) in zip(sprites, place):
            h, w = img.shape[:2]
            f.write(f'    {{{px}, {py}, {w}, {h}, {ax:.1f}f, {ay:.1f}f, {size}.0f}},\n')
        f.write('};\n')
    print('atlas', W, H, os.path.getsize(os.path.join(HERE, 'snowatlas.png')), 'sprites', len(sprites))


main()
