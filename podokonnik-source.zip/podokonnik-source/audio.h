// Звук компьютера для обоев, которые «реагируют на музыку»: захват того, что играет в колонках
// (WASAPI loopback), спектр 64 полосы на канал — как отдаёт его Wallpaper Engine.
#pragma once
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <complex>

#define WM_AUDIOFRAME (WM_APP + 23)

namespace aud {

static const GUID CLSID_Enum = {0xBCDE0395, 0xE52F, 0x467C, {0x8E, 0x3D, 0xC4, 0x57, 0x92, 0x91, 0x69, 0x2E}};
static const GUID IID_Enum   = {0xA95664D2, 0x9614, 0x4F35, {0xA7, 0x46, 0xDE, 0x8D, 0xB6, 0x36, 0x17, 0xE6}};
static const GUID IID_Client = {0x1CB9AD4C, 0xDBFA, 0x4C32, {0xB1, 0x78, 0xC2, 0xF5, 0x68, 0xA7, 0x03, 0xB2}};
static const GUID IID_Capture = {0xC8ADBD64, 0xE71E, 0x48A0, {0xA4, 0xDE, 0x18, 0x5C, 0x39, 0x5C, 0xD3, 0x17}};
static const GUID SUB_FLOAT  = {0x00000003, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71}};

static const int N = 1024;            // окно БПФ
static float gSpec[128];              // 0..63 — левый, 64..127 — правый
static CRITICAL_SECTION gLock;
static volatile LONG gQuit = 0, gRunning = 0;
static HANDLE gThread = nullptr;
static bool gInit = false;

static void fft(std::complex<float>* a, int n) {
    for (int i = 1, j = 0; i < n; ++i) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        float ang = -6.28318530718f / len;
        std::complex<float> wl(std::cos(ang), std::sin(ang));
        for (int i = 0; i < n; i += len) {
            std::complex<float> w(1, 0);
            for (int k = 0; k < len / 2; ++k) {
                std::complex<float> u = a[i + k], v = a[i + k + len / 2] * w;
                a[i + k] = u + v; a[i + k + len / 2] = u - v;
                w *= wl;
            }
        }
    }
}

// 64 полосы по логарифмической шкале 30 Гц … 16 кГц, мягкое затухание как у Wallpaper Engine
static void spectrum(const float* ring, int pos, int rate, float* out, float* smooth) {
    static std::complex<float> buf[N];
    for (int i = 0; i < N; ++i) {
        float w = 0.5f - 0.5f * std::cos(6.28318530718f * i / (N - 1));
        buf[i] = std::complex<float>(ring[(pos + i) % N] * w, 0);
    }
    fft(buf, N);
    for (int b = 0; b < 64; ++b) {
        float f0 = 30.0f * std::pow(16000.0f / 30.0f, b / 64.0f), f1 = 30.0f * std::pow(16000.0f / 30.0f, (b + 1) / 64.0f);
        int i0 = std::max(1, (int)(f0 * N / rate)), i1 = std::max(i0 + 1, (int)(f1 * N / rate));
        float m = 0;
        for (int i = i0; i < i1 && i < N / 2; ++i) m = std::max(m, std::abs(buf[i]));
        float v = std::log10(1.0f + m * 0.6f) * (0.9f + b * 0.02f);
        v = std::min(v, 1.5f);
        smooth[b] = v > smooth[b] ? v : smooth[b] * 0.82f + v * 0.18f;
        out[b] = smooth[b];
    }
}

static DWORD WINAPI Thread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    IMMDeviceEnumerator* en = nullptr;
    IMMDevice* dev = nullptr;
    IAudioClient* cl = nullptr;
    IAudioCaptureClient* cap = nullptr;
    WAVEFORMATEX* wf = nullptr;
    bool ok = false;
    do {
        if (FAILED(CoCreateInstance(CLSID_Enum, nullptr, CLSCTX_ALL, IID_Enum, (void**)&en))) break;
        if (FAILED(en->GetDefaultAudioEndpoint(eRender, eConsole, &dev))) break;
        if (FAILED(dev->Activate(IID_Client, CLSCTX_ALL, nullptr, (void**)&cl))) break;
        if (FAILED(cl->GetMixFormat(&wf))) break;
        if (FAILED(cl->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_LOOPBACK, 2000000, 0, wf, nullptr))) break;
        if (FAILED(cl->GetService(IID_Capture, (void**)&cap))) break;
        if (FAILED(cl->Start())) break;
        ok = true;
    } while (false);
    if (!ok) alog("audio: capture not available");
    bool isFloat = false;
    int bits = 16, ch = 2, rate = 48000;
    if (wf) {
        ch = std::max<int>(1, wf->nChannels); rate = (int)wf->nSamplesPerSec; bits = wf->wBitsPerSample;
        isFloat = wf->wFormatTag == WAVE_FORMAT_IEEE_FLOAT ||
                  (wf->wFormatTag == WAVE_FORMAT_EXTENSIBLE && IsEqualGUID(((WAVEFORMATEXTENSIBLE*)wf)->SubFormat, SUB_FLOAT));
    }
    static float ringL[N], ringR[N], smL[64], smR[64];
    int pos = 0;
    DWORD lastSend = 0, lastPacket = 0;
    while (ok && !gQuit) {
        Sleep(10);
        UINT32 packet = 0;
        while (SUCCEEDED(cap->GetNextPacketSize(&packet)) && packet) {
            BYTE* data = nullptr;
            UINT32 frames = 0;
            DWORD flags = 0;
            if (FAILED(cap->GetBuffer(&data, &frames, &flags, nullptr, nullptr))) break;
            for (UINT32 i = 0; i < frames; ++i) {
                float l = 0, r = 0;
                if (!(flags & AUDCLNT_BUFFERFLAGS_SILENT)) {
                    if (isFloat && bits == 32) { const float* p = (const float*)data + i * ch; l = p[0]; r = ch > 1 ? p[1] : l; }
                    else if (bits == 16) { const short* p = (const short*)data + i * ch; l = p[0] / 32768.0f; r = ch > 1 ? p[1] / 32768.0f : l; }
                    else if (bits == 32) { const int* p = (const int*)data + i * ch; l = p[0] / 2147483648.0f; r = ch > 1 ? p[1] / 2147483648.0f : l; }
                }
                ringL[pos] = l; ringR[pos] = r;
                pos = (pos + 1) % N;
            }
            cap->ReleaseBuffer(frames);
            lastPacket = GetTickCount();
        }
        DWORD now = GetTickCount();
        // когда ничего не играет, Windows не присылает звук вовсе — значит, тишина
        if (now - lastPacket > 150) { memset(ringL, 0, sizeof ringL); memset(ringR, 0, sizeof ringR); }
        if (now - lastSend >= 33) {   // 30 раз в секунду
            lastSend = now;
            float out[128];
            spectrum(ringL, pos, rate, out, smL);
            spectrum(ringR, pos, rate, out + 64, smR);
            EnterCriticalSection(&gLock);
            memcpy(gSpec, out, sizeof out);
            LeaveCriticalSection(&gLock);
            PostMessageW(gMsgWnd, WM_AUDIOFRAME, 0, 0);
        }
    }
    if (cl) cl->Stop();
    if (cap) cap->Release();
    if (cl) cl->Release();
    if (dev) dev->Release();
    if (en) en->Release();
    if (wf) CoTaskMemFree(wf);
    CoUninitialize();
    InterlockedExchange(&gRunning, 0);
    return 0;
}

static void start() {
    if (!gInit) { InitializeCriticalSection(&gLock); gInit = true; }
    if (InterlockedExchange(&gRunning, 1)) return;
    gQuit = 0;
    gThread = CreateThread(nullptr, 0, Thread, nullptr, 0, nullptr);
    if (!gThread) InterlockedExchange(&gRunning, 0);
    else alog("audio: capture started");
}
static void stop() {
    if (!gThread) return;
    gQuit = 1;
    WaitForSingleObject(gThread, 1500);
    CloseHandle(gThread);
    gThread = nullptr;
    alog("audio: capture stopped");
}
// спектр для отправки в обои: {"cmd":"audio","a":[…128 чисел…]}
static std::string json() {
    float s[128];
    EnterCriticalSection(&gLock);
    memcpy(s, gSpec, sizeof s);
    LeaveCriticalSection(&gLock);
    std::string o = "{\"cmd\":\"audio\",\"a\":[";
    char b[16];
    for (int i = 0; i < 128; ++i) { snprintf(b, sizeof b, i ? ",%.3f" : "%.3f", s[i]); o += b; }
    return o + "]}";
}

}  // namespace aud
