#!/bin/sh
# сборка: встраиваем we_fx.js в проигрыватель сцен, ресурсы, exe
set -e
cd "$(dirname "$0")"
python3 - <<'PY'
s = open('ui/scene.html', encoding='utf-8').read()
fx = open('ui/we_fx.js', encoding='utf-8').read()
assert '/*@WE_FX@*/' in s
open('build/scene.html', 'w', encoding='utf-8').write(s.replace('/*@WE_FX@*/', fx))
PY
python3 - <<'PY'
s = open('ui/index.html', encoding='utf-8').read()
js = open('ui/petdraw.js', encoding='utf-8').read()
tag = '<script src="petdraw.js"></script>'
assert tag in s
open('build/index.html', 'w', encoding='utf-8').write(s.replace(tag, '<script>\n' + js + '\n</script>'))
PY
cp ui/wwgl.html build/wwgl.html
cp third_party/webwallgl/webwallgl.global.min.js build/
cp third_party/webwallgl/LICENSE build/webwallgl-LICENSE.txt
[ "$1" = "html" ] && exit 0
x86_64-w64-mingw32-windres res.rc -O coff -o build/res.o
x86_64-w64-mingw32-g++ -std=c++17 -O2 -municode -mwindows -static -s -I. sugrob.cpp build/res.o -o build/Podokonnik.exe \
  -ldwmapi -lwinmm -lwinhttp -lcomctl32 -lole32 -luuid -lshell32 -lmfuuid -ldxguid
ls -la build/Podokonnik.exe
