#!/bin/sh
# сборка: встраиваем we_fx.js в проигрыватель сцен, ресурсы, exe
set -e
cd "$(dirname "$0")"
python3 - <<'PY'
s = open('ui/scene.html', encoding='utf-8').read()
fx = open('ui/we_fx.js', encoding='utf-8').read()
assert '/*@WE_FX@*/' in s
open('build/scene.html', 'w', encoding='utf-8').write(s.replace('/*@WE_FX@*/', fx))
PY
python3 - <<'PY'
s = open('ui/index.html', encoding='utf-8').read()
for f in ('petatlas.js', 'petdraw.js', 'cursors.js'):
    tag = '<script src="%s"></script>' % f
    assert tag in s
    s = s.replace(tag, '<script>\n' + open('ui/' + f, encoding='utf-8').read() + '\n</script>')
open('build/index.html', 'w', encoding='utf-8').write(s)
import re
icons = dict(re.findall(r'(<symbol id="([a-z0-9-]+)".*?</symbol>)', s, re.S)[i][::-1] for i in range(len(re.findall(r'<symbol id="([a-z0-9-]+)"', s))))
t = open('ui/tray.src.html', encoding='utf-8').read()
need = sorted(set(re.findall(r'#(i-[a-z0-9-]+)', t)) | {'i-flake', 'i-blossom', 'i-sun', 'i-leaf', 'i-calendar', 'i-play', 'i-pause'})
open('build/tray.html', 'w', encoding='utf-8').write(t.replace('<!--ICONS-->', '\n'.join(icons[n] for n in need if n in icons)))
PY
cp ui/wwgl.html build/wwgl.html
cp ui/cursors-web.js build/cursors-web.js
cp third_party/webwallgl/webwallgl.global.min.js build/
cp third_party/webwallgl/LICENSE build/webwallgl-LICENSE.txt
[ "$1" = "html" ] && exit 0
# каталог курсоров: git clone https://github.com/rohzzn/cursors && python3 tools/cursors.py <папка>
[ -f build/cursors.txt ] || { echo "нет build/cursors.txt — соберите каталог: python3 tools/cursors.py <rohzzn/cursors>"; exit 1; }
x86_64-w64-mingw32-windres res.rc -O coff -o build/res.o
x86_64-w64-mingw32-g++ -std=c++17 -O2 -municode -mwindows -static -s -I. sugrob.cpp build/res.o -o build/Podokonnik.exe \
  -ldwmapi -lwinmm -lwinhttp -lcomctl32 -lole32 -luuid -lshell32 -lmfuuid -ldxguid -lwindowscodecs
ls -la build/Podokonnik.exe
# Студия Подоконника (отдельная программа): редактор собирается в /home/…/studio (npx vite build) → build/studio.html
if [ -f build/studio.html ]; then
  x86_64-w64-mingw32-windres studio.rc -O coff -o build/studio_res.o
  x86_64-w64-mingw32-g++ -std=c++17 -O2 -municode -mwindows -static -s -I. studio.cpp build/studio_res.o -o build/PodokonnikStudio.exe \
    -lole32 -lshell32 -ldwmapi -luuid
  ls -la build/PodokonnikStudio.exe
fi
