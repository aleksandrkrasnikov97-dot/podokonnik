// ================================================================ обои сообщества
// Сервер — Cloudflare Worker (репозиторий сайта, папка community/). Список, жалобы и действия
// модератора окно настроек делает само (fetch), а здесь — то, для чего нужен доступ к файлам:
// «Поделиться» (упаковать обои в zip, сделать превью, загрузить) и «Установить» (скачать и распаковать).
#pragma once
#include <shobjidl.h>
#include <wincodec.h>

#define WM_COMMPROG (WM_APP + 61)
#define WM_COMMDONE (WM_APP + 62)

static const char* kCommApi = "https://podokonnik.aleksandrkrasnikov97.workers.dev";
static const char* kCommSpare = "https://raw.githubusercontent.com/aleksandrkrasnikov97-dot/podokonnik/community/community.json";
static const ULONGLONG kCommMax = 90ull * 1024 * 1024;

static std::string gModKey;            // ключ модератора: файл moderator.key в папке данных
static std::string gCommAuthor;        // имя автора, которое человек вписал в прошлый раз
static volatile LONG gCommBusy = 0;
static std::string gCommWpId, gCommTitle, gCommKind, gCommErr, gCommNewId;
static std::wstring gCommSrc, gCommThumb;

static void commLoad() {
    std::string k;
    if (readFile(baseDataDir() + L"\\moderator.key", k)) {
        while (!k.empty() && (unsigned char)k.back() <= ' ') k.pop_back();
        while (!k.empty() && (unsigned char)k[0] <= ' ') k.erase(0, 1);
        gModKey = k.size() >= 16 && k.size() <= 200 ? k : "";
    }
    std::wstring a;
    if (cfgGetStr(L"CommAuthor", a)) gCommAuthor = U8(a).substr(0, 40);
}

static bool splitUrl(const std::string& url, std::wstring& host, std::wstring& path) {
    if (url.rfind("https://", 0) != 0) return false;
    size_t s = url.find('/', 8);
    host = W16(url.substr(8, s == std::string::npos ? std::string::npos : s - 8));
    path = W16(s == std::string::npos ? "/" : url.substr(s));
    return !host.empty() && host.find(L'@') == std::wstring::npos && host.find(L':') == std::wstring::npos;
}

static HINTERNET commSession() {
    HINTERNET ses = WinHttpOpen(L"Podokonnik", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) ses = WinHttpOpen(L"Podokonnik", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) return nullptr;
    WinHttpSetTimeouts(ses, 15000, 20000, 120000, 120000);
    DWORD proto = 0x00000800 | 0x00002000;
    if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) { proto = 0x00000800; WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto)); }
    return ses;
}

// запрос с телом из памяти или из файла; ответ — в out
static int commHttp(const char* method, const std::string& url, const std::string& ctype, const std::string* body, const std::wstring* file, std::string& out, const std::string& extraHdr = "") {
    std::wstring host, path;
    if (!splitUrl(url, host, path)) return 0;
    int status = 0;
    HINTERNET ses = commSession();
    if (!ses) return 0;
    HINTERNET con = WinHttpConnect(ses, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
    HINTERNET req = con ? WinHttpOpenRequest(con, W16(method).c_str(), path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE) : nullptr;
    HANDLE f = INVALID_HANDLE_VALUE;
    ULONGLONG total = body ? body->size() : 0;
    if (file) {
        f = CreateFileW(file->c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        LARGE_INTEGER li{};
        if (f == INVALID_HANDLE_VALUE || !GetFileSizeEx(f, &li)) { if (req) WinHttpCloseHandle(req); if (con) WinHttpCloseHandle(con); WinHttpCloseHandle(ses); return 0; }
        total = (ULONGLONG)li.QuadPart;
    }
    std::wstring hdr = L"Content-Type: " + W16(ctype) + L"\r\n" + W16(extraHdr);
    bool sent = req && WinHttpSendRequest(req, hdr.c_str(), (DWORD)-1L, WINHTTP_NO_REQUEST_DATA, 0, (DWORD)total, 0);
    if (sent && body && !body->empty()) {
        DWORD wr = 0;
        sent = WinHttpWriteData(req, body->data(), (DWORD)body->size(), &wr) && wr == body->size();
    }
    if (sent && f != INVALID_HANDLE_VALUE) {
        std::vector<char> buf(256 * 1024);
        ULONGLONG done = 0;
        DWORD last = 101;
        for (;;) {
            DWORD got = 0;
            if (!ReadFile(f, buf.data(), (DWORD)buf.size(), &got, nullptr)) { sent = false; break; }
            if (!got) break;
            DWORD wr = 0;
            if (!WinHttpWriteData(req, buf.data(), got, &wr) || wr != got) { sent = false; break; }
            done += got;
            DWORD pct = total ? (DWORD)(done * 100 / total) : 0;
            if (pct != last) { last = pct; PostMessageW(gMsgWnd, WM_COMMPROG, pct, 0); }
        }
    }
    if (f != INVALID_HANDLE_VALUE) CloseHandle(f);
    if (sent && WinHttpReceiveResponse(req, nullptr)) {
        DWORD st = 0, sz = sizeof(st);
        WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &st, &sz, WINHTTP_NO_HEADER_INDEX);
        status = (int)st;
        char tmp[8192];
        DWORD got = 0;
        while (WinHttpReadData(req, tmp, sizeof tmp, &got) && got && out.size() < 1024 * 1024) out.append(tmp, got);
    }
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return status;
}

static std::string b64(const std::string& s) {
    static const char* t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string o;
    o.reserve((s.size() + 2) / 3 * 4);
    size_t i = 0;
    for (; i + 2 < s.size(); i += 3) {
        unsigned v = ((unsigned char)s[i] << 16) | ((unsigned char)s[i + 1] << 8) | (unsigned char)s[i + 2];
        o += t[v >> 18]; o += t[(v >> 12) & 63]; o += t[(v >> 6) & 63]; o += t[v & 63];
    }
    if (i < s.size()) {
        unsigned v = (unsigned char)s[i] << 16;
        if (i + 1 < s.size()) v |= (unsigned char)s[i + 1] << 8;
        o += t[v >> 18]; o += t[(v >> 12) & 63];
        o += i + 1 < s.size() ? t[(v >> 6) & 63] : '=';
        o += '=';
    }
    return o;
}

// превью: миниатюра Проводника (кадр видео, картинка, preview.gif) → JPEG
static bool commEncodeJpeg(IWICImagingFactory* wic, IWICBitmapSource* src, std::string& out) {
    bool ok = false;
    IStream* st = nullptr;
    IWICBitmapEncoder* enc = nullptr;
    IWICBitmapFrameEncode* fr = nullptr;
    IPropertyBag2* bag = nullptr;
    IWICFormatConverter* cv = nullptr;
    if (SUCCEEDED(CreateStreamOnHGlobal(nullptr, TRUE, &st)) &&
        SUCCEEDED(wic->CreateEncoder(GUID_ContainerFormatJpeg, nullptr, &enc)) &&
        SUCCEEDED(enc->Initialize(st, WICBitmapEncoderNoCache)) &&
        SUCCEEDED(enc->CreateNewFrame(&fr, &bag))) {
        PROPBAG2 opt{};
        opt.pstrName = (LPOLESTR)L"ImageQuality";
        VARIANT v; ZeroMemory(&v, sizeof v); v.vt = VT_R4; v.fltVal = 0.82f;
        bag->Write(1, &opt, &v);
        UINT w = 0, h = 0;
        src->GetSize(&w, &h);
        WICPixelFormatGUID pf = GUID_WICPixelFormat24bppBGR;
        if (SUCCEEDED(fr->Initialize(bag)) && SUCCEEDED(fr->SetSize(w, h)) && SUCCEEDED(fr->SetPixelFormat(&pf)) &&
            SUCCEEDED(wic->CreateFormatConverter(&cv)) &&
            SUCCEEDED(cv->Initialize(src, GUID_WICPixelFormat24bppBGR, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom)) &&
            SUCCEEDED(fr->WriteSource(cv, nullptr)) && SUCCEEDED(fr->Commit()) && SUCCEEDED(enc->Commit())) {
            HGLOBAL hg = nullptr;
            if (SUCCEEDED(GetHGlobalFromStream(st, &hg))) {
                STATSTG ss{};
                st->Stat(&ss, STATFLAG_NONAME);
                void* p = GlobalLock(hg);
                if (p) { out.assign((const char*)p, (size_t)ss.cbSize.QuadPart); GlobalUnlock(hg); ok = out.size() > 100; }
            }
        }
    }
    if (cv) cv->Release();
    if (bag) bag->Release();
    if (fr) fr->Release();
    if (enc) enc->Release();
    if (st) st->Release();
    return ok;
}

static bool commThumb(const std::wstring& path, std::string& jpg) {
    bool ok = false;
    IWICImagingFactory* wic = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&wic)))) return false;
    if (!path.empty()) {
        IShellItemImageFactory* sf = nullptr;
        if (SUCCEEDED(SHCreateItemFromParsingName(path.c_str(), nullptr, IID_PPV_ARGS(&sf)))) {
            HBITMAP hb = nullptr;
            SIZE sz{640, 360};
            if (SUCCEEDED(sf->GetImage(sz, SIIGBF_THUMBNAILONLY | SIIGBF_BIGGERSIZEOK, &hb)) ||
                SUCCEEDED(sf->GetImage(sz, SIIGBF_BIGGERSIZEOK, &hb))) {
                IWICBitmap* bm = nullptr;
                if (SUCCEEDED(wic->CreateBitmapFromHBITMAP(hb, nullptr, WICBitmapIgnoreAlpha, &bm))) {
                    UINT w = 0, h = 0;
                    bm->GetSize(&w, &h);
                    IWICBitmapScaler* sc = nullptr;
                    double k = std::min(1.0, 640.0 / std::max(1u, std::max(w, h)));
                    if (k < 1 && SUCCEEDED(wic->CreateBitmapScaler(&sc)) &&
                        SUCCEEDED(sc->Initialize(bm, std::max(1u, (UINT)(w * k)), std::max(1u, (UINT)(h * k)), WICBitmapInterpolationModeFant)))
                        ok = commEncodeJpeg(wic, sc, jpg);
                    else ok = commEncodeJpeg(wic, bm, jpg);
                    if (sc) sc->Release();
                    bm->Release();
                }
                DeleteObject(hb);
            }
            sf->Release();
        }
    }
    if (!ok) {   // миниатюры нет — тёмная заглушка, чтобы карточка не была пустой
        std::vector<BYTE> px(320 * 180 * 3);
        for (int y = 0; y < 180; y++) for (int x = 0; x < 320; x++) {
            BYTE* p = &px[(y * 320 + x) * 3];
            p[0] = (BYTE)(70 + y / 3); p[1] = (BYTE)(40 + y / 4); p[2] = (BYTE)(30 + x / 12);
        }
        IWICBitmap* bm = nullptr;
        if (SUCCEEDED(wic->CreateBitmapFromMemory(320, 180, GUID_WICPixelFormat24bppBGR, 320 * 3, (UINT)px.size(), px.data(), &bm))) {
            ok = commEncodeJpeg(wic, bm, jpg);
            bm->Release();
        }
    }
    wic->Release();
    return ok;
}

static std::wstring fileUrlToPath(const std::string& u) {
    if (u.rfind("file:///", 0) != 0) return L"";
    std::string s;
    for (size_t i = 8; i < u.size(); i++) {
        if (u[i] == '%' && i + 2 < u.size() && isxdigit((unsigned char)u[i + 1]) && isxdigit((unsigned char)u[i + 2])) {
            s += (char)strtol(u.substr(i + 1, 2).c_str(), nullptr, 16); i += 2;
        } else s += u[i] == '/' ? '\\' : u[i];
    }
    return W16(s);
}

static std::string jsonField(const std::string& body, const char* key) {
    js::Value v = js::parse(body);
    return v.str(key);
}

static DWORD WINAPI CommShareThread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    std::string err;
    std::wstring zip = dataPath(L"share.zip");
    DeleteFileW(zip.c_str());
    do {
        // 1. превью
        std::string jpg;
        commThumb(gCommThumb, jpg);
        // 2. архив: папка обоев целиком или один файл
        std::wstring src = gCommSrc;
        while (!src.empty() && (src.back() == L'\\' || src.back() == L'/')) src.pop_back();
        size_t sl = src.find_last_of(L"\\/");
        if (sl == std::wstring::npos) { err = T8("Не нашёл файлы этих обоев", "Couldn't find this wallpaper's files"); break; }
        std::wstring dir = src.substr(0, sl), name = src.substr(sl + 1);
        wchar_t sys[MAX_PATH] = {0};
        GetSystemDirectoryW(sys, MAX_PATH);
        PostMessageW(gMsgWnd, WM_COMMPROG, (WPARAM)-1, 0);
        bool ok = runHidden(L"\"" + std::wstring(sys) + L"\\tar.exe\" -a -c -f \"" + zip + L"\" -C \"" + dir + L"\" \"" + name + L"\"", 300000);
        if (!ok || fileSize(zip) < 22) {
            std::wstring q1 = src, q2 = zip;
            for (std::wstring* q : {&q1, &q2}) { std::wstring r; for (wchar_t c : *q) { if (c == L'\'') r += L"''"; else r += c; } *q = r; }
            DeleteFileW(zip.c_str());
            runHidden(L"powershell.exe -NoProfile -NonInteractive -Command \"Compress-Archive -LiteralPath '" + q1 + L"' -DestinationPath '" + q2 + L"' -Force\"", 300000);
        }
        ULONGLONG zs = fileSize(zip);
        if (zs < 22) { err = T8("Не получилось упаковать обои в архив", "Couldn't pack the wallpaper into an archive"); break; }
        if (zs > kCommMax) { err = T8("Обои слишком большие: ", "The wallpaper is too big: ") + std::to_string((int)(zs >> 20)) + T8(" МБ, можно до 90 МБ", " MB, the limit is 90 MB"); break; }
        // 3. заявка: название, автор, превью
        std::string body = "{\"title\":" + js::esc(gCommTitle) + ",\"author\":" + js::esc(gCommAuthor) + ",\"kind\":" + js::esc(gCommKind) +
                           ",\"size\":" + std::to_string(zs) + ",\"preview\":\"" + b64(jpg) + "\"}";
        std::string resp;
        // ключ модератора — обои создателя Подоконника получают отметку и не попадают под дневной лимит
        int st = commHttp("POST", std::string(kCommApi) + "/api/upload", "application/json", &body, nullptr, resp,
                          gModKey.empty() ? std::string() : "X-Mod-Key: " + gModKey + "\r\n");
        std::string e = jsonField(resp, "error");
        if (st != 200) {
            err = st == 0 ? T8("Сервер обоев не отвечает. Проверь интернет.", "The wallpaper server isn't responding. Check your internet.")
                : e == "banned" ? T8("Загрузка с этого компьютера запрещена модератором", "Uploads from this computer were blocked by a moderator")
                : e == "too_many" ? T8("Сегодня уже выложено 10 обоев — это предел на день", "You've already shared 10 wallpapers today, that's the daily limit")
                : e == "too_big" ? T8("Обои слишком большие, можно до 90 МБ", "The wallpaper is too big, the limit is 90 MB")
                : T8("Сервер не принял обои (", "The server didn't accept the wallpaper (") + (e.empty() ? std::to_string(st) : e) + ")";
            break;
        }
        std::string id = jsonField(resp, "id"), token = jsonField(resp, "token");
        // 4. сам архив
        resp.clear();
        st = commHttp("PUT", std::string(kCommApi) + "/api/upload/" + id + "?t=" + token, "application/zip", nullptr, &zip, resp);
        if (st != 200) { err = st == 0 ? T8("Связь оборвалась во время загрузки", "The connection dropped during the upload") : T8("Сервер не принял архив (", "The server didn't accept the archive (") + std::to_string(st) + ")"; break; }
        gCommNewId = id;
    } while (false);
    DeleteFileW(zip.c_str());
    gCommErr = err;
    alog("community share %s: %s", gCommWpId.c_str(), err.empty() ? ("ok " + gCommNewId).c_str() : err.c_str());
    CoUninitialize();
    PostMessageW(gMsgWnd, WM_COMMDONE, err.empty() ? 1 : 0, 0);
    return 0;
}

static void commShare(const std::string& wpId, const std::string& title, const std::string& author) {
    WpItem* it = findItem(wpId);
    if (!it || it->source == "builtin") { appToast(T8("Эти обои выложить нельзя", "This wallpaper can't be shared")); return; }
    if (InterlockedExchange(&gCommBusy, 1)) { appToast(T8("Уже выкладываю другие обои — подожди немного", "Already sharing another wallpaper — please wait")); return; }
    gCommWpId = wpId;
    gCommTitle = title.empty() ? it->title : title;
    gCommAuthor = author.substr(0, 40);
    cfgSetStr(L"CommAuthor", W16(gCommAuthor));
    gCommKind = it->kind;
    gCommSrc = !it->folder.empty() ? it->folder : it->path;
    gCommThumb = fileUrlToPath(it->thumb);
    if (gCommThumb.empty() || !fileExists(gCommThumb)) gCommThumb = it->kind == "video" || it->kind == "image" ? it->path : L"";
    gCommNewId.clear();
    HANDLE t = CreateThread(nullptr, 0, CommShareThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t); else InterlockedExchange(&gCommBusy, 0);
}

// скачать zip с обоями сообщества и поставить (тот же поток, что у каталога с сайта)
static void catInstallUrl(const std::string& id, const std::string& url) {
    std::wstring host, path;
    if (!splitUrl(url, host, path)) return;
    std::string api = kCommApi;
    std::wstring apiHost = W16(api.substr(8));
    if (_wcsicmp(host.c_str(), apiHost.c_str()) != 0 && _wcsicmp(host.c_str(), L"github.com") != 0) return;
    if (InterlockedExchange(&gCatBusy, 1)) { appToast(T8("Уже скачиваю другие обои — подожди немного", "Already downloading another wallpaper — please wait")); return; }
    gCatId = id;
    gCatHost = host;
    gCatPath = path;
    CreateDirectoryW(dataPath(L"packs").c_str(), nullptr);
    gCatDst = dataPath(L"packs") + L"\\" + W16(id) + L".zip";
    HANDLE t = CreateThread(nullptr, 0, CatThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t); else InterlockedExchange(&gCatBusy, 0);
}

static bool commUi(const std::string& cmd, const js::Value& m) {
    if (cmd == "commShare") { commShare(m.str("id"), m.str("title").substr(0, 80), m.str("author")); return true; }
    if (cmd == "commInstall") {
        std::string id = m.str("id");
        for (char c : id) if (!isalnum((unsigned char)c)) return true;
        if (id.empty() || id.size() > 16) return true;
        catInstallUrl("comm-" + id, m.str("url"));
        return true;
    }
    if (cmd == "newsSeen") { gNewsPending = false; regSet(L"NewsSeen", kNewsId); return true; }
    if (cmd == "modKey") {   // ввести или убрать ключ модератора
        std::string k = m.str("key");
        if (k.empty()) DeleteFileW(dataPath(L"moderator.key").c_str());
        else writeFile(dataPath(L"moderator.key"), k);
        commLoad();
        appPushState();
        return true;
    }
    return false;
}

static void commState(js::Value& v) {
    auto st = [&](const char* k, const std::string& s) { js::Value x; x.type = js::Value::Str; x.s = s; v.o.emplace_back(k, x); };
    st("commApi", kCommApi);
    st("commSpare", kCommSpare);
    st("modKey", gModKey);
    st("commAuthor", gCommAuthor);
    js::Value b; b.type = js::Value::Bool; b.b = gCommBusy != 0; v.o.emplace_back("commBusy", b);
}

static bool commMsg(UINT msg, WPARAM wp) {
    if (msg == WM_COMMPROG) {
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"commProgress\",\"pct\":" + std::to_string((int)wp) + "}");
        return true;
    }
    if (msg == WM_COMMDONE) {
        InterlockedExchange(&gCommBusy, 0);
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"commShared\",\"ok\":" + std::string(wp ? "true" : "false") +
                                ",\"id\":" + js::esc(gCommNewId) + ",\"error\":" + js::esc(gCommErr) + "}");
        appToast(wp ? T8("Обои выложены — их уже видят все", "Wallpaper shared: everyone can see it now") : gCommErr);
        appPushState();
        return true;
    }
    return false;
}
