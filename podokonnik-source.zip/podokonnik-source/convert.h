// Перекодирование видео, которое не умеет встроенный браузер (WMV, AVI, MKV…), в MP4 (H.264)
// средствами самой Windows (Media Foundation). Делается один раз, результат лежит в папке данных.
#pragma once
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>

#define WM_CONVPROGRESS (WM_APP + 21)   // wp: проценты
#define WM_CONVDONE     (WM_APP + 22)   // wp: 1 — готово, 0 — ошибка

static bool videoNeedsConvert(const std::wstring& p) {
    std::string e = lowerExt(p);
    return e == "wmv" || e == "avi" || e == "mkv" || e == "flv" || e == "mpg" || e == "mpeg" || e == "3gp" || e == "asf" || e == "ts" || e == "m2ts";
}

// готовый MP4 для файла: имя по пути, размеру и дате, чтобы не перекодировать заново
static std::wstring convertedPath(const std::wstring& src) {
    WIN32_FILE_ATTRIBUTE_DATA fa{};
    GetFileAttributesExW(src.c_str(), GetFileExInfoStandard, &fa);
    unsigned long long h = 1469598103934665603ULL;
    auto mix = [&](unsigned long long v) { h ^= v; h *= 1099511628211ULL; };
    for (wchar_t c : src) mix((unsigned long long)towlower(c));
    mix(fa.nFileSizeLow); mix(fa.nFileSizeHigh); mix(fa.ftLastWriteTime.dwLowDateTime); mix(fa.ftLastWriteTime.dwHighDateTime);
    wchar_t b[40];
    swprintf(b, 40, L"\\%016llx.mp4", h);
    CreateDirectoryW(dataPath(L"converted").c_str(), nullptr);
    return dataPath(L"converted") + b;
}

template <class T> static void mfRel(T*& p) { if (p) { p->Release(); p = nullptr; } }

// Media Foundation подгружаем только при перекодировании: в Windows N без «Медиа-компонентов» его нет,
// а программа должна запускаться и там
static HRESULT (WINAPI *pMFStartup)(ULONG, DWORD);
static HRESULT (WINAPI *pMFShutdown)();
static HRESULT (WINAPI *pMFCreateAttributes)(IMFAttributes**, UINT32);
static HRESULT (WINAPI *pMFCreateMediaType)(IMFMediaType**);
static HRESULT (WINAPI *pMFCreateSourceReaderFromURL)(LPCWSTR, IMFAttributes*, IMFSourceReader**);
static HRESULT (WINAPI *pMFCreateSinkWriterFromURL)(LPCWSTR, IMFByteStream*, IMFAttributes*, IMFSinkWriter**);
static bool mfLoad() {
    static int st = 0;
    if (st) return st > 0;
    HMODULE a = LoadLibraryW(L"mfplat.dll"), b = LoadLibraryW(L"mfreadwrite.dll");
    if (a && b) {
        pMFStartup = (decltype(pMFStartup))(void*)GetProcAddress(a, "MFStartup");
        pMFShutdown = (decltype(pMFShutdown))(void*)GetProcAddress(a, "MFShutdown");
        pMFCreateAttributes = (decltype(pMFCreateAttributes))(void*)GetProcAddress(a, "MFCreateAttributes");
        pMFCreateMediaType = (decltype(pMFCreateMediaType))(void*)GetProcAddress(a, "MFCreateMediaType");
        pMFCreateSourceReaderFromURL = (decltype(pMFCreateSourceReaderFromURL))(void*)GetProcAddress(b, "MFCreateSourceReaderFromURL");
        pMFCreateSinkWriterFromURL = (decltype(pMFCreateSinkWriterFromURL))(void*)GetProcAddress(b, "MFCreateSinkWriterFromURL");
    }
    st = pMFStartup && pMFShutdown && pMFCreateAttributes && pMFCreateMediaType && pMFCreateSourceReaderFromURL && pMFCreateSinkWriterFromURL ? 1 : -1;
    if (st < 0) alog("convert: Media Foundation not available");
    return st > 0;
}

static bool mfTranscode(const std::wstring& src, const std::wstring& dst) {
    IMFAttributes* ra = nullptr;
    IMFSourceReader* rd = nullptr;
    IMFSinkWriter* wr = nullptr;
    IMFMediaType *inType = nullptr, *outType = nullptr, *cur = nullptr;
    bool ok = false;
    HRESULT hr;
    UINT32 w = 0, h = 0, fn = 30, fd = 1;
    LONGLONG dur = 0;
    DWORD stream = 0;
    std::wstring part = dst + L".part.mp4";
    DeleteFileW(part.c_str());
    do {
        if (FAILED(hr = pMFCreateAttributes(&ra, 2))) break;
        ra->SetUINT32(MF_SOURCE_READER_ENABLE_ADVANCED_VIDEO_PROCESSING, TRUE);
        if (FAILED(hr = pMFCreateSourceReaderFromURL(src.c_str(), ra, &rd))) { alog("convert: cannot open hr=0x%08lx", (unsigned long)hr); break; }
        rd->SetStreamSelection((DWORD)MF_SOURCE_READER_ALL_STREAMS, FALSE);
        rd->SetStreamSelection((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, TRUE);
        // кадры в NV12 (если не выйдет — в RGB32; кодировщик сам переведёт)
        pMFCreateMediaType(&inType);
        inType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
        inType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
        hr = rd->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, inType);
        if (FAILED(hr)) {
            inType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_RGB32);
            if (FAILED(hr = rd->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, inType))) { alog("convert: no decoder hr=0x%08lx", (unsigned long)hr); break; }
        }
        if (FAILED(hr = rd->GetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur))) break;
        MFGetAttributeSize(cur, MF_MT_FRAME_SIZE, &w, &h);
        if (FAILED(MFGetAttributeRatio(cur, MF_MT_FRAME_RATE, &fn, &fd)) || !fn || !fd) { fn = 30; fd = 1; }
        PROPVARIANT pv;
        PropVariantInit(&pv);
        if (SUCCEEDED(rd->GetPresentationAttribute((DWORD)MF_SOURCE_READER_MEDIASOURCE, MF_PD_DURATION, &pv)) && pv.vt == VT_UI8) dur = (LONGLONG)pv.uhVal.QuadPart;
        PropVariantClear(&pv);
        if (!w || !h) break;
        alog("convert: %ux%u %u/%u fps, %.1f s", w, h, fn, fd, dur / 1e7);
        if (FAILED(hr = pMFCreateSinkWriterFromURL(part.c_str(), nullptr, nullptr, &wr))) { alog("convert: no writer hr=0x%08lx", (unsigned long)hr); break; }
        pMFCreateMediaType(&outType);
        outType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
        outType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
        UINT32 br = (UINT32)std::min<double>(40e6, std::max<double>(4e6, (double)w * h * fn / fd * 0.12));
        outType->SetUINT32(MF_MT_AVG_BITRATE, br);
        outType->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
        MFSetAttributeSize(outType, MF_MT_FRAME_SIZE, w & ~1u, h & ~1u);
        MFSetAttributeRatio(outType, MF_MT_FRAME_RATE, fn, fd);
        MFSetAttributeRatio(outType, MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
        if (FAILED(hr = wr->AddStream(outType, &stream))) { alog("convert: no encoder hr=0x%08lx", (unsigned long)hr); break; }
        if (FAILED(hr = wr->SetInputMediaType(stream, cur, nullptr))) { alog("convert: input type hr=0x%08lx", (unsigned long)hr); break; }
        if (FAILED(hr = wr->BeginWriting())) break;
        int lastPct = -1;
        LONGLONG t0 = -1;
        bool err = false;
        for (;;) {
            if (gVidQuit) { err = true; break; }
            DWORD si = 0, flags = 0;
            LONGLONG ts = 0;
            IMFSample* s = nullptr;
            hr = rd->ReadSample((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, &si, &flags, &ts, &s);
            if (FAILED(hr)) { alog("convert: read hr=0x%08lx", (unsigned long)hr); err = true; break; }
            if (flags & MF_SOURCE_READERF_ENDOFSTREAM) { mfRel(s); break; }
            if (s) {
                if (t0 < 0) t0 = ts;
                s->SetSampleTime(ts - t0);
                hr = wr->WriteSample(stream, s);
                s->Release();
                if (FAILED(hr)) { alog("convert: write hr=0x%08lx", (unsigned long)hr); err = true; break; }
                int pct = dur > 0 ? (int)std::min<LONGLONG>(99, (ts - t0) * 100 / dur) : 0;
                if (pct != lastPct) { lastPct = pct; PostMessageW(gMsgWnd, WM_CONVPROGRESS, pct, 0); }
            }
        }
        if (err) break;
        if (FAILED(hr = wr->Finalize())) { alog("convert: finalize hr=0x%08lx", (unsigned long)hr); break; }
        ok = true;
    } while (false);
    mfRel(cur); mfRel(outType); mfRel(inType); mfRel(wr); mfRel(rd); mfRel(ra);
    if (ok) ok = MoveFileExW(part.c_str(), dst.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
    if (!ok) DeleteFileW(part.c_str());
    return ok;
}

static std::wstring gConvSrc, gConvDst;
static std::string gConvId;
static volatile LONG gConvBusy = 0;

static DWORD WINAPI ConvThread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    bool ok = false;
    if (mfLoad() && SUCCEEDED(pMFStartup(MF_VERSION, MFSTARTUP_FULL))) {
        ok = mfTranscode(gConvSrc, gConvDst);
        pMFShutdown();
    }
    alog("convert %s: %s", U8(gConvSrc).c_str(), ok ? "OK" : "FAILED");
    CoUninitialize();
    PostMessageW(gMsgWnd, WM_CONVDONE, ok ? 1 : 0, 0);
    InterlockedExchange(&gConvBusy, 0);
    return 0;
}

// true — перекодирование запущено (обои включатся, когда оно закончится)
static bool convertStart(const std::string& id, const std::wstring& src) {
    if (InterlockedExchange(&gConvBusy, 1)) return false;
    gConvId = id; gConvSrc = src; gConvDst = convertedPath(src);
    HANDLE t = CreateThread(nullptr, 0, ConvThread, nullptr, 0, nullptr);
    if (!t) { InterlockedExchange(&gConvBusy, 0); return false; }
    CloseHandle(t);
    return true;
}
