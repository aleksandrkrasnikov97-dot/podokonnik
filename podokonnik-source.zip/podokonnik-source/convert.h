// Перекодирование видео, которое не умеет встроенный браузер (WMV, AVI, MKV…), в MP4 (H.264)
// средствами самой Windows (Media Foundation). Делается один раз, результат лежит в папке данных.
#pragma once
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>

#define WM_CONVPROGRESS (WM_APP + 21)   // wp: проценты
#define WM_CONVDONE     (WM_APP + 22)   // wp: 1 — готово, 0 — ошибка

static bool videoNeedsConvert(const std::wstring& p) {
    std::string e = lowerExt(p);
    return e == "wmv" || e == "avi" || e == "mkv" || e == "flv" || e == "mpg" || e == "mpeg" || e == "3gp" || e == "asf" || e == "ts" || e == "m2ts";
}

// готовый MP4 для файла: имя по пути, размеру и дате, чтобы не перекодировать заново
static std::wstring convertedPath(const std::wstring& src) {
    WIN32_FILE_ATTRIBUTE_DATA fa{};
    GetFileAttributesExW(src.c_str(), GetFileExInfoStandard, &fa);
    unsigned long long h = 1469598103934665603ULL;
    auto mix = [&](unsigned long long v) { h ^= v; h *= 1099511628211ULL; };
    for (wchar_t c : src) mix((unsigned long long)towlower(c));
    mix(fa.nFileSizeLow); mix(fa.nFileSizeHigh); mix(fa.ftLastWriteTime.dwLowDateTime); mix(fa.ftLastWriteTime.dwHighDateTime);
    wchar_t b[40];
    swprintf(b, 40, L"\\%016llx.mp4", h);
    CreateDirectoryW(dataPath(L"converted").c_str(), nullptr);
    return dataPath(L"converted") + b;
}

template <class T> static void mfRel(T*& p) { if (p) { p->Release(); p = nullptr; } }

// Media Foundation подгружаем только при перекодировании: в Windows N без «Медиа-компонентов» его нет,
// а программа должна запускаться и там
static HRESULT (WINAPI *pMFStartup)(ULONG, DWORD);
static HRESULT (WINAPI *pMFShutdown)();
static HRESULT (WINAPI *pMFCreateAttributes)(IMFAttributes**, UINT32);
static HRESULT (WINAPI *pMFCreateMediaType)(IMFMediaType**);
static HRESULT (WINAPI *pMFCreateSourceReaderFromURL)(LPCWSTR, IMFAttributes*, IMFSourceReader**);
static HRESULT (WINAPI *pMFCreateSinkWriterFromURL)(LPCWSTR, IMFByteStream*, IMFAttributes*, IMFSinkWriter**);
static bool mfLoad() {
    static int st = 0;
    if (st) return st > 0;
    HMODULE a = LoadLibraryW(L"mfplat.dll"), b = LoadLibraryW(L"mfreadwrite.dll");
    if (a && b) {
        pMFStartup = (decltype(pMFStartup))(void*)GetProcAddress(a, "MFStartup");
        pMFShutdown = (decltype(pMFShutdown))(void*)GetProcAddress(a, "MFShutdown");
        pMFCreateAttributes = (decltype(pMFCreateAttributes))(void*)GetProcAddress(a, "MFCreateAttributes");
        pMFCreateMediaType = (decltype(pMFCreateMediaType))(void*)GetProcAddress(a, "MFCreateMediaType");
        pMFCreateSourceReaderFromURL = (decltype(pMFCreateSourceReaderFromURL))(void*)GetProcAddress(b, "MFCreateSourceReaderFromURL");
        pMFCreateSinkWriterFromURL = (decltype(pMFCreateSinkWriterFromURL))(void*)GetProcAddress(b, "MFCreateSinkWriterFromURL");
    }
    st = pMFStartup && pMFShutdown && pMFCreateAttributes && pMFCreateMediaType && pMFCreateSourceReaderFromURL && pMFCreateSinkWriterFromURL ? 1 : -1;
    if (st < 0) alog("convert: Media Foundation not available");
    return st > 0;
}

// Перекодировать видео в MP4 (H.264). maxW/maxH > 0 — заодно уменьшить кадр так, чтобы он всё ещё покрывал экран
// такого размера (4K-обои на экране Full HD); если видео и так не больше экрана, *notNeeded = true и ничего не пишется.
// audio — перенести звуковую дорожку без перекодирования (если не выйдет — неудача, оригинал останется как есть).
static bool mfTranscode(const std::wstring& src, const std::wstring& dst, int maxW = 0, int maxH = 0, bool audio = false,
                        bool progress = true, bool* notNeeded = nullptr) {
    IMFAttributes *ra = nullptr, *wa = nullptr;
    IMFSourceReader* rd = nullptr;
    IMFSinkWriter* wr = nullptr;
    IMFMediaType *inType = nullptr, *outType = nullptr, *cur = nullptr, *native = nullptr, *aType = nullptr;
    bool ok = false, withAudio = false;
    HRESULT hr;
    UINT32 w = 0, h = 0, fn = 30, fd = 1, tw = 0, th = 0;
    LONGLONG dur = 0;
    DWORD stream = 0, astream = 0;
    if (notNeeded) *notNeeded = false;
    std::wstring part = dst + L".part.mp4";
    DeleteFileW(part.c_str());
    do {
        if (FAILED(hr = pMFCreateAttributes(&ra, 2))) break;
        ra->SetUINT32(MF_SOURCE_READER_ENABLE_ADVANCED_VIDEO_PROCESSING, TRUE);
        if (FAILED(hr = pMFCreateSourceReaderFromURL(src.c_str(), ra, &rd))) { alog("convert: cannot open hr=0x%08lx", (unsigned long)hr); break; }
        rd->SetStreamSelection((DWORD)MF_SOURCE_READER_ALL_STREAMS, FALSE);
        rd->SetStreamSelection((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, TRUE);
        if (maxW > 0 && maxH > 0) {
            if (FAILED(rd->GetNativeMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, &native))) break;
            MFGetAttributeSize(native, MF_MT_FRAME_SIZE, &w, &h);
            if (!w || !h) break;
            double k = std::max((double)maxW / w, (double)maxH / h);   // «покрыть экран»
            if (k > 0.8) { if (notNeeded) *notNeeded = true; break; }   // выигрыш меньше 20 % — не стоит
            tw = ((UINT32)(w * k + 1)) & ~1u; th = ((UINT32)(h * k + 1)) & ~1u;
        }
        // кадры в NV12 (если не выйдет — в RGB32; кодировщик сам переведёт)
        pMFCreateMediaType(&inType);
        inType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
        inType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
        if (tw) MFSetAttributeSize(inType, MF_MT_FRAME_SIZE, tw, th);
        hr = rd->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, inType);
        if (FAILED(hr)) {
            inType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_RGB32);
            if (FAILED(hr = rd->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, inType))) { alog("convert: no decoder hr=0x%08lx", (unsigned long)hr); break; }
        }
        if (FAILED(hr = rd->GetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur))) break;
        UINT32 cw = 0, ch = 0;
        MFGetAttributeSize(cur, MF_MT_FRAME_SIZE, &cw, &ch);
        if (tw && (cw != tw || ch != th)) { alog("convert: resize not supported (%ux%u)", cw, ch); break; }
        w = cw; h = ch;
        if (FAILED(MFGetAttributeRatio(cur, MF_MT_FRAME_RATE, &fn, &fd)) || !fn || !fd) { fn = 30; fd = 1; }
        PROPVARIANT pv;
        PropVariantInit(&pv);
        if (SUCCEEDED(rd->GetPresentationAttribute((DWORD)MF_SOURCE_READER_MEDIASOURCE, MF_PD_DURATION, &pv)) && pv.vt == VT_UI8) dur = (LONGLONG)pv.uhVal.QuadPart;
        PropVariantClear(&pv);
        if (!w || !h) break;
        alog("convert: %ux%u %u/%u fps, %.1f s", w, h, fn, fd, dur / 1e7);
        pMFCreateAttributes(&wa, 1);
        if (wa) wa->SetUINT32(MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, TRUE);   // кодировщик видеокарты, если есть
        if (FAILED(hr = pMFCreateSinkWriterFromURL(part.c_str(), nullptr, wa, &wr))) { alog("convert: no writer hr=0x%08lx", (unsigned long)hr); break; }
        pMFCreateMediaType(&outType);
        outType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
        outType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_H264);
        UINT32 br = (UINT32)std::min<double>(40e6, std::max<double>(4e6, (double)w * h * fn / fd * 0.12));
        outType->SetUINT32(MF_MT_AVG_BITRATE, br);
        outType->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive);
        MFSetAttributeSize(outType, MF_MT_FRAME_SIZE, w & ~1u, h & ~1u);
        MFSetAttributeRatio(outType, MF_MT_FRAME_RATE, fn, fd);
        MFSetAttributeRatio(outType, MF_MT_PIXEL_ASPECT_RATIO, 1, 1);
        if (FAILED(hr = wr->AddStream(outType, &stream))) { alog("convert: no encoder hr=0x%08lx", (unsigned long)hr); break; }
        if (FAILED(hr = wr->SetInputMediaType(stream, cur, nullptr))) { alog("convert: input type hr=0x%08lx", (unsigned long)hr); break; }
        if (audio && SUCCEEDED(rd->GetNativeMediaType((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, 0, &aType))) {
            // звук как есть, без перекодирования
            rd->SetStreamSelection((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, TRUE);
            if (FAILED(hr = rd->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, nullptr, aType)) ||
                FAILED(hr = wr->AddStream(aType, &astream)) || FAILED(hr = wr->SetInputMediaType(astream, aType, nullptr))) {
                alog("convert: audio passthrough failed hr=0x%08lx", (unsigned long)hr); break;
            }
            withAudio = true;
        }
        if (FAILED(hr = wr->BeginWriting())) break;
        int lastPct = -1;
        LONGLONG t0 = -1, lastV = 0, lastA = 0;
        bool err = false, eosV = false, eosA = !withAudio;
        while (!eosV || !eosA) {
            if (gVidQuit) { err = true; break; }
            // читаем ту дорожку, что отстала, — чтобы в файле они шли вперемешку
            bool takeAudio = !eosA && (eosV || lastA <= lastV);
            DWORD rs = takeAudio ? (DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM : (DWORD)MF_SOURCE_READER_FIRST_VIDEO_STREAM;
            DWORD si = 0, flags = 0;
            LONGLONG ts = 0;
            IMFSample* s = nullptr;
            hr = rd->ReadSample(rs, 0, &si, &flags, &ts, &s);
            if (FAILED(hr)) { alog("convert: read hr=0x%08lx", (unsigned long)hr); err = true; break; }
            if (flags & MF_SOURCE_READERF_ENDOFSTREAM) { mfRel(s); (takeAudio ? eosA : eosV) = true; continue; }
            if (!s) continue;
            if (withAudio) t0 = 0;                    // со звуком время не сдвигаем — дорожки остаются согласованными
            else if (t0 < 0) t0 = ts;
            s->SetSampleTime(ts - t0);
            (takeAudio ? lastA : lastV) = ts;
            hr = wr->WriteSample(takeAudio ? astream : stream, s);
            s->Release();
            if (FAILED(hr)) { alog("convert: write hr=0x%08lx", (unsigned long)hr); err = true; break; }
            if (!takeAudio && progress) {
                int pct = dur > 0 ? (int)std::min<LONGLONG>(99, (ts - std::max<LONGLONG>(t0, 0)) * 100 / dur) : 0;
                if (pct != lastPct) { lastPct = pct; PostMessageW(gMsgWnd, WM_CONVPROGRESS, pct, 0); }
            }
        }
        if (err) break;
        if (FAILED(hr = wr->Finalize())) { alog("convert: finalize hr=0x%08lx", (unsigned long)hr); break; }
        ok = true;
    } while (false);
    mfRel(aType); mfRel(native); mfRel(cur); mfRel(outType); mfRel(inType); mfRel(wr); mfRel(wa); mfRel(rd); mfRel(ra);
    if (ok) ok = MoveFileExW(part.c_str(), dst.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
    if (!ok) DeleteFileW(part.c_str());
    return ok;
}

static std::wstring gConvSrc, gConvDst;
static std::string gConvId;
static volatile LONG gConvBusy = 0;

static DWORD WINAPI ConvThread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    bool ok = false;
    if (mfLoad() && SUCCEEDED(pMFStartup(MF_VERSION, MFSTARTUP_FULL))) {
        ok = mfTranscode(gConvSrc, gConvDst);
        pMFShutdown();
    }
    alog("convert %s: %s", U8(gConvSrc).c_str(), ok ? "OK" : "FAILED");
    CoUninitialize();
    PostMessageW(gMsgWnd, WM_CONVDONE, ok ? 1 : 0, 0);
    InterlockedExchange(&gConvBusy, 0);
    return 0;
}

// true — перекодирование запущено (обои включатся, когда оно закончится)
static bool convertStart(const std::string& id, const std::wstring& src) {
    if (InterlockedExchange(&gConvBusy, 1)) return false;
    gConvId = id; gConvSrc = src; gConvDst = convertedPath(src);
    HANDLE t = CreateThread(nullptr, 0, ConvThread, nullptr, 0, nullptr);
    if (!t) { InterlockedExchange(&gConvBusy, 0); return false; }
    CloseHandle(t);
    return true;
}

// ================================================================ видео под размер экрана
// 4K-видео на экране Full HD: декодер и память тратятся на пиксели, которых не видно. Один раз в фоне делаем копию
// размером с экран (видео-обои — в converted\, видео внутри сцены — прямо в распакованной папке пакета)
// и перезапускаем обои уже с ней. Если уменьшать нечего или не вышло — помечаем и больше не трогаем.
#define WM_SHRINKDONE (WM_APP + 25)   // wp: 1 — готова уменьшенная копия
struct ShrinkJob { std::wstring src, dst; int w, h; bool folder; bool image = false; };
static std::vector<ShrinkJob> gShrinkQ;
static std::vector<std::wstring> gShrinkSeen;   // уже в очереди или сделано за этот запуск
static CRITICAL_SECTION gShrinkCs;
static volatile LONG gShrinkBusy = 0;

// самый большой монитор — копия должна покрывать любой экран, где могут стоять обои
static void screenMax(int& W, int& H) {
    W = H = 0;
    for (auto& m : gMons) { W = std::max(W, (int)(m.right - m.left)); H = std::max(H, (int)(m.bottom - m.top)); }
    if (W <= 0 || H <= 0) { W = GetSystemMetrics(SM_CXSCREEN); H = GetSystemMetrics(SM_CYSCREEN); }
}
static void touchFile(const std::wstring& p) { FILE* f = _wfopen(p.c_str(), L"wb"); if (f) fclose(f); }

// видео внутри .tex (у Wallpaper Engine это обычный MP4 после заголовка) — уменьшить на месте
static bool shrinkTex(const std::wstring& tex, int W, int H) {
    {   // сначала заголовок: картинки не трогаем
        char hd[512] = {};
        FILE* f = _wfopen(tex.c_str(), L"rb");
        if (!f) return false;
        size_t n = fread(hd, 1, sizeof hd, f);
        fclose(f);
        if (std::string(hd, n).find("ftyp") == std::string::npos) return false;
    }
    std::string b;
    if (!readFile(tex, b) || b.size() < 4u * 1024 * 1024) return false;
    size_t at = b.find("ftyp");
    if (at == std::string::npos || at < 8 || at > 512) return false;
    size_t start = at - 4;
    std::wstring tmpIn = tex + L".in.mp4", tmpOut = tex + L".out.mp4";
    FILE* f = _wfopen(tmpIn.c_str(), L"wb");
    if (!f) return false;
    bool wr = fwrite(b.data() + start, 1, b.size() - start, f) == b.size() - start;
    fclose(f);
    bool notNeeded = false, ok = wr && mfTranscode(tmpIn, tmpOut, W, H, false, false, &notNeeded);
    DeleteFileW(tmpIn.c_str());
    std::string mp4;
    if (ok && readFile(tmpOut, mp4) && mp4.size() < (b.size() - start) * 9 / 10) {
        std::string out = b.substr(0, start);
        int32_t oldLen = 0;
        memcpy(&oldLen, out.data() + start - 4, 4);
        if ((size_t)oldLen == b.size() - start) { int32_t n = (int32_t)mp4.size(); memcpy(&out[start - 4], &n, 4); }
        out += mp4;
        std::wstring tmpTex = tex + L".new";
        FILE* o = _wfopen(tmpTex.c_str(), L"wb");
        ok = o && fwrite(out.data(), 1, out.size(), o) == out.size();
        if (o) fclose(o);
        ok = ok && MoveFileExW(tmpTex.c_str(), tex.c_str(), MOVEFILE_REPLACE_EXISTING);
        if (!ok) DeleteFileW(tmpTex.c_str());
        if (ok) alog("shrink: %s %u -> %u MB", U8(tex).c_str(), (unsigned)(b.size() >> 20), (unsigned)(out.size() >> 20));
    } else ok = false;
    DeleteFileW(tmpOut.c_str());
    return ok;
}
// картинка-обои больше экрана — уменьшить (WIC), формат тот же: JPEG остаётся JPEG, PNG — PNG
static bool shrinkImage(const std::wstring& src, const std::wstring& dst, int W, int H, bool* notNeeded) {
    *notNeeded = false;
    IWICImagingFactory* f = nullptr; IWICBitmapDecoder* dec = nullptr; IWICBitmapFrameDecode* fr = nullptr;
    IWICBitmapScaler* sc = nullptr; IWICStream* st = nullptr; IWICBitmapEncoder* enc = nullptr;
    IWICBitmapFrameEncode* fe = nullptr; IPropertyBag2* bag = nullptr;
    bool ok = false, png = lowerExt(src) == "png";
    std::wstring part = dst + L".part";
    do {
        if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f)))) break;
        if (FAILED(f->CreateDecoderFromFilename(src.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &dec))) break;
        UINT n = 0;
        if (FAILED(dec->GetFrameCount(&n)) || n != 1) break;   // анимация — не трогаем
        if (FAILED(dec->GetFrame(0, &fr))) break;
        UINT w = 0, h = 0;
        fr->GetSize(&w, &h);
        if (!w || !h) break;
        double k = std::max((double)W / w, (double)H / h);
        if (k > 0.8) { *notNeeded = true; break; }
        UINT tw = std::max(1u, (UINT)(w * k + 0.5)), th = std::max(1u, (UINT)(h * k + 0.5));
        if (FAILED(f->CreateBitmapScaler(&sc)) || FAILED(sc->Initialize(fr, tw, th, (WICBitmapInterpolationMode)4 /* HighQualityCubic (Windows 10) */))) break;
        if (FAILED(f->CreateStream(&st)) || FAILED(st->InitializeFromFilename(part.c_str(), GENERIC_WRITE))) break;
        if (FAILED(f->CreateEncoder(png ? GUID_ContainerFormatPng : GUID_ContainerFormatJpeg, nullptr, &enc))) break;
        if (FAILED(enc->Initialize(st, WICBitmapEncoderNoCache)) || FAILED(enc->CreateNewFrame(&fe, &bag))) break;
        if (!png && bag) {
            PROPBAG2 opt{}; opt.pstrName = (LPOLESTR)L"ImageQuality";
            VARIANT v{}; v.vt = VT_R4; v.fltVal = 0.93f;
            bag->Write(1, &opt, &v);
        }
        if (FAILED(fe->Initialize(bag)) || FAILED(fe->SetSize(tw, th))) break;
        WICPixelFormatGUID pf = png ? GUID_WICPixelFormat32bppBGRA : GUID_WICPixelFormat24bppBGR;
        fe->SetPixelFormat(&pf);
        IWICFormatConverter* cv = nullptr;
        bool wrote = false;
        if (SUCCEEDED(f->CreateFormatConverter(&cv)) &&
            SUCCEEDED(cv->Initialize(sc, pf, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom)))
            wrote = SUCCEEDED(fe->WriteSource(cv, nullptr));
        if (cv) cv->Release();
        if (!wrote || FAILED(fe->Commit()) || FAILED(enc->Commit())) break;
        ok = true;
    } while (false);
    for (IUnknown* u : std::initializer_list<IUnknown*>{bag, fe, enc, st, sc, fr, dec, f}) if (u) u->Release();
    if (ok) ok = MoveFileExW(part.c_str(), dst.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
    if (!ok) DeleteFileW(part.c_str());
    return ok;
}
static void findTex(const std::wstring& dir, std::vector<std::wstring>& out) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (fd.cFileName[0] == L'.') continue;
        std::wstring p = dir + L"\\" + fd.cFileName;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) findTex(p, out);
        else if (lowerExt(p) == "tex" && fd.nFileSizeLow + ((unsigned long long)fd.nFileSizeHigh << 32) > 4u * 1024 * 1024) out.push_back(p);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}
static DWORD WINAPI ShrinkThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_LOWEST);   // фоновая работа: не мешать играм и окнам
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    bool mf = mfLoad() && SUCCEEDED(pMFStartup(MF_VERSION, MFSTARTUP_FULL));
    bool any = true;   // картинкам Media Foundation не нужен
    for (;;) {
        ShrinkJob j;
        EnterCriticalSection(&gShrinkCs);
        bool have = !gShrinkQ.empty() && any && !gVidQuit;
        if (have && !mf && !gShrinkQ.front().image) { gShrinkQ.erase(gShrinkQ.begin()); LeaveCriticalSection(&gShrinkCs); continue; }
        if (have) { j = gShrinkQ.front(); gShrinkQ.erase(gShrinkQ.begin()); }
        else { gShrinkQ.clear(); InterlockedExchange(&gShrinkBusy, 0); }
        LeaveCriticalSection(&gShrinkCs);
        if (!have) break;
        bool ok = false;
        wchar_t tag[40];
        swprintf(tag, 40, L"%dx%d", j.w, j.h);
        if (j.folder) {   // распакованная сцена: все видео-текстуры
            std::vector<std::wstring> tex;
            findTex(j.src, tex);
            for (auto& t : tex) if (!gVidQuit && shrinkTex(t, j.w, j.h)) ok = true;
            if (!gVidQuit) touchFile(j.src + L"\\.small-" + tag);
        } else {
            bool notNeeded = false;
            ok = j.image ? shrinkImage(j.src, j.dst, j.w, j.h, &notNeeded) : mfTranscode(j.src, j.dst, j.w, j.h, true, false, &notNeeded);
            if (!ok && !gVidQuit) touchFile(j.dst + L".skip");
            alog("shrink %s: %s", U8(j.src).c_str(), ok ? "done" : notNeeded ? "not needed" : "failed, keep original");
        }
        if (ok) PostMessageW(gMsgWnd, WM_SHRINKDONE, 1, 0);
    }
    if (mf) pMFShutdown();
    CoUninitialize();
    return 0;
}
static void shrinkQueue(const ShrinkJob& j) {
    static bool init = false;
    if (!init) { InitializeCriticalSection(&gShrinkCs); init = true; }
    std::wstring key = j.src + L"|" + j.dst;
    if (std::find(gShrinkSeen.begin(), gShrinkSeen.end(), key) != gShrinkSeen.end()) return;
    gShrinkSeen.push_back(key);
    EnterCriticalSection(&gShrinkCs);
    gShrinkQ.push_back(j);
    bool start = !InterlockedExchange(&gShrinkBusy, 1);
    LeaveCriticalSection(&gShrinkCs);
    if (start) {
        HANDLE t = CreateThread(nullptr, 0, ShrinkThread, nullptr, 0, nullptr);
        if (t) CloseHandle(t); else InterlockedExchange(&gShrinkBusy, 0);
    }
}
// видео-обои: готовая копия под экран или пусто (тогда она ставится в очередь, а пока играет оригинал)
static std::wstring videoForScreen(const std::wstring& path) {
    int W, H;
    screenMax(W, H);
    std::wstring base = convertedPath(path);   // ...\converted\<hash>.mp4
    wchar_t tag[40];
    swprintf(tag, 40, L"_%dx%d.mp4", W, H);
    std::wstring dst = base.substr(0, base.size() - 4) + tag;
    if (fileExists(dst)) return dst;
    if (!fileExists(dst + L".skip")) shrinkQueue({path, dst, W, H, false});
    return L"";
}

// картинка-обои: готовая уменьшенная копия или пусто (тогда — в очередь)
static std::wstring imageForScreen(const std::wstring& path) {
    std::string e = lowerExt(path);
    if (e != "jpg" && e != "jpeg" && e != "png" && e != "bmp") return L"";
    int W, H;
    screenMax(W, H);
    std::wstring base = convertedPath(path);
    wchar_t tag[48];
    swprintf(tag, 48, L"_%dx%d.%ls", W, H, e == "png" ? L"png" : L"jpg");
    std::wstring dst = base.substr(0, base.size() - 4) + tag;
    if (fileExists(dst)) return dst;
    if (!fileExists(dst + L".skip")) { ShrinkJob j{path, dst, W, H, false}; j.image = true; shrinkQueue(j); }
    return L"";
}
