// ================================================================ вылеты: причина — в crash.txt, повторные вылеты — безопасный режим
// Если программа падает, в папку данных пишется строка с адресом (модуль+смещение) и crash.dmp — по ним ошибку
// можно найти. Два вылета подряд вскоре после запуска — следующий запуск без своей темы и живых обоев.
// Отдельно — сторож Проводника: если его процесса нет больше 10 секунд (чёрный экран без панели задач), запускаем.
#include <exception>
#include <csignal>

static volatile LONG gCrashing = 0;
static ULONGLONG gStartTick = 0;

static void crashWrite(const char* what, void* addr, DWORD code, EXCEPTION_POINTERS* ep) {
    if (InterlockedExchange(&gCrashing, 1)) return;
    char mod[MAX_PATH] = "?";
    unsigned long long off = 0;
    HMODULE hm = nullptr;
    if (addr && GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)addr, &hm) && hm) {
        GetModuleFileNameA(hm, mod, MAX_PATH);
        off = (unsigned long long)((ULONG_PTR)addr - (ULONG_PTR)hm);
    }
    const char* base = strrchr(mod, '\\');
    base = base ? base + 1 : mod;
    ULONGLONG up = gStartTick ? (GetTickCount64() - gStartTick) / 1000 : 0;
    DWORD seq = regGet(L"CrashSeq", 0);
    regSet(L"CrashSeq", up < 180 ? seq + 1 : 1);
    regSet(L"CrashNew", 1);
    char line[640];
    snprintf(line, sizeof line, "%s 0x%08lx at %s+0x%llx, thread %lu, %llu s after start, version %s, Windows %lu",
             what, (unsigned long)code, base, off, GetCurrentThreadId(), (unsigned long long)up, kAppVersion, windowsBuild());
    alog("CRASH %s", line);
    std::wstring dir = baseDataDir();
    HANDLE f = CreateFileW((dir + L"\\crash.txt").c_str(), FILE_APPEND_DATA, FILE_SHARE_READ, nullptr, OPEN_ALWAYS, 0, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
        SYSTEMTIME st; GetLocalTime(&st);
        char b[760];
        int n = snprintf(b, sizeof b, "%04d-%02d-%02d %02d:%02d:%02d %s\r\n", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, line);
        DWORD w; WriteFile(f, b, (DWORD)n, &w, nullptr);
        CloseHandle(f);
    }
    // снимок памяти для разбора (dbghelp есть в любой Windows)
    typedef BOOL (WINAPI *MdwFn)(HANDLE, DWORD, HANDLE, int, void*, void*, void*);
    if (HMODULE dh = LoadLibraryW(L"dbghelp.dll"))
        if (auto mdw = (MdwFn)(void*)GetProcAddress(dh, "MiniDumpWriteDump")) {
            HANDLE df = CreateFileW((dir + L"\\crash.dmp").c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
            if (df != INVALID_HANDLE_VALUE) {
                struct { DWORD tid; EXCEPTION_POINTERS* ep; BOOL client; } mei{GetCurrentThreadId(), ep, FALSE};
                mdw(GetCurrentProcess(), GetCurrentProcessId(), df, 0x1040 /* ThreadInfo | IndirectlyReferencedMemory */, ep ? &mei : nullptr, nullptr, nullptr);
                CloseHandle(df);
            }
        }
}
static LONG WINAPI crashFilter(EXCEPTION_POINTERS* ep) {
    crashWrite("exception", ep && ep->ExceptionRecord ? ep->ExceptionRecord->ExceptionAddress : nullptr,
               ep && ep->ExceptionRecord ? ep->ExceptionRecord->ExceptionCode : 0, ep);
    return EXCEPTION_CONTINUE_SEARCH;
}
static void crashTerminate() {
    crashWrite("terminate", __builtin_return_address(0), 0xE0000001, nullptr);
    _exit(3);
}
static void crashAbort(int) {
    crashWrite("abort", __builtin_return_address(0), 0xE0000002, nullptr);
    _exit(3);
}

// при запуске: ловушки и решение про безопасный режим (до восстановления обоев и темы)
static void crashInit() {
    gStartTick = GetTickCount64();
    if (gDataDir.empty()) gDataDir = baseDataDir();
    SetUnhandledExceptionFilter(crashFilter);
    std::set_terminate(crashTerminate);
    signal(SIGABRT, crashAbort);
    DWORD seq = regGet(L"CrashSeq", 0);
    gCrashPending = regGet(L"CrashNew", 0) != 0;
    if (gCrashPending) {   // последняя строка crash.txt — показать в окне
        std::string t;
        if (readFile(baseDataDir() + L"\\crash.txt", t)) {
            while (!t.empty() && (t.back() == '\n' || t.back() == '\r')) t.pop_back();
            size_t nl = t.find_last_of('\n');
            gCrashLine = nl == std::string::npos ? t : t.substr(nl + 1);
        }
    }
    if (seq >= 2) {
        gSafeMode = true;
        alog("safe mode: %lu crashes in a row soon after start — own theme and live wallpaper are off", seq);
        cfgSetStr(L"Wallpaper", L"");
        cfgSetStr(L"WallpaperMon", L"");
    }
    SetTimer(gMsgWnd, 91, 180 * 1000, nullptr);   // 3 минуты без вылета — счётчик обнуляем
    SetTimer(gMsgWnd, 92, 2000, nullptr);         // сторож Проводника
}
static void crashTimer(WPARAM id) {
    if (id == 91) { KillTimer(gMsgWnd, 91); regSet(L"CrashSeq", 0); return; }
    if (id == 92) {
        static ULONGLONG noShell = 0;
        ULONGLONG now = GetTickCount64();
        if (FindWindowW(L"Shell_TrayWnd", nullptr)) { noShell = 0; return; }
        if (!noShell) { noShell = now; return; }
        if (now - noShell > 10000 && !explorerRunning()) {
            alog("explorer is not running for 10 s — starting it");
            wchar_t win[MAX_PATH]; GetWindowsDirectoryW(win, MAX_PATH);
            ShellExecuteW(nullptr, L"open", (std::wstring(win) + L"\\explorer.exe").c_str(), nullptr, nullptr, SW_SHOWNORMAL);
            noShell = now;
        }
    }
}
