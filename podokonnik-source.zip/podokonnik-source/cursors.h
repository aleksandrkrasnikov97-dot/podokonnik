// Наборы курсоров мыши из проекта Cursors (https://github.com/rohzzn/cursors): 60 открытых наборов,
// у каждого свой автор и лицензия. В программе только каталог; выбранный набор скачиваем в папку
// данных и прописываем в HKCU\Control Panel\Cursors — как делает «Параметры мыши» Windows.
// Прежние курсоры пользователя сохраняем и возвращаем, когда выбирают «Стандартный».
#pragma once

static const wchar_t* kCurRoles[] = {
    L"Arrow", L"Help", L"AppStarting", L"Wait", L"Crosshair", L"IBeam", L"NWPen", L"No",
    L"SizeNS", L"SizeWE", L"SizeNWSE", L"SizeNESW", L"SizeAll", L"UpArrow", L"Hand", L"Pin", L"Person",
};
static const wchar_t* kCurRegKey = L"Control Panel\\Cursors";
static const char* kSeasonPacks[4] = {"bibata-modern-ice", "bibata-pink", "bibata-rainbow-modern", "bibata-modern-amber"};   // зима, весна, лето, осень

// каталог наборов (ресурс IDR_CURSORS, собран tools/cursors.py из github.com/rohzzn/cursors)
struct CurFileInfo { std::wstring role, file; DWORD size; };
struct CurPackInfo { std::string id, name, author, license, url; std::vector<CurFileInfo> files; };
static std::string gCurSha;
static std::vector<CurPackInfo> gCurPacks;
static volatile LONG gCurThreadBusy = 0;

static void cursorCatalog() {
    if (!gCurPacks.empty()) return;
    std::string t = resourceText(IDR_CURSORS);
    size_t pos = 0;
    while (pos < t.size()) {
        size_t e = t.find('\n', pos); if (e == std::string::npos) e = t.size();
        std::string line = t.substr(pos, e - pos); pos = e + 1;
        std::vector<std::string> f;
        for (size_t a = 0;;) { size_t b = line.find('\t', a); f.push_back(line.substr(a, b == std::string::npos ? std::string::npos : b - a)); if (b == std::string::npos) break; a = b + 1; }
        if (f[0] == "sha" && f.size() >= 2) gCurSha = f[1];
        else if (f[0] == "pack" && f.size() >= 6) gCurPacks.push_back({f[1], f[2], f[3], f[4], f[5], {}});
        else if (f[0] == "file" && f.size() >= 4 && !gCurPacks.empty()) gCurPacks.back().files.push_back({W16(f[1]), W16(f[2]), (DWORD)strtoul(f[3].c_str(), nullptr, 10)});
    }
}
static const CurPackInfo* cursorPack(const std::string& id) {
    cursorCatalog();
    for (auto& p : gCurPacks) if (p.id == id) return &p;
    return nullptr;
}
static bool isWebPack(const std::string& id) { return id.rfind("web:", 0) == 0; }
static bool webSlugOk(const std::string& s);
static bool cursorPackExists(const std::string& id) {
    if (isWebPack(id)) return webSlugOk(id.substr(4));
    return !id.empty() && cursorPack(id) != nullptr;
}
static std::wstring cursorDir(const std::string& id) {
    return dataPath(L"cursors") + L"\\" + W16(isWebPack(id) ? "web-" + id.substr(4) : id);
}
#include "cursorsweb.h"
static bool cursorReady(const std::string& id) {
    if (isWebPack(id)) { std::map<std::wstring, std::wstring> r; std::string n; return webManifest(id, r, n); }
    const CurPackInfo* p = cursorPack(id);
    if (!p || p->files.empty()) return false;
    for (auto& f : p->files) if (fileSize(cursorDir(p->id) + L"\\" + f.file) != f.size) return false;
    return true;
}

// скачать набор в фоне (с raw.githubusercontent.com, по закреплённому коммиту каталога)
static DWORD WINAPI CursorDownloadThread(LPVOID arg) {
    std::string* idp = (std::string*)arg;
    std::string id = *idp; delete idp;
    if (isWebPack(id)) {
        size_t nl = id.find('\n');
        std::string nm = nl == std::string::npos ? "" : id.substr(nl + 1);
        if (nl != std::string::npos) id.resize(nl);
        if (nm.empty()) nm = id.substr(4);
        bool ok = false;
        ok = webDownloadPack(id, nm);
        PostMessageW(gMsgWnd, WM_APP + 60, ok ? 1 : 0, 0);
        InterlockedExchange(&gCurThreadBusy, 0);
        return 0;
    }
    const CurPackInfo* p = cursorPack(id);
    bool ok = p != nullptr;
    if (ok) {
        CreateDirectoryW(dataPath(L"cursors").c_str(), nullptr);
        CreateDirectoryW(cursorDir(id).c_str(), nullptr);
        for (auto& f : p->files) {
            std::wstring dst = cursorDir(id) + L"\\" + f.file;
            if (fileSize(dst) == f.size) continue;
            std::string data;
            std::wstring rel = W16(gCurSha) + L"/packs/" + W16(id) + L"/" + f.file;
            // несколько зеркал: raw.githubusercontent.com местами заблокирован — тогда jsDelivr или сам github.com
            static int good = 0;   // какое зеркало сработало последним — с него и начинаем
            struct Mirror { const wchar_t* host; std::wstring path; } mirrors[3] = {
                {L"raw.githubusercontent.com", L"/rohzzn/cursors/" + rel},
                {L"cdn.jsdelivr.net", L"/gh/rohzzn/cursors@" + rel},
                {L"github.com", L"/rohzzn/cursors/raw/" + rel},
            };
            bool got = false;
            for (int t = 0; t < 4 && !got; ++t) {
                int m = (good + t) % 3;
                got = httpsGet(mirrors[m].host, mirrors[m].path, data, 8u << 20) && data.size() == f.size;
                if (got) good = m;
                else alog("cursor get %ls%ls: status %lu, err %lu, %zu bytes", mirrors[m].host, mirrors[m].path.c_str(), gHttpLastStatus, gHttpLastErr, data.size());
            }
            if (!got || !writeFile(dst, data)) { ok = false; alog("cursor download failed: %s/%s", id.c_str(), U8(f.file).c_str()); break; }
        }
        if (ok) {
            std::string about = "Набор курсоров «" + p->name + "»\r\nАвтор: " + p->author + "\r\nЛицензия: " + p->license +
                "\r\nИсходник: " + p->url + "\r\n\r\nВзят из проекта Cursors (Rohan, MIT): https://github.com/rohzzn/cursors\r\n"
                "Тексты лицензий: https://github.com/rohzzn/cursors/tree/main/packs/LICENSES\r\n";
            writeFile(cursorDir(id) + L"\\Авторы и лицензия.txt", about);
        }
    }
    PostMessageW(gMsgWnd, WM_APP + 60, ok ? 1 : 0, 0);
    InterlockedExchange(&gCurThreadBusy, 0);
    return 0;
}
static void cursorDownload(const std::string& id) {
    if (InterlockedCompareExchange(&gCurThreadBusy, 1, 0) != 0) return;   // уже качаем — после него проверим ещё раз
    gCurLoading = id;
    std::string arg = id;
    if (isWebPack(id)) { auto it = gCurWebNames.find(id); arg += "\n" + (it != gCurWebNames.end() ? it->second : std::string()); }
    HANDLE h = CreateThread(nullptr, 0, CursorDownloadThread, new std::string(arg), 0, nullptr);
    if (h) CloseHandle(h); else { gCurLoading.clear(); InterlockedExchange(&gCurThreadBusy, 0); }
}

static bool curRegGet(HKEY k, const wchar_t* name, std::wstring& out) {
    DWORD type = 0, sz = 0;
    if (RegQueryValueExW(k, name, nullptr, &type, nullptr, &sz) != ERROR_SUCCESS || (type != REG_SZ && type != REG_EXPAND_SZ)) return false;
    std::vector<wchar_t> b(sz / 2 + 2, 0);
    if (RegQueryValueExW(k, name, nullptr, &type, (BYTE*)b.data(), &sz) != ERROR_SUCCESS) return false;
    out = b.data();
    return true;
}
static void curRegSet(HKEY k, const wchar_t* name, const std::wstring& v) {
    RegSetValueExW(k, name, 0, REG_EXPAND_SZ, (const BYTE*)v.c_str(), (DWORD)((v.size() + 1) * sizeof(wchar_t)));
}
static void cursorReload() {
    // Windows перечитывает курсоры из реестра; рассылку WM_SETTINGCHANGE делаем в фоне — она бывает медленной
    SystemParametersInfoW(SPI_SETCURSORS, 0, nullptr, 0);
    CreateThread(nullptr, 0, [](LPVOID) -> DWORD {
        DWORD_PTR r;
        SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, SPI_SETCURSORS, (LPARAM)L"Control Panel\\Cursors", SMTO_ABORTIFHUNG, 2000, &r);
        return 0;
    }, nullptr, 0, nullptr);
}

// запоминаем курсоры пользователя один раз — до первой замены
static void cursorBackup(HKEY k) {
    std::wstring have;
    if (cfgGetStr(L"CursorBackup", have) && !have.empty()) return;
    std::wstring b = L"v1";
    std::wstring v;
    b += L"\n=" + (curRegGet(k, L"", v) ? v : L"");
    for (auto r : kCurRoles) { v.clear(); b += L"\n" + std::wstring(r) + L"=" + (curRegGet(k, r, v) ? v : L""); }
    cfgSetStr(L"CursorBackup", b);
}

static bool cursorApply(const std::string& id) {
    if (!cursorReady(id)) return false;
    const CurPackInfo* p = cursorPack(id);
    std::map<std::wstring, std::wstring> webRoles;
    std::string webName;
    if (isWebPack(id)) webManifest(id, webRoles, webName);
    HKEY k = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kCurRegKey, 0, nullptr, 0, KEY_READ | KEY_SET_VALUE, nullptr, &k, nullptr) != ERROR_SUCCESS) return false;
    cursorBackup(k);
    std::wstring dir = cursorDir(id);
    for (auto r : kCurRoles) {
        std::wstring v;   // нет такого курсора в наборе — пусто, Windows возьмёт стандартный
        if (p) { for (auto& f : p->files) if (f.role == r) { v = dir + L"\\" + f.file; break; } }
        else { auto it = webRoles.find(r); if (it != webRoles.end()) v = dir + L"\\" + it->second; }
        curRegSet(k, r, v);
    }
    curRegSet(k, L"", L"Подоконник — " + W16(p ? p->name : webName));
    RegCloseKey(k);
    cursorReload();
    gCursorApplied = id;
    cfgSetStr(L"CursorApplied", W16(id));
    alog("cursor pack applied: %s", id.c_str());
    return true;
}

// вернуть курсоры, которые были до Подоконника
static void cursorRestore() {
    std::wstring b;
    bool had = cfgGetStr(L"CursorBackup", b) && b.rfind(L"v1", 0) == 0;
    std::wstring applied;
    bool ours = cfgGetStr(L"CursorApplied", applied) && !applied.empty();
    if (!had && !ours) return;
    HKEY k = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kCurRegKey, 0, KEY_READ | KEY_SET_VALUE, &k) == ERROR_SUCCESS) {
        // восстанавливаем только то, что всё ещё наше — если пользователь сам сменил курсоры, не трогаем
        std::wstring arrow;
        bool stillOurs = curRegGet(k, L"Arrow", arrow) && !gDataDir.empty() && arrow.find(dataPath(L"cursors")) == 0;
        if (stillOurs) {
            if (had) {
                size_t pos = 0;
                while (pos < b.size()) {
                    size_t e = b.find(L'\n', pos); if (e == std::wstring::npos) e = b.size();
                    std::wstring line = b.substr(pos, e - pos); pos = e + 1;
                    size_t eq = line.find(L'=');
                    if (eq == std::wstring::npos) continue;
                    curRegSet(k, line.substr(0, eq).c_str(), line.substr(eq + 1));
                }
            } else {
                for (auto r : kCurRoles) curRegSet(k, r, L"");   // пусто — стандартные курсоры Windows
                curRegSet(k, L"", L"");
            }
            cursorReload();
        }
        RegCloseKey(k);
    }
    cfgSetStr(L"CursorBackup", L"");
    cfgSetStr(L"CursorApplied", L"");
    gCursorApplied.clear();
    alog("cursor restored");
}

static std::string cursorWanted() {
    if (gCursorSeason) return kSeasonPacks[gSeason & 3];
    return gCursorPack;
}
// привести курсор Windows к выбранному (при запуске, смене настройки и сезона, после скачивания)
static void cursorSync() {
    std::string want = cursorWanted();
    if (!cursorPackExists(want)) want.clear();
    if (want.empty()) { if (!gCursorApplied.empty()) cursorRestore(); return; }
    if (!cursorReady(want)) { cursorDownload(want); return; }   // файлы могли удалить — скачаем заново
    if (want != gCursorApplied) cursorApply(want);
}
// пришёл ответ от потока скачивания
static void cursorDownloaded(bool ok) {
    std::string id = gCurLoading;
    gCurLoading.clear();
    if (!ok) {
        appToast(T8("Не удалось скачать курсоры — проверь интернет и попробуй ещё раз", "Couldn't download the cursors. Check your internet connection and try again"));
        if (!gCursorSeason && gCursorPack == id) { gCursorPack = gCursorApplied; saveSettings(); }   // выбор возвращаем на то, что стоит
    } else cursorSync();
    appPushState();
}

// размер указателя, как ползунок в «Параметры → Специальные возможности → Указатель мыши» (1–15)
static int cursorSizeGet() {
    DWORD v = 0, sz = sizeof(v);
    if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Accessibility", L"CursorSize", RRF_RT_REG_DWORD, nullptr, &v, &sz) == ERROR_SUCCESS && v >= 1 && v <= 15) return (int)v;
    sz = sizeof(v);
    if (RegGetValueW(HKEY_CURRENT_USER, kCurRegKey, L"CursorBaseSize", RRF_RT_REG_DWORD, nullptr, &v, &sz) == ERROR_SUCCESS && v >= 32)
        return (int)std::min<DWORD>(15, (v - 32) / 16 + 1);
    return 1;
}
static void cursorSizeSet(int n) {
    n = n < 1 ? 1 : n > 15 ? 15 : n;
    DWORD px = 32 + 16 * (n - 1), nn = (DWORD)n;
    RegSetKeyValueW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Accessibility", L"CursorSize", REG_DWORD, &nn, sizeof(nn));
    RegSetKeyValueW(HKEY_CURRENT_USER, kCurRegKey, L"CursorBaseSize", REG_DWORD, &px, sizeof(px));
    SystemParametersInfoW(0x2029 /*SPI_SETCURSORSIZE*/, 0, (PVOID)(UINT_PTR)px, SPIF_UPDATEINIFILE);
    cursorReload();
    gCursorPx = (int)px;
    alog("cursor size %d (%lu px)", n, px);
}

static void cursorSaveSettings() {
    regSet(L"CursorTrail", (DWORD)gCursorTrail);
    regSet(L"CursorSeason", gCursorSeason);
    if (!gRegCollect) cfgSetStr(L"CursorPack", W16(gCursorPack));
}
static void cursorLoadSettings() {
    gCursorPx = 32 + 16 * (cursorSizeGet() - 1);
    gCursorTrail = (int)std::min<DWORD>(4, regGet(L"CursorTrail", 0));
    gCursorSeason = regGet(L"CursorSeason", 0) != 0;
    std::wstring s;
    gCursorPack = cfgGetStr(L"CursorPack", s) ? U8(s) : "";
    gCursorApplied = cfgGetStr(L"CursorApplied", s) ? U8(s) : "";
}
