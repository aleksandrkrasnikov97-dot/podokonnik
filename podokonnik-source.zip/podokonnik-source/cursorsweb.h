// Наборы курсоров сообщества с rw-designer.com (каталог из github.com/rohzzn/cursors, 11 тысяч наборов).
// Выбранный набор: открываем его страницу, берём ссылку на .zip и роли курсоров, которые сайт подписал,
// распаковываем, раскладываем по ролям Windows (install.inf → подписи сайта → имена файлов) и кладём
// в папку данных cursors\web-<slug> с описанием roles.txt. Логика ролей — как в Cursors (PackDetection.cs).
#pragma once

static const wchar_t* kWebRoleClasses[15] = {   // классы ролей на странице набора, в порядке ролей реестра
    L"curarrow", L"curhelp", L"curwork", L"curbusy", L"curprec", L"curtext", L"curpen", L"curunav",
    L"curvert", L"curhorz", L"curnwse", L"curnesw", L"curmove", L"curalt", L"curlink",
};
enum { CR_ARROW, CR_HELP, CR_APPSTARTING, CR_WAIT, CR_CROSS, CR_IBEAM, CR_NWPEN, CR_NO, CR_SIZENS, CR_SIZEWE,
       CR_SIZENWSE, CR_SIZENESW, CR_SIZEALL, CR_UPARROW, CR_HAND, CR_PIN, CR_PERSON, CR_COUNT };

static bool webSlugOk(const std::string& s) {
    if (s.empty() || s.size() > 120) return false;
    for (unsigned char c : s) if (!(isalnum(c) || c == '_' || c == '.' || c == '~' || c == '-')) return false;
    return true;
}

static std::wstring lowerW(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }

// --- роль по имени файла (порядок правил важен: сначала конкретные слова, потом общие)
struct RoleRule { int role; std::vector<std::wstring> keys; };
static const std::vector<RoleRule>& roleRules() {
    static const std::vector<RoleRule> r = {
        {CR_APPSTARTING, {L"appstarting", L"appstart", L"appstrt", L"workinginbackground", L"background", L"working", L"progress", L"work"}},
        {CR_HELP, {L"helpselect", L"helpsel", L"help", L"question"}},
        {CR_WAIT, {L"busy", L"wait", L"loading", L"hourglass"}},
        {CR_CROSS, {L"precisionselect", L"precision", L"crosshair", L"cross"}},
        {CR_IBEAM, {L"textselect", L"ibeam", L"beam", L"text"}},
        {CR_NWPEN, {L"handwriting", L"nwpen", L"pencil", L"draft", L"pen", L"write"}},
        {CR_NO, {L"unavailable", L"unavailiable", L"unavail", L"nodrop", L"notallowed", L"forbidden", L"denied", L"no"}},
        {CR_SIZENWSE, {L"diagonalresize1", L"diagonal1", L"dgn1", L"dng1", L"diag1", L"nwse", L"=size2"}},
        {CR_SIZENESW, {L"diagonalresize2", L"diagonal2", L"dgn2", L"dng2", L"diag2", L"nesw", L"=size1"}},
        {CR_SIZENS, {L"verticalresize", L"vertical", L"vert", L"sizens", L"=size4", L"ns"}},
        {CR_SIZEWE, {L"horizontalresize", L"horizontal", L"horiz", L"horz", L"sizewe", L"=size3", L"ew", L"we"}},
        {CR_SIZEALL, {L"sizeall", L"move"}},
        {CR_UPARROW, {L"alternateselect", L"alternate", L"uparrow", L"up", L"alt"}},
        {CR_PIN, {L"locationselect", L"location", L"pin"}},
        {CR_PERSON, {L"personselect", L"person"}},
        {CR_HAND, {L"linkselect", L"link", L"hand"}},
        {CR_ARROW, {L"normalselect", L"normal", L"arrow", L"pointer", L"default", L"select", L"cursor"}},
    };
    return r;
}
static int guessRoleName(const std::wstring& name) {
    if (name.empty()) return -1;
    // camelCase → слова, всё в нижний регистр
    std::wstring sp;
    for (size_t i = 0; i < name.size(); ++i) {
        if (i && iswlower(name[i - 1]) && iswupper(name[i])) sp += L' ';
        sp += (wchar_t)towlower(name[i]);
    }
    std::set<std::wstring> tokens;
    auto split = [&](bool digits) {
        std::wstring cur;
        for (wchar_t c : sp) {
            bool ok = (c >= L'a' && c <= L'z') || (digits && c >= L'0' && c <= L'9');
            if (ok) cur += c; else { if (!cur.empty()) tokens.insert(cur); cur.clear(); }
        }
        if (!cur.empty()) tokens.insert(cur);
    };
    split(true); split(false);
    std::wstring compact;
    for (wchar_t c : sp) if (iswalnum(c)) compact += c;
    for (auto& rule : roleRules())
        for (auto& k : rule.keys) {
            bool hit = k[0] == L'=' ? tokens.count(k.substr(1)) > 0 : k.size() >= 4 ? compact.find(k) != std::wstring::npos : tokens.count(k) > 0;
            if (hit) return rule.role;
        }
    return -1;
}
static int guessRole(const std::wstring& name) {
    // сайты называют файлы «<картинка> - <роль>»: смотрим сначала на часть после последнего « - »
    size_t d = name.rfind(L" - ");
    if (d != std::wstring::npos && d > 0) { int r = guessRoleName(name.substr(d + 3)); if (r >= 0) return r; }
    return guessRoleName(name);
}
static std::wstring stemOf(const std::wstring& path) {
    std::wstring b = baseName(path);
    size_t dot = b.rfind(L'.');
    return dot == std::wstring::npos ? b : b.substr(0, dot);
}
static bool isCursorFileW(const std::wstring& p) {
    std::wstring l = lowerW(p);
    return l.size() > 4 && (l.compare(l.size() - 4, 4, L".cur") == 0 || l.compare(l.size() - 4, 4, L".ani") == 0);
}
static void listFilesRec(const std::wstring& dir, int depth, std::vector<std::wstring>& out) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
        std::wstring p = dir + L"\\" + fd.cFileName;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (depth < 6) listFilesRec(p, depth + 1, out); }
        else out.push_back(p);
    } while (FindNextFileW(h, &fd) && out.size() < 4000);
    FindClose(h);
}

// --- install.inf
static std::wstring readTextAny(const std::wstring& p) {
    std::string b;
    if (!readFile(p, b) || b.size() > 1024 * 1024) return L"";
    if (b.size() >= 2 && (unsigned char)b[0] == 0xFF && (unsigned char)b[1] == 0xFE)
        return std::wstring((const wchar_t*)(b.data() + 2), (b.size() - 2) / 2);
    UINT cp = (b.size() >= 3 && (unsigned char)b[0] == 0xEF && (unsigned char)b[1] == 0xBB) ? CP_UTF8 : CP_ACP;
    size_t off = cp == CP_UTF8 ? 3 : 0;
    int n = MultiByteToWideChar(cp, 0, b.data() + off, (int)(b.size() - off), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(cp, 0, b.data() + off, (int)(b.size() - off), &w[0], n);
    return w;
}
static std::wstring trimW(const std::wstring& s, const wchar_t* chars = L" \t\r\n") {
    size_t a = s.find_first_not_of(chars), b = s.find_last_not_of(chars);
    return a == std::wstring::npos ? L"" : s.substr(a, b - a + 1);
}
static std::vector<std::wstring> infFields(const std::wstring& line) {
    std::vector<std::wstring> f; std::wstring cur; bool q = false;
    for (size_t i = 0; i < line.size(); ++i) {
        wchar_t c = line[i];
        if (c == L'"') { if (q && i + 1 < line.size() && line[i + 1] == L'"') { cur += L'"'; ++i; } else q = !q; }
        else if (c == L',' && !q) { f.push_back(trimW(cur)); cur.clear(); }
        else cur += c;
    }
    f.push_back(trimW(cur));
    return f;
}
static bool parseInf(const std::wstring& inf, const std::vector<std::wstring>& files, std::wstring roles[CR_COUNT]) {
    std::wstring text = readTextAny(inf);
    if (text.empty()) return false;
    // строки с «\» в конце склеиваем, комментарии «;» вне кавычек убираем
    std::vector<std::wstring> lines; std::wstring acc;
    size_t pos = 0;
    while (pos <= text.size()) {
        size_t e = text.find(L'\n', pos); if (e == std::wstring::npos) e = text.size();
        std::wstring l = text.substr(pos, e - pos); pos = e + 1;
        if (!l.empty() && l.back() == L'\r') l.pop_back();
        std::wstring t = l; while (!t.empty() && (t.back() == L' ' || t.back() == L'\t')) t.pop_back();
        if (!t.empty() && t.back() == L'\\' && !(t.size() >= 2 && t[t.size() - 2] == L'\\')) { acc += t.substr(0, t.size() - 1); continue; }
        acc += l; lines.push_back(acc); acc.clear();
        if (e == text.size()) break;
    }
    std::map<std::wstring, std::wstring> strs;
    std::vector<std::wstring> body;
    std::wstring section;
    for (auto& raw : lines) {
        std::wstring l; bool q = false;
        for (wchar_t c : raw) { if (c == L'"') q = !q; else if (c == L';' && !q) break; l += c; }
        l = trimW(l);
        if (l.empty()) continue;
        if (l.front() == L'[' && l.back() == L']') { section = lowerW(trimW(l.substr(1, l.size() - 2))); continue; }
        if (section == L"strings") {
            size_t eq = l.find(L'=');
            if (eq != std::wstring::npos && eq > 0) {
                std::wstring v = trimW(l.substr(eq + 1));
                if (v.size() >= 2 && v.front() == L'"' && v.back() == L'"') v = v.substr(1, v.size() - 2);
                strs[lowerW(trimW(l.substr(0, eq)))] = v;
            }
        } else body.push_back(l);
    }
    auto expand = [&](std::wstring s) {
        for (int pass = 0; pass < 8 && s.find(L'%') != std::wstring::npos; ++pass) {
            std::wstring o; size_t i = 0; bool changed = false;
            while (i < s.size()) {
                size_t a = s.find(L'%', i);
                if (a == std::wstring::npos) { o += s.substr(i); break; }
                size_t b = s.find(L'%', a + 1);
                if (b == std::wstring::npos) { o += s.substr(i); break; }
                o += s.substr(i, a - i);
                std::wstring k = lowerW(s.substr(a + 1, b - a - 1));
                if (k.empty()) o += L'%'; else { auto it = strs.find(k); if (it != strs.end()) o += it->second; }
                changed = true; i = b + 1;
            }
            if (!changed || o == s) break;
            s = o;
        }
        return s;
    };
    auto resolve = [&](const std::wstring& entry) -> std::wstring {
        std::wstring e = trimW(trimW(entry), L" \t\"");
        size_t sl = e.find_last_of(L"\\/");
        std::wstring fn = lowerW(sl == std::wstring::npos ? e : e.substr(sl + 1));
        if (fn.empty()) return L"";
        for (auto& f : files) if (lowerW(baseName(f)) == fn) return f;
        return L"";
    };
    std::vector<std::wstring> pos17(CR_COUNT), extras;
    for (auto& l : body) {
        auto f = infFields(l);
        if (f.size() < 3) continue;
        std::wstring key = lowerW(trimW(expand(f[1]), L" \t\\"));
        if (key == L"control panel\\cursors\\schemes" && f.size() >= 5) {
            std::wstring list;
            for (size_t i = 4; i < f.size(); ++i) { if (i > 4) list += L","; list += f[i]; }
            list = expand(list);
            size_t p0 = 0; int idx = 0;
            while (p0 <= list.size()) {
                size_t c = list.find(L',', p0); if (c == std::wstring::npos) c = list.size();
                std::wstring r = resolve(list.substr(p0, c - p0));
                if (idx < CR_COUNT) { if (pos17[idx].empty()) pos17[idx] = r; } else if (!r.empty()) extras.push_back(r);
                ++idx; p0 = c + 1;
                if (c == list.size()) break;
            }
        } else if (key == L"control panel\\cursors") {
            std::wstring vn = trimW(expand(f[2]));
            if (vn.empty()) continue;
            std::wstring v = f.size() >= 5 ? expand(f[4]) : L"";
            for (int i = 0; i < CR_COUNT; ++i) if (!_wcsicmp(vn.c_str(), kCurRoles[i])) { if (pos17[i].empty()) pos17[i] = resolve(v); }
        }
    }
    bool any = false;
    for (auto& s : pos17) any |= !s.empty();
    if (!any) {   // нет строк реестра — по ключам [Strings]: pointer, help, work, busy…
        for (auto& kv : strs) {
            if (!isCursorFileW(kv.second)) continue;
            int r = kv.first == L"hand" ? CR_NWPEN : kv.first == L"work" ? CR_APPSTARTING : guessRole(kv.first);
            if (r < 0) r = guessRole(stemOf(kv.second));
            if (r >= 0 && pos17[r].empty()) pos17[r] = resolve(kv.second);
        }
    }
    // inf с перепутанным порядком: файл, чьё имя явно называет роль, важнее позиции
    std::vector<std::wstring> fixed(CR_COUNT);
    std::vector<int> unplaced;
    for (int i = 0; i < CR_COUNT; ++i) {
        if (pos17[i].empty()) continue;
        int g = guessRole(stemOf(pos17[i]));
        if (g >= 0 && fixed[g].empty()) fixed[g] = pos17[i]; else unplaced.push_back(i);
    }
    for (auto& f : extras) { int g = guessRole(stemOf(f)); if (g >= 0 && fixed[g].empty() && std::find(fixed.begin(), fixed.end(), f) == fixed.end()) fixed[g] = f; }
    for (int i : unplaced) if (fixed[i].empty() && std::find(fixed.begin(), fixed.end(), pos17[i]) == fixed.end()) fixed[i] = pos17[i];
    any = false;
    for (int i = 0; i < CR_COUNT; ++i) { roles[i] = fixed[i]; any |= !fixed[i].empty(); }
    return any;
}

// --- страница набора: ссылка на .zip и роли, подписанные сайтом
static std::string htmlDecode(std::string s) {
    static const std::pair<const char*, const char*> ents[] = {{"&amp;", "&"}, {"&quot;", "\""}, {"&#39;", "'"}, {"&lt;", "<"}, {"&gt;", ">"}};
    for (auto& e : ents) for (size_t p; (p = s.find(e.first)) != std::string::npos;) s.replace(p, strlen(e.first), e.second);
    return s;
}
static std::string urlDecode(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '%' && i + 2 < s.size() && isxdigit((unsigned char)s[i + 1]) && isxdigit((unsigned char)s[i + 2])) { o += (char)strtol(s.substr(i + 1, 2).c_str(), nullptr, 16); i += 2; }
        else o += s[i];
    }
    return o;
}
static std::string webZipPath(const std::string& html) {
    size_t p = 0;
    while ((p = html.find("href=\"", p)) != std::string::npos) {
        p += 6;
        size_t e = html.find('"', p);
        if (e == std::string::npos) break;
        std::string h = htmlDecode(html.substr(p, e - p));
        const std::string abs = "https://www.rw-designer.com";
        if (h.rfind(abs, 0) == 0) h = h.substr(abs.size());
        if (h.rfind("/cursor-downloadset/", 0) == 0 && h.size() > 4 && _stricmp(h.c_str() + h.size() - 4, ".zip") == 0) return h;
    }
    return "";
}
static std::map<std::wstring, int> webRoleHints(const std::string& html) {
    std::map<std::wstring, int> out;
    std::set<int> taken;
    const std::string a = "class=\"itemteaser", b = "\"><a class=\"download\" href=\"/cursor-download/";
    size_t p = 0;
    while ((p = html.find(a, p)) != std::string::npos) {
        size_t cEnd = html.find('"', p + 7);   // конец значения class
        if (cEnd == std::string::npos) break;
        std::string cls = html.substr(p + 7, cEnd - p - 7);
        p = cEnd;
        if (html.compare(cEnd, b.size(), b) != 0) continue;
        size_t q = cEnd + b.size();
        while (q < html.size() && isdigit((unsigned char)html[q])) ++q;
        if (q >= html.size() || html[q] != '/') continue;
        size_t fe = html.find('"', q + 1);
        if (fe == std::string::npos) break;
        std::wstring file = lowerW(W16(urlDecode(htmlDecode(html.substr(q + 1, fe - q - 1)))));
        int role = -1;
        std::wstring wc = lowerW(W16(cls));
        for (size_t s = 0; s <= wc.size() && role < 0;) {
            size_t e = wc.find(L' ', s); if (e == std::wstring::npos) e = wc.size();
            std::wstring tok = wc.substr(s, e - s);
            for (int i = 0; i < 15; ++i) if (tok == kWebRoleClasses[i]) { role = i; break; }
            s = e + 1;
        }
        if (role < 0 || out.count(file) || taken.count(role)) continue;
        taken.insert(role);
        out[file] = role;
    }
    return out;
}

static bool webUnzip(const std::wstring& zip, const std::wstring& dst) {
    CreateDirectoryW(dst.c_str(), nullptr);
    wchar_t sys[MAX_PATH] = {0};
    GetSystemDirectoryW(sys, MAX_PATH);
    runHidden(L"\"" + std::wstring(sys) + L"\\tar.exe\" -xf \"" + zip + L"\" -C \"" + dst + L"\"", 60000);
    std::vector<std::wstring> f; listFilesRec(dst, 0, f);
    bool any = false; for (auto& x : f) any |= isCursorFileW(x);
    if (any) return true;
    std::wstring q1, q2;
    for (wchar_t c : zip) { if (c == L'\'') q1 += L"''"; else q1 += c; }
    for (wchar_t c : dst) { if (c == L'\'') q2 += L"''"; else q2 += c; }
    runHidden(L"powershell.exe -NoProfile -NonInteractive -Command \"Expand-Archive -LiteralPath '" + q1 + L"' -DestinationPath '" + q2 + L"' -Force\"", 120000);
    f.clear(); listFilesRec(dst, 0, f);
    for (auto& x : f) if (isCursorFileW(x)) return true;
    return false;
}

// скачать набор сообщества в cursorDir(id); вызывается из потока
static bool webDownloadPack(const std::string& id, const std::string& name) {
    std::string slug = id.substr(4);
    std::string html;
    if (!httpsGet(L"www.rw-designer.com", L"/cursor-set/" + W16(slug), html, 4u << 20)) { alog("cursor web: page failed %s: status %lu, err %lu", slug.c_str(), gHttpLastStatus, gHttpLastErr); return false; }
    std::string zipPath = webZipPath(html);
    if (zipPath.empty()) { alog("cursor web: no zip on page %s", slug.c_str()); return false; }
    std::string zipData;
    if (!httpsGet(L"www.rw-designer.com", W16(zipPath), zipData, 50u << 20) || zipData.size() < 22) { alog("cursor web: zip failed %s: status %lu, err %lu, %zu bytes", zipPath.c_str(), gHttpLastStatus, gHttpLastErr, zipData.size()); return false; }
    std::wstring dir = cursorDir(id), tmp = dir + L".tmp", zip = dir + L".zip";
    deleteTree(tmp);
    if (!writeFile(zip, zipData)) return false;
    bool unz = webUnzip(zip, tmp);
    DeleteFileW(zip.c_str());
    if (!unz) { deleteTree(tmp); alog("cursor web: unzip failed %s", slug.c_str()); return false; }

    std::vector<std::wstring> all, curs, infs;
    listFilesRec(tmp, 0, all);
    for (auto& f : all) {
        if (isCursorFileW(f)) curs.push_back(f);
        else { std::wstring l = lowerW(f); if (l.size() > 4 && l.compare(l.size() - 4, 4, L".inf") == 0) infs.push_back(f); }
    }
    std::wstring roles[CR_COUNT];
    bool byInf = false;
    for (auto& inf : infs) if (parseInf(inf, curs, roles)) { byInf = true; break; }
    if (!byInf) {
        auto hints = webRoleHints(html);
        for (auto& f : curs) {
            auto it = hints.find(lowerW(baseName(f)));
            if (it != hints.end() && roles[it->second].empty()) roles[it->second] = f;
        }
        // остальное — по именам файлов (анимированные сначала)
        std::vector<std::wstring> sorted = curs, left;
        std::stable_sort(sorted.begin(), sorted.end(), [](const std::wstring& a, const std::wstring& b) {
            bool aa = lowerW(a).find(L".ani") != std::wstring::npos, ba = lowerW(b).find(L".ani") != std::wstring::npos;
            if (aa != ba) return aa;
            return lowerW(a) < lowerW(b);
        });
        for (auto& f : sorted) {
            bool used = false; for (auto& r : roles) used |= r == f;
            if (used) continue;
            int g = guessRole(stemOf(f));
            if (g >= 0 && roles[g].empty()) roles[g] = f; else left.push_back(f);
        }
        if (roles[CR_ARROW].empty() && !left.empty()) roles[CR_ARROW] = left[0];
    }
    if (roles[CR_ARROW].empty()) { deleteTree(tmp); alog("cursor web: no arrow in %s", slug.c_str()); return false; }

    deleteTree(dir);
    CreateDirectoryW(dir.c_str(), nullptr);
    std::string manifest = "name=" + name + "\n";
    int n = 0;
    for (int i = 0; i < CR_COUNT; ++i) {
        if (roles[i].empty()) continue;
        std::wstring ext = lowerW(roles[i].substr(roles[i].size() - 4));
        std::wstring dst = dir + L"\\" + kCurRoles[i] + ext;
        if (CopyFileW(roles[i].c_str(), dst.c_str(), FALSE)) { manifest += U8(kCurRoles[i]) + "=" + U8(std::wstring(kCurRoles[i]) + ext) + "\n"; ++n; }
    }
    deleteTree(tmp);
    writeFile(dir + L"\\Источник.txt", "Набор «" + name + "» с rw-designer.com: https://www.rw-designer.com/cursor-set/" + slug +
              "\r\nЛицензия — на странице набора. Каталог — из проекта Cursors: https://github.com/rohzzn/cursors\r\n");
    if (!n || !writeFile(dir + L"\\roles.txt", manifest)) return false;
    alog("cursor web: %s ok, %d roles%s", slug.c_str(), n, byInf ? " (inf)" : "");
    return true;
}
// роли готового набора сообщества (roles.txt)
static bool webManifest(const std::string& id, std::map<std::wstring, std::wstring>& roles, std::string& name) {
    std::string t;
    if (!readFile(cursorDir(id) + L"\\roles.txt", t)) return false;
    size_t p = 0;
    while (p < t.size()) {
        size_t e = t.find('\n', p); if (e == std::string::npos) e = t.size();
        std::string l = t.substr(p, e - p); p = e + 1;
        size_t eq = l.find('=');
        if (eq == std::string::npos) continue;
        if (l.substr(0, eq) == "name") name = l.substr(eq + 1);
        else roles[W16(l.substr(0, eq))] = W16(l.substr(eq + 1));
    }
    for (auto& kv : roles) if (!fileExists(cursorDir(id) + L"\\" + kv.second)) return false;
    return roles.count(L"Arrow") > 0;
}
