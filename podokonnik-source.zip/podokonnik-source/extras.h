// Время суток на обоях и обои по времени суток, интернет-радио и таймер сна, свой праздник и питомец (настройки),
// заставка Windows, портативный режим, «скопировать журнал», каталог обоев с сайта.
// Подключается в конце sugrob.cpp (после features.h).
#pragma once

#define WM_SCRSTART   (WM_APP + 40)   // заставка: показать (от процесса .scr)
#define WM_SCRQUERY   (WM_APP + 41)   // заставка: ещё идёт? (1 — да)
#define WM_SCRSHOWAPP (WM_APP + 42)   // заставка: открыть настройки
#define WM_CATPROGRESS (WM_APP + 43)
#define WM_CATDONE     (WM_APP + 44)

// ================================================================ время суток
static bool gTodOn = true;                 // вечер, ночь и рассвет на живых обоях
static bool gTodWpOn = false;              // свои обои на утро, день, вечер и ночь
static std::string gTodWp[4];              // id обоев: утро, день, вечер, ночь ("" — не менять)
static int gTodWpLast = -1;

static float minutesNow() { SYSTEMTIME st; GetLocalTime(&st); return st.wHour * 60 + st.wMinute + st.wSecond / 60.0f; }
static void todFactors(float& night, float& warm) {
    float m = minutesNow(), rise = (float)gSunRise, set = (float)gSunSet;
    // ночь: темнеет от заката до +50 минут, светлеет от −50 минут до рассвета +20
    if (m >= set + 50 || m < rise - 50) night = 1;
    else if (m >= set - 20) night = (m - (set - 20)) / 70.0f;
    else if (m < rise + 20) night = 1 - (m - (rise - 50)) / 70.0f;
    else night = 0;
    night = clampf(night, 0, 1);
    float ws = 1 - std::fabs(m - (set - 10)) / 70.0f, wr = 1 - std::fabs(m - (rise + 10)) / 60.0f;
    warm = clampf(std::max(ws, wr * 0.8f), 0, 1);
}
// 0 — утро, 1 — день, 2 — вечер, 3 — ночь
static int todPhase() {
    float m = minutesNow();
    float mStart = gSunRise - 30.0f, dStart = 11 * 60.0f;
    float eStart = std::min(std::max(gSunSet - 60.0f, 15 * 60.0f), 21 * 60.0f), nStart = std::max(eStart + 60, 22 * 60.0f + 30);
    if (m >= mStart && m < dStart) return 0;
    if (m >= dStart && m < eStart) return 1;
    if (m >= eStart && m < nStart) return 2;
    return 3;
}
static std::string todJson(bool flash) {
    float n, w;
    todFactors(n, w);
    char b[160];
    snprintf(b, sizeof b, "{\"cmd\":\"tod\",\"on\":%s,\"night\":%.3f,\"warm\":%.3f%s}", gTodOn ? "true" : "false", n, w, flash ? ",\"flash\":1" : "");
    return b;
}
// слой поверх обоев: синеватая ночь, тёплый закат, звёзды, вспышка молнии
static std::wstring todScript() {
    std::string init = todJson(false);
    std::string js = std::string("(function(){var st=") + init + ";"
        "var ov,wm,cv,fl,cx,stars=[],tm=0,paused=false;"
        "function mk(){if(ov)return;var r=document.documentElement;if(!r)return;"
        "ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483645;background:#22306e;mix-blend-mode:multiply;opacity:0;transition:opacity 5s';"
        "wm=document.createElement('div');wm.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483645;background:linear-gradient(to top,rgba(255,110,40,.6),rgba(255,150,80,.28) 45%,rgba(255,170,120,0) 80%);mix-blend-mode:soft-light;opacity:0;transition:opacity 5s';"
        "cv=document.createElement('canvas');cv.style.cssText='position:fixed;left:0;top:0;width:100%;height:42%;pointer-events:none;z-index:2147483646;opacity:0;transition:opacity 5s;-webkit-mask-image:linear-gradient(#000,transparent);mask-image:linear-gradient(#000,transparent)';"
        "fl=document.createElement('div');fl.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483647;background:#e4ecff;mix-blend-mode:screen;opacity:0;transition:opacity .35s';"
        "r.appendChild(ov);r.appendChild(wm);r.appendChild(cv);r.appendChild(fl);cx=cv.getContext('2d');apply();}"
        "function size(){var d=devicePixelRatio||1;cv.width=innerWidth*d;cv.height=innerHeight*0.42*d;stars=[];for(var i=0;i<140;i++)stars.push([Math.random(),Math.pow(Math.random(),1.4),Math.random()*6.28,0.4+Math.random()*1.3]);}"
        "function draw(){tm=0;if(!st.on||st.night<0.05||paused)return;if(!stars.length)size();var w=cv.width,h=cv.height,t=performance.now()/1000,d=devicePixelRatio||1;cx.clearRect(0,0,w,h);"
        "for(var i=0;i<stars.length;i++){var s=stars[i],a=0.35+0.65*Math.abs(Math.sin(t*0.9+s[2]));cx.globalAlpha=a;cx.fillStyle='#fff';cx.beginPath();cx.arc(s[0]*w,s[1]*h,s[3]*d,0,6.283);cx.fill();}"
        "tm=setTimeout(draw,120);}"
        "function apply(){if(!ov)return;var on=st.on;ov.style.opacity=on?(st.night*0.55).toFixed(3):0;wm.style.opacity=on?(st.warm*0.9).toFixed(3):0;cv.style.opacity=on?(st.night*0.55).toFixed(3):0;if(!tm)draw();}"
        "addEventListener('resize',function(){if(cv)size();});"
        "if(document.readyState!=='loading')mk();else addEventListener('DOMContentLoaded',mk);"
        "if(window.chrome&&chrome.webview)chrome.webview.addEventListener('message',function(e){var m=e.data||{};"
        "if(m.cmd==='pause'){paused=true;return;}if(m.cmd==='play'){paused=false;if(!tm&&cx)draw();return;}"
        "if(m.cmd!=='tod')return;if(m.flash){if(fl){fl.style.transition='none';fl.style.opacity=0.55;setTimeout(function(){fl.style.transition='opacity .35s';fl.style.opacity=0;},70);setTimeout(function(){fl.style.transition='none';fl.style.opacity=0.35;setTimeout(function(){fl.style.transition='opacity .5s';fl.style.opacity=0;},50);},220);}return;}"
        "st.on=!!m.on;st.night=+m.night||0;st.warm=+m.warm||0;apply();});"
        "})();";
    return W16(js);
}
static void todPush() { std::string j = todJson(false); for (auto& w : gWpWins) if (w.host) wv::post(w.host, j); }
static void wpFlash() { if (!gTodOn) return; std::string j = todJson(true); for (auto& w : gWpWins) if (w.host && !w.paused) wv::post(w.host, j); }

static bool todWpActive() {
    if (!gTodWpOn) return false;
    for (auto& s : gTodWp) if (!s.empty()) return true;
    return false;
}
// обои по времени суток: при смене части дня ставим выбранные
static void todWpTick(bool force) {
    if (!todWpActive()) { gTodWpLast = -1; return; }
    int ph = todPhase();
    if (ph == gTodWpLast && !force) return;
    gTodWpLast = ph;
    // не задано на эту часть дня — берём ближайшую раньше
    std::string id;
    for (int k = 0; k < 4 && id.empty(); ++k) id = gTodWp[(ph - k + 4) % 4];
    if (id.empty() || id == gWpCurrent || !findItem(id)) return;
    alog("time of day %d -> %s", ph, id.c_str());
    wpApply(id);
}

// ================================================================ интернет-радио
struct Station { const char* name; const char* nameEn; const char* desc; const char* descEn; const char* urls[3]; };
static const Station kStations[] = {
    {"Лоу-фай для работы", "Lo-fi for work", "Спокойные биты без слов — freeCodeCamp", "Calm beats without words — freeCodeCamp",
     {"https://coderadio-admin-v2.freecodecamp.org/listen/coderadio/radio.mp3", nullptr, nullptr}},
    {"Groove Salad", "Groove Salad", "Эмбиент и даунтемпо — SomaFM", "Ambient and downtempo — SomaFM",
     {"https://ice1.somafm.com/groovesalad-128-mp3", "https://ice2.somafm.com/groovesalad-128-mp3", "https://ice4.somafm.com/groovesalad-128-mp3"}},
    {"Drone Zone", "Drone Zone", "Космический эмбиент без ритма — SomaFM", "Spacey beat-free ambient — SomaFM",
     {"https://ice1.somafm.com/dronezone-128-mp3", "https://ice2.somafm.com/dronezone-128-mp3", "https://ice4.somafm.com/dronezone-128-mp3"}},
    {"Fluid", "Fluid", "Инструментальный хип-хоп — SomaFM", "Instrumental hip-hop — SomaFM",
     {"https://ice1.somafm.com/fluid-128-mp3", "https://ice2.somafm.com/fluid-128-mp3", "https://ice4.somafm.com/fluid-128-mp3"}},
    {"Lush", "Lush", "Мягкий вокал и электроника — SomaFM", "Soft vocals and electronica — SomaFM",
     {"https://ice1.somafm.com/lush-128-mp3", "https://ice2.somafm.com/lush-128-mp3", "https://ice4.somafm.com/lush-128-mp3"}},
    {"Christmas Lounge", "Christmas Lounge", "Новогодняя музыка — SomaFM (зимой)", "Holiday music — SomaFM (in winter)",
     {"https://ice1.somafm.com/christmas-128-mp3", "https://ice2.somafm.com/christmas-128-mp3", "https://ice4.somafm.com/christmas-128-mp3"}},
    {"Radio Paradise Mellow", "Radio Paradise Mellow", "Спокойный микс — Radio Paradise", "Mellow mix — Radio Paradise",
     {"https://stream.radioparadise.com/mellow-128", "https://stream.radioparadise.com/mellow-192", nullptr}},
};
static const int kStationCount = (int)(sizeof(kStations) / sizeof(kStations[0]));
static std::wstring gRadioUrl;          // своя ссылка
static std::string gRadioState = "off"; // off / loading / playing / error
static HWND gRadioWnd = nullptr;
static wv::Host* gRadioHost = nullptr;
static bool gRadioReady = false;
static std::string gRadioPending;

static void radioSend(const std::string& j) { if (gRadioHost && gRadioReady) wv::post(gRadioHost, j); else gRadioPending = j; }
static float radioVol() { float v = gMusicVol / 100.0f; return v * v; }
static std::string radioPlayJson() {
    std::string arr = "[";
    if (gRadioIdx < 0) arr += js::esc(U8(gRadioUrl));
    else for (int k = 0; k < 3; ++k) if (kStations[gRadioIdx].urls[k]) { if (arr.size() > 1) arr += ","; arr += js::esc(kStations[gRadioIdx].urls[k]); }
    arr += "]";
    char b[64];
    snprintf(b, sizeof b, ",\"vol\":%.3f,\"muted\":%s}", radioVol(), gHiddenFS ? "true" : "false");
    return "{\"cmd\":\"play\",\"urls\":" + arr + b;
}
static void radioEnsure() {
    if (gRadioWnd) return;
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = gInst;
    wc.lpszClassName = L"SugrobRadio";
    RegisterClassExW(&wc);
    gRadioWnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"SugrobRadio", L"Подоконник — радио", WS_POPUP, -32000, -32000, 16, 16, nullptr, nullptr, gInst, nullptr);
    gRadioHost = new wv::Host();
    gRadioHost->hwnd = gRadioWnd;
    gRadioHost->onMessage = [](const std::string& msg) {
        js::Value m = js::parse(msg);
        if (m.str("cmd") == "ready") { gRadioReady = true; if (!gRadioPending.empty()) { wv::post(gRadioHost, gRadioPending); gRadioPending.clear(); } return; }
        if (m.str("cmd") == "state") {
            std::string s = m.str("state");
            if (s != gRadioState) { gRadioState = s; if (s == "error") alog("radio error: %s", m.str("text").c_str()); appPushState(); updateTip(); }
        }
    };
    gRadioReady = false;
    wv::create(gRadioHost, dataPath(L"WebView2"), fileUrl(dataPath(L"ui\\radio.html")), {}, false, [](bool ok) { if (!ok) { gRadioState = "error"; appPushState(); } });
}
static void radioStop() {
    if (!gRadioOn) return;
    gRadioOn = false;
    gRadioState = "off";
    radioSend("{\"cmd\":\"stop\"}");
    updateTip();
}
static void radioPlay(int idx) {
    if (idx >= kStationCount) idx = 0;
    if (idx < 0 && gRadioUrl.empty()) return;
    gRadioIdx = idx;
    if (gMusicOn) musicSetOn(false);
    gRadioOn = true;
    gRadioState = "loading";
    radioEnsure();
    radioSend(radioPlayJson());
    alog("radio: %s", idx >= 0 ? kStations[idx].name : U8(gRadioUrl).c_str());
    updateTip();
}
static void radioVolume() { if (gRadioOn) { char b[64]; snprintf(b, sizeof b, "{\"cmd\":\"vol\",\"v\":%.3f}", radioVol()); radioSend(b); } }
static void radioSetPaused(bool p) {
    static bool last = false;
    if (!gRadioOn || p == last) return;
    last = p;
    radioSend(std::string("{\"cmd\":\"mute\",\"v\":") + (p ? "true" : "false") + "}");
}
static std::string radioTitle() {
    if (!gRadioOn) return "";
    if (gRadioIdx < 0) return T8("Своё радио", "My radio");
    return gLang ? kStations[gRadioIdx].nameEn : kStations[gRadioIdx].name;
}

// ================================================================ таймер сна
static ULONGLONG gSleepAt = 0;
static int gSleepMin = 0;
static void sleepSet(int min) {
    gSleepMin = min;
    gSleepAt = min > 0 ? GetTickCount64() + (ULONGLONG)min * 60000 : 0;
}
static int sleepLeft() { if (!gSleepAt) return 0; ULONGLONG n = GetTickCount64(); return n >= gSleepAt ? 0 : (int)((gSleepAt - n + 59999) / 60000); }
static void sleepTick() {
    if (!gSleepAt || GetTickCount64() < gSleepAt) return;
    gSleepAt = 0; gSleepMin = 0;
    alog("sleep timer: music off");
    if (gMusicOn) musicSetOn(false);
    radioStop();
    saveSettings();
    appPushState();
}

// ================================================================ журнал в буфер обмена
static std::string tailFile(const std::wstring& p, size_t maxBytes) {
    std::string t;
    if (!readFile(p, t)) return "";
    if (t.size() > maxBytes) { t = t.substr(t.size() - maxBytes); size_t nl = t.find('\n'); if (nl != std::string::npos) t = t.substr(nl + 1); }
    return t;
}
static void copyLog() {
    char head[512];
    snprintf(head, sizeof head, "Подоконник %s · Windows build %lu · мониторов %zu · %d Гц · %s%s · кадров %d\r\n",
             kAppVersion, windowsBuild(), gMons.size(), gMonitorHz, gGpuOn ? "видеокарта" : "процессор", gPortable ? " · портативный" : "", gFps);
    std::string all = std::string(head) + "---- app.log ----\r\n" + tailFile(dataPath(L"app.log"), 40000) +
                      "---- music ----\r\n" + tailFile(dataPath(L"music\\log.txt"), 6000);
    std::wstring w = W16(all);
    bool ok = false;
    if (OpenClipboard(gMsgWnd)) {
        EmptyClipboard();
        HGLOBAL h = GlobalAlloc(GMEM_MOVEABLE, (w.size() + 1) * sizeof(wchar_t));
        if (h) {
            memcpy(GlobalLock(h), w.c_str(), (w.size() + 1) * sizeof(wchar_t));
            GlobalUnlock(h);
            ok = SetClipboardData(CF_UNICODETEXT, h) != nullptr;
            if (!ok) GlobalFree(h);
        }
        CloseClipboard();
    }
    appToast(ok ? T8("Журнал скопирован — вставь его в сообщение (Ctrl+V)", "Log copied — paste it into a message (Ctrl+V)")
                : T8("Не получилось скопировать журнал", "Couldn't copy the log"));
}

// ================================================================ перезапуск и портативный режим
static void restartSelf() {
    std::wstring cmd = L"\"" + exePath() + L"\" --restart";
    STARTUPINFOW si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) { CloseHandle(pi.hThread); CloseHandle(pi.hProcess); }
    DestroyWindow(gMsgWnd);
}
static void copySmallData(const std::wstring& from, const std::wstring& to) {
    CreateDirectoryW(to.c_str(), nullptr);
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((from + L"\\*.json").c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do CopyFileW((from + L"\\" + fd.cFileName).c_str(), (to + L"\\" + fd.cFileName).c_str(), FALSE);
        while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    CreateDirectoryW((to + L"\\props").c_str(), nullptr);
    h = FindFirstFileW((from + L"\\props\\*.json").c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do CopyFileW((from + L"\\props\\" + fd.cFileName).c_str(), (to + L"\\props\\" + fd.cFileName).c_str(), FALSE);
        while (FindNextFileW(h, &fd));
        FindClose(h);
    }
}
static void setPortable(bool on) {
    if (on == gPortable) return;
    std::wstring oldData = gDataDir;
    if (on) {
        HANDLE f = CreateFileW(gIniPath.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
        if (f == INVALID_HANDLE_VALUE) { appToast(T8("Не получилось: в папку программы нельзя записывать", "Couldn't do it: the program folder is read-only")); return; }
        DWORD w;
        WriteFile(f, "\xFF\xFE", 2, &w, nullptr);
        CloseHandle(f);
        // все настройки из реестра — в ini
        HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, kRegKey, 0, KEY_READ, &k) == ERROR_SUCCESS) {
            for (DWORD i = 0;; ++i) {
                wchar_t name[256]; DWORD nl = 256, type = 0, dl = 0;
                if (RegEnumValueW(k, i, name, &nl, nullptr, &type, nullptr, &dl) != ERROR_SUCCESS) break;
                std::vector<BYTE> data(dl + 4, 0);
                nl = 256; dl = (DWORD)data.size();
                if (RegEnumValueW(k, i, name, &nl, nullptr, &type, data.data(), &dl) != ERROR_SUCCESS) continue;
                std::wstring v;
                if (type == REG_DWORD) v = std::to_wstring(*(DWORD*)data.data());
                else if (type == REG_SZ) v = (const wchar_t*)data.data();
                else continue;
                WritePrivateProfileStringW(L"Settings", name, v.c_str(), gIniPath.c_str());
            }
            RegCloseKey(k);
        }
        gPortable = true;
        copySmallData(oldData, baseDataDir());
    } else {
        // из ini обратно в реестр
        std::vector<wchar_t> buf(65536);
        DWORD n = GetPrivateProfileSectionW(L"Settings", buf.data(), (DWORD)buf.size(), gIniPath.c_str());
        for (const wchar_t* p = buf.data(); p < buf.data() + n && *p; p += wcslen(p) + 1) {
            std::wstring line = p;
            size_t eq = line.find(L'=');
            if (eq == std::wstring::npos) continue;
            std::wstring name = line.substr(0, eq), v = line.substr(eq + 1);
            bool num = !v.empty() && v.size() < 11 && v.find_first_not_of(L"0123456789") == std::wstring::npos;
            static const wchar_t* strKeys[] = {L"Wallpaper", L"WallpaperMon", L"WeatherCity", L"CustText", L"RadioUrl", L"TodWp", L"ExePath"};
            for (auto sk : strKeys) if (name == sk) num = false;
            if (num) { DWORD d = (DWORD)wcstoul(v.c_str(), nullptr, 10); RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, name.c_str(), REG_DWORD, &d, sizeof d); }
            else RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, name.c_str(), REG_SZ, v.c_str(), (DWORD)((v.size() + 1) * 2));
        }
        DeleteFileW(gIniPath.c_str());
        gPortable = false;
        copySmallData(oldData, baseDataDir());
    }
    alog("portable mode %s", on ? "on" : "off");
    restartSelf();
}

// ================================================================ заставка Windows
static bool gScrExitAfter = false;
static std::vector<std::pair<HWND, wv::Host*>> gScrWins;
static DWORD gScrInput = 0;
static POINT gScrCur{};
static double gScrStartT = 0;
static int gScrMin = 10;   // через сколько минут Windows включает заставку

static std::wstring scrPathBesideExe() { return gExeDir + L"\\Podokonnik.scr"; }
static std::wstring scrRegValue() {
    wchar_t b[MAX_PATH * 2] = {0};
    DWORD sz = sizeof(b);
    if (RegGetValueW(HKEY_CURRENT_USER, L"Control Panel\\Desktop", L"SCRNSAVE.EXE", RRF_RT_REG_SZ, nullptr, b, &sz) != ERROR_SUCCESS) return L"";
    return b;
}
static bool scrInstalled() {
    std::wstring v = scrRegValue();
    for (auto& c : v) c = towlower(c);
    if (v.find(L"podokonnik.scr") != std::wstring::npos) return true;
    wchar_t sp[MAX_PATH * 2] = {0};
    if (GetShortPathNameW(scrPathBesideExe().c_str(), sp, MAX_PATH * 2)) { std::wstring s = sp; for (auto& c : s) c = towlower(c); return v == s; }
    return false;
}
static void scrInstall(int minutes) {
    std::wstring scr = scrPathBesideExe();
    if (!CopyFileW(exePath().c_str(), scr.c_str(), FALSE)) {
        scr = dataPath(L"Podokonnik.scr");   // папка программы только для чтения — кладём к данным вместе с WebView2Loader.dll
        if (!CopyFileW(exePath().c_str(), scr.c_str(), FALSE)) { appToast(T8("Не получилось сделать заставку", "Couldn't set up the screensaver")); return; }
        CopyFileW((gExeDir + L"\\WebView2Loader.dll").c_str(), dataPath(L"WebView2Loader.dll").c_str(), FALSE);
    }
    wchar_t sp[MAX_PATH * 2] = {0};
    std::wstring val = GetShortPathNameW(scr.c_str(), sp, MAX_PATH * 2) ? std::wstring(sp) : scr;
    RegSetKeyValueW(HKEY_CURRENT_USER, L"Control Panel\\Desktop", L"SCRNSAVE.EXE", REG_SZ, val.c_str(), (DWORD)((val.size() + 1) * 2));
    gScrMin = std::max(1, minutes);
    SystemParametersInfoW(SPI_SETSCREENSAVETIMEOUT, (UINT)(gScrMin * 60), nullptr, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    SystemParametersInfoW(SPI_SETSCREENSAVEACTIVE, TRUE, nullptr, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    alog("screensaver installed: %s, %d min", U8(val).c_str(), gScrMin);
    appToast(T8("Готово: Подоконник — заставка Windows", "Done: Podokonnik is your Windows screensaver"));
}
static void scrUninstall() {
    if (scrInstalled()) {
        HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Control Panel\\Desktop", 0, KEY_SET_VALUE, &k) == ERROR_SUCCESS) { RegDeleteValueW(k, L"SCRNSAVE.EXE"); RegCloseKey(k); }
        SystemParametersInfoW(SPI_SETSCREENSAVEACTIVE, FALSE, nullptr, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    }
    DeleteFileW(scrPathBesideExe().c_str());
    DeleteFileW(dataPath(L"Podokonnik.scr").c_str());
}
// после обновления программы — обновить и копию-заставку
static void scrRefreshCopy() {
    if (!scrInstalled()) return;
    std::wstring scr = fileExists(scrPathBesideExe()) ? scrPathBesideExe() : dataPath(L"Podokonnik.scr");
    if (fileSize(scr) != fileSize(exePath())) CopyFileW(exePath().c_str(), scr.c_str(), FALSE);
}
static std::wstring clockScript() {
    std::string loc = gLang ? "en-GB" : "ru-RU";
    std::string js = "(function(){function mk(){if(document.getElementById('__pdclock'))return;var d=document.createElement('div');d.id='__pdclock';"
        "d.style.cssText='position:fixed;left:6vw;bottom:10vh;z-index:2147483647;pointer-events:none;color:#fff;font-family:\"Segoe UI\",sans-serif;text-shadow:0 2px 24px rgba(0,0,0,.6)';"
        "d.innerHTML='<div style=\"font-size:13vh;font-weight:300;line-height:1;letter-spacing:-.02em\"></div><div style=\"font-size:3vh;opacity:.85;margin-top:1.4vh\"></div>';"
        "document.documentElement.appendChild(d);var a=d.children[0],b=d.children[1];"
        "function t(){var n=new Date();a.textContent=n.toLocaleTimeString('" + loc + "',{hour:'2-digit',minute:'2-digit'});"
        "var s=n.toLocaleDateString('" + loc + "',{weekday:'long',day:'numeric',month:'long'});b.textContent=s.charAt(0).toUpperCase()+s.slice(1);}t();setInterval(t,1000);}"
        "if(document.readyState!=='loading')mk();else addEventListener('DOMContentLoaded',mk);})();";
    return W16(js);
}
static LRESULT CALLBACK ScrProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_SIZE) { for (auto& w : gScrWins) if (w.first == h) wv::fit(w.second); return 0; }
    if (msg == WM_SETCURSOR) { SetCursor(nullptr); return TRUE; }
    if (msg == WM_ERASEBKGND) { RECT rc; GetClientRect(h, &rc); FillRect((HDC)wp, &rc, (HBRUSH)GetStockObject(BLACK_BRUSH)); return 1; }
    return DefWindowProcW(h, msg, wp, lp);
}
static void scrStop() {
    if (!gScrActive) return;
    gScrActive = false;
    KillTimer(gMsgWnd, 9);
    for (auto& w : gScrWins) { wv::destroy(w.second); DestroyWindow(w.first); }
    gScrWins.clear();
    alog("screensaver stop");
    if (gScrExitAfter) DestroyWindow(gMsgWnd);
}
static void scrStart(bool exitAfter) {
    if (gScrActive) return;
    gScrExitAfter = exitAfter;
    static bool reg = false;
    if (!reg) {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = ScrProc;
        wc.hInstance = gInst;
        wc.lpszClassName = L"SugrobSaver";
        wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
        RegisterClassExW(&wc);
        reg = true;
    }
    gScrActive = true;
    for (size_t i = 0; i < gMons.size(); ++i) {
        const RECT& m = gMons[i];
        HWND h = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, L"SugrobSaver", L"Подоконник — заставка", WS_POPUP | WS_VISIBLE,
                                 m.left, m.top, m.right - m.left, m.bottom - m.top, nullptr, nullptr, gInst, nullptr);
        if (!h) continue;
        std::wstring url;
        std::vector<std::wstring> scripts;
        WpItem* it = findItem(wpIdOn(i));
        if (!(it && itemReady(*it) && wpUrlFor(*it, url, scripts))) { url = fileUrl(dataPath(L"ui\\saver.html")); scripts.clear(); }
        scripts.push_back(todScript());
        scripts.push_back(clockScript());
        auto* host = new wv::Host();
        host->hwnd = h;
        wv::create(host, dataPath(L"WebView2"), url, scripts, false, nullptr);
        gScrWins.push_back({h, host});
    }
    SetWindowPos(gOverlay, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    LASTINPUTINFO li{sizeof(li)};
    GetLastInputInfo(&li);
    gScrInput = li.dwTime;
    GetCursorPos(&gScrCur);
    gScrStartT = gTime;
    SetTimer(gMsgWnd, 9, 100, nullptr);
    alog("screensaver start (%zu monitors)", gScrWins.size());
}
static void scrTick() {
    if (!gScrActive) return;
    if (gTime - gScrStartT < 1.5) {   // первые полторы секунды — без проверки (мышь ещё «дрожит»)
        LASTINPUTINFO li{sizeof(li)}; GetLastInputInfo(&li); gScrInput = li.dwTime; GetCursorPos(&gScrCur);
        return;
    }
    LASTINPUTINFO li{sizeof(li)};
    GetLastInputInfo(&li);
    POINT p; GetCursorPos(&p);
    if (li.dwTime != gScrInput && (std::abs(p.x - gScrCur.x) > 6 || std::abs(p.y - gScrCur.y) > 6 || (p.x == gScrCur.x && p.y == gScrCur.y))) scrStop();
    else gScrInput = li.dwTime;
}

// ================================================================ каталог обоев с сайта
static volatile LONG gCatBusy = 0;
static std::string gCatId;
static std::wstring gCatPath, gCatDst;
static DWORD WINAPI CatThread(LPVOID) {
    bool ok = false;
    HINTERNET ses = WinHttpOpen(L"Podokonnik", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) ses = WinHttpOpen(L"Podokonnik", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (ses) {
        WinHttpSetTimeouts(ses, 15000, 15000, 20000, 60000);
        DWORD proto = 0x00000800 | 0x00002000;
        if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) { proto = 0x00000800; WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto)); }
        HINTERNET con = WinHttpConnect(ses, kUpdHost, INTERNET_DEFAULT_HTTPS_PORT, 0);
        HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", gCatPath.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE) : nullptr;
        if (req && WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(req, nullptr)) {
            DWORD status = 0, sz = sizeof(status), clen = 0;
            WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
            sz = sizeof(clen);
            WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_LENGTH | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &clen, &sz, WINHTTP_NO_HEADER_INDEX);
            HANDLE f = status == 200 ? CreateFileW(gCatDst.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr) : INVALID_HANDLE_VALUE;
            if (f != INVALID_HANDLE_VALUE) {
                std::vector<char> buf(64 * 1024);
                DWORD got = 0, total = 0, lastPct = 0;
                bool err = false;
                for (;;) {
                    if (!WinHttpReadData(req, buf.data(), (DWORD)buf.size(), &got)) { err = true; break; }
                    if (!got) break;
                    DWORD wr = 0;
                    if (!WriteFile(f, buf.data(), got, &wr, nullptr) || wr != got) { err = true; break; }
                    total += got;
                    if (clen) { DWORD pct = (DWORD)((ULONGLONG)total * 100 / clen); if (pct != lastPct) { lastPct = pct; PostMessageW(gMsgWnd, WM_CATPROGRESS, pct, 0); } }
                }
                CloseHandle(f);
                ok = !err && total > 0;
                if (!ok) DeleteFileW(gCatDst.c_str());
            }
        }
        if (req) WinHttpCloseHandle(req);
        if (con) WinHttpCloseHandle(con);
        WinHttpCloseHandle(ses);
    }
    PostMessageW(gMsgWnd, WM_CATDONE, ok ? 1 : 0, 0);
    return 0;
}
static void catInstall(const std::string& id, const std::string& path) {
    if (id.empty() || path.rfind("/podokonnik/", 0) != 0) return;
    for (char c : id) if (!isalnum((unsigned char)c) && c != '-' && c != '_') return;
    if (InterlockedExchange(&gCatBusy, 1)) { appToast(T8("Уже скачиваю другие обои — подожди немного", "Already downloading another wallpaper — please wait")); return; }
    gCatId = id;
    gCatPath = W16(path);
    CreateDirectoryW(dataPath(L"packs").c_str(), nullptr);
    gCatDst = dataPath(L"packs") + L"\\catalog-" + W16(id) + L".zip";
    HANDLE t = CreateThread(nullptr, 0, CatThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t); else InterlockedExchange(&gCatBusy, 0);
}

// ================================================================ настройки
static void saveSettings3() {
    regSet(L"CustDay", (DWORD)gCustDay);
    regSet(L"CustMon", (DWORD)gCustMon);
    regSet(L"CustFx", (DWORD)gCustFx);
    cfgSetStr(L"CustText", gCustText);
    regSet(L"Pet", (DWORD)gPetMode);
    regSet(L"PetCoat", (DWORD)gPetCoat);
    regSet(L"TodOn", gTodOn);
    regSet(L"TodWpOn", gTodWpOn);
    cfgSetStr(L"TodWp", W16(gTodWp[0] + "\n" + gTodWp[1] + "\n" + gTodWp[2] + "\n" + gTodWp[3]));
    regSet(L"SunRise", (DWORD)gSunRise);
    regSet(L"SunSet", (DWORD)gSunSet);
    regSet(L"RadioIdx", (DWORD)(gRadioIdx + 1));
    cfgSetStr(L"RadioUrl", gRadioUrl);
    regSet(L"ScrMin", (DWORD)gScrMin);
    regSet(L"Gpu", gGpuWanted);
}
static void loadSettings3() {
    gCustDay = (int)std::min<DWORD>(31, regGet(L"CustDay", 0));
    gCustMon = (int)std::min<DWORD>(12, regGet(L"CustMon", 0));
    gCustFx = (int)std::min<DWORD>(3, regGet(L"CustFx", 0));
    if (!cfgGetStr(L"CustText", gCustText)) gCustText.clear();
    gPetMode = (int)std::min<DWORD>(2, regGet(L"Pet", 1));
    gPetCoat = (int)std::min<DWORD>(3, regGet(L"PetCoat", 0));
    gTodOn = regGet(L"TodOn", 1) != 0;
    gTodWpOn = regGet(L"TodWpOn", 0) != 0;
    std::wstring t;
    if (cfgGetStr(L"TodWp", t)) {
        std::string s = U8(t);
        for (int k = 0; k < 4; ++k) { size_t nl = s.find('\n'); gTodWp[k] = s.substr(0, nl); s = nl == std::string::npos ? "" : s.substr(nl + 1); }
    }
    gSunRise = (int)regGet(L"SunRise", 390);
    gSunSet = (int)regGet(L"SunSet", 1110);
    if (gSunRise < 120 || gSunRise > 720) gSunRise = 390;
    if (gSunSet < 900 || gSunSet > 1380) gSunSet = 1110;
    gRadioIdx = (int)regGet(L"RadioIdx", 1) - 1;
    if (gRadioIdx >= kStationCount) gRadioIdx = 0;
    if (!cfgGetStr(L"RadioUrl", gRadioUrl)) gRadioUrl.clear();
    if (gRadioIdx < 0 && gRadioUrl.empty()) gRadioIdx = 0;
    gScrMin = (int)std::max<DWORD>(1, std::min<DWORD>(120, regGet(L"ScrMin", 10)));
    gGpuWanted = regGet(L"Gpu", 0) != 0;
}

// ================================================================ окно настроек: состояние и команды
static void extraState(js::Value& v) {
    auto num = [&](const char* k, double n) { js::Value x; x.type = js::Value::Num; x.n = n; v.o.emplace_back(k, x); };
    auto bl = [&](const char* k, bool b) { js::Value x; x.type = js::Value::Bool; x.b = b; v.o.emplace_back(k, x); };
    auto st = [&](const char* k, const std::string& s) { js::Value x; x.type = js::Value::Str; x.s = s; v.o.emplace_back(k, x); };
    num("custDay", gCustDay); num("custMon", gCustMon); num("custFx", gCustFx); st("custText", U8(gCustText));
    bl("fireworks", gFwManual > 0);
    num("pet", gPetMode); num("petCoat", gPetCoat);
    bl("todOn", gTodOn); bl("todWpOn", gTodWpOn);
    {
        js::Value a; a.type = js::Value::Arr;
        for (auto& s : gTodWp) { js::Value x; x.type = js::Value::Str; x.s = s; a.a.push_back(x); }
        v.o.emplace_back("todWp", a);
    }
    num("todPhase", todPhase());
    char sun[32]; snprintf(sun, sizeof sun, "%02d:%02d–%02d:%02d", gSunRise / 60, gSunRise % 60, gSunSet / 60, gSunSet % 60);
    st("sunTimes", sun);
    bl("radioOn", gRadioOn); num("radioIdx", gRadioIdx); st("radioUrl", U8(gRadioUrl)); st("radioState", gRadioState); st("radioTitle", radioTitle());
    {
        js::Value a; a.type = js::Value::Arr;
        for (int i = 0; i < kStationCount; ++i) {
            js::Value o; o.type = js::Value::Obj;
            js::Value n; n.type = js::Value::Str; n.s = gLang ? kStations[i].nameEn : kStations[i].name;
            js::Value d; d.type = js::Value::Str; d.s = gLang ? kStations[i].descEn : kStations[i].desc;
            o.o.emplace_back("name", n); o.o.emplace_back("desc", d);
            a.a.push_back(o);
        }
        v.o.emplace_back("stations", a);
    }
    num("sleepMin", gSleepMin); num("sleepLeft", sleepLeft());
    bl("portable", gPortable);
    bl("scrInstalled", scrInstalled()); num("scrMin", gScrMin);
    bl("gpu", gGpuWanted); bl("gpuActive", gGpuOn);
}
static void gpuSetWanted(bool on);
static bool extraSet(const std::string& k, double v) {
    bool b = v != 0;
    if (k == "pet") { gPetMode = (int)clampf((float)v, 0, 2); gPet.alive = false; }
    else if (k == "petCoat") gPetCoat = (int)clampf((float)v, 0, 3);
    else if (k == "todOn") { gTodOn = b; todPush(); }
    else if (k == "todWpOn") { gTodWpOn = b; todWpTick(true); }
    else if (k == "sleepMin") sleepSet((int)v);
    else if (k == "scrMin") { gScrMin = (int)clampf((float)v, 1, 120); if (scrInstalled()) SystemParametersInfoW(SPI_SETSCREENSAVETIMEOUT, (UINT)(gScrMin * 60), nullptr, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE); }
    else if (k == "gpu") gpuSetWanted(b);
    else return false;
    return true;
}
static bool extraUi(const std::string& cmd, const js::Value& m) {
    if (cmd == "custHoliday") {
        gCustDay = (int)clampf((float)m.num("day"), 0, 31);
        gCustMon = (int)clampf((float)m.num("mon"), 0, 12);
        gCustFx = (int)clampf((float)m.num("fx"), 0, 3);
        gCustText = W16(m.str("text").substr(0, 120));
        gHolChk = 99;
        gHFall.clear();
    } else if (cmd == "fireworks") {
        gFwManual = 25;
        gFwNext = 0;
    } else if (cmd == "todWp") {
        int slot = (int)m.num("slot");
        if (slot >= 0 && slot < 4) gTodWp[slot] = m.str("id");
        gTodWpLast = -1;
        todWpTick(true);
    } else if (cmd == "radio") {
        std::string a = m.str("action");
        if (a == "play") radioPlay((int)m.num("index"));
        else if (a == "stop") radioStop();
        else if (a == "toggle") { if (gRadioOn) radioStop(); else radioPlay(gRadioIdx); }
        else if (a == "url") {
            std::string u = m.str("url");
            if (u.rfind("http://", 0) == 0 || u.rfind("https://", 0) == 0) { gRadioUrl = W16(u); radioPlay(-1); }
            else appToast(T8("Нужна ссылка, которая начинается с http:// или https://", "The link must start with http:// or https://"));
        }
    } else if (cmd == "copyLog") {
        copyLog();
        return true;
    } else if (cmd == "portable") {
        setPortable(m.boolean("value"));
    } else if (cmd == "scr") {
        std::string a = m.str("action");
        if (a == "install") scrInstall(gScrMin);
        else if (a == "remove") scrUninstall();
        else if (a == "test") { if (gAppWnd) ShowWindow(gAppWnd, SW_MINIMIZE); scrStart(false); }
        else if (a == "settings") ShellExecuteW(nullptr, L"open", L"control.exe", L"desk.cpl,,@screensaver", nullptr, SW_SHOWNORMAL);
    } else if (cmd == "catInstall") {
        catInstall(m.str("id"), m.str("path"));
        return true;
    } else return false;
    saveSettings();
    appPushState();
    return true;
}

// ================================================================ сообщения и таймер
static void extrasInit() {
    alog("render: %s%s%s", gGpuOn ? "GPU (DirectComposition)" : "CPU", gGpuOn || gGpuWhy.empty() ? "" : ", GPU unavailable: ", gGpuOn ? "" : gGpuWhy.c_str());
    todWpTick(true);
    if (!gScrExitAfter && !gPortable) cfgSetStr(L"ExePath", exePath());
    if (!gScrExitAfter) scrRefreshCopy();
}
static void extrasTick5() {   // раз в 5 секунд (таймер 8)
    todWpTick(false);
    sleepTick();
    static int n = 0;
    if (++n % 12 == 0) todPush();   // раз в минуту — свет на обоях
}
static bool extrasMsg(UINT msg, WPARAM wp, LPARAM) {
    if (msg == WM_TIMER && wp == 9) { scrTick(); return true; }
    if (msg == WM_SCRSTART) { scrStart(false); return true; }
    if (msg == WM_SCRSHOWAPP) { showApp(); return true; }
    if (msg == WM_CATPROGRESS) {
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"catProgress\",\"id\":" + js::esc(gCatId) + ",\"pct\":" + std::to_string((int)wp) + "}");
        return true;
    }
    if (msg == WM_CATDONE) {
        InterlockedExchange(&gCatBusy, 0);
        std::string id = gCatId;
        if (wp == 1) {
            std::wstring p = unpackZip(gCatDst);
            DeleteFileW(gCatDst.c_str());
            if (!p.empty()) {
                bool dup = false;
                for (auto& u : gUserWp) if (_wcsicmp(u.c_str(), p.c_str()) == 0) dup = true;
                if (!dup) gUserWp.push_back(p);
                saveUserWp();
                rebuildCatalog();
                std::string wid = (GetFileAttributesW(p.c_str()) & FILE_ATTRIBUTE_DIRECTORY) ? "we:" + U8(p) : "file:" + U8(p);
                if (findItem(wid)) wpApply(wid);
                appToast(T8("Обои установлены и включены", "Wallpaper installed and turned on"));
            } else appToast(T8("Архив скачался, но обоев в нём нет", "The archive downloaded, but there's no wallpaper in it"));
        } else appToast(T8("Не получилось скачать обои. Проверь интернет.", "Couldn't download the wallpaper. Check your internet."));
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"catProgress\",\"id\":" + js::esc(id) + ",\"pct\":-1}");
        appPushWallpapers();
        appPushState();
        return true;
    }
    return false;
}
