// Батарея и лёгкий режим, смена обоев по расписанию, горячие клавиши, погода за окном.
// Подключается в конце sugrob.cpp (после app.h и update.h).
#pragma once
#include <set>

#define WM_WEATHER (WM_APP + 24)

// ---------------------------------------------------------------- настройки
static void saveSettings3();
static void loadSettings3();
static void extrasInit();
static void extrasTick5();
static bool todWpActive();
static void radioStop();
static void radioPlay(int idx);
static bool gRadioOn = false;              // интернет-радио играет (extras.h)
static int gRadioIdx = 0;                  // выбранная станция (-1 — своя ссылка)
static int gSunRise = 390, gSunSet = 1110; // восход и закат, минуты от полуночи (по городу из погоды или 6:30 / 18:30)
static void saveSettings2() {
    regSet(L"Lang", (DWORD)gLang);
    regSet(L"Battery", (DWORD)gBatteryMode);
    regSet(L"Light", gLightMode);
    regSet(L"RotMin", (DWORD)gRotMin);
    regSet(L"RotRandom", gRotRandom);
    regSet(L"Hotkeys", gHotkeys);
    regSet(L"WeatherOn", gWeatherOn);
    std::wstring c = gWeatherCity + L"|" + std::to_wstring(gLat) + L"|" + std::to_wstring(gLon);
    cfgSetStr(L"WeatherCity", c);
    saveSettings3();
}
static void loadSettings2() {
    // язык: если не выбран — как у Windows (русский, украинский, белорусский, казахский → русский)
    LANGID lid = GetUserDefaultUILanguage();
    WORD pl = PRIMARYLANGID(lid);
    int def = (pl == LANG_RUSSIAN || pl == LANG_UKRAINIAN || pl == LANG_BELARUSIAN || pl == LANG_KAZAK) ? 0 : 1;
    gLang = (int)std::min<DWORD>(1, regGet(L"Lang", (DWORD)def));
    gBatteryMode = (int)std::min<DWORD>(2, regGet(L"Battery", 0));
    gLightMode = regGet(L"Light", 0) != 0;
    gRotMin = (int)regGet(L"RotMin", 0);
    if (gRotMin != 0 && gRotMin != 5 && gRotMin != 15 && gRotMin != 30 && gRotMin != 60 && gRotMin != 180) gRotMin = 0;
    gRotRandom = regGet(L"RotRandom", 1) != 0;
    gHotkeys = regGet(L"Hotkeys", 1) != 0;
    gWeatherOn = regGet(L"WeatherOn", 0) != 0;
    std::wstring s;
    if (cfgGetStr(L"WeatherCity", s)) {
        size_t a = s.find(L'|'), b = a == std::wstring::npos ? a : s.find(L'|', a + 1);
        if (b != std::wstring::npos) {
            gWeatherCity = s.substr(0, a);
            gLat = _wtof(s.substr(a + 1, b - a - 1).c_str());
            gLon = _wtof(s.substr(b + 1).c_str());
        }
    }
    loadSettings3();
}

// ---------------------------------------------------------------- батарея и лёгкий режим
static bool batteryNow() {
    SYSTEM_POWER_STATUS ps{};
    if (!GetSystemPowerStatus(&ps)) return false;
    if (ps.BatteryFlag & 128) return false;   // батареи нет — настольный компьютер
    return ps.ACLineStatus == 0;
}
// кадры, качество сцен, пауза обоев — всё по текущему режиму
static void powerApply() {
    applyActivePace();
    std::string f = "{\"cmd\":\"fps\",\"value\":" + std::to_string(wpFps()) + "}";
    std::string l = std::string("{\"cmd\":\"lite\",\"value\":") + (liteNow() ? "true" : "false") + "}";
    for (auto& w : gWpWins) if (w.scene && w.host) { wv::post(w.host, f); wv::post(w.host, l); }
    gWpTickLast = -1;
    wpTick();
    appPushState();
}
static void powerCheck() {
    bool b = batteryNow();
    if (b == gOnBattery) return;
    gOnBattery = b;
    alog("power: %s", b ? "battery" : "plugged in");
    powerApply();
}

// ---------------------------------------------------------------- избранное и смена обоев
static std::set<std::string> gFav;
static void loadFav() {
    std::string t;
    gFav.clear();
    if (!readFile(dataPath(L"favorites.json"), t)) return;
    js::Value v = js::parse(t);
    for (auto& x : v.a) if (x.type == js::Value::Str) gFav.insert(x.s);
}
static void saveFav() {
    js::Value v; v.type = js::Value::Arr;
    for (auto& id : gFav) { js::Value x; x.type = js::Value::Str; x.s = id; v.a.push_back(x); }
    writeFile(dataPath(L"favorites.json"), js::dump(v));
}
static bool isFav(const std::string& id) { return gFav.count(id) != 0; }
static void toggleFav(const std::string& id) { if (!gFav.erase(id)) gFav.insert(id); saveFav(); }

// следующие обои: из избранного (если оно есть), иначе из всех готовых
static void rotNext(int dir) {
    std::vector<std::string> list;
    for (auto& it : gWpItems) if (isFav(it.id) && itemReady(it)) list.push_back(it.id);
    if (list.empty())
        for (auto& it : gWpItems) if (itemReady(it) && (it.kind != "scene" || it.scene)) list.push_back(it.id);
    if (list.empty()) return;
    size_t cur = std::find(list.begin(), list.end(), gWpCurrent) - list.begin();
    std::string next;
    if (gRotRandom && dir > 0 && list.size() > 1) {
        do next = list[xr() % list.size()]; while (next == gWpCurrent);
    } else {
        size_t n = list.size();
        size_t i = cur >= n ? 0 : (cur + n + (size_t)(dir > 0 ? 1 : n - 1)) % n;
        next = list[i];
    }
    alog("rotate -> %s", next.c_str());
    wpApply(next);
    gRotLast = gTime;
}

// ---------------------------------------------------------------- горячие клавиши
enum { HK_NEXT = 1, HK_PREV, HK_EFFECTS, HK_PAUSE, HK_MUSIC };
static void hotkeysApply() {
    for (int i = HK_NEXT; i <= HK_MUSIC; ++i) UnregisterHotKey(gMsgWnd, i);
    if (!gHotkeys) return;
    const UINT mod = MOD_CONTROL | MOD_ALT | 0x4000 /*MOD_NOREPEAT*/;
    struct { int id; UINT vk; } k[] = {{HK_NEXT, VK_RIGHT}, {HK_PREV, VK_LEFT}, {HK_EFFECTS, 'H'}, {HK_PAUSE, 'P'}, {HK_MUSIC, 'M'}};
    for (auto& x : k) if (!RegisterHotKey(gMsgWnd, x.id, mod, x.vk)) alog("hotkey %d busy", x.id);
}
static void hotkey(int id) {
    if (id == HK_NEXT) rotNext(1);
    else if (id == HK_PREV) rotNext(-1);
    else if (id == HK_EFFECTS) gSnowOn = !gSnowOn;
    else if (id == HK_PAUSE) { gWpUserPause = !gWpUserPause; gWpTickLast = -1; wpTick(); }
    else if (id == HK_MUSIC) {
        if (gRadioOn) radioStop();
        else { if (!gMusicOn) musicEnsureDownloader(); musicSetOn(!gMusicOn); }
    }
    saveSettings();
    appPushState();
}

// ---------------------------------------------------------------- погода (Open-Meteo, без ключа)
static int gWCode = -1;
static double gWTemp = 0;
static DWORD gWTime = 0;
static volatile LONG gWBusy = 0;
static std::wstring gWNewCity;
static double gWNewLat = 0, gWNewLon = 0;
static int gWNewCode = -1;
static double gWNewTemp = 0;
static double gWWind = 0, gWDir = 0, gWNewWind = 0, gWNewDir = 0;   // ветер: км/ч и откуда дует (градусы)
static int gWNewRise = -1, gWNewSet = -1;                           // восход и закат, минуты
static bool gWGeoFail = false;

static bool httpsGet(const wchar_t* host, const std::wstring& path, std::string& out) {
    out.clear();
    HINTERNET ses = WinHttpOpen(L"Podokonnik", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) ses = WinHttpOpen(L"Podokonnik", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) return false;
    WinHttpSetTimeouts(ses, 10000, 10000, 15000, 15000);
    DWORD proto = 0x00000800 | 0x00002000;
    if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) { proto = 0x00000800; WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto)); }
    bool ok = false;
    HINTERNET con = WinHttpConnect(ses, host, INTERNET_DEFAULT_HTTPS_PORT, 0);
    HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE) : nullptr;
    if (req && WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(req, nullptr)) {
        DWORD status = 0, sz = sizeof(status);
        WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
        char buf[8192];
        DWORD got = 0;
        while (status == 200 && WinHttpReadData(req, buf, sizeof buf, &got) && got && out.size() < 512 * 1024) out.append(buf, got);
        ok = status == 200 && !out.empty();
    }
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return ok;
}

static DWORD WINAPI WeatherThread(LPVOID geo) {
    std::wstring city = gWNewCity;
    double lat = gWNewLat, lon = gWNewLon;
    std::string body;
    gWGeoFail = false;
    if (geo) {   // город → координаты
        std::wstring p = L"/v1/search?count=1&format=json&language=" + std::wstring(gLang ? L"en" : L"ru") + L"&name=" + W16(urlEncode(U8(city)));
        bool found = false;
        if (httpsGet(L"geocoding-api.open-meteo.com", p, body)) {
            js::Value v = js::parse(body);
            if (const js::Value* r = v.get("results")) if (!r->a.empty()) {
                const js::Value& x = r->a[0];
                lat = x.num("latitude"); lon = x.num("longitude");
                city = W16(x.str("name"));
                found = true;
            }
        }
        if (!found) { gWGeoFail = true; alog("weather: city not found"); PostMessageW(gMsgWnd, WM_WEATHER, 0, 0); InterlockedExchange(&gWBusy, 0); return 0; }
    }
    wchar_t p[200];
    swprintf(p, 200, L"/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m&daily=sunrise,sunset&forecast_days=1&timezone=auto", lat, lon);
    int code = -1, rise = -1, set = -1;
    double temp = 0, wind = 0, dir = 0;
    if (httpsGet(L"api.open-meteo.com", p, body)) {
        js::Value v = js::parse(body);
        if (const js::Value* c = v.get("current")) {
            code = (int)c->num("weather_code", -1); temp = c->num("temperature_2m", 0);
            wind = c->num("wind_speed_10m", 0); dir = c->num("wind_direction_10m", 0);
        }
        // «2026-11-11T05:52» — время города; берём часы и минуты
        auto hm = [](const std::string& t) { size_t k = t.find('T'); return k == std::string::npos || t.size() < k + 6 ? -1 : atoi(t.c_str() + k + 1) * 60 + atoi(t.c_str() + k + 4); };
        if (const js::Value* d = v.get("daily")) {
            const js::Value* sr = d->get("sunrise");
            const js::Value* ss = d->get("sunset");
            if (sr && !sr->a.empty() && sr->a[0].type == js::Value::Str) rise = hm(sr->a[0].s);
            if (ss && !ss->a.empty() && ss->a[0].type == js::Value::Str) set = hm(ss->a[0].s);
        }
    }
    gWNewCity = city; gWNewLat = lat; gWNewLon = lon; gWNewCode = code; gWNewTemp = temp;
    gWNewWind = wind; gWNewDir = dir; gWNewRise = rise; gWNewSet = set;
    alog("weather: code %d, %.1f C", code, temp);
    PostMessageW(gMsgWnd, WM_WEATHER, code >= 0 ? 1 : 0, 0);
    InterlockedExchange(&gWBusy, 0);
    return 0;
}
static void weatherRequest(bool geocode) {
    if (!gWeatherOn || (gWeatherCity.empty() && !geocode)) return;
    if (InterlockedExchange(&gWBusy, 1)) return;
    gWNewCity = gWeatherCity; gWNewLat = gLat; gWNewLon = gLon;
    HANDLE t = CreateThread(nullptr, 0, WeatherThread, geocode ? (LPVOID)1 : nullptr, 0, nullptr);
    if (t) CloseHandle(t); else InterlockedExchange(&gWBusy, 0);
}
static bool weatherFresh() { return gWeatherOn && gWCode >= 0 && GetTickCount() - gWTime < 3 * 3600 * 1000; }
static bool codeRain(int c) { return (c >= 51 && c <= 67) || (c >= 80 && c <= 82) || c >= 95; }
static bool codeSnow(int c) { return (c >= 71 && c <= 77) || c == 85 || c == 86; }
static int weatherRainState() { return weatherFresh() ? (codeRain(gWCode) ? 1 : 0) : -1; }
static bool weatherThunderNow() { return weatherFresh() && gWCode >= 95; }
// ветер за окном → сдвиг снега и листьев (дует «откуда»: западный ветер несёт вправо)
static float weatherWindX() {
    if (!weatherFresh()) return 0;
    float sp = (float)std::min(gWWind, 70.0);
    float gust = 0.75f + 0.25f * (float)std::sin(gTime * 0.37) + 0.15f * (float)std::sin(gTime * 1.3);
    return -(float)std::sin(gWDir * 3.14159265 / 180.0) * sp * 1.5f * S * gust;
}
static bool weatherSnowNow() { return weatherFresh() && codeSnow(gWCode); }
static std::string weatherText() {
    if (!gWeatherOn) return "";
    if (gWGeoFail) return T8("Город не найден", "City not found");
    if (gWCode < 0) return gWeatherCity.empty() ? T8("Укажи город", "Enter a city") : T8("Узнаю погоду…", "Checking the weather…");
    const char* w;
    int c = gWCode;
    if (c == 0) w = T8("ясно", "clear");
    else if (c <= 3) w = T8("облачно", "cloudy");
    else if (c == 45 || c == 48) w = T8("туман", "fog");
    else if (c <= 57) w = T8("морось", "drizzle");
    else if (c <= 67) w = T8("дождь", "rain");
    else if (c <= 77) w = T8("снег", "snow");
    else if (c <= 82) w = T8("ливень", "showers");
    else if (c <= 86) w = T8("снегопад", "snow showers");
    else w = T8("гроза", "thunderstorm");
    char b[160];
    if (gWWind >= 1) snprintf(b, sizeof b, "%s: %+.0f°, %s, %s %.0f %s", U8(gWeatherCity).c_str(), gWTemp, w, T8("ветер", "wind"), gWWind, T8("км/ч", "km/h"));
    else snprintf(b, sizeof b, "%s: %+.0f°, %s", U8(gWeatherCity).c_str(), gWTemp, w);
    return b;
}

// ---------------------------------------------------------------- сообщения
static void featuresInit() {
    loadFav();
    {   // установлено установщиком → после обновления внутри программы версия в «Приложениях» тоже новая
        HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Podokonnik", 0, KEY_SET_VALUE, &k) == ERROR_SUCCESS) {
            std::wstring v = W16(kAppVersion);
            RegSetValueExW(k, L"DisplayVersion", 0, REG_SZ, (const BYTE*)v.c_str(), (DWORD)((v.size() + 1) * 2));
            RegCloseKey(k);
        }
    }
    gOnBattery = batteryNow();
    hotkeysApply();
    SetTimer(gMsgWnd, 8, 5000, nullptr);
    gRotLast = 0;
    if (gWeatherOn && !gWeatherCity.empty()) weatherRequest(false);
    extrasInit();
}
static bool featuresMsg(UINT msg, WPARAM wp, LPARAM) {
    if (msg == WM_HOTKEY) { hotkey((int)wp); return true; }
    if (msg == WM_POWERBROADCAST) { powerCheck(); return false; }
    if (msg == WM_TIMER && wp == 8) {
        powerCheck();
        if (gRotMin > 0 && !gWpCurrent.empty() && !todWpActive() && gTime - gRotLast >= gRotMin * 60.0) rotNext(1);
        extrasTick5();
        if (gRotLast <= 0) gRotLast = gTime;
        static DWORD lastW = 0;
        if (gWeatherOn && GetTickCount() - lastW > 30 * 60 * 1000) { lastW = GetTickCount(); weatherRequest(false); }
        return true;
    }
    if (msg == WM_WEATHER) {
        if (wp == 1) {
            gWeatherCity = gWNewCity; gLat = gWNewLat; gLon = gWNewLon;
            gWCode = gWNewCode; gWTemp = gWNewTemp; gWTime = GetTickCount();
            gWWind = gWNewWind; gWDir = gWNewDir;
            if (gWNewRise >= 120 && gWNewRise <= 720) gSunRise = gWNewRise;
            if (gWNewSet >= 900 && gWNewSet <= 1380) gSunSet = gWNewSet;
            saveSettings();
            int sea = effectiveSeason();
            if (sea != gSeason) { applySeason(sea); onSeasonChanged(); }
        }
        appPushState();
        return true;
    }
    return false;
}
