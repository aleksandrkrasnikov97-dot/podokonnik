// Кадры через видеокарту: картинка эффектов попадает на экран через DirectComposition.
// Отправляются только изменившиеся плитки 64×64 (а не весь прямоугольник вокруг них, как у UpdateLayeredWindow),
// склейку с остальным экраном делает видеокарта. Если что-то не так — программа сама возвращается к обычному способу.
#pragma once
#include <d3d11.h>
#include <dxgi1_2.h>
#include <dcomp.h>

static bool gGpuWanted = false;  // настройка «Рисовать на видеокарте» (пока новая — выключена, пока не проверим на многих компьютерах)
static bool gGpuOn = false;      // работает сейчас
static std::string gGpuWhy;      // почему не работает (для журнала)

namespace gpu {
static ID3D11Device* dev = nullptr;
static ID3D11DeviceContext* ctx = nullptr;
static IDCompositionDevice* dc = nullptr;
static IDCompositionTarget* target = nullptr;
static IDCompositionVisual* visual = nullptr;
static IDCompositionVirtualSurface* surf = nullptr;
static int sw = 0, sh = 0;

template <class T> static void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }
static void shutdown() {
    rel(surf); rel(visual); rel(target); rel(dc); rel(ctx); rel(dev);
    gGpuOn = false;
    sw = sh = 0;
}

typedef HRESULT (WINAPI* D3D11CreateDeviceFn)(IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT, const D3D_FEATURE_LEVEL*, UINT, UINT,
                                              ID3D11Device**, D3D_FEATURE_LEVEL*, ID3D11DeviceContext**);
typedef HRESULT (WINAPI* DCompCreateFn)(IDXGIDevice*, REFIID, void**);

// окно уже создано со стилем WS_EX_NOREDIRECTIONBITMAP
static bool init(HWND hwnd, int w, int h) {
    shutdown();
    HMODULE d3d = LoadLibraryW(L"d3d11.dll"), dcm = LoadLibraryW(L"dcomp.dll");
    auto createDev = d3d ? (D3D11CreateDeviceFn)(void*)GetProcAddress(d3d, "D3D11CreateDevice") : nullptr;
    auto createDc = dcm ? (DCompCreateFn)(void*)GetProcAddress(dcm, "DCompositionCreateDevice") : nullptr;
    if (!createDev || !createDc) { gGpuWhy = "no d3d11/dcomp"; return false; }
    HRESULT hr = E_FAIL;
    for (D3D_DRIVER_TYPE dt : {D3D_DRIVER_TYPE_HARDWARE, D3D_DRIVER_TYPE_WARP}) {
        hr = createDev(nullptr, dt, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, nullptr, 0, D3D11_SDK_VERSION, &dev, nullptr, &ctx);
        if (SUCCEEDED(hr)) break;
    }
    if (FAILED(hr) || !dev) { gGpuWhy = "D3D11CreateDevice failed"; shutdown(); return false; }
    IDXGIDevice* dxgi = nullptr;
    dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgi);
    if (!dxgi) { gGpuWhy = "no IDXGIDevice"; shutdown(); return false; }
    hr = createDc(dxgi, __uuidof(IDCompositionDevice), (void**)&dc);
    dxgi->Release();
    if (FAILED(hr) || !dc) { gGpuWhy = "DCompositionCreateDevice failed"; shutdown(); return false; }
    if (FAILED(dc->CreateTargetForHwnd(hwnd, TRUE, &target)) || FAILED(dc->CreateVisual(&visual)) ||
        FAILED(dc->CreateVirtualSurface(w, h, DXGI_FORMAT_B8G8R8A8_UNORM, DXGI_ALPHA_MODE_PREMULTIPLIED, &surf)) ||
        FAILED(visual->SetContent(surf)) || FAILED(target->SetRoot(visual)) || FAILED(dc->Commit())) {
        gGpuWhy = "composition setup failed"; shutdown(); return false;
    }
    sw = w; sh = h;
    gGpuOn = true;
    return true;
}
static void resize(int w, int h) {
    if (!gGpuOn || (w == sw && h == sh)) return;
    if (FAILED(surf->Resize(w, h))) { gGpuOn = false; return; }
    sw = w; sh = h;
    dc->Commit();
}
// одна полоса из буфера в поверхность
static bool upload(const uint32_t* pix, int stride, const RECT& r) {
    POINT off{};
    IDXGISurface* s = nullptr;
    HRESULT hr = surf->BeginDraw(&r, __uuidof(IDXGISurface), (void**)&s, &off);
    if (FAILED(hr) || !s) return false;
    ID3D11Texture2D* tex = nullptr;
    s->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&tex);
    if (tex) {
        D3D11_BOX box{(UINT)off.x, (UINT)off.y, 0, (UINT)(off.x + r.right - r.left), (UINT)(off.y + r.bottom - r.top), 1};
        ctx->UpdateSubresource(tex, 0, &box, pix + (size_t)r.top * stride + r.left, stride * 4, 0);
        tex->Release();
    }
    s->Release();
    surf->EndDraw();
    return tex != nullptr;
}
// всё стёрто — освобождаем поверхность целиком (она становится прозрачной)
static void clearAll() {
    if (!gGpuOn) return;
    surf->Trim(nullptr, 0);
    dc->Commit();
}
static bool commit() { return gGpuOn && SUCCEEDED(dc->Commit()); }
}  // namespace gpu
