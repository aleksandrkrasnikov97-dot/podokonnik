// Кадры через видеокарту: картинка эффектов попадает на экран через DirectComposition.
// Отправляются только изменившиеся плитки 64×64 (а не весь прямоугольник вокруг них, как у UpdateLayeredWindow),
// склейку с остальным экраном делает видеокарта. Если что-то не так — программа сама возвращается к обычному способу.
#pragma once
#include <d3d11.h>
#include <dxgi1_2.h>
#include <dcomp.h>
#include <d3dcompiler.h>

static bool gGpuWanted = false;  // настройка «Рисовать на видеокарте» (пока новая — выключена, пока не проверим на многих компьютерах)
static bool gGpuOn = false;      // работает сейчас
static std::string gGpuWhy;      // почему не работает (для журнала)
static bool gGpuSprOn = false;   // падающие частицы рисует видеокарта (отдельный слой поверх плиток)

namespace gpu {
static ID3D11Device* dev = nullptr;
static ID3D11DeviceContext* ctx = nullptr;
static IDCompositionDevice* dc = nullptr;
static IDCompositionTarget* target = nullptr;
static IDCompositionVisual* visual = nullptr;
static IDCompositionVirtualSurface* surf = nullptr;
static IDCompositionVisual* root = nullptr;      // корень: плитки (снизу) и частицы (сверху)
static IDCompositionVisual* sprVis = nullptr;
static IDCompositionVirtualSurface* sprSurf = nullptr;
static int sw = 0, sh = 0;

// ---- частицы на видеокарте: все снежинки/листья/капли — один вызов DrawInstanced
struct SprInst { float x, y, hx, hy, c, s, r, g, b, a, cell; };   // центр, полуразмер, поворот, цвет (premultiplied), ячейка атласа
static ID3D11VertexShader* sVS = nullptr;
static ID3D11PixelShader* sPS = nullptr;
static ID3D11InputLayout* sIL = nullptr;
static ID3D11Buffer* sIB = nullptr;
static UINT sIBCap = 0;
static ID3D11Buffer* sCB = nullptr;
static ID3D11Texture2D* sAtlas = nullptr;
static ID3D11ShaderResourceView* sSRV = nullptr;
static ID3D11SamplerState* sSmp = nullptr;
static ID3D11BlendState* sBlend = nullptr;
static ID3D11BlendState* sNoBlend = nullptr;
static ID3D11RasterizerState* sRS = nullptr;
static bool sprDrewLast = false;

template <class T> static void rel(T*& p) { if (p) { p->Release(); p = nullptr; } }
static void sprShutdown() {
    rel(sVS); rel(sPS); rel(sIL); rel(sIB); sIBCap = 0; rel(sCB); rel(sSRV); rel(sAtlas); rel(sSmp); rel(sBlend); rel(sNoBlend); rel(sRS);
    rel(sprSurf); rel(sprVis);
    gGpuSprOn = false; sprDrewLast = false;
}
static void shutdown() {
    sprShutdown();
    rel(surf); rel(visual); rel(root); rel(target); rel(dc); rel(ctx); rel(dev);
    gGpuOn = false;
    sw = sh = 0;
}

typedef HRESULT (WINAPI* D3D11CreateDeviceFn)(IDXGIAdapter*, D3D_DRIVER_TYPE, HMODULE, UINT, const D3D_FEATURE_LEVEL*, UINT, UINT,
                                              ID3D11Device**, D3D_FEATURE_LEVEL*, ID3D11DeviceContext**);
typedef HRESULT (WINAPI* DCompCreateFn)(IDXGIDevice*, REFIID, void**);

// окно уже создано со стилем WS_EX_NOREDIRECTIONBITMAP
static bool init(HWND hwnd, int w, int h) {
    shutdown();
    HMODULE d3d = LoadLibraryW(L"d3d11.dll"), dcm = LoadLibraryW(L"dcomp.dll");
    auto createDev = d3d ? (D3D11CreateDeviceFn)(void*)GetProcAddress(d3d, "D3D11CreateDevice") : nullptr;
    auto createDc = dcm ? (DCompCreateFn)(void*)GetProcAddress(dcm, "DCompositionCreateDevice") : nullptr;
    if (!createDev || !createDc) { gGpuWhy = "no d3d11/dcomp"; return false; }
    HRESULT hr = E_FAIL;
    for (D3D_DRIVER_TYPE dt : {D3D_DRIVER_TYPE_HARDWARE, D3D_DRIVER_TYPE_WARP}) {
        hr = createDev(nullptr, dt, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, nullptr, 0, D3D11_SDK_VERSION, &dev, nullptr, &ctx);
        if (SUCCEEDED(hr)) break;
    }
    if (FAILED(hr) || !dev) { gGpuWhy = "D3D11CreateDevice failed"; shutdown(); return false; }
    IDXGIDevice* dxgi = nullptr;
    dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgi);
    if (!dxgi) { gGpuWhy = "no IDXGIDevice"; shutdown(); return false; }
    hr = createDc(dxgi, __uuidof(IDCompositionDevice), (void**)&dc);
    dxgi->Release();
    if (FAILED(hr) || !dc) { gGpuWhy = "DCompositionCreateDevice failed"; shutdown(); return false; }
    if (FAILED(dc->CreateTargetForHwnd(hwnd, TRUE, &target)) || FAILED(dc->CreateVisual(&root)) || FAILED(dc->CreateVisual(&visual)) ||
        FAILED(dc->CreateVirtualSurface(w, h, DXGI_FORMAT_B8G8R8A8_UNORM, DXGI_ALPHA_MODE_PREMULTIPLIED, &surf)) ||
        FAILED(visual->SetContent(surf)) || FAILED(root->AddVisual(visual, FALSE, nullptr)) || FAILED(target->SetRoot(root)) || FAILED(dc->Commit())) {
        gGpuWhy = "composition setup failed"; shutdown(); return false;
    }
    sw = w; sh = h;
    gGpuOn = true;
    return true;
}
static void resize(int w, int h) {
    if (!gGpuOn || (w == sw && h == sh)) return;
    if (FAILED(surf->Resize(w, h))) { gGpuOn = false; return; }
    if (sprSurf && FAILED(sprSurf->Resize(w, h))) sprShutdown();
    sw = w; sh = h;
    dc->Commit();
}
// одна полоса из буфера в поверхность
static bool upload(const uint32_t* pix, int stride, const RECT& r) {
    POINT off{};
    IDXGISurface* s = nullptr;
    HRESULT hr = surf->BeginDraw(&r, __uuidof(IDXGISurface), (void**)&s, &off);
    if (FAILED(hr) || !s) return false;
    ID3D11Texture2D* tex = nullptr;
    s->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&tex);
    if (tex) {
        D3D11_BOX box{(UINT)off.x, (UINT)off.y, 0, (UINT)(off.x + r.right - r.left), (UINT)(off.y + r.bottom - r.top), 1};
        ctx->UpdateSubresource(tex, 0, &box, pix + (size_t)r.top * stride + r.left, stride * 4, 0);
        tex->Release();
    }
    s->Release();
    surf->EndDraw();
    return tex != nullptr;
}
// всё стёрто — освобождаем поверхность целиком (она становится прозрачной)
static void clearAll() {
    if (!gGpuOn) return;
    surf->Trim(nullptr, 0);
    if (sprSurf && sprDrewLast) { sprSurf->Trim(nullptr, 0); sprDrewLast = false; }
    dc->Commit();
}
static bool commit() { return gGpuOn && SUCCEEDED(dc->Commit()); }

// ---- шейдеры частиц (компилируются при запуске через d3dcompiler_47.dll из Windows)
static const char* kSprHlsl = R"(
cbuffer C : register(b0) { float2 inv; float2 pad; };
struct VI { float2 pos : POS; float2 hs : HALF; float2 cs : ROT; float4 col : COL; float cell : CELL; uint vid : SV_VertexID; };
struct VO { float4 p : SV_Position; float2 uv : TEXCOORD0; float4 col : COLOR0; };
VO vsMain(VI i) {
    float2 q = float2((i.vid & 1) ? 1.0 : -1.0, (i.vid & 2) ? 1.0 : -1.0);
    float2 l = q * i.hs;
    float2 w = float2(l.x * i.cs.x - l.y * i.cs.y, l.x * i.cs.y + l.y * i.cs.x) + i.pos;
    VO o;
    o.p = float4(w.x * inv.x - 1.0, 1.0 - w.y * inv.y, 0.0, 1.0);
    float cx = fmod(i.cell, 8.0), cy = floor(i.cell / 8.0);
    o.uv = (float2(cx, cy) + q * 0.5 + 0.5) / 8.0;
    o.col = i.col;
    return o;
}
Texture2D tex : register(t0);
SamplerState smp : register(s0);
float4 psMain(VO o) : SV_Target { return tex.Sample(smp, o.uv) * o.col; }
)";
typedef HRESULT (WINAPI* D3DCompileFn)(LPCVOID, SIZE_T, LPCSTR, const D3D_SHADER_MACRO*, ID3DInclude*, LPCSTR, LPCSTR, UINT, UINT, ID3DBlob**, ID3DBlob**);
// d — устройство D3D11, atlas — картинка 512×512 (BGRA, premultiplied): 8×8 ячеек по 64 пикселя
static bool sprPipeline(ID3D11Device* d, const uint32_t* atlas) {
    static D3DCompileFn compile = nullptr;
    if (!compile) {
        HMODULE m = LoadLibraryW(L"d3dcompiler_47.dll");
        if (m) compile = (D3DCompileFn)(void*)GetProcAddress(m, "D3DCompile");
    }
    if (!compile) { gGpuWhy = "no d3dcompiler_47"; return false; }
    ID3DBlob *vb = nullptr, *pb = nullptr, *err = nullptr;
    size_t len = strlen(kSprHlsl);
    if (FAILED(compile(kSprHlsl, len, "spr", nullptr, nullptr, "vsMain", "vs_4_0", 0, 0, &vb, &err)) ||
        FAILED(compile(kSprHlsl, len, "spr", nullptr, nullptr, "psMain", "ps_4_0", 0, 0, &pb, &err))) {
        gGpuWhy = std::string("shader: ") + (err ? (const char*)err->GetBufferPointer() : "?");
        rel(vb); rel(pb); rel(err);
        return false;
    }
    bool ok = SUCCEEDED(d->CreateVertexShader(vb->GetBufferPointer(), vb->GetBufferSize(), nullptr, &sVS)) &&
              SUCCEEDED(d->CreatePixelShader(pb->GetBufferPointer(), pb->GetBufferSize(), nullptr, &sPS));
    D3D11_INPUT_ELEMENT_DESC il[] = {
        {"POS", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 0, D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"HALF", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 8, D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"ROT", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 16, D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"COL", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 24, D3D11_INPUT_PER_INSTANCE_DATA, 1},
        {"CELL", 0, DXGI_FORMAT_R32_FLOAT, 0, 40, D3D11_INPUT_PER_INSTANCE_DATA, 1},
    };
    ok = ok && SUCCEEDED(d->CreateInputLayout(il, 5, vb->GetBufferPointer(), vb->GetBufferSize(), &sIL));
    rel(vb); rel(pb); rel(err);
    if (!ok) { gGpuWhy = "shader objects"; return false; }
    D3D11_BUFFER_DESC cb{16, D3D11_USAGE_DYNAMIC, D3D11_BIND_CONSTANT_BUFFER, D3D11_CPU_ACCESS_WRITE, 0, 0};
    if (FAILED(d->CreateBuffer(&cb, nullptr, &sCB))) { gGpuWhy = "cbuffer"; return false; }
    // атлас с мип-уровнями: мелкие снежинки сглаживаются, а не мерцают
    D3D11_TEXTURE2D_DESC td{};
    td.Width = td.Height = 512; td.MipLevels = 0; td.ArraySize = 1; td.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    td.SampleDesc.Count = 1; td.Usage = D3D11_USAGE_DEFAULT;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET; td.MiscFlags = D3D11_RESOURCE_MISC_GENERATE_MIPS;
    if (FAILED(d->CreateTexture2D(&td, nullptr, &sAtlas)) || FAILED(d->CreateShaderResourceView(sAtlas, nullptr, &sSRV))) { gGpuWhy = "atlas"; return false; }
    ID3D11DeviceContext* c = nullptr;
    d->GetImmediateContext(&c);
    c->UpdateSubresource(sAtlas, 0, nullptr, atlas, 512 * 4, 0);
    c->GenerateMips(sSRV);
    c->Release();
    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.MaxLOD = 4;   // глубже — ячейки атласа начнут смешиваться
    sd.ComparisonFunc = D3D11_COMPARISON_NEVER;
    D3D11_BLEND_DESC bd{};
    bd.RenderTarget[0].BlendEnable = TRUE;
    bd.RenderTarget[0].SrcBlend = bd.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bd.RenderTarget[0].DestBlend = bd.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
    bd.RenderTarget[0].BlendOp = bd.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bd.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    D3D11_BLEND_DESC nb = bd;
    nb.RenderTarget[0].BlendEnable = FALSE;
    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.ScissorEnable = TRUE; rd.DepthClipEnable = TRUE;
    if (FAILED(d->CreateSamplerState(&sd, &sSmp)) || FAILED(d->CreateBlendState(&bd, &sBlend)) ||
        FAILED(d->CreateBlendState(&nb, &sNoBlend)) || FAILED(d->CreateRasterizerState(&rd, &sRS))) { gGpuWhy = "states"; return false; }
    return true;
}
// нарисовать частицы в цель rtv: область (ox, oy, w, h); clipY — ниже этой строки не рисовать
static bool sprRender(ID3D11DeviceContext* c, ID3D11RenderTargetView* rtv, int ox, int oy, int w, int h, int clipY,
                      const std::vector<SprInst>& v) {
    ID3D11Device* d = nullptr;
    c->GetDevice(&d);
    UINT need = (UINT)v.size() + 1;
    if (need > sIBCap) {
        rel(sIB);
        UINT cap = std::max<UINT>(1024, need * 2);
        D3D11_BUFFER_DESC bd{(UINT)(cap * sizeof(SprInst)), D3D11_USAGE_DYNAMIC, D3D11_BIND_VERTEX_BUFFER, D3D11_CPU_ACCESS_WRITE, 0, 0};
        if (FAILED(d->CreateBuffer(&bd, nullptr, &sIB))) { d->Release(); return false; }
        sIBCap = cap;
    }
    d->Release();
    D3D11_MAPPED_SUBRESOURCE m{};
    if (FAILED(c->Map(sIB, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) return false;
    // первый экземпляр стирает прошлый кадр: пустая ячейка 63, без смешивания, на весь слой
    SprInst clr{w * 0.5f, h * 0.5f, w * 0.5f + 2, h * 0.5f + 2, 1, 0, 0, 0, 0, 0, 63};
    memcpy(m.pData, &clr, sizeof clr);
    if (!v.empty()) memcpy((SprInst*)m.pData + 1, v.data(), v.size() * sizeof(SprInst));
    c->Unmap(sIB, 0);
    if (SUCCEEDED(c->Map(sCB, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) {
        float k[4] = {2.0f / w, 2.0f / h, 0, 0};
        memcpy(m.pData, k, sizeof k);
        c->Unmap(sCB, 0);
    }
    D3D11_VIEWPORT vp{(float)ox, (float)oy, (float)w, (float)h, 0, 1};
    c->RSSetViewports(1, &vp);
    c->RSSetState(sRS);
    c->OMSetRenderTargets(1, &rtv, nullptr);
    UINT stride = sizeof(SprInst), off = 0;
    c->IASetVertexBuffers(0, 1, &sIB, &stride, &off);
    c->IASetInputLayout(sIL);
    c->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    c->VSSetShader(sVS, nullptr, 0);
    c->VSSetConstantBuffers(0, 1, &sCB);
    c->PSSetShader(sPS, nullptr, 0);
    c->PSSetShaderResources(0, 1, &sSRV);
    c->PSSetSamplers(0, 1, &sSmp);
    float bf[4] = {0, 0, 0, 0};
    D3D11_RECT full{ox, oy, ox + w, oy + h};
    c->RSSetScissorRects(1, &full);
    c->OMSetBlendState(sNoBlend, bf, 0xffffffff);
    c->DrawInstanced(4, 1, 0, 0);
    if (!v.empty()) {
        D3D11_RECT clip{ox, oy, ox + w, oy + std::min(h, clipY)};
        c->RSSetScissorRects(1, &clip);
        c->OMSetBlendState(sBlend, bf, 0xffffffff);
        c->DrawInstanced(4, (UINT)v.size(), 0, 1);
    }
    ID3D11ShaderResourceView* none = nullptr;
    c->PSSetShaderResources(0, 1, &none);
    return true;
}
// слой частиц поверх плиток (включается после gpu::init)
static bool sprInit(const uint32_t* atlas) {
    if (!gGpuOn) return false;
    if (!sprPipeline(dev, atlas)) { sprShutdown(); return false; }
    if (FAILED(dc->CreateVisual(&sprVis)) ||
        FAILED(dc->CreateVirtualSurface(sw, sh, DXGI_FORMAT_B8G8R8A8_UNORM, DXGI_ALPHA_MODE_PREMULTIPLIED, &sprSurf)) ||
        FAILED(sprVis->SetContent(sprSurf)) || FAILED(root->AddVisual(sprVis, TRUE, nullptr)) || FAILED(dc->Commit())) {
        gGpuWhy = "sprite layer"; sprShutdown(); return false;
    }
    gGpuSprOn = true;
    return true;
}
// кадр частиц; false — что-то сломалось (тогда вернёмся к рисованию процессором)
static bool sprFrame(const std::vector<SprInst>& v, int clipY) {
    if (!gGpuSprOn) return false;
    if (v.empty()) {
        if (sprDrewLast) { sprSurf->Trim(nullptr, 0); sprDrewLast = false; }
        return true;
    }
    RECT r{0, 0, sw, sh};
    POINT off{};
    IDXGISurface* s = nullptr;
    if (FAILED(sprSurf->BeginDraw(&r, __uuidof(IDXGISurface), (void**)&s, &off)) || !s) return false;
    ID3D11Texture2D* tex = nullptr;
    s->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&tex);
    ID3D11RenderTargetView* rtv = nullptr;
    bool ok = tex && SUCCEEDED(dev->CreateRenderTargetView(tex, nullptr, &rtv)) &&
              sprRender(ctx, rtv, off.x, off.y, sw, sh, clipY, v);
    ID3D11RenderTargetView* none = nullptr;
    ctx->OMSetRenderTargets(1, &none, nullptr);
    rel(rtv); rel(tex); s->Release();
    sprSurf->EndDraw();
    sprDrewLast = true;
    return ok;
}
}  // namespace gpu
