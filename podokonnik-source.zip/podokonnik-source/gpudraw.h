// Падающие частицы на видеокарте: атлас их картинок (рисуется при запуске теми же функциями, что и на процессоре)
// и перевод частиц в «экземпляры» для одного вызова DrawInstanced (gpu.h).
#pragma once

static std::vector<uint32_t> gSprAtlas;   // 512×512, 8×8 ячеек по 64 пикселя
enum { SC_SNOW = 0, SC_CLUMP = 1, SC_LEAF = 2, SC_PETAL = 3, SC_FLUFF = 4, SC_LINE = 5 };

static void sprAtlasBuild() {
    if (!gSprAtlas.empty()) return;
    gSprAtlas.assign(512 * 512, 0);
    // рисуем в атлас обычными функциями: на время подменяем буфер кадра
    uint32_t* oPix = gPix; int oW = gW, oH = gH, oTW = gTW, oTH = gTH, oClip = gClipY;
    std::vector<uint8_t> oTiles; oTiles.swap(gTileNow);
    gPix = gSprAtlas.data(); gW = gH = 512; gTW = gTH = 512 >> kTileShift; gClipY = INT_MAX;
    gTileNow.assign((size_t)gTW * gTH, 0);
    auto at = [](int i, float& cx, float& cy) { cx = (i % 8) * 64 + 32.0f; cy = (i / 8) * 64 + 32.0f; };
    float cx, cy;
    at(SC_SNOW, cx, cy);  drawDisc(cx, cy, 26, 255, 255, 255, 1, 1.4f, 0);
    at(SC_CLUMP, cx, cy); drawDisc(cx, cy, 26, 248, 250, 255, 1, 1.0f, 0.25f);
    at(SC_LEAF, cx, cy);  drawLeaf(cx, cy, 60, 32, 0, 255, 255, 255, 1, true);
    at(SC_PETAL, cx, cy); drawLeaf(cx, cy, 60, 44, 0, 255, 255, 255, 1, false);
    at(SC_FLUFF, cx, cy);   // пушинка одуванчика при r = 10
    for (int i = 0; i < 8; ++i) {
        float ang = -PI * 0.5f + (i - 3.5f) * 0.32f;
        float ex = cx + std::cos(ang) * 16, ey = cy + std::sin(ang) * 16;
        drawLine(cx, cy, ex, ey, 0.9f, 245, 245, 240, 0.55f);
        drawDisc(ex, ey, 1.4f, 250, 250, 248, 0.7f, 1, 0);
    }
    drawLine(cx, cy, cx, cy + 13, 0.9f, 200, 190, 160, 0.8f);
    drawDisc(cx, cy + 13, 1.8f, 150, 120, 80, 1, 1, 0);
    at(SC_LINE, cx, cy);    // вертикальная черта шириной ~8 px: капли дождя и щепки
    for (int y = (int)cy - 30; y < (int)cy + 30; ++y)
        for (int x = (int)cx - 5; x < (int)cx + 5; ++x) {
            float a = clampf(4.0f - std::fabs(x + 0.5f - cx), 0, 1) * clampf((30 - std::fabs(y + 0.5f - cy)) / 3.0f, 0, 1);
            if (a > 0) blendPx(x, y, 255, 255, 255, a);
        }
    gPix = oPix; gW = oW; gH = oH; gTW = oTW; gTH = oTH; gClipY = oClip;
    gTileNow.swap(oTiles);
}

static std::vector<gpu::SprInst> gSprInst;
static void gpuParticlesBuild() {
    auto& v = gSprInst;
    v.clear();
    v.reserve(gP.size() + 16);
    auto add = [&](float x, float y, float hx, float hy, float ang, float R, float G, float B, float a, int cell) {
        if (a <= 0.003f || hx <= 0 || hy <= 0) return;
        if (x + hx * 1.5f + hy < 0 || y + hx + hy * 1.5f < 0 || x - hx * 1.5f - hy > gW || y - hx - hy * 1.5f > gH) return;
        float c = 1, s = 0;
        if (ang != 0) { c = std::cos(ang); s = std::sin(ang); }
        a = std::min(a, 1.0f);
        v.push_back({x, y, hx, hy, c, s, R / 255.0f * a, G / 255.0f * a, B / 255.0f * a, a, (float)cell});
    };
    // черта от (x0, y0) до (x1, y1) шириной w
    auto line = [&](float x0, float y0, float x1, float y1, float w, float R, float G, float B, float a) {
        float dx = x1 - x0, dy = y1 - y0, L = std::sqrt(dx * dx + dy * dy);
        if (L < 0.01f) return;
        float c = dy / L, s = -dx / L;   // ось Y черты вдоль отрезка
        if (a <= 0.003f) return;
        v.push_back({(x0 + x1) * 0.5f, (y0 + y1) * 0.5f, 32.0f * w / 8.0f, L * 0.5f * 32.0f / 30.0f, c, s,
                     R / 255.0f * a, G / 255.0f * a, B / 255.0f * a, a, (float)SC_LINE});
    };
    const size_t np = sizeof(kPal) / sizeof(kPal[0]);
    for (const P& p : gP) {
        float x = p.x - gVX, y = p.y - gVY;
        switch (p.type) {
        case T_SNOW: case T_CLUMP:
            if (p.clump) add(x, y, p.r * 32 / 26, p.r * 32 / 26, 0, 255, 255, 255, 1.0f, SC_CLUMP);
            else add(x, y, p.r * 32 / 26, p.r * 32 / 26, 0, 255, 255, 255, p.a, SC_SNOW);
            break;
        case T_LEAF: {
            const RGB8& c = kPal[p.col % np];
            float flip = 0.35f + 0.65f * std::fabs(std::cos(p.ph * 0.5f + p.z * 3));
            float len = p.r * 2.3f, wid = p.r * 1.25f * flip;
            add(x, y, 32 * len / 60, wid, p.rot, c.r, c.g, c.b, p.a, SC_LEAF);
            break;
        }
        case T_PETAL: {
            const RGB8& c = kPal[p.col % np];
            float flip = 0.3f + 0.7f * std::fabs(std::cos(p.ph * 0.8f + p.z * 3));
            float len = p.r * 1.7f, wid = p.r * 1.25f * flip;
            add(x, y, 32 * len / 60, 32 * wid / 44, p.rot, c.r, c.g, c.b, p.a, SC_PETAL);
            break;
        }
        case T_FLUFF: {
            float a = p.a * clampf(p.life / 3.0f, 0, 1);
            add(x, y, 32 * p.r / 10, 32 * p.r / 10, std::sin(p.ph) * 0.1f, 255, 255, 255, a, SC_FLUFF);
            break;
        }
        case T_RAIN: {
            float w = baseWind() * 1.6f, len = 12 * S;
            float nx = w / p.vy, n = std::sqrt(1 + nx * nx);
            line(x, y, x - nx / n * len, y - len / n, 1.1f * S, 200, 215, 238, p.a);
            break;
        }
        case T_DROP:
            add(x, y, 0.8f * S * 32 / 26, 0.8f * S * 32 / 26, 0, 210, 225, 245, p.a * clampf(p.life / 0.45f, 0, 1), SC_SNOW);
            break;
        case T_BIT: {
            const RGB8& c = kPal[p.col % np];
            float ca = std::cos(p.rot) * 1.6f * S, sa = std::sin(p.rot) * 1.6f * S;
            line(x - ca, y - sa, x + ca, y + sa, 1.1f * S, c.r, c.g, c.b, 0.9f);
            break;
        }
        }
    }
}

#ifdef SUGROB_GPUTEST
static void drawParticles();
// проверка без DirectComposition (например, в Wine): частицы рисуются видеокартой в текстуру и процессором в буфер,
// обе картинки сохраняются в C:\gputest_gpu.bmp и C:\gputest_cpu.bmp
static void saveBmp(const wchar_t* path, const uint32_t* px, int w, int h) {
    FILE* f = _wfopen(path, L"wb");
    if (!f) return;
    BITMAPFILEHEADER fh{}; BITMAPINFOHEADER ih{};
    fh.bfType = 0x4D42; fh.bfOffBits = sizeof fh + sizeof ih; fh.bfSize = fh.bfOffBits + w * h * 4;
    ih.biSize = sizeof ih; ih.biWidth = w; ih.biHeight = -h; ih.biPlanes = 1; ih.biBitCount = 32;
    fwrite(&fh, sizeof fh, 1, f); fwrite(&ih, sizeof ih, 1, f);
    // на тёмно-синем фоне, чтобы было видно белое
    std::vector<uint32_t> o((size_t)w * h);
    for (size_t i = 0; i < o.size(); ++i) {
        uint32_t p = px[i]; float a = (p >> 24) / 255.0f;
        int b = (int)((p & 255) + 60 * (1 - a)), g = (int)(((p >> 8) & 255) + 40 * (1 - a)), r = (int)(((p >> 16) & 255) + 25 * (1 - a));
        o[i] = 0xff000000u | (std::min(r, 255) << 16) | (std::min(g, 255) << 8) | std::min(b, 255);
    }
    fwrite(o.data(), 4, o.size(), f);
    fclose(f);
}
static void gpuSelfTest() {
    sprAtlasBuild();
    saveBmp(L"C:\\gputest_atlas.bmp", gSprAtlas.data(), 512, 512);
    ID3D11Device* d = nullptr; ID3D11DeviceContext* c = nullptr;
    HRESULT hr = E_FAIL;
    for (D3D_DRIVER_TYPE dt : {D3D_DRIVER_TYPE_HARDWARE, D3D_DRIVER_TYPE_WARP})
        if (SUCCEEDED(hr = D3D11CreateDevice(nullptr, dt, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, nullptr, 0, D3D11_SDK_VERSION, &d, nullptr, &c))) break;
    if (FAILED(hr)) { alogFwd("gputest: no device"); return; }
    if (!gpu::sprPipeline(d, gSprAtlas.data())) { alogFwd("gputest: pipeline failed: %s", gGpuWhy.c_str()); return; }
    D3D11_TEXTURE2D_DESC td{};
    td.Width = gW; td.Height = gH; td.MipLevels = 1; td.ArraySize = 1; td.Format = DXGI_FORMAT_B8G8R8A8_UNORM; td.SampleDesc.Count = 1;
    td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_RENDER_TARGET;
    ID3D11Texture2D* rt = nullptr; ID3D11RenderTargetView* rtv = nullptr;
    d->CreateTexture2D(&td, nullptr, &rt);
    d->CreateRenderTargetView(rt, nullptr, &rtv);
    gpuParticlesBuild();
    bool ok = gpu::sprRender(c, rtv, 0, 0, gW, gH, gClipY, gSprInst);
    td.Usage = D3D11_USAGE_STAGING; td.BindFlags = 0; td.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    ID3D11Texture2D* st = nullptr;
    d->CreateTexture2D(&td, nullptr, &st);
    c->CopyResource(st, rt);
    D3D11_MAPPED_SUBRESOURCE m{};
    std::vector<uint32_t> img((size_t)gW * gH);
    if (SUCCEEDED(c->Map(st, 0, D3D11_MAP_READ, 0, &m))) {
        for (int y = 0; y < gH; ++y) memcpy(&img[(size_t)y * gW], (uint8_t*)m.pData + (size_t)y * m.RowPitch, gW * 4);
        c->Unmap(st, 0);
    }
    saveBmp(L"C:\\gputest_gpu.bmp", img.data(), gW, gH);
    // то же процессором
    std::vector<uint32_t> cpu((size_t)gW * gH, 0);
    uint32_t* o = gPix; gPix = cpu.data();
    drawParticles();
    gPix = o;
    saveBmp(L"C:\\gputest_cpu.bmp", cpu.data(), gW, gH);
    alogFwd("gputest: render %s, %zu particles", ok ? "ok" : "FAILED", gSprInst.size());
}
#endif
