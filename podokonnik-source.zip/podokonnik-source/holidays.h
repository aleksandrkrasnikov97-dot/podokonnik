// Праздники: Новый год (гирлянды, отсчёт, салют в полночь), Рождество, Тет, День влюблённых, 8 Марта,
// Масленица, Пасха, Хэллоуин и свой праздник (шарики, конфетти, цветы или салют).
// Включаются сами по датам или вручную — когда захочешь. Салют можно запустить в любой момент.
#pragma once

enum { H_NONE = 0, H_NY = 1, H_TET = 2, H_HAL = 3, H_VAL = 4, H_XMAS = 5, H_WOMEN = 6, H_MASL = 7, H_EASTER = 8, H_CUSTOM = 9, H_LAST = 9 };
// режим: 0 — выкл, 1 — по датам, 2…10 — праздник (номер праздника + 1)
static int gHolidayMode = 0;
static bool gCountdownOn = false;    // отсчёт до Нового года и поздравления
static int gHoliday = H_NONE;
static float gHolChk = 99;           // проверить праздник прямо сейчас — выставить большое значение
// свой праздник: день и месяц (0 — не задан), эффект и надпись
static int gCustDay = 0, gCustMon = 0;
static int gCustFx = 0;              // 0 — шарики, 1 — конфетти, 2 — цветы, 3 — салют
static std::wstring gCustText;
static float gFwManual = 0;          // салют по кнопке: сколько секунд ещё

static int dayNumber(int y, int m, int d) {   // дни от условного начала (для сравнения дат)
    SYSTEMTIME st{}; st.wYear = (WORD)y; st.wMonth = (WORD)m; st.wDay = (WORD)d;
    FILETIME ft; SystemTimeToFileTime(&st, &ft);
    ULARGE_INTEGER u; u.LowPart = ft.dwLowDateTime; u.HighPart = ft.dwHighDateTime;
    return (int)(u.QuadPart / 864000000000ULL);
}
// Тет (Лунный Новый год) по годам
static int tetDay(int y) {
    static const int T[][3] = {{2026, 2, 17}, {2027, 2, 6}, {2028, 1, 26}, {2029, 2, 13}, {2030, 2, 3}, {2031, 1, 23},
                               {2032, 2, 11}, {2033, 1, 31}, {2034, 2, 19}, {2035, 2, 8}, {2036, 1, 28}};
    for (auto& t : T) if (t[0] == y) return dayNumber(t[0], t[1], t[2]);
    return dayNumber(y, 2, 5);
}
// православная Пасха (алгоритм Меёса по юлианскому календарю + 13 дней)
static int easterDay(int y) {
    int a = y % 4, b = y % 7, c = y % 19, d = (19 * c + 15) % 30, e = (2 * a + 4 * b - d + 34) % 7;
    int month = (d + e + 114) / 31, day = (d + e + 114) % 31 + 1;
    return dayNumber(y, month, day) + 13;
}
static int holidayByDate() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    int m = st.wMonth, d = st.wDay;
    int today = dayNumber(st.wYear, m, d), tet = tetDay(st.wYear), easter = easterDay(st.wYear);
    if (gCustMon && m == gCustMon && d == gCustDay) return H_CUSTOM;
    if (today >= tet - 7 && today <= tet + 7) return H_TET;
    if ((m == 12 && (d == 24 || d == 25)) || (m == 1 && d >= 6 && d <= 8)) return H_XMAS;
    if ((m == 12 && d >= 15) || (m == 1 && d <= 10)) return H_NY;
    if (today >= easter && today <= easter + 7) return H_EASTER;
    if (today >= easter - 55 && today <= easter - 49) return H_MASL;
    if (m == 3 && d >= 6 && d <= 8) return H_WOMEN;
    if (m == 2 && d >= 10 && d <= 15) return H_VAL;
    if ((m == 10 && d >= 24) || (m == 11 && d == 1)) return H_HAL;
    return H_NONE;
}
static int activeHoliday() {
    if (gHolidayMode <= 0) return H_NONE;
    if (gHolidayMode == 1) return holidayByDate();
    return std::min(gHolidayMode - 1, (int)H_LAST);
}
static bool holidayActive() { return gHoliday != H_NONE; }
static bool holidayNeedsWindows() { return gHoliday == H_NY || gHoliday == H_HAL || gHoliday == H_XMAS; }

// ---------------------------------------------------------------- фигуры
// многоугольник со сглаженными краями (любой, в том числе звезда)
static void fillPoly(const float* px, const float* py, int n, float R, float G, float B, float a) {
    float x0 = px[0], x1 = px[0], y0 = py[0], y1 = py[0];
    for (int i = 1; i < n; ++i) { x0 = std::min(x0, px[i]); x1 = std::max(x1, px[i]); y0 = std::min(y0, py[i]); y1 = std::max(y1, py[i]); }
    int X0 = std::max(0, (int)std::floor(x0) - 1), X1 = std::min(gW - 1, (int)std::ceil(x1) + 1);
    int Y0 = std::max(0, (int)std::floor(y0) - 1), Y1 = std::min(gH - 1, (int)std::ceil(y1) + 1);
    for (int Y = Y0; Y <= Y1; ++Y)
        for (int X = X0; X <= X1; ++X) {
            float x = X + 0.5f, y = Y + 0.5f, md = 1e9f;
            bool in = false;
            for (int i = 0, j = n - 1; i < n; j = i++) {
                float ax = px[j], ay = py[j], bx = px[i], by = py[i];
                if (((ay > y) != (by > y)) && (x < (bx - ax) * (y - ay) / (by - ay) + ax)) in = !in;
                float ex = bx - ax, ey = by - ay, l2 = ex * ex + ey * ey;
                float t = l2 > 0 ? clampf(((x - ax) * ex + (y - ay) * ey) / l2, 0, 1) : 0;
                float dx = x - ax - ex * t, dy = y - ay - ey * t;
                md = std::min(md, dx * dx + dy * dy);
            }
            float sd = std::sqrt(md) * (in ? 1 : -1);
            float cov = clampf(sd + 0.5f, 0, 1);
            if (cov > 0) blendPx(X, Y, R, G, B, a * cov);
        }
}
static void drawStar(float cx, float cy, float r, float rot, float R, float G, float B, float a) {
    float xs[10], ys[10];
    for (int i = 0; i < 10; ++i) {
        float an = rot - PI / 2 + i * PI / 5, rr = (i & 1) ? r * 0.45f : r;
        xs[i] = cx + std::cos(an) * rr; ys[i] = cy + std::sin(an) * rr;
    }
    fillPoly(xs, ys, 10, R, G, B, a);
}
// повёрнутый прямоугольник (конфетти)
static void fillRectRot(float cx, float cy, float hw, float hh, float ang, float R, float G, float B, float a) {
    float c = std::cos(ang), s = std::sin(ang);
    float xs[4] = {cx + (-hw) * c - (-hh) * s, cx + hw * c - (-hh) * s, cx + hw * c - hh * s, cx + (-hw) * c - hh * s};
    float ys[4] = {cy + (-hw) * s + (-hh) * c, cy + hw * s + (-hh) * c, cy + hw * s + hh * c, cy + (-hw) * s + hh * c};
    fillPoly(xs, ys, 4, R, G, B, a);
}

static void drawHeart(float cx, float cy, float sz, float R, float G, float B, float a, float rot) {
    int r = (int)std::ceil(sz * 1.4f) + 1;
    float ca = std::cos(rot), sa = std::sin(rot);
    for (int Y = (int)cy - r; Y <= (int)cy + r; ++Y)
        for (int X = (int)cx - r; X <= (int)cx + r; ++X) {
            float dx = (X + 0.5f - cx) / sz, dy = (Y + 0.5f - cy) / sz;
            float x = dx * ca + dy * sa, y = -(-dx * sa + dy * ca) + 0.15f;
            float q = x * x + y * y - 1;
            float f = q * q * q - x * x * y * y * y;
            float cov = clampf(-f * 6.0f + 0.5f, 0, 1);
            if (cov > 0) blendPx(X, Y, R, G, B, a * cov * (0.85f + 0.15f * clampf(y, -1, 1)));
        }
}
// цветок из пяти лепестков (абрикос на Тет, цветы на свой праздник)
static void drawFlower5(float cx, float cy, float sz, float a, float rot, RGB8 petal, RGB8 mid) {
    for (int i = 0; i < 5; ++i) {
        float an = rot + i * 6.2831853f / 5;
        drawDisc(cx + std::cos(an) * sz * 0.6f, cy + std::sin(an) * sz * 0.6f, sz * 0.55f, petal.r, petal.g, petal.b, a, 1, 0);
    }
    drawDisc(cx, cy, sz * 0.32f, mid.r, mid.g, mid.b, a, 1, 0);
}
static void drawBlossom(float cx, float cy, float sz, float a, float rot) { drawFlower5(cx, cy, sz, a, rot, {255, 214, 40}, {230, 120, 20}); }

// тюльпан: три лепестка-бутона и стебель с листом
static void drawTulip(float x, float y, float s, float rot, RGB8 c) {
    float ux = std::sin(rot), uy = -std::cos(rot);   // «вверх» цветка
    float vx = -uy, vy = ux;
    thinLine(x - ux * s * 0.4f, y - uy * s * 0.4f, x - ux * s * 2.0f, y - uy * s * 2.0f, 70, 140, 50, 1);
    thinLine(x - ux * s * 0.4f + vx * 0.8f, y - uy * s * 0.4f + vy * 0.8f, x - ux * s * 2.0f + vx * 0.8f, y - uy * s * 2.0f + vy * 0.8f, 70, 140, 50, 0.8f);
    float lx = x - ux * s * 1.5f, ly = y - uy * s * 1.5f;
    drawLeaf(lx + vx * s * 0.35f, ly + vy * s * 0.35f, s * 1.3f, s * 0.38f, std::atan2(uy + vy * 0.9f, ux + vx * 0.9f), 80, 160, 60, 1, false);
    float up = std::atan2(uy, ux);
    drawLeaf(x - vx * s * 0.28f, y - vy * s * 0.28f, s * 1.45f, s * 0.75f, up - 0.32f, c.r * 0.85f, c.g * 0.85f, c.b * 0.85f, 1, false);
    drawLeaf(x + vx * s * 0.28f, y + vy * s * 0.28f, s * 1.45f, s * 0.75f, up + 0.32f, c.r * 0.85f, c.g * 0.85f, c.b * 0.85f, 1, false);
    drawLeaf(x + ux * s * 0.05f, y + uy * s * 0.05f, s * 1.5f, s * 0.95f, up, c.r, c.g, c.b, 1, false);
}
// веточка мимозы: пушистые жёлтые шарики
static void drawMimosa(float x, float y, float s, float rot) {
    float ca = std::cos(rot), sa = std::sin(rot);
    thinLine(x - ca * s * 1.4f, y - sa * s * 1.4f, x + ca * s * 1.4f, y + sa * s * 1.4f, 90, 140, 60, 1);
    drawLeaf(x - sa * s * 0.6f, y + ca * s * 0.6f, s * 1.4f, s * 0.35f, rot + 0.5f, 110, 160, 90, 0.9f, true);
    static const float o[7][2] = {{0, 0}, {0.9f, -0.3f}, {-0.9f, -0.2f}, {0.4f, -0.8f}, {-0.4f, -0.75f}, {1.3f, 0.3f}, {-1.3f, 0.35f}};
    for (auto& p : o) {
        float px = x + (p[0] * ca - p[1] * sa) * s * 0.7f, py = y + (p[0] * sa + p[1] * ca) * s * 0.7f;
        drawDisc(px, py, s * 0.33f, 250, 215, 40, 1, 1.4f, 0);
        drawDisc(px - s * 0.08f, py - s * 0.08f, s * 0.14f, 255, 245, 140, 0.8f, 1, 0);
    }
}
// блин: золотистый круг с подрумяненными пятнами, крутится в полёте
static void drawPancake(float x, float y, float s, float flip, uint32_t seed) {
    float ry = s * (0.25f + 0.75f * std::fabs(std::cos(flip)));
    drawEllipse(x, y, s, ry, 230, 170, 70, 1);
    drawEllipse(x, y, s * 0.86f, ry * 0.86f, 245, 196, 100, 1);
    for (int k = 0; k < 6; ++k) {
        uint32_t h = hash2((int)seed, k);
        float a = (h & 1023) / 1023.0f * 6.28f, d = ((h >> 10) & 1023) / 1023.0f * 0.7f;
        drawEllipse(x + std::cos(a) * d * s, y + std::sin(a) * d * ry, s * 0.13f, std::max(0.6f, ry * 0.13f), 200, 130, 50, 0.7f);
    }
}
// пасхальное яйцо с узором
static void drawEgg(float cx, float cy, float s, float rot, RGB8 c1, RGB8 c2, int pat) {
    float rx = s * 0.72f, ry = s;
    int r = (int)std::ceil(s * 1.2f) + 2;
    float ca = std::cos(rot), sa = std::sin(rot);
    for (int Y = (int)cy - r; Y <= (int)cy + r; ++Y)
        for (int X = (int)cx - r; X <= (int)cx + r; ++X) {
            float dx = X + 0.5f - cx, dy = Y + 0.5f - cy;
            float u = dx * ca + dy * sa, v = -dx * sa + dy * ca;     // v < 0 — узкий верх
            float rxv = rx * (1.0f + 0.16f * v / ry);
            float d = std::sqrt((u / rxv) * (u / rxv) + (v / ry) * (v / ry));
            float cov = clampf((1 - d) * std::min(rxv, ry) + 0.5f, 0, 1);
            if (cov <= 0) continue;
            float t = (v / ry + 1) * 0.5f;
            bool alt = false;
            if (pat == 0) alt = ((int)(t * 6)) & 1;                                    // полосы
            else if (pat == 1) alt = std::fabs(std::fmod(t * 5 + 10, 1.0f) - 0.5f) < 0.12f + 0.1f * std::sin(u / rx * 9);   // волны
            else { float gx = std::fmod(u / rx * 3 + 10, 1.0f) - 0.5f, gy = std::fmod(t * 5 + 10, 1.0f) - 0.5f; alt = gx * gx + gy * gy < 0.07f; }   // горошек
            const RGB8& c = alt ? c2 : c1;
            float l = 1.0f - 0.25f * clampf(0.5f + 0.5f * u / rx + 0.3f * v / ry, 0, 1);
            blendPx(X, Y, c.r * l, c.g * l, c.b * l, cov);
        }
    drawEllipse(cx - s * 0.25f, cy - s * 0.35f, s * 0.12f, s * 0.2f, 255, 255, 255, 0.35f);
}
// воздушный шарик на ниточке
static void drawBalloon(float x, float y, float s, float sway, RGB8 c) {
    float sx = x + std::sin(sway) * s * 0.6f;
    for (int k = 0; k < 14; ++k) {   // ниточка
        float t0 = k / 14.0f, t1 = (k + 1) / 14.0f;
        float y0 = y + s * 1.05f + t0 * s * 2.6f, y1 = y + s * 1.05f + t1 * s * 2.6f;
        float x0 = x + std::sin(sway + t0 * 4) * s * 0.18f * t0, x1 = x + std::sin(sway + t1 * 4) * s * 0.18f * t1;
        thinLine(x0, y0, x1, y1, 120, 120, 130, 0.8f);
    }
    (void)sx;
    float tx[3] = {x - s * 0.16f, x + s * 0.16f, x}, ty[3] = {y + s * 1.08f, y + s * 1.08f, y + s * 0.88f};
    fillPoly(tx, ty, 3, c.r * 0.8f, c.g * 0.8f, c.b * 0.8f, 1);
    drawEllipse(x, y, s * 0.78f, s * 0.95f, c.r, c.g, c.b, 0.96f);
    drawEllipse(x - s * 0.28f, y - s * 0.38f, s * 0.16f, s * 0.26f, 255, 255, 255, 0.45f);
}

// ---------------------------------------------------------------- то, что падает или летит
// kind: 0 сердце, 1 цветок абрикоса, 2 звезда, 3 тюльпан, 4 мимоза, 5 блин, 6 яйцо, 7 конфетти, 8 цветок, 9 шарик
struct HFall { float x, y, vx, vy, ph, sz, rot, vr; uint8_t col, kind; uint32_t seed; };
static std::vector<HFall> gHFall;
struct Bat { float x, y, vx, ph, sz, baseY; };
static std::vector<Bat> gBats;
static float gBatTimer = 6;
// салют: ракеты и искры
struct Spark { float x, y, vx, vy, life, max, sz; uint8_t r, g, b, type; };   // type: 0 искра, 1 ракета, 2 вспышка
static std::vector<Spark> gSparks;
static float gFwNext = 0;

static const RGB8 kFestive[] = {{255, 70, 90}, {255, 190, 50}, {80, 200, 120}, {80, 160, 255}, {200, 110, 255}, {255, 130, 200}, {60, 220, 230}, {255, 255, 255}};

// салют сейчас: по кнопке, в первые 10 минут Нового года или как эффект своего праздника
static bool fireworksNow() {
    if (gFwManual > 0) return true;
    if (gHoliday == H_CUSTOM && gCustFx == 3) return true;
    if (gHoliday == H_NY) {
        SYSTEMTIME st; GetLocalTime(&st);
        if (st.wMonth == 1 && st.wDay == 1 && st.wHour == 0 && st.wMinute < 10) return true;
    }
    return false;
}
static bool holidayBusy() { return gHoliday != H_NONE || !gSparks.empty() || gFwManual > 0; }

static void launchRocket() {
    if (gMons.empty()) return;
    const RECT& m = gMons[xr() % gMons.size()];
    float w = (float)(m.right - m.left), h = (float)(m.bottom - m.top);
    Spark r{};
    r.type = 1;
    r.x = m.left + w * frange(0.12f, 0.88f);
    r.y = (float)m.bottom - 30 * S;
    float g = 420 * S, rise = h * frange(0.45f, 0.75f);
    r.vy = -std::sqrt(2 * g * rise);
    r.vx = frange(-40, 40) * S;
    r.life = r.max = 9;
    const RGB8& c = kFestive[xr() % 8];
    r.r = c.r; r.g = c.g; r.b = c.b; r.sz = 2.2f * S;
    gSparks.push_back(r);
}
static void explode(const Spark& r) {
    int n = liteNow() ? 40 : 75;
    bool ring = frand() < 0.3f, two = frand() < 0.4f;
    const RGB8& c1 = kFestive[xr() % 8];
    const RGB8& c2 = kFestive[xr() % 8];
    float sp = frange(150, 250) * S;
    for (int i = 0; i < n; ++i) {
        Spark s{};
        float a = frand() * 6.2832f, v = ring ? sp * frange(0.92f, 1.0f) : sp * std::sqrt(frand());
        s.x = r.x; s.y = r.y; s.vx = std::cos(a) * v; s.vy = std::sin(a) * v;
        s.life = s.max = frange(1.2f, 2.1f);
        const RGB8& c = (two && (i & 1)) ? c2 : c1;
        s.r = c.r; s.g = c.g; s.b = c.b; s.sz = frange(1.1f, 1.8f) * S;
        gSparks.push_back(s);
    }
    Spark f{};
    f.type = 2; f.x = r.x; f.y = r.y; f.life = f.max = 0.25f; f.sz = sp * 0.45f; f.r = c1.r; f.g = c1.g; f.b = c1.b;
    gSparks.push_back(f);
}
static void updateFireworks(float dt) {
    if (gFwManual > 0) gFwManual = std::max(0.0f, gFwManual - dt);
    if (fireworksNow()) {
        gFwNext -= dt;
        if (gFwNext <= 0) {
            int burst = 1 + (frand() < 0.35f ? 1 + (int)(xr() % 2) : 0);
            for (int i = 0; i < burst && gSparks.size() < 1600; ++i) launchRocket();
            gFwNext = frange(0.45f, 1.3f) / std::max(1.0f, (float)gMons.size() * 0.7f);
        }
    }
    std::vector<Spark> born;
    for (auto& s : gSparks) {
        s.life -= dt;
        if (s.type == 1) {
            s.vy += 420 * S * dt;
            s.x += s.vx * dt; s.y += s.vy * dt;
            if (s.vy > -40 * S) { s.life = 0; born.push_back(s); }
        } else if (s.type == 0) {
            float drag = std::exp(-1.3f * dt);
            s.vx *= drag; s.vy = s.vy * drag + 110 * S * dt;
            s.x += s.vx * dt; s.y += s.vy * dt;
        }
    }
    gSparks.erase(std::remove_if(gSparks.begin(), gSparks.end(), [](const Spark& s) { return s.life <= 0; }), gSparks.end());
    for (auto& r : born) explode(r);
}
static void drawFireworks() {
    for (auto& s : gSparks) {
        float X = s.x - gVX, Y = s.y - gVY;
        if (s.type == 1) {
            thinLine(X, Y, X - s.vx * 0.06f, Y - s.vy * 0.06f, 255, 220, 160, 0.7f);
            drawDisc(X, Y, s.sz, 255, 240, 200, 1, 1, 0);
        } else if (s.type == 2) {
            float k = s.life / s.max;
            drawDisc(X, Y, s.sz * (1.2f - k * 0.5f), s.r, s.g, s.b, 0.10f * k, s.sz * 0.8f, 0);
        } else {
            float k = clampf(s.life / s.max, 0, 1);
            float a = k < 0.3f ? k / 0.3f : 1.0f;
            if (k < 0.25f && ((int)(s.life * 30 + s.x) & 1)) a *= 0.3f;   // мерцание в конце
            thinLine(X, Y, X - s.vx * 0.05f, Y - s.vy * 0.05f, s.r, s.g, s.b, 0.45f * a);
            drawDisc(X, Y, s.sz, 255 - (255 - s.r) * 0.6f, 255 - (255 - s.g) * 0.6f, 255 - (255 - s.b) * 0.6f, a, 1, 0);
        }
    }
}

// что падает на этот праздник
static int fallKind() {
    switch (gHoliday) {
    case H_VAL: return 0;
    case H_TET: return 1;
    case H_XMAS: return 2;
    case H_WOMEN: return frand() < 0.6f ? 3 : 4;
    case H_MASL: return 5;
    case H_EASTER: return 6;
    case H_CUSTOM: return gCustFx == 0 ? 9 : gCustFx == 1 ? 7 : gCustFx == 2 ? 8 : -1;
    }
    return -1;
}

static void holidayUpdate(float dt) {
    {   // смена праздника: раз в несколько секунд
        gHolChk += dt;
        if (gHolChk > 5) { gHolChk = 0; int h = activeHoliday(); if (h != gHoliday) { gHoliday = h; gHFall.clear(); gBats.clear(); } }
    }
    updateFireworks(dt);
    if (!gHoliday) return;
    float width = gW / 1000.0f / S;
    int k0 = fallKind();
    if (k0 >= 0) {
        static float acc = 0;
        float rate = k0 == 7 ? 9.0f : k0 == 9 ? 0.45f : k0 == 5 || k0 == 6 ? 0.9f : k0 == 2 ? 1.2f : 1.6f;
        size_t cap = k0 == 7 ? 420 : k0 == 9 ? 26 : 120;
        if (liteNow()) { rate *= 0.6f; cap = cap * 2 / 3; }
        acc += dt * rate * width;
        while (acc >= 1) {
            acc -= 1;
            if (gHFall.size() >= cap) continue;
            HFall f{};
            f.kind = (uint8_t)(k0 == 3 || k0 == 4 ? fallKind() : k0);
            f.ph = frange(0, 6.28f); f.rot = frange(-0.4f, 0.4f); f.vr = frange(-0.8f, 0.8f);
            f.seed = xr();
            f.col = (uint8_t)(xr() % 8);
            if (f.kind == 9) {   // шарики поднимаются снизу
                const RECT& m = gMons[xr() % gMons.size()];
                f.x = m.left + frand() * (m.right - m.left); f.y = m.bottom + 60 * S;
                f.vy = -frange(45, 85) * S; f.sz = frange(16, 24) * S;
            } else {
                f.x = gVX + frand() * gW; f.y = gVY - 30 * S;
                f.vy = frange(28, 55) * S; f.sz = frange(4, 8) * S;
                if (f.kind == 7) { f.vy = frange(60, 110) * S; f.sz = frange(3, 5) * S; f.vr = frange(-5, 5); }
                if (f.kind == 3 || f.kind == 4) f.sz = frange(7, 10) * S;
                if (f.kind == 5) { f.sz = frange(9, 13) * S; f.vr = frange(1.5f, 3.5f); }
                if (f.kind == 6) f.sz = frange(9, 13) * S;
                if (f.kind == 2) f.sz = frange(5, 9) * S;
                if (f.kind == 8) f.sz = frange(5, 9) * S;
            }
            gHFall.push_back(f);
        }
        for (auto& f : gHFall) {
            f.ph += dt * (f.kind == 7 ? 6.0f : 1.3f);
            f.y += f.vy * dt;
            f.x += (std::sin(f.ph) * (f.kind == 9 ? 14 : 30) * S + baseWind() * (f.kind == 9 ? 0.15f : 0.4f)) * dt;
            f.rot += f.vr * dt;
        }
        gHFall.erase(std::remove_if(gHFall.begin(), gHFall.end(), [](const HFall& f) {
            return f.kind == 9 ? f.y < gVY - 120 * S : f.y > gVY + gH + 30 * S; }), gHFall.end());
    } else if (!gHFall.empty()) gHFall.clear();
    if (gHoliday == H_HAL) {
        gBatTimer -= dt;
        if (gBatTimer <= 0) {
            gBatTimer = frange(10, 22);
            int n = 2 + (int)(xr() % 3);
            int dir = frand() < 0.5f ? 1 : -1;
            float y0 = gVY + frange(0.1f, 0.5f) * gH;
            for (int i = 0; i < n; ++i) {
                Bat b;
                b.x = (dir > 0 ? gVX - 40 * S : gVX + gW + 40 * S) - dir * i * frange(30, 60) * S;
                b.baseY = y0 + frange(-40, 40) * S; b.y = b.baseY;
                b.vx = dir * frange(160, 230) * S; b.ph = frange(0, 6.28f); b.sz = frange(9, 14) * S;
                gBats.push_back(b);
            }
        }
        for (auto& b : gBats) {
            b.ph += dt * 14;
            b.x += b.vx * dt;
            b.y = b.baseY + std::sin(b.x * 0.01f / S + b.sz) * 30 * S;
            // от курсора шарахаются
            float dx = b.x - gCursor.x, dy = b.y - gCursor.y, d = std::sqrt(dx * dx + dy * dy) + 1;
            if (d < 120 * S) b.baseY += dy / d * 260 * S * dt;
        }
        gBats.erase(std::remove_if(gBats.begin(), gBats.end(), [](const Bat& b) { return b.x < gVX - 120 * S || b.x > gVX + gW + 120 * S; }), gBats.end());
    }
}

// ---------------------------------------------------------------- гирлянда вдоль верха окна / панели задач
static void drawGarland(const Cap& c) {
    float x0 = (float)c.r.left + 10 * S, x1 = (float)c.r.right - 10 * S;
    if (x1 - x0 < 60 * S) return;
    float span = 120 * S;
    int segs = std::max(1, (int)std::round((x1 - x0) / span));
    span = (x1 - x0) / segs;
    float sag = 7 * S;
    auto wireY = [&](float x) {
        int j = (int)((x - c.r.left) / CW);
        float t = std::fmod(x - x0, span) / span;
        return c.edgeY(j) - c.smoothD(j) * 0.6f - 4 * S + sag * std::sin(3.1415926f * t) * 0.6f - sag * 0.6f;
    };
    auto visAt = [&](float x) { int j = (int)((x - c.r.left) / CW); return j >= 0 && j < c.n() && c.vis[j]; };
    // провод
    float step = 3 * S;
    float px = x0, py = wireY(x0);
    for (float x = x0 + step; x <= x1; x += step) {
        float y = wireY(x);
        if (visAt(x)) thinLine(px - gVX, py - gVY, x - gVX, y - gVY, 30, 60, 30, 0.85f);
        px = x; py = y;
    }
    // лампочки
    static const RGB8 bc[5] = {{255, 60, 60}, {255, 200, 60}, {70, 220, 110}, {80, 150, 255}, {255, 110, 210}};
    float t = (float)gTime;
    int i = 0;
    uint32_t seed = (uint32_t)(uintptr_t)c.h;
    for (float x = x0 + 15 * S; x < x1; x += 30 * S, ++i) {
        if (!visAt(x)) continue;
        const RGB8& col = bc[(i + seed) % 5];
        // мигание: волна бежит по гирлянде, у каждой лампочки своя фаза
        float br = 0.35f + 0.65f * clampf(0.5f + 0.5f * std::sin(t * 2.4f - i * 0.9f) + 0.25f * std::sin(t * 5.3f + i * 2.1f), 0, 1);
        float y = wireY(x) + 5.5f * S, X = x - gVX, Y = y - gVY;
        drawDisc(X, Y, 9 * S * br, col.r, col.g, col.b, 0.22f * br, 5 * S, 0);   // свечение
        drawEllipse(X, Y, 3.3f * S, 4.6f * S, col.r * (0.55f + 0.45f * br), col.g * (0.55f + 0.45f * br), col.b * (0.55f + 0.45f * br), 1);
        drawDisc(X - 0.8f * S, Y - 1.2f * S, 0.9f * S, 255, 255, 255, 0.55f * br, 1, 0);
        fillRect(X - 1.8f * S, Y - 6.0f * S, X + 1.8f * S, Y - 3.8f * S, 70, 70, 60, 1);   // цоколь
    }
}

// ---------------------------------------------------------------- тыквы на окнах
static void drawPumpkin(float X, float Y, float s, float flick) {
    // тело — три дольки
    drawEllipse(X - s * 0.55f, Y, s * 0.6f, s * 0.75f, 200, 95, 20, 1);
    drawEllipse(X + s * 0.55f, Y, s * 0.6f, s * 0.75f, 200, 95, 20, 1);
    drawEllipse(X, Y, s * 0.7f, s * 0.8f, 235, 125, 30, 1);
    fillRect(X - s * 0.08f, Y - s * 1.05f, X + s * 0.1f, Y - s * 0.7f, 70, 110, 40, 1);   // хвостик
    // лицо светится
    float g = 0.75f + 0.25f * flick;
    float R = 255, G = 210 * g + 30, B = 60;
    for (int sd = -1; sd <= 1; sd += 2) {   // глаза-треугольники
        float ex = X + sd * s * 0.3f, ey = Y - s * 0.2f;
        for (int k = 0; k < 4; ++k) fillRect(ex - s * (0.04f + k * 0.045f), ey + k * s * 0.05f, ex + s * (0.04f + k * 0.045f), ey + (k + 1) * s * 0.05f, R, G, B, g);
    }
    for (int k = -3; k <= 3; ++k) {   // рот зубчиками
        float mx = X + k * s * 0.09f;
        float top = Y + s * 0.22f + ((k & 1) ? 0 : s * 0.06f);
        fillRect(mx - s * 0.045f, top, mx + s * 0.045f, Y + s * 0.38f, R, G, B, g);
    }
    drawDisc(X, Y + s * 0.05f, s * 1.4f, 255, 160, 40, 0.06f * g, s, 0);
}

static void drawLantern(float X, float Y, float s, float sway) {
    float x = X + std::sin(sway) * s * 0.4f;
    thinLine(X, Y - s * 3.5f, x, Y - s * 0.9f, 120, 80, 30, 0.9f);
    drawEllipse(x, Y, s * 0.95f, s * 0.8f, 215, 30, 35, 1);
    drawEllipse(x, Y, s * 0.55f, s * 0.75f, 245, 70, 55, 0.6f);
    fillRect(x - s * 0.45f, Y - s * 0.95f, x + s * 0.45f, Y - s * 0.75f, 230, 180, 50, 1);
    fillRect(x - s * 0.45f, Y + s * 0.75f, x + s * 0.45f, Y + s * 0.95f, 230, 180, 50, 1);
    for (int k = -1; k <= 1; ++k) thinLine(x + k * s * 0.12f, Y + s * 0.95f, x + k * s * 0.18f + std::sin(sway) * s * 0.2f, Y + s * 1.7f, 240, 190, 60, 0.9f);
    drawDisc(x, Y, s * 1.6f, 255, 120, 60, 0.07f, s, 0);
}
// солнышко на Масленицу: лучи и улыбка
static void drawSun(float X, float Y, float s, float t) {
    drawDisc(X, Y, s * 2.2f, 255, 200, 60, 0.08f, s, 0);
    for (int i = 0; i < 12; ++i) {
        float a = t * 0.3f + i * PI / 6, l = (i & 1) ? 1.55f : 1.8f;
        float px[3] = {X + std::cos(a - 0.12f) * s * 1.05f, X + std::cos(a + 0.12f) * s * 1.05f, X + std::cos(a) * s * l};
        float py[3] = {Y + std::sin(a - 0.12f) * s * 1.05f, Y + std::sin(a + 0.12f) * s * 1.05f, Y + std::sin(a) * s * l};
        fillPoly(px, py, 3, 255, 190, 40, 1);
    }
    drawDisc(X, Y, s, 255, 210, 60, 1, 1, 0.15f);
    drawDisc(X - s * 0.35f, Y - s * 0.2f, s * 0.1f, 120, 60, 20, 1, 1, 0);
    drawDisc(X + s * 0.35f, Y - s * 0.2f, s * 0.1f, 120, 60, 20, 1, 1, 0);
    drawDisc(X - s * 0.55f, Y + s * 0.15f, s * 0.16f, 255, 120, 90, 0.5f, 1, 0);
    drawDisc(X + s * 0.55f, Y + s * 0.15f, s * 0.16f, 255, 120, 90, 0.5f, 1, 0);
    for (int k = 0; k < 10; ++k) {
        float a0 = 0.35f + k * 0.24f, a1 = a0 + 0.24f;
        thinLine(X + std::cos(a0) * s * 0.5f, Y + std::sin(a0) * s * 0.45f, X + std::cos(a1) * s * 0.5f, Y + std::sin(a1) * s * 0.45f, 120, 60, 20, 1);
    }
}

// ---------------------------------------------------------------- надпись (отсчёт и поздравления)
static HDC gTxtDC = nullptr;
static HBITMAP gTxtBmp = nullptr;
static uint32_t* gTxtPix = nullptr;
static int gTxtW = 0, gTxtH = 0, gTxtUsedW = 0;
static std::wstring gTxtLast;
static void renderText(const std::wstring& s, int px) {
    if (s == gTxtLast && gTxtDC) return;
    gTxtLast = s;
    int w = (int)(px * 0.62f * (s.size() + 2)) + 8, h = (int)(px * 1.6f);
    if (!gTxtDC || w > gTxtW || h > gTxtH) {
        if (gTxtBmp) DeleteObject(gTxtBmp);
        if (!gTxtDC) gTxtDC = CreateCompatibleDC(nullptr);
        BITMAPINFO bi{};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = std::max(w, gTxtW); bi.bmiHeader.biHeight = -std::max(h, gTxtH);
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
        gTxtBmp = CreateDIBSection(gTxtDC, &bi, DIB_RGB_COLORS, (void**)&gTxtPix, nullptr, 0);
        SelectObject(gTxtDC, gTxtBmp);
        gTxtW = std::max(w, gTxtW); gTxtH = std::max(h, gTxtH);
    }
    memset(gTxtPix, 0, (size_t)gTxtW * gTxtH * 4);
    HFONT f = CreateFontW(-px, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, L"Segoe UI");
    HGDIOBJ old = SelectObject(gTxtDC, f);
    SetBkMode(gTxtDC, TRANSPARENT);
    SetTextColor(gTxtDC, RGB(255, 255, 255));
    RECT r{0, 0, gTxtW, (int)(px * 1.6f)};
    DrawTextW(gTxtDC, s.c_str(), (int)s.size(), &r, DT_SINGLELINE | DT_LEFT | DT_VCENTER | DT_NOPREFIX);
    SIZE sz{};
    GetTextExtentPoint32W(gTxtDC, s.c_str(), (int)s.size(), &sz);
    gTxtUsedW = std::min<int>(gTxtW, sz.cx + 2);
    SelectObject(gTxtDC, old);
    DeleteObject(f);
    GdiFlush();
}
static void blitText(int X, int Y, float R, float G, float B, float a) {
    int h = std::min(gTxtH, (int)(18 * S * 1.6f) + 2);
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < gTxtUsedW; ++x) {
            uint32_t p = gTxtPix[(size_t)y * gTxtW + x];
            float m = ((p >> 16) & 255) / 255.0f;
            if (m > 0.01f) {
                blendPx(X + x + 1, Y + y + 1, 0, 0, 0, a * m * 0.55f);   // тень
                blendPx(X + x, Y + y, R, G, B, a * m);
            }
        }
}
static std::wstring hW(const char* s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
    std::wstring w(n > 0 ? n - 1 : 0, L'\0');
    if (n > 1) MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n);
    return w;
}
static std::wstring countdownText() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    if (st.wMonth == 1 && st.wDay <= 2) return hW(T8("С Новым годом!", "Happy New Year!"));
    FILETIME nowF, nyF;
    SystemTimeToFileTime(&st, &nowF);
    SYSTEMTIME ny{}; ny.wYear = (WORD)(st.wYear + 1); ny.wMonth = 1; ny.wDay = 1;
    SystemTimeToFileTime(&ny, &nyF);
    ULARGE_INTEGER a, b; a.LowPart = nowF.dwLowDateTime; a.HighPart = nowF.dwHighDateTime; b.LowPart = nyF.dwLowDateTime; b.HighPart = nyF.dwHighDateTime;
    long long sec = (long long)((b.QuadPart - a.QuadPart) / 10000000ULL);
    long long days = sec / 86400; sec %= 86400;
    wchar_t buf[96];
    if (days > 0) swprintf(buf, 96, L"%ls %lld %ls %02lld:%02lld:%02lld", hW(T8("До Нового года", "New Year in")).c_str(), days,
                           hW(T8(days % 10 == 1 && days % 100 != 11 ? "день" : (days % 10 >= 2 && days % 10 <= 4 && (days % 100 < 10 || days % 100 >= 20)) ? "дня" : "дней", days == 1 ? "day" : "days")).c_str(),
                           sec / 3600, sec / 60 % 60, sec % 60);
    else swprintf(buf, 96, L"%ls %02lld:%02lld:%02lld", hW(T8("До Нового года", "New Year in")).c_str(), sec / 3600, sec / 60 % 60, sec % 60);
    return buf;
}
// надпись в углу над часами
static std::wstring holidayText() {
    switch (gHoliday) {
    case H_NY: return countdownText();
    case H_XMAS: return hW(T8("С Рождеством!", "Merry Christmas!"));
    case H_TET: return L"Chúc Mừng Năm Mới!";
    case H_VAL: return hW(T8("С Днём святого Валентина!", "Happy Valentine's Day!"));
    case H_WOMEN: return hW(T8("С 8 Марта!", "Happy Women's Day!"));
    case H_MASL: return hW(T8("Широкая Масленица!", "Happy Maslenitsa!"));
    case H_EASTER: return hW(T8("Светлой Пасхи!", "Happy Easter!"));
    case H_HAL: return hW(T8("Счастливого Хэллоуина!", "Happy Halloween!"));
    case H_CUSTOM: return gCustText;
    }
    return L"";
}

static void holidayDrawOnWindows() {
    if (!gHoliday) return;
    float t = (float)gTime;
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->n() < 2) continue;
        if (gHoliday == H_NY || gHoliday == H_XMAS) drawGarland(*c);
        else if (gHoliday == H_HAL && !c->taskbar) {
            uint32_t h = hash2((int)(uintptr_t)c->h, 77);
            float w = (float)(c->r.right - c->r.left);
            int cnt = std::min(3, std::max(1, (int)(w / (450 * S))));
            for (int k = 0; k < cnt; ++k) {
                float fx = (k + 0.3f + 0.4f * ((h >> (k * 5)) & 31) / 31.0f) / cnt;
                float x = c->r.left + w * fx;
                int j = (int)((x - c->r.left) / CW);
                if (j < 0 || j >= c->n() || !c->vis[j]) continue;
                float s = (15 + (h >> (k * 3) & 7)) * S;
                float flick = 0.5f + 0.5f * std::sin(t * 9 + k * 3 + h) * std::sin(t * 3.7f + k);
                drawPumpkin(x - gVX, c->surfY(j) - gVY - s * 0.75f, s, flick);
            }
        }
    }
}
static void holidayDrawOver() {
    float t = (float)gTime;
    if (gHoliday) {
        static const RGB8 hc[4] = {{235, 50, 80}, {255, 120, 160}, {255, 190, 210}, {200, 30, 60}};
        static const RGB8 tul[4] = {{230, 40, 60}, {250, 110, 170}, {250, 210, 50}, {250, 240, 235}};
        static const RGB8 egg1[6] = {{240, 90, 90}, {90, 160, 240}, {250, 200, 70}, {120, 200, 120}, {190, 120, 230}, {250, 150, 190}};
        static const RGB8 egg2[6] = {{255, 240, 200}, {255, 255, 255}, {200, 60, 60}, {255, 245, 160}, {255, 220, 250}, {255, 255, 255}};
        static const RGB8 fl[6] = {{255, 120, 160}, {255, 255, 255}, {255, 200, 60}, {160, 120, 255}, {255, 90, 90}, {120, 190, 255}};
        for (auto& f : gHFall) {
            float X = f.x - gVX, Y = f.y - gVY;
            switch (f.kind) {
            case 0: { const RGB8& c = hc[f.col & 3]; drawHeart(X, Y, f.sz, c.r, c.g, c.b, 0.9f, f.rot); break; }
            case 1: drawBlossom(X, Y, f.sz * 0.8f, 0.92f, f.rot); break;
            case 2: {
                bool gold = f.col & 1;
                drawDisc(X, Y, f.sz * 1.6f, 255, 230, 150, 0.08f, f.sz, 0);
                drawStar(X, Y, f.sz, f.rot, gold ? 255 : 230, gold ? 215 : 235, gold ? 90 : 245, 0.95f);
                break;
            }
            case 3: drawTulip(X, Y, f.sz, f.rot, tul[f.col & 3]); break;
            case 4: drawMimosa(X, Y, f.sz, f.rot); break;
            case 5: drawPancake(X, Y, f.sz, f.rot, f.seed); break;
            case 6: drawEgg(X, Y, f.sz, f.rot * 0.5f, egg1[f.col % 6], egg2[f.col % 6], (int)(f.seed % 3)); break;
            case 7: {
                const RGB8& c = kFestive[f.col & 7];
                float fl2 = std::cos(f.ph);
                fillRectRot(X, Y, f.sz * (0.25f + 0.75f * std::fabs(fl2)), f.sz * 0.5f, f.rot, c.r * (0.75f + 0.25f * fl2), c.g * (0.75f + 0.25f * fl2), c.b * (0.75f + 0.25f * fl2), 1);
                break;
            }
            case 8: drawFlower5(X, Y, f.sz, 0.95f, f.rot, fl[f.col % 6], {250, 210, 60}); break;
            case 9: drawBalloon(X, Y, f.sz, f.ph, kFestive[f.col % 7]); break;
            }
        }
    }
    if (gHoliday == H_TET) {   // фонарики по верхним углам каждого монитора
        for (size_t m = 0; m < gMons.size(); ++m) {
            const RECT& r = gMons[m];
            float s = 13 * S;
            for (int k = 0; k < 2; ++k) {
                float x1 = r.left + (60 + k * 55) * S, x2 = r.right - (60 + k * 55) * S;
                float y = r.top + (48 + k * 26) * S;
                drawLantern(x1 - gVX, y - gVY, s, t * 1.1f + k + m);
                drawLantern(x2 - gVX, y - gVY, s, t * 1.0f + k * 1.7f + m);
            }
        }
    }
    if (gHoliday == H_XMAS) {   // звезда наверху каждого монитора
        for (size_t m = 0; m < gMons.size(); ++m) {
            const RECT& r = gMons[m];
            float X = (r.left + r.right) * 0.5f - gVX, Y = r.top + 46 * S - gVY, s = 24 * S;
            float p = 0.8f + 0.2f * std::sin(t * 1.7f);
            drawDisc(X, Y, s * 2.4f * p, 255, 220, 120, 0.10f, s * 1.5f, 0);
            for (int k = 0; k < 8; ++k) {   // лучики
                float a = k * PI / 4 + t * 0.15f, l = (k & 1 ? 2.0f : 2.8f) * s * p;
                thinLine(X, Y, X + std::cos(a) * l, Y + std::sin(a) * l, 255, 235, 170, 0.35f);
            }
            drawStar(X, Y, s, std::sin(t * 0.5f) * 0.08f, 255, 215, 80, 1);
            drawStar(X, Y, s * 0.5f, std::sin(t * 0.5f) * 0.08f, 255, 245, 190, 0.9f);
        }
    }
    if (gHoliday == H_MASL) {   // солнышко в углу каждого монитора
        for (size_t m = 0; m < gMons.size(); ++m) {
            const RECT& r = gMons[m];
            drawSun(r.right - 70 * S - gVX, r.top + 70 * S - gVY, 26 * S, t);
        }
    }
    if (gHoliday == H_HAL) {
        for (auto& b : gBats) {
            float X = b.x - gVX, Y = b.y - gVY, s = b.sz;
            float w = std::sin(b.ph) * 0.7f;
            float dir = b.vx > 0 ? 1.0f : -1.0f;
            for (int sd = -1; sd <= 1; sd += 2) {
                float ex = X + sd * s, ey = Y - s * w;
                thinLine(X, Y, X + sd * s * 0.5f, Y - s * (w + 0.35f), 30, 25, 35, 1);
                thinLine(X + sd * s * 0.5f, Y - s * (w + 0.35f), ex, ey, 30, 25, 35, 1);
                for (float q = 0.2f; q <= 1.0f; q += 0.2f)
                    thinLine(X, Y + s * 0.1f, X + (ex - X) * q, Y + (ey - Y) * q + s * 0.15f * std::sin(q * 9), 30, 25, 35, 0.9f);
            }
            drawEllipse(X, Y, s * 0.22f, s * 0.32f, 30, 25, 35, 1);
            drawDisc(X + dir * s * 0.08f, Y - s * 0.12f, 0.9f * S, 255, 200, 60, 1, 1, 0);
        }
    }
    drawFireworks();
    if (gHoliday && gCountdownOn && !gMons.empty()) {
        std::wstring txt = holidayText();
        if (!txt.empty()) {
            RECT wa;
            SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
            renderText(txt, (int)(18 * S));
            float pulse = 0.85f + 0.15f * std::sin(t * 2.0f);
            static const float tc[10][3] = {{255, 215, 120}, {255, 215, 120}, {255, 200, 90}, {255, 170, 70}, {255, 150, 180},
                                            {255, 225, 140}, {255, 170, 200}, {255, 205, 90}, {255, 220, 170}, {255, 225, 150}};
            const float* c = tc[gHoliday % 10];
            blitText(wa.right - gVX - gTxtUsedW - (int)(18 * S), wa.bottom - gVY - (int)(18 * S * 1.6f) - (int)(6 * S), c[0], c[1], c[2], pulse);
        }
    }
}
