// Праздники: гирлянды и отсчёт до Нового года, фонарики Тета, тыквы и летучие мыши на Хэллоуин,
// сердечки на День влюблённых. Включаются сами по датам или вручную — когда захочешь.
#pragma once

enum { H_NONE = 0, H_NY = 1, H_TET = 2, H_HAL = 3, H_VAL = 4 };
// режим: 0 — выкл, 1 — по датам, 2 — Новый год, 3 — Тет, 4 — Хэллоуин, 5 — День влюблённых
static int gHolidayMode = 1;
static bool gCountdownOn = true;
static int gHoliday = H_NONE;
static float gHolChk = 99;   // проверить праздник прямо сейчас — выставить большое значение

static int dayNumber(int y, int m, int d) {   // дни от условного начала (для сравнения дат)
    SYSTEMTIME st{}; st.wYear = (WORD)y; st.wMonth = (WORD)m; st.wDay = (WORD)d;
    FILETIME ft; SystemTimeToFileTime(&st, &ft);
    ULARGE_INTEGER u; u.LowPart = ft.dwLowDateTime; u.HighPart = ft.dwHighDateTime;
    return (int)(u.QuadPart / 864000000000ULL);
}
// Тет (Лунный Новый год) по годам
static int tetDay(int y) {
    static const int T[][3] = {{2026, 2, 17}, {2027, 2, 6}, {2028, 1, 26}, {2029, 2, 13}, {2030, 2, 3}, {2031, 1, 23},
                               {2032, 2, 11}, {2033, 1, 31}, {2034, 2, 19}, {2035, 2, 8}, {2036, 1, 28}};
    for (auto& t : T) if (t[0] == y) return dayNumber(t[0], t[1], t[2]);
    return dayNumber(y, 2, 5);
}
static int holidayByDate() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    int m = st.wMonth, d = st.wDay;
    int today = dayNumber(st.wYear, m, d), tet = tetDay(st.wYear);
    if (today >= tet - 7 && today <= tet + 7) return H_TET;
    if ((m == 12 && d >= 15) || (m == 1 && d <= 10)) return H_NY;
    if ((m == 10 && d >= 24) || (m == 11 && d == 1)) return H_HAL;
    if (m == 2 && d >= 10 && d <= 15) return H_VAL;
    return H_NONE;
}
static int activeHoliday() {
    if (gHolidayMode <= 0) return H_NONE;
    if (gHolidayMode == 1) return holidayByDate();
    return std::min(gHolidayMode - 1, (int)H_VAL);
}
static bool holidayActive() { return gHoliday != H_NONE; }
static bool holidayNeedsWindows() { return gHoliday == H_NY || gHoliday == H_HAL; }

// ---------------------------------------------------------------- сердечко и цветок
static void drawHeart(float cx, float cy, float sz, float R, float G, float B, float a, float rot) {
    int r = (int)std::ceil(sz * 1.4f) + 1;
    float ca = std::cos(rot), sa = std::sin(rot);
    for (int Y = (int)cy - r; Y <= (int)cy + r; ++Y)
        for (int X = (int)cx - r; X <= (int)cx + r; ++X) {
            float dx = (X + 0.5f - cx) / sz, dy = (Y + 0.5f - cy) / sz;
            float x = dx * ca + dy * sa, y = -(-dx * sa + dy * ca) + 0.15f;
            float q = x * x + y * y - 1;
            float f = q * q * q - x * x * y * y * y;
            float cov = clampf(-f * 6.0f + 0.5f, 0, 1);
            if (cov > 0) blendPx(X, Y, R, G, B, a * cov * (0.85f + 0.15f * clampf(y, -1, 1)));
        }
}
static void drawBlossom(float cx, float cy, float sz, float a, float rot) {   // цветок абрикоса (хоа май)
    for (int i = 0; i < 5; ++i) {
        float an = rot + i * 6.2831853f / 5;
        drawDisc(cx + std::cos(an) * sz * 0.6f, cy + std::sin(an) * sz * 0.6f, sz * 0.55f, 255, 214, 40, a, 1, 0);
    }
    drawDisc(cx, cy, sz * 0.32f, 230, 120, 20, a, 1, 0);
}

// ---------------------------------------------------------------- падающие сердечки / лепестки, летучие мыши
struct HFall { float x, y, vy, ph, sz, rot, vr; uint8_t col; };
static std::vector<HFall> gHFall;
struct Bat { float x, y, vx, ph, sz, baseY; };
static std::vector<Bat> gBats;
static float gBatTimer = 6;

static void holidayUpdate(float dt) {
    {   // смена праздника: раз в несколько секунд
        gHolChk += dt;
        if (gHolChk > 5) { gHolChk = 0; int h = activeHoliday(); if (h != gHoliday) { gHoliday = h; gHFall.clear(); gBats.clear(); } }
    }
    if (!gHoliday) return;
    float width = gW / 1000.0f / S;
    if (gHoliday == H_VAL || gHoliday == H_TET) {
        static float acc = 0;
        acc += dt * 1.6f * width;
        while (acc >= 1 && gHFall.size() < 120) {
            acc -= 1;
            HFall f;
            f.x = gVX + frand() * gW; f.y = gVY - 20 * S;
            f.vy = frange(28, 55) * S; f.ph = frange(0, 6.28f); f.sz = frange(4, 8) * S;
            f.rot = frange(-0.4f, 0.4f); f.vr = frange(-0.8f, 0.8f);
            static const uint8_t cols[] = {0, 1, 2, 3};
            f.col = cols[xr() % 4];
            gHFall.push_back(f);
        }
        for (auto& f : gHFall) {
            f.ph += dt * 1.3f;
            f.y += f.vy * dt;
            f.x += (std::sin(f.ph) * 30 * S + baseWind() * 0.4f) * dt;
            f.rot += f.vr * dt;
        }
        gHFall.erase(std::remove_if(gHFall.begin(), gHFall.end(), [](const HFall& f) { return f.y > gVY + gH + 30 * S; }), gHFall.end());
    }
    if (gHoliday == H_HAL) {
        gBatTimer -= dt;
        if (gBatTimer <= 0) {
            gBatTimer = frange(10, 22);
            int n = 2 + (int)(xr() % 3);
            int dir = frand() < 0.5f ? 1 : -1;
            float y0 = gVY + frange(0.1f, 0.5f) * gH;
            for (int i = 0; i < n; ++i) {
                Bat b;
                b.x = (dir > 0 ? gVX - 40 * S : gVX + gW + 40 * S) - dir * i * frange(30, 60) * S;
                b.baseY = y0 + frange(-40, 40) * S; b.y = b.baseY;
                b.vx = dir * frange(160, 230) * S; b.ph = frange(0, 6.28f); b.sz = frange(9, 14) * S;
                gBats.push_back(b);
            }
        }
        for (auto& b : gBats) {
            b.ph += dt * 14;
            b.x += b.vx * dt;
            b.y = b.baseY + std::sin(b.x * 0.01f / S + b.sz) * 30 * S;
            // от курсора шарахаются
            float dx = b.x - gCursor.x, dy = b.y - gCursor.y, d = std::sqrt(dx * dx + dy * dy) + 1;
            if (d < 120 * S) b.baseY += dy / d * 260 * S * dt;
        }
        gBats.erase(std::remove_if(gBats.begin(), gBats.end(), [](const Bat& b) { return b.x < gVX - 120 * S || b.x > gVX + gW + 120 * S; }), gBats.end());
    }
}

// ---------------------------------------------------------------- гирлянда вдоль верха окна / панели задач
static void drawGarland(const Cap& c) {
    float x0 = (float)c.r.left + 10 * S, x1 = (float)c.r.right - 10 * S;
    if (x1 - x0 < 60 * S) return;
    float span = 120 * S;
    int segs = std::max(1, (int)std::round((x1 - x0) / span));
    span = (x1 - x0) / segs;
    float sag = 7 * S;
    auto wireY = [&](float x) {
        int j = (int)((x - c.r.left) / CW);
        float t = std::fmod(x - x0, span) / span;
        return c.edgeY(j) - c.smoothD(j) * 0.6f - 4 * S + sag * std::sin(3.1415926f * t) * 0.6f - sag * 0.6f;
    };
    auto visAt = [&](float x) { int j = (int)((x - c.r.left) / CW); return j >= 0 && j < c.n() && c.vis[j]; };
    // провод
    float step = 3 * S;
    float px = x0, py = wireY(x0);
    for (float x = x0 + step; x <= x1; x += step) {
        float y = wireY(x);
        if (visAt(x)) thinLine(px - gVX, py - gVY, x - gVX, y - gVY, 30, 60, 30, 0.85f);
        px = x; py = y;
    }
    // лампочки
    static const RGB8 bc[5] = {{255, 60, 60}, {255, 200, 60}, {70, 220, 110}, {80, 150, 255}, {255, 110, 210}};
    float t = (float)gTime;
    int i = 0;
    uint32_t seed = (uint32_t)(uintptr_t)c.h;
    for (float x = x0 + 15 * S; x < x1; x += 30 * S, ++i) {
        if (!visAt(x)) continue;
        const RGB8& col = bc[(i + seed) % 5];
        // мигание: волна бежит по гирлянде, у каждой лампочки своя фаза
        float br = 0.35f + 0.65f * clampf(0.5f + 0.5f * std::sin(t * 2.4f - i * 0.9f) + 0.25f * std::sin(t * 5.3f + i * 2.1f), 0, 1);
        float y = wireY(x) + 5.5f * S, X = x - gVX, Y = y - gVY;
        drawDisc(X, Y, 9 * S * br, col.r, col.g, col.b, 0.22f * br, 5 * S, 0);   // свечение
        drawEllipse(X, Y, 3.3f * S, 4.6f * S, col.r * (0.55f + 0.45f * br), col.g * (0.55f + 0.45f * br), col.b * (0.55f + 0.45f * br), 1);
        drawDisc(X - 0.8f * S, Y - 1.2f * S, 0.9f * S, 255, 255, 255, 0.55f * br, 1, 0);
        fillRect(X - 1.8f * S, Y - 6.0f * S, X + 1.8f * S, Y - 3.8f * S, 70, 70, 60, 1);   // цоколь
    }
}

// ---------------------------------------------------------------- тыквы на окнах
static void drawPumpkin(float X, float Y, float s, float flick) {
    // тело — три дольки
    drawEllipse(X - s * 0.55f, Y, s * 0.6f, s * 0.75f, 200, 95, 20, 1);
    drawEllipse(X + s * 0.55f, Y, s * 0.6f, s * 0.75f, 200, 95, 20, 1);
    drawEllipse(X, Y, s * 0.7f, s * 0.8f, 235, 125, 30, 1);
    fillRect(X - s * 0.08f, Y - s * 1.05f, X + s * 0.1f, Y - s * 0.7f, 70, 110, 40, 1);   // хвостик
    // лицо светится
    float g = 0.75f + 0.25f * flick;
    float R = 255, G = 210 * g + 30, B = 60;
    for (int sd = -1; sd <= 1; sd += 2) {   // глаза-треугольники
        float ex = X + sd * s * 0.3f, ey = Y - s * 0.2f;
        for (int k = 0; k < 4; ++k) fillRect(ex - s * (0.04f + k * 0.045f), ey + k * s * 0.05f, ex + s * (0.04f + k * 0.045f), ey + (k + 1) * s * 0.05f, R, G, B, g);
    }
    for (int k = -3; k <= 3; ++k) {   // рот зубчиками
        float mx = X + k * s * 0.09f;
        float top = Y + s * 0.22f + ((k & 1) ? 0 : s * 0.06f);
        fillRect(mx - s * 0.045f, top, mx + s * 0.045f, Y + s * 0.38f, R, G, B, g);
    }
    drawDisc(X, Y + s * 0.05f, s * 1.4f, 255, 160, 40, 0.06f * g, s, 0);
}

static void drawLantern(float X, float Y, float s, float sway) {
    float x = X + std::sin(sway) * s * 0.4f;
    thinLine(X, Y - s * 3.5f, x, Y - s * 0.9f, 120, 80, 30, 0.9f);
    drawEllipse(x, Y, s * 0.95f, s * 0.8f, 215, 30, 35, 1);
    drawEllipse(x, Y, s * 0.55f, s * 0.75f, 245, 70, 55, 0.6f);
    fillRect(x - s * 0.45f, Y - s * 0.95f, x + s * 0.45f, Y - s * 0.75f, 230, 180, 50, 1);
    fillRect(x - s * 0.45f, Y + s * 0.75f, x + s * 0.45f, Y + s * 0.95f, 230, 180, 50, 1);
    for (int k = -1; k <= 1; ++k) thinLine(x + k * s * 0.12f, Y + s * 0.95f, x + k * s * 0.18f + std::sin(sway) * s * 0.2f, Y + s * 1.7f, 240, 190, 60, 0.9f);
    drawDisc(x, Y, s * 1.6f, 255, 120, 60, 0.07f, s, 0);
}

// ---------------------------------------------------------------- надпись (отсчёт до Нового года)
static HDC gTxtDC = nullptr;
static HBITMAP gTxtBmp = nullptr;
static uint32_t* gTxtPix = nullptr;
static int gTxtW = 0, gTxtH = 0, gTxtUsedW = 0;
static std::wstring gTxtLast;
static void renderText(const std::wstring& s, int px) {
    if (s == gTxtLast && gTxtDC) return;
    gTxtLast = s;
    int w = (int)(px * 0.62f * (s.size() + 2)) + 8, h = (int)(px * 1.6f);
    if (!gTxtDC || w > gTxtW || h > gTxtH) {
        if (gTxtBmp) DeleteObject(gTxtBmp);
        if (!gTxtDC) gTxtDC = CreateCompatibleDC(nullptr);
        BITMAPINFO bi{};
        bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h;
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
        gTxtBmp = CreateDIBSection(gTxtDC, &bi, DIB_RGB_COLORS, (void**)&gTxtPix, nullptr, 0);
        SelectObject(gTxtDC, gTxtBmp);
        gTxtW = w; gTxtH = h;
    }
    memset(gTxtPix, 0, (size_t)gTxtW * gTxtH * 4);
    HFONT f = CreateFontW(-px, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET, 0, 0, ANTIALIASED_QUALITY, 0, L"Segoe UI");
    HGDIOBJ old = SelectObject(gTxtDC, f);
    SetBkMode(gTxtDC, TRANSPARENT);
    SetTextColor(gTxtDC, RGB(255, 255, 255));
    RECT r{0, 0, gTxtW, gTxtH};
    DrawTextW(gTxtDC, s.c_str(), (int)s.size(), &r, DT_SINGLELINE | DT_LEFT | DT_VCENTER | DT_NOPREFIX);
    SIZE sz{};
    GetTextExtentPoint32W(gTxtDC, s.c_str(), (int)s.size(), &sz);
    gTxtUsedW = std::min<int>(gTxtW, sz.cx + 2);
    SelectObject(gTxtDC, old);
    DeleteObject(f);
    GdiFlush();
}
static void blitText(int X, int Y, float R, float G, float B, float a) {
    for (int y = 0; y < gTxtH; ++y)
        for (int x = 0; x < gTxtUsedW; ++x) {
            uint32_t p = gTxtPix[(size_t)y * gTxtW + x];
            float m = ((p >> 16) & 255) / 255.0f;
            if (m > 0.01f) {
                blendPx(X + x + 1, Y + y + 1, 0, 0, 0, a * m * 0.55f);   // тень
                blendPx(X + x, Y + y, R, G, B, a * m);
            }
        }
}
static std::wstring hW(const char* s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
    std::wstring w(n > 0 ? n - 1 : 0, L'\0');
    if (n > 1) MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n);
    return w;
}
static std::wstring countdownText() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    if (st.wMonth == 1 && st.wDay <= 2) return hW(T8("С Новым годом!", "Happy New Year!"));
    FILETIME nowF, nyF;
    SystemTimeToFileTime(&st, &nowF);
    SYSTEMTIME ny{}; ny.wYear = (WORD)(st.wYear + 1); ny.wMonth = 1; ny.wDay = 1;
    SystemTimeToFileTime(&ny, &nyF);
    ULARGE_INTEGER a, b; a.LowPart = nowF.dwLowDateTime; a.HighPart = nowF.dwHighDateTime; b.LowPart = nyF.dwLowDateTime; b.HighPart = nyF.dwHighDateTime;
    long long sec = (long long)((b.QuadPart - a.QuadPart) / 10000000ULL);
    long long days = sec / 86400; sec %= 86400;
    wchar_t buf[96];
    if (days > 0) swprintf(buf, 96, L"%ls %lld %ls %02lld:%02lld:%02lld", hW(T8("До Нового года", "New Year in")).c_str(), days,
                           hW(T8(days % 10 == 1 && days % 100 != 11 ? "день" : (days % 10 >= 2 && days % 10 <= 4 && (days % 100 < 10 || days % 100 >= 20)) ? "дня" : "дней", days == 1 ? "day" : "days")).c_str(),
                           sec / 3600, sec / 60 % 60, sec % 60);
    else swprintf(buf, 96, L"%ls %02lld:%02lld:%02lld", hW(T8("До Нового года", "New Year in")).c_str(), sec / 3600, sec / 60 % 60, sec % 60);
    return buf;
}

static void holidayDrawOnWindows() {
    if (!gHoliday) return;
    float t = (float)gTime;
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->n() < 2) continue;
        if (gHoliday == H_NY) drawGarland(*c);
        else if (gHoliday == H_HAL && !c->taskbar) {
            uint32_t h = hash2((int)(uintptr_t)c->h, 77);
            float w = (float)(c->r.right - c->r.left);
            int cnt = std::min(3, std::max(1, (int)(w / (450 * S))));
            for (int k = 0; k < cnt; ++k) {
                float fx = (k + 0.3f + 0.4f * ((h >> (k * 5)) & 31) / 31.0f) / cnt;
                float x = c->r.left + w * fx;
                int j = (int)((x - c->r.left) / CW);
                if (j < 0 || j >= c->n() || !c->vis[j]) continue;
                float s = (15 + (h >> (k * 3) & 7)) * S;
                float flick = 0.5f + 0.5f * std::sin(t * 9 + k * 3 + h) * std::sin(t * 3.7f + k);
                drawPumpkin(x - gVX, c->surfY(j) - gVY - s * 0.75f, s, flick);
            }
        }
    }
}
static void holidayDrawOver() {
    if (!gHoliday) return;
    float t = (float)gTime;
    if (gHoliday == H_VAL || gHoliday == H_TET) {
        static const RGB8 hc[4] = {{235, 50, 80}, {255, 120, 160}, {255, 190, 210}, {200, 30, 60}};
        for (auto& f : gHFall) {
            if (gHoliday == H_VAL) { const RGB8& c = hc[f.col]; drawHeart(f.x - gVX, f.y - gVY, f.sz, c.r, c.g, c.b, 0.9f, f.rot); }
            else drawBlossom(f.x - gVX, f.y - gVY, f.sz * 0.8f, 0.92f, f.rot);
        }
    }
    if (gHoliday == H_TET) {   // фонарики по верхним углам каждого монитора
        for (size_t m = 0; m < gMons.size(); ++m) {
            const RECT& r = gMons[m];
            float s = 13 * S;
            for (int k = 0; k < 2; ++k) {
                float x1 = r.left + (60 + k * 55) * S, x2 = r.right - (60 + k * 55) * S;
                float y = r.top + (48 + k * 26) * S;
                drawLantern(x1 - gVX, y - gVY, s, t * 1.1f + k + m);
                drawLantern(x2 - gVX, y - gVY, s, t * 1.0f + k * 1.7f + m);
            }
        }
    }
    if (gHoliday == H_HAL) {
        for (auto& b : gBats) {
            float X = b.x - gVX, Y = b.y - gVY, s = b.sz;
            float w = std::sin(b.ph) * 0.7f;
            float dir = b.vx > 0 ? 1.0f : -1.0f;
            for (int sd = -1; sd <= 1; sd += 2) {
                float ex = X + sd * s, ey = Y - s * w;
                thinLine(X, Y, X + sd * s * 0.5f, Y - s * (w + 0.35f), 30, 25, 35, 1);
                thinLine(X + sd * s * 0.5f, Y - s * (w + 0.35f), ex, ey, 30, 25, 35, 1);
                for (float q = 0.2f; q <= 1.0f; q += 0.2f)
                    thinLine(X, Y + s * 0.1f, X + (ex - X) * q, Y + (ey - Y) * q + s * 0.15f * std::sin(q * 9), 30, 25, 35, 0.9f);
            }
            drawEllipse(X, Y, s * 0.22f, s * 0.32f, 30, 25, 35, 1);
            drawDisc(X + dir * s * 0.08f, Y - s * 0.12f, 0.9f * S, 255, 200, 60, 1, 1, 0);
        }
    }
    if (gHoliday == H_NY && gCountdownOn && !gMons.empty()) {
        RECT wa;
        SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
        renderText(countdownText(), (int)(18 * S));
        float pulse = 0.85f + 0.15f * std::sin(t * 2.0f);
        blitText(wa.right - gVX - gTxtUsedW - (int)(18 * S), wa.bottom - gVY - gTxtH - (int)(6 * S), 255, 215, 120, pulse);
    }
}
