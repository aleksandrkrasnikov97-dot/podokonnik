// Паки иконок: значки папок, «Этот компьютер», Корзины и ярлыков программ и игр.
// Паки — открытые темы значков (Papirus, Candy, WhiteSur, Fluent, Tela, Colloid, Kora, Numix Circle; GPL-3.0),
// собраны tools/iconpacks.py и лежат на сайте: icons/catalog.txt, icons/<пак>/<значок>.png.
// Выбранный пак скачиваем по одному значку (только нужные), делаем .ico и ставим:
//  • ярлыки (.lnk и .url) на рабочем столе, в «Пуске» и на панели задач — IconLocation ярлыка;
//  • «Этот компьютер», Корзина, папка пользователя — HKCU\...\Explorer\CLSID\{...}\DefaultIcon;
//  • Загрузки, Документы, Музыка, Изображения, Видео, Рабочий стол — desktop.ini этих папок;
//  • все остальные папки — HKLM\...\Explorer\Shell Icons (нужно разрешение администратора, спросим отдельно).
// Всё, что меняем, сначала запоминаем в icons\backup.txt — «Вернуть стандартные» ставит как было.
#pragma once
#include <shobjidl.h>
#include <knownfolders.h>
#include <functional>

#define WM_ICOPROG (WM_APP + 63)
#define WM_ICODONE (WM_APP + 64)
#define WM_ICOCAT  (WM_APP + 65)

static const wchar_t* kIcoHost = L"aleksandrkrasnikov97-dot.github.io";
static const wchar_t* kIcoPath = L"/podokonnik/icons/";

struct IcoRule { std::string id; std::vector<std::wstring> exe, name, path; };
static std::vector<IcoRule> gIcoRules;
static std::string gIcoApplied;              // какой пак стоит ("" — стандартные значки Windows)
static bool gIcoOptApps = true, gIcoOptSystem = true, gIcoOptFolders = true, gIcoOptAll = false;
static bool gIcoOptFrame = true;             // программы без значка в паке — их значок в рамке пака
static volatile LONG gIcoBusy = 0;
static std::string gIcoMsg;                  // итог для окна настроек
static std::string gIcoJobPack;              // что ставим сейчас ("" — возвращаем стандартные)
static int gIcoChanged = 0;

static std::wstring icoDir() { return baseDataDir() + L"\\icons"; }
static std::wstring icoLower(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }

// ---------------------------------------------------------------- каталог и правила
static bool icoParseCatalog(const std::string& t) {
    gIcoRules.clear();
    size_t pos = 0;
    while (pos < t.size()) {
        size_t e = t.find('\n', pos); if (e == std::string::npos) e = t.size();
        std::string line = t.substr(pos, e - pos); pos = e + 1;
        if (line.rfind("rule\t", 0) != 0) continue;
        size_t a = line.find('\t', 5);
        if (a == std::string::npos) continue;
        IcoRule r; r.id = line.substr(5, a - 5);
        std::wstring keys = W16(line.substr(a + 1));
        // признаки через пробел, но имена могут быть из нескольких слов: «n:google chrome e:chrome»
        size_t i = 0;
        while (i < keys.size()) {
            size_t c = keys.find(L':', i);
            if (c == std::wstring::npos || c == 0) break;
            wchar_t kind = keys[c - 1];
            size_t next = keys.size();
            for (size_t j = c + 1; j + 1 < keys.size(); ++j)
                if (keys[j] == L' ' && (keys[j + 1] == L'e' || keys[j + 1] == L'n' || keys[j + 1] == L'p') && j + 2 < keys.size() && keys[j + 2] == L':') { next = j; break; }
            std::wstring v = icoLower(keys.substr(c + 1, next - c - 1));
            if (kind == L'e') r.exe.push_back(v); else if (kind == L'n') r.name.push_back(v); else if (kind == L'p') r.path.push_back(v);
            i = next + 1;
        }
        gIcoRules.push_back(r);
    }
    return !gIcoRules.empty();
}
static std::string icoMatch(const std::wstring& exe, const std::wstring& name, const std::wstring& path, const std::unordered_map<std::string, bool>& have) {
    for (auto& r : gIcoRules) {
        bool ok = false;
        for (auto& x : r.exe) if (x == exe) { ok = true; break; }
        if (!ok) for (auto& x : r.name) if (x == name) { ok = true; break; }
        if (!ok) for (auto& x : r.path) if (path.find(x) != std::wstring::npos) { ok = true; break; }
        if (ok && have.count(r.id)) return r.id;
    }
    return "";
}

// ---------------------------------------------------------------- PNG → ICO (256, 48, 32, 16)
static bool icoEncodePng(IWICImagingFactory* f, IWICBitmapSource* src, std::string& out) {
    IStream* ms = nullptr;
    if (FAILED(CreateStreamOnHGlobal(nullptr, TRUE, &ms))) return false;
    IWICBitmapEncoder* enc = nullptr; IWICBitmapFrameEncode* fr = nullptr; IPropertyBag2* props = nullptr;
    bool ok = SUCCEEDED(f->CreateEncoder(GUID_ContainerFormatPng, nullptr, &enc)) && SUCCEEDED(enc->Initialize(ms, WICBitmapEncoderNoCache)) &&
              SUCCEEDED(enc->CreateNewFrame(&fr, &props)) && SUCCEEDED(fr->Initialize(props));
    UINT w = 0, h = 0;
    if (ok) { src->GetSize(&w, &h); ok = SUCCEEDED(fr->SetSize(w, h)); }
    WICPixelFormatGUID pf = GUID_WICPixelFormat32bppBGRA;
    if (ok) ok = SUCCEEDED(fr->SetPixelFormat(&pf)) && SUCCEEDED(fr->WriteSource(src, nullptr)) && SUCCEEDED(fr->Commit()) && SUCCEEDED(enc->Commit());
    if (ok) {
        HGLOBAL hg = nullptr;
        GetHGlobalFromStream(ms, &hg);
        STATSTG stt{}; ms->Stat(&stt, STATFLAG_NONAME);
        void* p = hg ? GlobalLock(hg) : nullptr;
        if (p) { out.assign((const char*)p, (size_t)stt.cbSize.QuadPart); GlobalUnlock(hg); } else ok = false;
    }
    if (props) props->Release(); if (fr) fr->Release(); if (enc) enc->Release(); ms->Release();
    return ok && !out.empty();
}
// маленькие размеры — классическая картинка (BGRA + маска): так их понимает любая часть Windows
static bool icoEncodeBmp(IWICBitmapSource* src, int s, std::string& out) {
    std::vector<uint8_t> px((size_t)s * s * 4);
    if (FAILED(src->CopyPixels(nullptr, s * 4, (UINT)px.size(), px.data()))) return false;
    int maskRow = ((s + 31) / 32) * 4;
    BITMAPINFOHEADER bh{};
    bh.biSize = sizeof(bh); bh.biWidth = s; bh.biHeight = s * 2; bh.biPlanes = 1; bh.biBitCount = 32; bh.biCompression = BI_RGB;
    bh.biSizeImage = (DWORD)(s * s * 4 + maskRow * s);
    out.assign((const char*)&bh, sizeof(bh));
    for (int y = s - 1; y >= 0; --y) out.append((const char*)&px[(size_t)y * s * 4], (size_t)s * 4);   // снизу вверх
    for (int y = s - 1; y >= 0; --y) {
        std::string row(maskRow, '\0');
        for (int x = 0; x < s; ++x) if (px[((size_t)y * s + x) * 4 + 3] == 0) row[x >> 3] |= (char)(0x80 >> (x & 7));
        out += row;
    }
    return true;
}
// готовая картинка (PBGRA) → .ico: 256 — PNG, 48/32/16 — BMP
static bool icoWrite(IWICImagingFactory* f, IWICBitmapSource* pre, const std::wstring& outPath) {
    std::vector<std::string> blobs; std::vector<int> sizes;
    for (int sz : {256, 48, 32, 16}) {
        IWICBitmapScaler* sc = nullptr; IWICFormatConverter* cv = nullptr;
        std::string b;
        if (SUCCEEDED(f->CreateBitmapScaler(&sc)) && SUCCEEDED(sc->Initialize(pre, sz, sz, WICBitmapInterpolationModeFant)) &&
            SUCCEEDED(f->CreateFormatConverter(&cv)) &&
            SUCCEEDED(cv->Initialize(sc, GUID_WICPixelFormat32bppBGRA, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom)) &&
            (sz >= 256 ? icoEncodePng(f, cv, b) : icoEncodeBmp(cv, sz, b))) { blobs.push_back(b); sizes.push_back(sz); }
        if (cv) cv->Release(); if (sc) sc->Release();
    }
    if (blobs.empty()) return false;
    std::string ico;
    auto u16 = [&](unsigned v) { ico.push_back((char)(v & 255)); ico.push_back((char)(v >> 8)); };
    auto u32 = [&](unsigned v) { u16(v & 0xffff); u16(v >> 16); };
    u16(0); u16(1); u16((unsigned)blobs.size());
    unsigned off = 6 + 16 * (unsigned)blobs.size();
    for (size_t i = 0; i < blobs.size(); ++i) {
        ico.push_back((char)(sizes[i] >= 256 ? 0 : sizes[i])); ico.push_back((char)(sizes[i] >= 256 ? 0 : sizes[i]));
        ico.push_back(0); ico.push_back(0); u16(1); u16(32); u32((unsigned)blobs[i].size()); u32(off);
        off += (unsigned)blobs[i].size();
    }
    for (auto& b : blobs) ico += b;
    std::wstring tmp = outPath + L".tmp";
    if (!writeFile(tmp, ico)) return false;
    return MoveFileExW(tmp.c_str(), outPath.c_str(), MOVEFILE_REPLACE_EXISTING) != 0;
}
// PNG → PBGRA-пиксели нужного размера
static bool icoDecode(IWICImagingFactory* f, const std::string& png, int w, int h, std::vector<uint8_t>& px) {
    IWICStream* st = nullptr; IWICBitmapDecoder* dec = nullptr; IWICBitmapFrameDecode* fr = nullptr; IWICFormatConverter* pre = nullptr; IWICBitmapScaler* sc = nullptr;
    px.assign((size_t)w * h * 4, 0);
    bool ok = SUCCEEDED(f->CreateStream(&st)) && SUCCEEDED(st->InitializeFromMemory((BYTE*)png.data(), (DWORD)png.size())) &&
              SUCCEEDED(f->CreateDecoderFromStream(st, nullptr, WICDecodeMetadataCacheOnLoad, &dec)) && SUCCEEDED(dec->GetFrame(0, &fr)) &&
              SUCCEEDED(f->CreateFormatConverter(&pre)) &&
              SUCCEEDED(pre->Initialize(fr, GUID_WICPixelFormat32bppPBGRA, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom)) &&
              SUCCEEDED(f->CreateBitmapScaler(&sc)) && SUCCEEDED(sc->Initialize(pre, w, h, WICBitmapInterpolationModeFant)) &&
              SUCCEEDED(sc->CopyPixels(nullptr, w * 4, (UINT)px.size(), px.data()));
    if (sc) sc->Release(); if (pre) pre->Release(); if (fr) fr->Release(); if (dec) dec->Release(); if (st) st->Release();
    return ok;
}
static bool icoFromPixels(IWICImagingFactory* f, std::vector<uint8_t>& px, int w, int h, const std::wstring& outPath) {
    IWICBitmap* bm = nullptr;
    bool ok = SUCCEEDED(f->CreateBitmapFromMemory(w, h, GUID_WICPixelFormat32bppPBGRA, w * 4, (UINT)px.size(), px.data(), &bm)) && icoWrite(f, bm, outPath);
    if (bm) bm->Release();
    return ok;
}
static bool icoFromPng(const std::string& png, const std::wstring& outPath) {
    IWICImagingFactory* f = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f)))) return false;
    std::vector<uint8_t> px;
    bool ok = icoDecode(f, png, 256, 256, px) && icoFromPixels(f, px, 256, 256, outPath);
    f->Release();
    return ok;
}
// значок программы (PBGRA, n×n): из файла значка ярлыка или из самой программы
static bool icoAppPixels(const std::wstring& file, int idx, std::vector<uint8_t>& px, int& n) {
    HICON hi = nullptr;
    if (FAILED(SHDefExtractIconW(file.c_str(), idx, 0, &hi, nullptr, 256)) || !hi) {
        hi = nullptr;
        IShellItem* si = nullptr; IShellItemImageFactory* fac = nullptr; HBITMAP hb = nullptr;
        if (SUCCEEDED(SHCreateItemFromParsingName(file.c_str(), nullptr, IID_PPV_ARGS(&si))) && SUCCEEDED(si->QueryInterface(IID_PPV_ARGS(&fac))) &&
            SUCCEEDED(fac->GetImage(SIZE{256, 256}, SIIGBF_ICONONLY | SIIGBF_BIGGERSIZEOK, &hb)) && hb) {
            BITMAP bmi{}; GetObjectW(hb, sizeof bmi, &bmi);
            n = bmi.bmWidth;
            BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = n; bi.bmiHeader.biHeight = -bmi.bmHeight;
            bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
            std::vector<uint8_t> raw((size_t)n * bmi.bmHeight * 4);
            HDC dc = GetDC(nullptr);
            bool got = GetDIBits(dc, hb, 0, bmi.bmHeight, raw.data(), &bi, DIB_RGB_COLORS) != 0;
            ReleaseDC(nullptr, dc);
            DeleteObject(hb);
            if (fac) fac->Release(); if (si) si->Release();
            if (!got || n <= 0 || bmi.bmHeight != n) return false;
            px = raw;   // уже с альфой (премультиплированной)
            return true;
        }
        if (fac) fac->Release(); if (si) si->Release();
        return false;
    }
    ICONINFO ii{};
    bool ok = false;
    if (GetIconInfo(hi, &ii) && ii.hbmColor) {
        BITMAP bmi{}; GetObjectW(ii.hbmColor, sizeof bmi, &bmi);
        n = bmi.bmWidth;
        if (n > 0 && bmi.bmHeight == n) {
            BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = n; bi.bmiHeader.biHeight = -n;
            bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
            px.assign((size_t)n * n * 4, 0);
            HDC dc = GetDC(nullptr);
            ok = GetDIBits(dc, ii.hbmColor, 0, n, px.data(), &bi, DIB_RGB_COLORS) != 0;
            bool anyA = false;
            for (size_t i = 3; i < px.size(); i += 4) if (px[i]) { anyA = true; break; }
            if (ok && !anyA && ii.hbmMask) {   // старый значок без альфы — прозрачность из маски
                std::vector<uint8_t> mk((size_t)n * n * 4);
                if (GetDIBits(dc, ii.hbmMask, 0, n, mk.data(), &bi, DIB_RGB_COLORS))
                    for (size_t i = 0; i < (size_t)n * n; ++i) px[i * 4 + 3] = mk[i * 4] ? 0 : 255;
            }
            ReleaseDC(nullptr, dc);
            for (size_t i = 0; i < (size_t)n * n; ++i) {   // в премультиплированный вид
                unsigned a = px[i * 4 + 3];
                for (int c = 0; c < 3; ++c) px[i * 4 + c] = (uint8_t)(px[i * 4 + c] * a / 255);
            }
        }
    }
    if (ii.hbmColor) DeleteObject(ii.hbmColor);
    if (ii.hbmMask) DeleteObject(ii.hbmMask);
    DestroyIcon(hi);
    return ok;
}
// значок программы на рамке пака
static bool icoFramed(const std::string& tilePng, float inner, float offy, const std::wstring& file, int idx, const std::wstring& outPath) {
    std::vector<uint8_t> app; int n = 0;
    if (!icoAppPixels(file, idx, app, n) || n < 8) return false;
    IWICImagingFactory* f = nullptr;
    if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f)))) return false;
    std::vector<uint8_t> tile;
    bool ok = icoDecode(f, tilePng, 256, 256, tile);
    int s = std::max(16, (int)(256 * inner));
    std::vector<uint8_t> sm((size_t)s * s * 4);
    IWICBitmap* bm = nullptr; IWICBitmapScaler* sc = nullptr;
    ok = ok && SUCCEEDED(f->CreateBitmapFromMemory(n, n, GUID_WICPixelFormat32bppPBGRA, n * 4, (UINT)app.size(), app.data(), &bm)) &&
         SUCCEEDED(f->CreateBitmapScaler(&sc)) && SUCCEEDED(sc->Initialize(bm, s, s, n < s ? WICBitmapInterpolationModeCubic : WICBitmapInterpolationModeFant)) &&
         SUCCEEDED(sc->CopyPixels(nullptr, s * 4, (UINT)sm.size(), sm.data()));
    if (sc) sc->Release(); if (bm) bm->Release();
    if (ok) {
        int ox = (256 - s) / 2, oy = (256 - s) / 2 + (int)(offy * 256);
        for (int y = 0; y < s; ++y)
            for (int x = 0; x < s; ++x) {
                int X = ox + x, Y = oy + y;
                if (X < 0 || Y < 0 || X >= 256 || Y >= 256) continue;
                const uint8_t* a = &sm[((size_t)y * s + x) * 4];
                uint8_t* d = &tile[((size_t)Y * 256 + X) * 4];
                unsigned ia = 255 - a[3];
                for (int c = 0; c < 4; ++c) d[c] = (uint8_t)std::min(255u, a[c] + d[c] * ia / 255);
            }
        ok = icoFromPixels(f, tile, 256, 256, outPath);
    }
    f->Release();
    return ok;
}

// ---------------------------------------------------------------- запоминаем, как было
// строки: lnk|url|reg|ini <TAB> где <TAB> что было (у reg — ключ<TAB>значение<TAB>было или \x01 — не было)
static std::vector<std::wstring> gIcoBackup;
static void icoBackupLoad() {
    gIcoBackup.clear();
    std::string t;
    if (!readFile(icoDir() + L"\\backup.txt", t)) return;
    std::wstring w = W16(t);
    size_t p = 0;
    while (p < w.size()) { size_t e = w.find(L'\n', p); if (e == std::wstring::npos) e = w.size(); if (e > p) gIcoBackup.push_back(w.substr(p, e - p)); p = e + 1; }
}
static void icoBackupSave() {
    std::wstring w;
    for (auto& l : gIcoBackup) { w += l; w += L'\n'; }
    CreateDirectoryW(icoDir().c_str(), nullptr);
    writeFile(icoDir() + L"\\backup.txt", U8(w));
}
static bool icoBackupHas(const std::wstring& prefix) {
    for (auto& l : gIcoBackup) if (l.compare(0, prefix.size(), prefix) == 0) return true;
    return false;
}
static void icoBackupAdd(const std::wstring& line, const std::wstring& key) { if (!icoBackupHas(key)) gIcoBackup.push_back(line); }
static std::vector<std::wstring> icoSplit(const std::wstring& s) {
    std::vector<std::wstring> f; size_t a = 0;
    for (;;) { size_t b = s.find(L'\t', a); f.push_back(s.substr(a, b == std::wstring::npos ? std::wstring::npos : b - a)); if (b == std::wstring::npos) break; a = b + 1; }
    return f;
}

// ---------------------------------------------------------------- ярлыки
struct IcoShortcut { std::wstring path, exe, name, full, icoFile; int icoIdx = 0; bool url = false; int steam = -1; };
static void icoScan(const std::wstring& dir, std::vector<IcoShortcut>& out, int depth) {
    if (depth > 4 || out.size() > 3000) return;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((dir + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        std::wstring n = fd.cFileName;
        if (n == L"." || n == L"..") continue;
        std::wstring p = dir + L"\\" + n;
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) icoScan(p, out, depth + 1); continue; }
        std::wstring ln = icoLower(n);
        bool lnk = ln.size() > 4 && ln.compare(ln.size() - 4, 4, L".lnk") == 0, url = ln.size() > 4 && ln.compare(ln.size() - 4, 4, L".url") == 0;
        if (!lnk && !url) continue;
        IcoShortcut s; s.path = p; s.url = url; s.name = ln.substr(0, ln.size() - 4);
        if (url) {
            wchar_t buf[2048] = {0};
            GetPrivateProfileStringW(L"InternetShortcut", L"URL", L"", buf, 2048, p.c_str());
            s.full = icoLower(buf);
            size_t k = s.full.find(L"steam://rungameid/");
            if (k != std::wstring::npos) s.steam = _wtoi(s.full.c_str() + k + 18);
            wchar_t ic[2048] = {0}, ix[32] = {0};
            GetPrivateProfileStringW(L"InternetShortcut", L"IconFile", L"", ic, 2048, p.c_str());
            GetPrivateProfileStringW(L"InternetShortcut", L"IconIndex", L"0", ix, 32, p.c_str());
            wchar_t ex[2048] = {0}; ExpandEnvironmentStringsW(ic, ex, 2048);
            s.icoFile = ex; s.icoIdx = _wtoi(ix);
        } else {
            IShellLinkW* sl = nullptr; IPersistFile* pf = nullptr;
            if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&sl))) &&
                SUCCEEDED(sl->QueryInterface(IID_PPV_ARGS(&pf))) && SUCCEEDED(pf->Load(p.c_str(), STGM_READ))) {
                wchar_t tgt[MAX_PATH * 2] = {0}, args[1024] = {0};
                sl->GetPath(tgt, MAX_PATH * 2, nullptr, SLGP_RAWPATH);
                sl->GetArguments(args, 1024);
                wchar_t exp[MAX_PATH * 2] = {0};
                ExpandEnvironmentStringsW(tgt, exp, MAX_PATH * 2);
                s.full = icoLower(std::wstring(exp) + L" " + args);
                std::wstring t = icoLower(exp);
                size_t sl2 = t.find_last_of(L"\\/");
                std::wstring fn = sl2 == std::wstring::npos ? t : t.substr(sl2 + 1);
                if (fn.size() > 4 && fn.compare(fn.size() - 4, 4, L".exe") == 0) fn.resize(fn.size() - 4);
                s.exe = fn;
                wchar_t il[MAX_PATH * 2] = {0}; int ii = 0;
                sl->GetIconLocation(il, MAX_PATH * 2, &ii);
                wchar_t ile[MAX_PATH * 2] = {0}; ExpandEnvironmentStringsW(il, ile, MAX_PATH * 2);
                s.icoFile = ile[0] ? ile : exp; s.icoIdx = ile[0] ? ii : 0;
                // Discord и другие: Update.exe --processStart Discord.exe
                size_t ps = s.full.find(L"--processstart ");
                if (ps != std::wstring::npos) { std::wstring q = s.full.substr(ps + 15); size_t sp = q.find_first_of(L" \""); q = q.substr(0, sp); if (q.size() > 4) s.exe = q.substr(0, q.size() - 4); }
            }
            if (pf) pf->Release(); if (sl) sl->Release();
        }
        out.push_back(s);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}
static std::wstring icoKnown(REFKNOWNFOLDERID id) {
    PWSTR p = nullptr; std::wstring r;
    if (SUCCEEDED(SHGetKnownFolderPath(id, 0, nullptr, &p)) && p) r = p;
    if (p) CoTaskMemFree(p);
    return r;
}
static bool icoSetShortcut(const IcoShortcut& s, const std::wstring& ico) {
    if (s.url) {
        wchar_t f[2048] = {0}, ix[32] = {0};
        GetPrivateProfileStringW(L"InternetShortcut", L"IconFile", L"\x01", f, 2048, s.path.c_str());
        GetPrivateProfileStringW(L"InternetShortcut", L"IconIndex", L"0", ix, 32, s.path.c_str());
        if (std::wstring(f).find(L"\\icons\\") == std::wstring::npos || std::wstring(f).find(L"Sugrob") == std::wstring::npos)
            icoBackupAdd(L"url\t" + s.path + L"\t" + f + L"\t" + ix, L"url\t" + s.path + L"\t");
        DWORD attr = GetFileAttributesW(s.path.c_str());
        if (attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_READONLY)) SetFileAttributesW(s.path.c_str(), attr & ~FILE_ATTRIBUTE_READONLY);
        bool ok = WritePrivateProfileStringW(L"InternetShortcut", L"IconFile", ico.c_str(), s.path.c_str()) &&
                  WritePrivateProfileStringW(L"InternetShortcut", L"IconIndex", L"0", s.path.c_str());
        WritePrivateProfileStringW(nullptr, nullptr, nullptr, s.path.c_str());   // сбросить кэш ini
        if (attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_READONLY)) SetFileAttributesW(s.path.c_str(), attr);
        return ok;
    }
    IShellLinkW* sl = nullptr; IPersistFile* pf = nullptr;
    bool ok = false;
    if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&sl))) &&
        SUCCEEDED(sl->QueryInterface(IID_PPV_ARGS(&pf))) && SUCCEEDED(pf->Load(s.path.c_str(), STGM_READWRITE))) {
        wchar_t old[MAX_PATH * 2] = {0}; int idx = 0;
        sl->GetIconLocation(old, MAX_PATH * 2, &idx);
        std::wstring o = old;
        if (o.find(L"\\Sugrob\\icons\\") == std::wstring::npos)
            icoBackupAdd(L"lnk\t" + s.path + L"\t" + (o.empty() ? std::wstring(L"\x01") : o) + L"\t" + std::to_wstring(idx), L"lnk\t" + s.path + L"\t");
        ok = SUCCEEDED(sl->SetIconLocation(ico.c_str(), 0)) && SUCCEEDED(pf->Save(s.path.c_str(), TRUE));
    }
    if (pf) pf->Release(); if (sl) sl->Release();
    if (ok) SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, s.path.c_str(), nullptr);
    return ok;
}

// ---------------------------------------------------------------- реестр (HKCU) и desktop.ini
static const wchar_t* kIcoClsKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\CLSID\\";
static void icoRegSet(const std::wstring& sub, const wchar_t* name, const std::wstring& val) {
    HKEY k;
    std::wstring nm = name ? name : L"";
    if (RegOpenKeyExW(HKEY_CURRENT_USER, sub.c_str(), 0, KEY_READ, &k) == ERROR_SUCCESS) {
        wchar_t buf[1024] = {0}; DWORD sz = sizeof(buf), type = 0;
        LONG r = RegQueryValueExW(k, name, nullptr, &type, (BYTE*)buf, &sz);
        RegCloseKey(k);
        std::wstring old = r == ERROR_SUCCESS ? std::wstring(buf) : L"\x01";
        if (old.find(L"\\Sugrob\\icons\\") == std::wstring::npos) icoBackupAdd(L"reg\t" + sub + L"\t" + nm + L"\t" + old, L"reg\t" + sub + L"\t" + nm + L"\t");
    } else icoBackupAdd(L"reg\t" + sub + L"\t" + nm + L"\t\x01", L"reg\t" + sub + L"\t" + nm + L"\t");
    if (RegCreateKeyExW(HKEY_CURRENT_USER, sub.c_str(), 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr) == ERROR_SUCCESS) {
        RegSetValueExW(k, name, 0, REG_EXPAND_SZ, (const BYTE*)val.c_str(), (DWORD)((val.size() + 1) * 2));
        RegCloseKey(k);
    }
}
static bool icoSetFolder(const std::wstring& dir, const std::wstring& ico) {
    if (dir.empty() || GetFileAttributesW(dir.c_str()) == INVALID_FILE_ATTRIBUTES) return false;
    std::wstring ini = dir + L"\\desktop.ini";
    std::string old;
    if (!icoBackupHas(L"ini\t" + dir + L"\t")) {
        bool had = readFile(ini, old);
        std::string hexs;
        if (had) {   // содержимое как есть — шестнадцатеричной строкой
            static const char* hx = "0123456789abcdef";
            for (unsigned char c : old) { hexs.push_back(hx[c >> 4]); hexs.push_back(hx[c & 15]); }
        }
        DWORD da = GetFileAttributesW(dir.c_str());
        icoBackupAdd(L"ini\t" + dir + L"\t" + (had ? W16(hexs) : std::wstring(L"\x01")) + L"\t" + std::to_wstring(da), L"ini\t" + dir + L"\t");
    }
    DWORD fa = GetFileAttributesW(ini.c_str());
    if (fa != INVALID_FILE_ATTRIBUTES) SetFileAttributesW(ini.c_str(), FILE_ATTRIBUTE_NORMAL);
    bool ok = WritePrivateProfileStringW(L".ShellClassInfo", L"IconResource", (ico + L",0").c_str(), ini.c_str()) != 0;
    WritePrivateProfileStringW(L".ShellClassInfo", L"IconFile", ico.c_str(), ini.c_str());
    WritePrivateProfileStringW(L".ShellClassInfo", L"IconIndex", L"0", ini.c_str());
    WritePrivateProfileStringW(nullptr, nullptr, nullptr, ini.c_str());
    SetFileAttributesW(ini.c_str(), FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
    DWORD da = GetFileAttributesW(dir.c_str());
    if (!(da & (FILE_ATTRIBUTE_READONLY | FILE_ATTRIBUTE_SYSTEM))) SetFileAttributesW(dir.c_str(), da | FILE_ATTRIBUTE_READONLY);   // без этого Проводник desktop.ini не читает
    SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, dir.c_str(), nullptr);
    return ok;
}

// ---------------------------------------------------------------- все папки: HKLM\...\Shell Icons (отдельный процесс с правами администратора)
static const wchar_t* kShellIconsKey = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Icons";
static std::wstring icoCommonDir() {
    std::wstring pd = icoKnown(FOLDERID_ProgramData);
    return pd.empty() ? L"" : pd + L"\\Podokonnik\\icons";
}
// запускается как «Подоконник.exe --icons-admin <папка с folder.ico>» или «--icons-admin-reset»
static int icoAdminMain(const std::wstring& folderIco, const std::wstring& openIco, bool reset) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    HKEY k;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, kShellIconsKey, 0, nullptr, 0, KEY_READ | KEY_WRITE | KEY_WOW64_64KEY, nullptr, &k, nullptr) != ERROR_SUCCESS) return 2;
    for (const wchar_t* v : {L"3", L"4"}) {
        std::wstring keep = std::wstring(L"Podokonnik_") + v;
        wchar_t buf[1024] = {0}; DWORD sz = sizeof(buf), type = 0;
        bool has = RegQueryValueExW(k, v, nullptr, &type, (BYTE*)buf, &sz) == ERROR_SUCCESS;
        if (reset) {
            wchar_t kb[1024] = {0}; DWORD ksz = sizeof(kb);
            if (RegQueryValueExW(k, keep.c_str(), nullptr, &type, (BYTE*)kb, &ksz) == ERROR_SUCCESS) {
                if (kb[0]) RegSetValueExW(k, v, 0, REG_SZ, (const BYTE*)kb, (DWORD)((wcslen(kb) + 1) * 2)); else RegDeleteValueW(k, v);
                RegDeleteValueW(k, keep.c_str());
            } else if (has && wcsstr(buf, L"\\Podokonnik\\icons\\")) RegDeleteValueW(k, v);
            continue;
        }
        // запомнить чужое значение один раз
        wchar_t kb[8]; DWORD ksz = sizeof(kb);
        if (RegQueryValueExW(k, keep.c_str(), nullptr, nullptr, (BYTE*)kb, &ksz) == ERROR_FILE_NOT_FOUND) {
            std::wstring o = has && !wcsstr(buf, L"\\Podokonnik\\icons\\") ? std::wstring(buf) : L"";
            RegSetValueExW(k, keep.c_str(), 0, REG_SZ, (const BYTE*)o.c_str(), (DWORD)((o.size() + 1) * 2));
        }
        std::wstring dst = icoCommonDir();
        SHCreateDirectoryExW(nullptr, dst.c_str(), nullptr);
        // новое имя каждый раз — иначе Windows покажет старую картинку из своего кэша
        std::wstring name = (wcscmp(v, L"3") == 0 ? L"folder-" : L"folder-open-") + std::to_wstring(GetTickCount()) + L".ico";
        {
            WIN32_FIND_DATAW fd;
            std::wstring mask = dst + (wcscmp(v, L"3") == 0 ? L"\\folder-*.ico" : L"\\folder-open-*.ico");
            HANDLE h = FindFirstFileW(mask.c_str(), &fd);
            if (h != INVALID_HANDLE_VALUE) {
                do {
                    std::wstring n = fd.cFileName;
                    if (wcscmp(v, L"3") == 0 && n.rfind(L"folder-open-", 0) == 0) continue;
                    DeleteFileW((dst + L"\\" + n).c_str());
                } while (FindNextFileW(h, &fd));
                FindClose(h);
            }
        }
        std::wstring from = wcscmp(v, L"3") == 0 ? folderIco : openIco, to = dst + L"\\" + name;
        if (!CopyFileW(from.c_str(), to.c_str(), FALSE)) continue;
        std::wstring val = to + L",0";
        RegSetValueExW(k, v, 0, REG_SZ, (const BYTE*)val.c_str(), (DWORD)((val.size() + 1) * 2));
    }
    RegCloseKey(k);
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nullptr, nullptr);
    return 0;
}
static bool icoRunAdmin(const std::wstring& params) {
    wchar_t self[MAX_PATH * 2] = {0};
    GetModuleFileNameW(nullptr, self, MAX_PATH * 2);
    SHELLEXECUTEINFOW ei{sizeof(ei)};
    ei.fMask = SEE_MASK_NOCLOSEPROCESS | SEE_MASK_NOASYNC;
    ei.lpVerb = L"runas"; ei.lpFile = self; ei.lpParameters = params.c_str(); ei.nShow = SW_HIDE;
    if (!ShellExecuteExW(&ei) || !ei.hProcess) return false;
    WaitForSingleObject(ei.hProcess, 60000);
    DWORD code = 1; GetExitCodeProcess(ei.hProcess, &code);
    CloseHandle(ei.hProcess);
    return code == 0;
}
static bool icoHklmSet() {
    HKEY k; bool r = false;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, kShellIconsKey, 0, KEY_READ | KEY_WOW64_64KEY, &k) == ERROR_SUCCESS) {
        wchar_t buf[1024] = {0}; DWORD sz = sizeof(buf);
        r = RegQueryValueExW(k, L"3", nullptr, nullptr, (BYTE*)buf, &sz) == ERROR_SUCCESS && wcsstr(buf, L"\\Podokonnik\\icons\\");
        RegCloseKey(k);
    }
    return r;
}

// ---------------------------------------------------------------- обновить значки в Проводнике
static void icoRefreshShell() {
    for (REFKNOWNFOLDERID id : {FOLDERID_Desktop, FOLDERID_PublicDesktop, FOLDERID_Programs, FOLDERID_Profile}) {
        std::wstring d = icoKnown(id);
        if (!d.empty()) SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_PATHW | SHCNF_FLUSHNOWAIT, d.c_str(), nullptr);
    }
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST | SHCNF_FLUSH, nullptr, nullptr);
    wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
    std::wstring cmd = std::wstring(L"\"") + sys + L"\\ie4uinit.exe\" -show";
    STARTUPINFOW si{sizeof(si)}; PROCESS_INFORMATION pi{};
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);   // не ждём: Проводник обновится сам
    }
}

// ---------------------------------------------------------------- вернуть как было
static int icoRestoreAll(bool hklm) {
    icoBackupLoad();
    int n = 0;
    for (auto& l : gIcoBackup) {
        auto f = icoSplit(l);
        if (f.size() < 3) continue;
        if (f[0] == L"lnk" && f.size() >= 4) {
            IShellLinkW* sl = nullptr; IPersistFile* pf = nullptr;
            if (SUCCEEDED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&sl))) &&
                SUCCEEDED(sl->QueryInterface(IID_PPV_ARGS(&pf))) && SUCCEEDED(pf->Load(f[1].c_str(), STGM_READWRITE))) {
                sl->SetIconLocation(f[2] == L"\x01" ? L"" : f[2].c_str(), _wtoi(f[3].c_str()));
                if (SUCCEEDED(pf->Save(f[1].c_str(), TRUE))) ++n;
            }
            if (pf) pf->Release(); if (sl) sl->Release();
            SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, f[1].c_str(), nullptr);
        } else if (f[0] == L"url" && f.size() >= 4) {
            if (f[2] == L"\x01") { WritePrivateProfileStringW(L"InternetShortcut", L"IconFile", nullptr, f[1].c_str()); WritePrivateProfileStringW(L"InternetShortcut", L"IconIndex", nullptr, f[1].c_str()); }
            else { WritePrivateProfileStringW(L"InternetShortcut", L"IconFile", f[2].c_str(), f[1].c_str()); WritePrivateProfileStringW(L"InternetShortcut", L"IconIndex", f[3].c_str(), f[1].c_str()); }
            WritePrivateProfileStringW(nullptr, nullptr, nullptr, f[1].c_str());
            SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, f[1].c_str(), nullptr);
            ++n;
        } else if (f[0] == L"reg" && f.size() >= 4) {
            HKEY k;
            if (RegOpenKeyExW(HKEY_CURRENT_USER, f[1].c_str(), 0, KEY_WRITE, &k) == ERROR_SUCCESS) {
                const wchar_t* nm = f[2].empty() ? nullptr : f[2].c_str();
                if (f[3] == L"\x01") RegDeleteValueW(k, nm);
                else RegSetValueExW(k, nm, 0, REG_EXPAND_SZ, (const BYTE*)f[3].c_str(), (DWORD)((f[3].size() + 1) * 2));
                RegCloseKey(k);
            }
            ++n;
        } else if (f[0] == L"ini" && f.size() >= 4) {
            std::wstring ini = f[1] + L"\\desktop.ini";
            SetFileAttributesW(ini.c_str(), FILE_ATTRIBUTE_NORMAL);
            if (f[2] == L"\x01") DeleteFileW(ini.c_str());
            else {
                std::string hex = U8(f[2]), raw;
                for (size_t i = 0; i + 1 < hex.size(); i += 2) raw.push_back((char)strtol(hex.substr(i, 2).c_str(), nullptr, 16));
                writeFile(ini, raw);
                SetFileAttributesW(ini.c_str(), FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
            }
            DWORD da = (DWORD)_wtoi(f[3].c_str());
            if (da && da != INVALID_FILE_ATTRIBUTES) SetFileAttributesW(f[1].c_str(), da);
            SHChangeNotify(SHCNE_UPDATEITEM, SHCNF_PATHW, f[1].c_str(), nullptr);
            ++n;
        }
    }
    gIcoBackup.clear();
    DeleteFileW((icoDir() + L"\\backup.txt").c_str());
    if (hklm && icoHklmSet()) icoRunAdmin(L"--icons-admin-reset");
    return n;
}

// ---------------------------------------------------------------- поток: поставить пак
// паки берём с сайта (одно соединение на поток, без повторных рукопожатий); пока их там нет
// (проверка до выкладки) — из папки данных icons-src (или из icons-src.zip рядом — распакуем один раз)
static volatile LONG gIcoLocal = -1;   // -1 — ещё не знаем, 0 — сайт, 1 — своя папка
struct IcoHttp {
    HINTERNET ses = nullptr, con = nullptr;
    ~IcoHttp() { if (con) WinHttpCloseHandle(con); if (ses) WinHttpCloseHandle(ses); }
    bool get(const std::wstring& rel, std::string& out, size_t cap = 4 * 1024 * 1024) {
        out.clear();
        if (!ses) {
            ses = WinHttpOpen(L"Podokonnik", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
            if (!ses) ses = WinHttpOpen(L"Podokonnik", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
            if (!ses) return false;
            WinHttpSetTimeouts(ses, 8000, 8000, 15000, 20000);
            DWORD proto = 0x00000800 | 0x00002000;
            if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) { proto = 0x00000800; WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto)); }
            con = WinHttpConnect(ses, kIcoHost, INTERNET_DEFAULT_HTTPS_PORT, 0);
        }
        if (!con) return false;
        std::wstring path = std::wstring(kIcoPath) + rel;
        HINTERNET req = WinHttpOpenRequest(con, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        bool ok = false;
        if (req && WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(req, nullptr)) {
            DWORD status = 0, sz = sizeof(status);
            WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
            char buf[16384]; DWORD got = 0;
            while (status == 200 && WinHttpReadData(req, buf, sizeof buf, &got) && got && out.size() < cap) out.append(buf, got);
            ok = status == 200 && !out.empty();
        }
        if (req) WinHttpCloseHandle(req);
        return ok;
    }
};
static bool icoLocalGet(const std::wstring& rel, std::string& out) {
    std::wstring local = baseDataDir() + L"\\icons-src", zip = local + L".zip";
    auto mtime = [](const std::wstring& f) -> ULONGLONG {
        WIN32_FILE_ATTRIBUTE_DATA a; if (!GetFileAttributesExW(f.c_str(), GetFileExInfoStandard, &a)) return 0;
        return ((ULONGLONG)a.ftLastWriteTime.dwHighDateTime << 32) | a.ftLastWriteTime.dwLowDateTime; };
    static volatile LONG unpacking = 0;
    ULONGLONG zt = mtime(zip);
    if (zt && zt > mtime(local + L"\\.stamp") && InterlockedCompareExchange(&unpacking, 1, 0) == 0) {   // новый архив — распаковать
        CreateDirectoryW(local.c_str(), nullptr);
        wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
        std::wstring cmd = std::wstring(L"\"") + sys + L"\\tar.exe\" -xf \"" + zip + L"\" -C \"" + local + L"\"";
        STARTUPINFOW si{sizeof(si)}; PROCESS_INFORMATION pi{};
        if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
            WaitForSingleObject(pi.hProcess, 180000); CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        }
        writeFile(local + L"\\.stamp", "1");
        InterlockedExchange(&unpacking, 0);
    }
    while (unpacking) Sleep(100);
    std::wstring p = local + L"\\" + rel;
    for (auto& c : p) if (c == L'/') c = L'\\';
    return readFile(p, out) && !out.empty();
}
static bool icoGet(IcoHttp& h, const std::wstring& rel, std::string& out) {
    if (gIcoLocal != 1 && h.get(rel, out)) { gIcoLocal = 0; return true; }
    if (gIcoLocal == 0) return false;
    if (icoLocalGet(rel, out)) { gIcoLocal = 1; return true; }
    return false;
}

// каталог для окна настроек: catalog.txt и все превью одним файлом previews.txt (id<TAB>base64)
static std::string gIcoCatJson;
static volatile LONG gIcoCatBusy = 0;
static DWORD WINAPI IcoCatThread(LPVOID) {
    IcoHttp h;
    std::string cat, prev, js = "{\"type\":\"icoCatalog\",\"ok\":";
    if (!icoGet(h, L"catalog.txt", cat)) js += "false}";
    else {
        js += "true,\"text\":" + js::esc(cat) + ",\"previews\":{";
        bool first = true;
        if (icoGet(h, L"previews.txt", prev))
            for (size_t p = 0; p < prev.size();) {
                size_t e = prev.find('\n', p); if (e == std::string::npos) e = prev.size();
                std::string line = prev.substr(p, e - p); p = e + 1;
                while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
                size_t t = line.find('\t');
                if (t == std::string::npos) continue;
                js += std::string(first ? "" : ",") + js::esc(line.substr(0, t)) + ":\"data:image/png;base64," + line.substr(t + 1) + "\"";
                first = false;
            }
        js += "}}";
    }
    if (js.find("\"ok\":true") != std::string::npos) {   // запомнить на диск: в следующий раз список откроется сразу
        gIcoCatJson = js;
        CreateDirectoryW(icoDir().c_str(), nullptr);
        writeFile(icoDir() + L"\\catalog-cache.json", js);
    } else if (gIcoCatJson.empty()) gIcoCatJson = js;
    PostMessageW(gMsgWnd, WM_ICOCAT, 0, 0);
    return 0;
}

// список пака: значки и «base <пак>», откуда брать остальное
static void icoParseList(const std::string& list, const std::string& pack, std::unordered_map<std::string, std::string>& where, std::string& base) {
    for (size_t p = 0; p < list.size();) {
        size_t e = list.find('\n', p); if (e == std::string::npos) e = list.size();
        std::string id = list.substr(p, e - p); p = e + 1;
        while (!id.empty() && (id.back() == '\r' || id.back() == ' ')) id.pop_back();
        if (id.rfind("base ", 0) == 0) { base = id.substr(5); continue; }
        if (!id.empty() && !where.count(id)) where[id] = pack;
    }
}
// параллельно: несколько потоков берут задания по очереди
struct IcoPar { volatile LONG next = 0; int n = 0; std::function<void(int, IcoHttp&)> fn; };
static DWORD WINAPI IcoParBody(LPVOID p) {
    IcoPar* c = (IcoPar*)p;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    {
        IcoHttp h;
        for (;;) { LONG i = InterlockedIncrement(&c->next) - 1; if (i >= c->n) break; c->fn((int)i, h); }
    }
    CoUninitialize();
    return 0;
}
static void icoParallel(int n, int threads, std::function<void(int, IcoHttp&)> fn) {
    if (n <= 0) return;
    IcoPar c; c.n = n; c.fn = fn;
    std::vector<HANDLE> th;
    for (int i = 0; i < std::min(threads, n); ++i) { HANDLE t = CreateThread(nullptr, 0, IcoParBody, &c, 0, nullptr); if (t) th.push_back(t); }
    if (th.empty()) { IcoParBody(&c); return; }
    WaitForMultipleObjects((DWORD)th.size(), th.data(), TRUE, INFINITE);
    for (HANDLE t : th) CloseHandle(t);
}

static bool icoWebPrepare(const std::string& pack, const std::string& cat, std::string& err, std::function<void(int)> prog);
static DWORD WINAPI IcoWebListThread(LPVOID);
static std::string gIcoWebQuery, gIcoWebJson;
static volatile LONG gIcoWebBusy = 0;
#define WM_ICOWEB (WM_APP + 66)
static DWORD WINAPI IcoThread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    DWORD t0 = GetTickCount();
    std::string pack = gIcoJobPack;
    std::string err;
    volatile LONG changed = 0;
    icoRestoreAll(pack.empty() || !gIcoOptAll);   // сначала вернуть всё как было (другой пак или стандартные)
    if (!pack.empty()) {
        IcoHttp http;
        std::string cat, list, blist, base;
        std::unordered_map<std::string, std::string> where;   // значок → из какого пака
        bool web = pack.rfind("web-", 0) == 0;   // тема с gnome-look.org: скачать архив и разобрать у себя
        if (!icoGet(http, L"catalog.txt", cat) || !icoParseCatalog(cat)) err = T8("Не удалось скачать каталог значков — проверь интернет", "Couldn't download the icon catalog: check the internet");
        else if (web) {
            if (icoWebPrepare(pack, cat, err, [](int p) { PostMessageW(gMsgWnd, WM_ICOPROG, (WPARAM)std::max(1, std::min(99, p)), 0); })) { err.clear(); readFile(icoDir() + L"\\" + W16(pack) + L"\\list.txt", list); }
            else if (err.empty()) err = T8("Не удалось поставить тему", "Couldn't set the theme");
        }
        else if (!icoGet(http, W16(pack) + L"/list.txt", list)) err = T8("Не удалось скачать пак значков", "Couldn't download the icon pack");
        if (err.empty()) {
            icoParseList(list, pack, where, base);
            if (!base.empty() && icoGet(http, W16(base) + L"/list.txt", blist)) { std::string b2; icoParseList(blist, base, where, b2); }
            std::unordered_map<std::string, bool> have;
            for (auto& w : where) have[w.first] = true;
            auto icoPath = [&](const std::string& id) {
                auto it = where.find(id);
                std::string src = it == where.end() ? pack : it->second;
                return icoDir() + L"\\" + W16(src) + L"\\" + W16(id) + L"-2.ico";   // -2: маленькие размеры BMP
            };
            // ярлыки
            std::vector<std::pair<IcoShortcut, std::string>> jobs;
            std::vector<IcoShortcut> frames;
            if (gIcoOptApps) {
                std::vector<IcoShortcut> sc;
                icoScan(icoKnown(FOLDERID_Desktop), sc, 1);
                icoScan(icoKnown(FOLDERID_PublicDesktop), sc, 1);
                icoScan(icoKnown(FOLDERID_Programs), sc, 0);
                icoScan(icoKnown(FOLDERID_CommonPrograms), sc, 0);
                icoScan(icoKnown(FOLDERID_RoamingAppData) + L"\\Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar", sc, 1);
                for (auto& s : sc) {
                    std::string id;
                    if (s.steam > 0 && have.count("steam_" + std::to_string(s.steam))) id = "steam_" + std::to_string(s.steam);
                    if (id.empty()) id = icoMatch(s.exe, s.name, s.full, have);
                    if (!id.empty()) jobs.push_back({s, id});
                    else if (gIcoOptFrame && have.count("tile") && !s.icoFile.empty()) frames.push_back(s);
                }
                alog("icons: shortcuts %d, pack icons %d, framed %d", (int)sc.size(), (int)jobs.size(), (int)frames.size());
            }
            std::vector<std::pair<std::wstring, std::string>> folders;   // папка → значок
            if (gIcoOptFolders) {
                folders.push_back({icoKnown(FOLDERID_Downloads), "folder-download"});
                folders.push_back({icoKnown(FOLDERID_Documents), "folder-documents"});
                folders.push_back({icoKnown(FOLDERID_Music), "folder-music"});
                folders.push_back({icoKnown(FOLDERID_Pictures), "folder-pictures"});
                folders.push_back({icoKnown(FOLDERID_Videos), "folder-videos"});
                folders.push_back({icoKnown(FOLDERID_Desktop), "folder-desktop"});
                // обычные папки на рабочем столе — каждой свой desktop.ini (без прав администратора)
                std::wstring desk = icoKnown(FOLDERID_Desktop);
                WIN32_FIND_DATAW fd;
                HANDLE h = desk.empty() ? INVALID_HANDLE_VALUE : FindFirstFileW((desk + L"\\*").c_str(), &fd);
                if (h != INVALID_HANDLE_VALUE) {
                    int cnt = 0;
                    do {
                        std::wstring n = fd.cFileName;
                        if (n == L"." || n == L".." || !(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
                        if (fd.dwFileAttributes & (FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_REPARSE_POINT)) continue;
                        std::wstring sub = desk + L"\\" + n;
                        std::string ini;
                        if (readFile(sub + L"\\desktop.ini", ini) && !icoBackupHas(L"ini\t" + sub + L"\t")) continue;   // у папки уже свой значок — не трогаем
                        folders.push_back({sub, "folder"});
                        if (++cnt >= 200) break;
                    } while (FindNextFileW(h, &fd));
                    FindClose(h);
                }
            }
            // 1) все нужные значки пака — скачать параллельно (что уже есть на диске — не качаем)
            std::vector<std::string> need;
            {
                std::unordered_map<std::string, bool> seen;
                auto want = [&](const std::string& id) { if (have.count(id) && !seen.count(id)) { seen[id] = true; need.push_back(id); } };
                for (auto& j : jobs) want(j.second);
                for (auto& f : folders) want(f.second);
                if (gIcoOptFolders) for (const char* x : {"folder-desktop", "folder-documents", "folder-download", "folder-music", "folder-pictures", "folder-videos"}) want(x);
                if (gIcoOptSystem) for (const char* x : {"computer", "user-home", "trash", "trash-full"}) want(x);
                if (gIcoOptAll) { want("folder"); want("folder-open"); }
            }
            int total = (int)need.size() + (int)frames.size() + 1;
            volatile LONG done = 0;
            auto prog = [&]() { LONG d = InterlockedIncrement(&done); PostMessageW(gMsgWnd, WM_ICOPROG, (WPARAM)std::min<LONG>(99, d * 100 / std::max(1, total)), 0); };
            PostMessageW(gMsgWnd, WM_ICOPROG, 1, 0);
            for (auto& w : where) SHCreateDirectoryExW(nullptr, (icoDir() + L"\\" + W16(w.second)).c_str(), nullptr);
            SHCreateDirectoryExW(nullptr, (icoDir() + L"\\" + W16(pack)).c_str(), nullptr);
            icoParallel((int)need.size(), 8, [&](int i, IcoHttp& h) {
                const std::string& id = need[i];
                std::wstring p = icoPath(id);
                if (GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) {
                    std::string png;
                    auto it = where.find(id);
                    if (it != where.end() && icoGet(h, W16(it->second) + L"/" + W16(id) + L".png", png)) icoFromPng(png, p);
                }
                prog();
            });
            auto ico = [&](const std::string& id) -> std::wstring { if (!have.count(id)) return L""; std::wstring p = icoPath(id); return GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES ? p : L""; };
            // 2) программы без значка — их значок в рамке пака (тоже параллельно)
            std::vector<std::wstring> framedPath(frames.size());
            if (!frames.empty()) {
                std::string tile, style;
                float inner = 0.58f, offy = 0;
                std::string tsrc = where.count("tile") ? where["tile"] : pack;
                bool localTile = tsrc.rfind("web-", 0) == 0;
                if (localTile ? readFile(icoDir() + L"\\" + W16(tsrc) + L"\\tile.png", tile) : icoGet(http, W16(tsrc) + L"/tile.png", tile)) {
                    if (localTile ? readFile(icoDir() + L"\\" + W16(tsrc) + L"\\style.txt", style) : icoGet(http, W16(tsrc) + L"/style.txt", style)) {
                        size_t a = style.find("inner "); if (a != std::string::npos) inner = (float)atof(style.c_str() + a + 6);
                        a = style.find("offy "); if (a != std::string::npos) offy = (float)atof(style.c_str() + a + 5);
                    }
                    std::wstring tdir = icoDir() + L"\\" + W16(tsrc);
                    SHCreateDirectoryExW(nullptr, tdir.c_str(), nullptr);
                    icoParallel((int)frames.size(), 6, [&](int i, IcoHttp&) {
                        const IcoShortcut& s = frames[i];
                        uint32_t hh = 2166136261u;
                        for (wchar_t c : icoLower(s.icoFile) + L"|" + std::to_wstring(s.icoIdx)) { hh ^= (uint32_t)c; hh *= 16777619u; }
                        wchar_t nmb[32]; swprintf(nmb, 32, L"\\app-%08x-2.ico", hh);
                        std::wstring p = tdir + nmb;
                        if (GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES || icoFramed(tile, inner, offy, s.icoFile, s.icoIdx, p)) framedPath[i] = p;
                        prog();
                    });
                }
            }
            // 3) поставить (быстро: только пишем ярлыки и реестр)
            for (auto& j : jobs) { std::wstring p = ico(j.second); if (!p.empty() && icoSetShortcut(j.first, p)) ++changed; }
            for (size_t i = 0; i < frames.size(); ++i) if (!framedPath[i].empty() && icoSetShortcut(frames[i], framedPath[i])) ++changed;
            for (auto& fo : folders) { std::wstring p = ico(fo.second); if (!p.empty() && icoSetFolder(fo.first, p)) ++changed; }
            if (gIcoOptFolders) {   // те же папки в «Этом компьютере» и слева в Проводнике — свои CLSID
                struct { const wchar_t* clsid; const char* id; } lib[] = {
                    {L"{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}", "folder-desktop"},
                    {L"{d3162b92-9365-467a-956b-92703aca08af}", "folder-documents"}, {L"{A8CDFF1C-4878-43be-B5FD-F8091C1C60D0}", "folder-documents"},
                    {L"{088e3905-0323-4b02-9826-5d99428e115f}", "folder-download"}, {L"{374DE290-123F-4565-9164-39C4925E467B}", "folder-download"},
                    {L"{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}", "folder-music"}, {L"{1CF1260C-4DD0-4ebb-811F-33C572699FDE}", "folder-music"},
                    {L"{24ad3ad4-a569-4530-98e1-ab02f9417aa8}", "folder-pictures"}, {L"{3ADD1653-EB32-4cb0-BBD7-DFA0ABB5ACCA}", "folder-pictures"},
                    {L"{f86fa3ab-70d2-4fc7-9c99-fcbf05467f3a}", "folder-videos"}, {L"{A0953C92-50DC-43bf-BE83-3742FED03C9C}", "folder-videos"},
                };
                for (auto& l : lib) { std::wstring p = ico(l.id); if (!p.empty()) icoRegSet(std::wstring(L"Software\\Classes\\CLSID\\") + l.clsid + L"\\DefaultIcon", nullptr, p + L",0"); }
            }
            if (gIcoOptSystem) {
                struct { const wchar_t* clsid; const char* id; const wchar_t* val; } sys[] = {
                    {L"{20D04FE0-3AEA-1069-A2D8-08002B30309D}", "computer", nullptr},
                    {L"{59031a47-3f72-44a7-89c5-5595fe6b30ee}", "user-home", nullptr},
                    {L"{645FF040-5081-101B-9F08-00AA002F954E}", "trash", L"empty"},
                    {L"{645FF040-5081-101B-9F08-00AA002F954E}", "trash-full", L"full"},
                    {L"{645FF040-5081-101B-9F08-00AA002F954E}", "trash", nullptr},
                };
                for (auto& s : sys) {
                    std::wstring p = ico(s.id);
                    if (p.empty()) continue;
                    icoRegSet(std::wstring(kIcoClsKey) + s.clsid + L"\\DefaultIcon", s.val, p + L",0");
                    ++changed;
                }
            }
            icoBackupSave();
            if (gIcoOptAll) {   // все папки — через администратора
                std::wstring f = ico("folder"), fo = ico("folder-open");
                if (!f.empty() && !icoRunAdmin(L"--icons-admin \"" + f + L"\" \"" + (fo.empty() ? f : fo) + L"\"")) err = T8("Все папки не поменялись: Windows не дала разрешение администратора", "Other folders didn't change: Windows didn't grant administrator rights");
                else if (!f.empty()) ++changed;
            }
            gIcoApplied = pack;
        }
    } else gIcoApplied.clear();
    icoBackupSave();
    icoRefreshShell();
    gIcoChanged = changed;
    alog("icons: done in %lu ms", GetTickCount() - t0);
    if (!err.empty()) gIcoMsg = err;
    else if (pack.empty()) gIcoMsg = T8("Вернул стандартные значки Windows", "Standard Windows icons are back");
    else {
        char b[160];
        snprintf(b, sizeof b, T8("Значки поставлены: %d. Если какие-то не сменились — перезапусти Проводник", "Icons set: %d. If some didn't change, restart Explorer"), (int)changed);
        gIcoMsg = b;
    }
    PostMessageW(gMsgWnd, WM_ICODONE, err.empty() ? 1 : 0, 0);
    CoUninitialize();
    return 0;
}
static void icoStart(const std::string& pack) {
    if (InterlockedCompareExchange(&gIcoBusy, 1, 0) != 0) return;
    gIcoJobPack = pack;
    gIcoMsg.clear();
    HANDLE t = CreateThread(nullptr, 0, IcoThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t); else InterlockedExchange(&gIcoBusy, 0);
}
static void icoRestartExplorer() {
    std::wstring cmd = L"cmd.exe /c taskkill /f /im explorer.exe & start explorer.exe";
    STARTUPINFOW si{sizeof(si)}; PROCESS_INFORMATION pi{};
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    if (CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) { CloseHandle(pi.hProcess); CloseHandle(pi.hThread); }
}

// ---------------------------------------------------------------- настройки и окно
static void icoSave() {
    cfgSetStr(L"IconPack", W16(gIcoApplied));
    regSet(L"IcoFrame", gIcoOptFrame); regSet(L"IcoApps", gIcoOptApps); regSet(L"IcoSystem", gIcoOptSystem); regSet(L"IcoFolders", gIcoOptFolders); regSet(L"IcoAll", gIcoOptAll);
}
static void icoLoad() {
    std::wstring p;
    gIcoApplied = cfgGetStr(L"IconPack", p) ? U8(p) : "";
    gIcoOptApps = regGet(L"IcoApps", 1) != 0; gIcoOptSystem = regGet(L"IcoSystem", 1) != 0;
    gIcoOptFolders = regGet(L"IcoFolders", 1) != 0; gIcoOptAll = regGet(L"IcoAll", 0) != 0;
    gIcoOptFrame = regGet(L"IcoFrame", 1) != 0;
}
static void icoState(js::Value& v) {
    auto st = [&](const char* k, const std::string& s) { js::Value x; x.type = js::Value::Str; x.s = s; v.o.emplace_back(k, x); };
    auto bl = [&](const char* k, bool b) { js::Value x; x.type = js::Value::Bool; x.b = b; v.o.emplace_back(k, x); };
    st("icoPack", gIcoApplied); st("icoJob", gIcoBusy ? gIcoJobPack : std::string("~"));
    {
        std::string nmw;
        if (gIcoApplied.rfind("web-", 0) == 0) readFile(icoDir() + L"\\" + W16(gIcoApplied) + L"\\name.txt", nmw);
        st("icoPackName", nmw);
    }
    bl("icoBusy", gIcoBusy != 0);
    bl("icoApps", gIcoOptApps); bl("icoSystem", gIcoOptSystem); bl("icoFolders", gIcoOptFolders); bl("icoAll", gIcoOptAll); bl("icoFrame", gIcoOptFrame);
    st("icoBase", "https://aleksandrkrasnikov97-dot.github.io/podokonnik/icons/");
}
static bool icoUi(const std::string& cmd, const js::Value& m) {
    if (cmd == "icoCatalog") {   // сначала — что есть (с диска), а свежий список — раз за запуск, в фоне
        static bool fresh = false;
        if (gIcoCatJson.empty()) readFile(icoDir() + L"\\catalog-cache.json", gIcoCatJson);
        if (!gIcoCatJson.empty() && gIcoCatJson.find("\"ok\":true") != std::string::npos && gAppHost) wv::post(gAppHost, gIcoCatJson);
        if (!fresh && InterlockedCompareExchange(&gIcoCatBusy, 1, 0) == 0) { fresh = true; HANDLE t = CreateThread(nullptr, 0, IcoCatThread, nullptr, 0, nullptr); if (t) CloseHandle(t); else gIcoCatBusy = 0; }
        return true;
    }
    if (cmd == "icoWeb") {   // страница каталога gnome-look.org
        gIcoWebQuery = std::to_string((int)m.num("page")) + "\t" + m.str("sort") + "\t" + m.str("q").substr(0, 80);
        if (InterlockedCompareExchange(&gIcoWebBusy, 1, 0) == 0) { HANDLE t = CreateThread(nullptr, 0, IcoWebListThread, nullptr, 0, nullptr); if (t) CloseHandle(t); else gIcoWebBusy = 0; }
        return true;
    }
    if (cmd == "icoApply") { icoStart(m.str("pack").substr(0, 40)); appPushState(); return true; }
    if (cmd == "icoWebOpen") { std::string u = m.str("url"); if (u.rfind("https://www.gnome-look.org/", 0) == 0 || u.rfind("https://www.pling.com/", 0) == 0) ShellExecuteW(nullptr, L"open", W16(u).c_str(), nullptr, nullptr, SW_SHOWNORMAL); return true; }
    if (cmd == "icoReset") { icoStart(""); appPushState(); return true; }
    if (cmd == "icoExplorer") { icoRestartExplorer(); return true; }
    if (cmd == "icoOpt") {
        std::string k = m.str("key"); bool b = m.num("value") != 0;
        if (k == "apps") gIcoOptApps = b; else if (k == "system") gIcoOptSystem = b; else if (k == "folders") gIcoOptFolders = b; else if (k == "all") gIcoOptAll = b; else if (k == "frame") gIcoOptFrame = b;
        icoSave(); appPushState();
        return true;
    }
    return false;
}
static bool icoMsg(UINT msg, WPARAM wp) {
    if (msg == WM_ICOWEB) {
        InterlockedExchange(&gIcoWebBusy, 0);
        if (gAppHost) wv::post(gAppHost, gIcoWebJson);
        return true;
    }
    if (msg == WM_ICOCAT) {
        InterlockedExchange(&gIcoCatBusy, 0);
        if (gAppHost) wv::post(gAppHost, gIcoCatJson);
        return true;
    }
    if (msg == WM_ICOPROG) {
        if (gAppHost) wv::post(gAppHost, "{\"type\":\"icoProgress\",\"pct\":" + std::to_string((int)wp) + "}");
        return true;
    }
    if (msg == WM_ICODONE) {
        InterlockedExchange(&gIcoBusy, 0);
        icoSave();
        appToast(gIcoMsg);
        alog("icons: pack=%s changed=%d ok=%d", gIcoApplied.c_str(), gIcoChanged, (int)wp);
        appPushState();
        return true;
    }
    return false;
}
