// Темы значков с сайта gnome-look.org (Pling, раздел «Full Icon Themes», больше тысячи тем) — как наборы курсоров с rw-designer.
// Каталог — их открытый API (OCS). Выбранная тема скачивается архивом (.tar.xz, .tar.gz или .zip), из него достаём только
// нужные значки (папки, Корзина, «Этот компьютер», программы из нашего списка и игры Steam), SVG рисуем сами (nanosvg),
// PNG берём как есть — и кладём .ico в icons\web-<id>, дальше всё как у своих паков (iconpacks.h).
#pragma once
#define XZ_USE_CRC64
#define XZ_DEC_ANY_CHECK
#define XZ_DEC_CONCATENATED
#include "third_party/xz/xz.h"
#include "third_party/tinf/tinf.h"
#define NANOSVG_IMPLEMENTATION
#define NANOSVGRAST_IMPLEMENTATION
#include "third_party/nanosvg/nanosvg.h"
#include "third_party/nanosvg/nanosvgrast.h"


static const wchar_t* kPlingHost = L"api.gnome-look.org";
struct IcoWebFile { std::string url, name; long long kb = 0; };
struct IcoWebItem { std::string name, author, pic, page; std::vector<IcoWebFile> files; };
static std::unordered_map<std::string, IcoWebItem> gIcoWeb;   // id → что знаем о теме
static CRITICAL_SECTION gIcoWebCs;
static bool gIcoWebCsInit = false;

static std::string icoUrlEnc(const std::string& s) {
    std::string o; char b[4];
    for (unsigned char c : s) { if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c; else { snprintf(b, 4, "%%%02X", c); o += b; } }
    return o;
}
static void icoWebRemember(const js::Value& it) {
    IcoWebItem w;
    w.name = it.str("name"); w.author = it.str("personid"); w.pic = it.str("smallpreviewpic1"); w.page = it.str("detailpage");
    for (int k = 1; k <= 30; ++k) {
        char kl[24], kn[24], ks[24];
        snprintf(kl, 24, "downloadlink%d", k); snprintf(kn, 24, "downloadname%d", k); snprintf(ks, 24, "downloadsize%d", k);
        std::string u = it.str(kl);
        if (u.empty()) continue;
        IcoWebFile f; f.url = u; f.name = it.str(kn); f.kb = (long long)it.num(ks);
        w.files.push_back(f);
    }
    std::string id = it.get("id") && it.get("id")->type == js::Value::Num ? std::to_string((long long)it.get("id")->n) : it.str("id");
    if (!gIcoWebCsInit) { InitializeCriticalSection(&gIcoWebCs); gIcoWebCsInit = true; }
    EnterCriticalSection(&gIcoWebCs); gIcoWeb[id] = w; LeaveCriticalSection(&gIcoWebCs);
}
// архив, который годится: tar.xz / tar.gz / tgz / zip, не курсоры, не огромный
static bool icoWebUsable(const IcoWebFile& f) {
    std::string n = f.name; for (auto& c : n) c = (char)tolower((unsigned char)c);
    if (n.find("cursor") != std::string::npos) return false;
    auto ends = [&](const char* e) { size_t l = strlen(e); return n.size() >= l && n.compare(n.size() - l, l, e) == 0; };
    return ends(".tar.xz") || ends(".txz") || ends(".tar.gz") || ends(".tgz") || ends(".zip");
}
static DWORD WINAPI IcoWebListThread(LPVOID) {
    std::string q = gIcoWebQuery;
    size_t a = q.find('\t'), b = q.find('\t', a + 1);
    int page = atoi(q.substr(0, a).c_str());
    std::string sort = q.substr(a + 1, b - a - 1), search = q.substr(b + 1);
    std::string mode = sort == "new" ? "new" : sort == "top" ? "high" : "down";
    std::string path = "/ocs/v1/content/data?categories=132&format=json&pagesize=48&page=" + std::to_string(page) + "&sortmode=" + mode;
    if (!search.empty()) path += "&search=" + icoUrlEnc(search);
    std::string body;
    std::string js = "{\"type\":\"icoWeb\",\"page\":" + std::to_string(page) + ",\"ok\":";
    if (!httpsGet(kPlingHost, W16(path), body, 8 * 1024 * 1024)) js += "false}";
    else {
        js::Value v = js::parse(body);
        const js::Value* data = v.get("data");
        js += "true,\"total\":" + std::to_string((long long)v.num("totalitems")) + ",\"items\":[";
        bool first = true;
        if (data && data->type == js::Value::Arr)
            for (auto& it : data->a) {
                icoWebRemember(it);
                long long kb = 0; bool ok = false;
                for (int k = 1; k <= 30; ++k) {
                    char kn[24], ks[24]; snprintf(kn, 24, "downloadname%d", k); snprintf(ks, 24, "downloadsize%d", k);
                    IcoWebFile f; f.name = it.str(kn); f.kb = (long long)it.num(ks);
                    if (!f.name.empty() && icoWebUsable(f) && (!ok || f.kb < kb)) { kb = f.kb; ok = true; }
                }
                std::string id = it.get("id") && it.get("id")->type == js::Value::Num ? std::to_string((long long)it.get("id")->n) : it.str("id");
                js += std::string(first ? "" : ",") + "{\"id\":" + js::esc(id) + ",\"name\":" + js::esc(it.str("name")) + ",\"author\":" + js::esc(it.str("personid")) +
                      ",\"dl\":" + std::to_string((long long)it.num("downloads")) + ",\"score\":" + std::to_string((int)it.num("score")) +
                      ",\"pic\":" + js::esc(it.str("smallpreviewpic1")) + ",\"page\":" + js::esc(it.str("detailpage")) + ",\"kb\":" + std::to_string(ok ? kb : -1) + "}";
                first = false;
            }
        js += "]}";
    }
    gIcoWebJson = js;
    PostMessageW(gMsgWnd, WM_ICOWEB, 0, 0);
    return 0;
}

// ---------------------------------------------------------------- скачать архив в файл (с ходом)
static bool icoDownload(const std::string& url, const std::wstring& out, std::function<void(int)> prog) {
    std::wstring u = W16(url);
    URL_COMPONENTSW uc{sizeof(uc)};
    wchar_t host[256] = {0}, path[4096] = {0};
    uc.lpszHostName = host; uc.dwHostNameLength = 255; uc.lpszUrlPath = path; uc.dwUrlPathLength = 4095;
    wchar_t extra[2048] = {0}; uc.lpszExtraInfo = extra; uc.dwExtraInfoLength = 2047;
    if (!WinHttpCrackUrl(u.c_str(), 0, 0, &uc)) return false;
    HINTERNET ses = WinHttpOpen(L"Podokonnik", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) ses = WinHttpOpen(L"Podokonnik", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) return false;
    WinHttpSetTimeouts(ses, 15000, 15000, 30000, 60000);
    DWORD proto = 0x00000800 | 0x00002000;
    if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) { proto = 0x00000800; WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto)); }
    HINTERNET con = WinHttpConnect(ses, host, uc.nPort, 0);
    std::wstring full = std::wstring(path) + extra;
    HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", full.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0) : nullptr;
    bool ok = false;
    if (req && WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(req, nullptr)) {
        DWORD status = 0, sz = sizeof(status);
        WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
        wchar_t lenb[32] = {0}; DWORD ls = sizeof(lenb);
        long long total = WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_LENGTH, WINHTTP_HEADER_NAME_BY_INDEX, lenb, &ls, WINHTTP_NO_HEADER_INDEX) ? _wtoi64(lenb) : 0;
        HANDLE fh = status == 200 ? CreateFileW(out.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr) : INVALID_HANDLE_VALUE;
        if (fh != INVALID_HANDLE_VALUE) {
            std::vector<char> buf(256 * 1024);
            DWORD got = 0; long long have = 0; int last = -1;
            ok = true;
            while (WinHttpReadData(req, buf.data(), (DWORD)buf.size(), &got) && got) {
                DWORD w = 0;
                if (!WriteFile(fh, buf.data(), got, &w, nullptr) || w != got) { ok = false; break; }
                have += got;
                if (have > 400LL * 1024 * 1024) { ok = false; break; }   // больше 400 МБ — не тема значков
                int pct = total > 0 ? (int)(have * 100 / total) : (int)std::min<long long>(95, have / (1024 * 1024));
                if (pct != last) { last = pct; prog(pct); }
            }
            CloseHandle(fh);
            ok = ok && have > 0;
        }
    }
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return ok;
}

// ---------------------------------------------------------------- tar по кусочкам: берём только нужные файлы
struct IcoTar {
    std::function<bool(const std::string&)> want;
    std::unordered_map<std::string, std::string> files, links;   // путь → содержимое / цель ссылки
    std::string hdr, longName, paxPath, data, name;
    uint64_t left = 0, pad = 0;
    char type = 0; bool keep = false; int st = 0;   // 0 — заголовок, 1 — данные, 2 — добивка до 512
    size_t kept = 0;
    static uint64_t num(const char* p, int n) {
        if ((unsigned char)p[0] & 0x80) { uint64_t v = 0; for (int i = 1; i < n; ++i) v = (v << 8) | (unsigned char)p[i]; return v; }
        uint64_t v = 0; for (int i = 0; i < n && p[i]; ++i) if (p[i] >= '0' && p[i] <= '7') v = v * 8 + (p[i] - '0');
        return v;
    }
    void header() {
        const char* h = hdr.data();
        bool zero = true; for (int i = 0; i < 512; ++i) if (h[i]) { zero = false; break; }
        if (zero) { st = 0; return; }
        std::string nm(h, strnlen(h, 100)), prefix(h + 345, strnlen(h + 345, 155));
        if (!memcmp(h + 257, "ustar", 5) && !prefix.empty()) nm = prefix + "/" + nm;
        if (!longName.empty()) { nm = longName; longName.clear(); }
        if (!paxPath.empty()) { nm = paxPath; paxPath.clear(); }
        type = h[156];
        left = num(h + 124, 12);
        pad = (512 - left % 512) % 512;
        while (nm.size() > 2 && nm.compare(0, 2, "./") == 0) nm.erase(0, 2);
        name = nm;
        data.clear();
        if (type == '2' || type == '1') { links[nm] = std::string(h + 157, strnlen(h + 157, 100)); keep = false; }
        else if (type == 'L' || type == 'x') keep = true;
        else if (type == '0' || type == 0 || type == '7') keep = left < 4 * 1024 * 1024 && want(nm);
        else keep = false;
        st = left ? 1 : (pad ? 2 : 0);
        if (!left) finish();
    }
    void finish() {
        if (type == 'L') { longName = std::string(data.c_str()); }
        else if (type == 'x') {   // pax: «NN path=...\n»
            size_t p = data.find(" path=");
            if (p != std::string::npos) { size_t e = data.find('\n', p); paxPath = data.substr(p + 6, e - p - 6); }
            size_t l = data.find(" linkpath=");
            if (l != std::string::npos) { size_t e = data.find('\n', l); paxLink = data.substr(l + 10, e - l - 10); }
        } else if (keep) { kept += data.size(); files[name] = data; }
        if ((type == '2' || type == '1') && !paxLink.empty()) { links[name] = paxLink; }
        if (type != 'x') paxLink.clear();
        data.clear();
    }
    std::string paxLink;
    void feed(const uint8_t* p, size_t n) {
        while (n) {
            if (st == 0) {
                size_t k = std::min(n, 512 - hdr.size());
                hdr.append((const char*)p, k); p += k; n -= k;
                if (hdr.size() == 512) { header(); hdr.clear(); }
            } else if (st == 1) {
                size_t k = (size_t)std::min<uint64_t>(n, left);
                if (keep) data.append((const char*)p, k);
                p += k; n -= k; left -= k;
                if (!left) { finish(); st = pad ? 2 : 0; }
            } else {
                size_t k = (size_t)std::min<uint64_t>(n, pad);
                p += k; n -= k; pad -= k;
                if (!pad) st = 0;
            }
        }
    }
};

// распаковать архив: xz и gz — потоком в tar, zip — по оглавлению
static bool icoUnpack(const std::wstring& file, IcoTar& tar, std::string& err) {
    HANDLE fh = CreateFileW(file.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    if (fh == INVALID_HANDLE_VALUE) { err = "open"; return false; }
    LARGE_INTEGER fs{}; GetFileSizeEx(fh, &fs);
    uint8_t magic[6] = {0}; DWORD got = 0;
    ReadFile(fh, magic, 6, &got, nullptr);
    SetFilePointer(fh, 0, nullptr, FILE_BEGIN);
    bool ok = false;
    if (got >= 6 && magic[0] == 0xFD && magic[1] == '7' && magic[2] == 'z' && magic[3] == 'X' && magic[4] == 'Z') {
        xz_crc32_init(); xz_crc64_init();
        xz_dec* d = xz_dec_init(XZ_DYNALLOC, 1u << 28);
        std::vector<uint8_t> in(1 << 20), out(1 << 20);
        xz_buf b{}; b.in = in.data(); b.out = out.data(); b.out_size = out.size();
        xz_ret r = XZ_OK;
        for (;;) {
            if (b.in_pos == b.in_size) { DWORD rd = 0; ReadFile(fh, in.data(), (DWORD)in.size(), &rd, nullptr); b.in_size = rd; b.in_pos = 0; if (!rd) { r = XZ_STREAM_END; break; } }
            r = xz_dec_run(d, &b);
            if (b.out_pos) { tar.feed(out.data(), b.out_pos); b.out_pos = 0; }
            if (r == XZ_STREAM_END) break;
            if (r != XZ_OK && r != XZ_UNSUPPORTED_CHECK) break;
        }
        xz_dec_end(d);
        ok = r == XZ_STREAM_END;
        if (!ok) err = "xz";
    } else if (got >= 2 && magic[0] == 0x1F && magic[1] == 0x8B) {
        if (fs.QuadPart > 300LL * 1024 * 1024) { CloseHandle(fh); err = "big"; return false; }
        std::string src((size_t)fs.QuadPart, '\0');
        DWORD rd = 0; ReadFile(fh, &src[0], (DWORD)src.size(), &rd, nullptr);
        unsigned isize = (unsigned char)src[src.size() - 4] | ((unsigned char)src[src.size() - 3] << 8) | ((unsigned char)src[src.size() - 2] << 16) | ((unsigned)(unsigned char)src[src.size() - 1] << 24);
        if (isize > 900u * 1024 * 1024) { CloseHandle(fh); err = "big"; return false; }
        std::vector<uint8_t> out(isize + 16);
        unsigned dl = isize;
        tinf_init();
        if (tinf_gzip_uncompress(out.data(), &dl, src.data(), (unsigned)src.size()) == TINF_OK) { tar.feed(out.data(), dl); ok = true; }
        else err = "gz";
    } else if (got >= 4 && magic[0] == 'P' && magic[1] == 'K') {
        if (fs.QuadPart > 400LL * 1024 * 1024) { CloseHandle(fh); err = "big"; return false; }
        std::string z((size_t)fs.QuadPart, '\0');
        DWORD rd = 0; ReadFile(fh, &z[0], (DWORD)z.size(), &rd, nullptr);
        auto u16 = [&](size_t o) { return (unsigned)(unsigned char)z[o] | ((unsigned)(unsigned char)z[o + 1] << 8); };
        auto u32 = [&](size_t o) { return u16(o) | (u16(o + 2) << 16); };
        size_t eocd = std::string::npos;
        for (size_t i = z.size() >= 22 ? z.size() - 22 : 0; i + 4 <= z.size() && i > 0 && z.size() - i < 70000; --i)
            if (u32(i) == 0x06054b50) { eocd = i; break; }
        if (eocd != std::string::npos) {
            size_t cd = u32(eocd + 16), cnt = u16(eocd + 10);
            tinf_init();
            for (size_t k = 0; k < cnt && cd + 46 <= z.size() && u32(cd) == 0x02014b50; ++k) {
                unsigned method = u16(cd + 10), csz = u32(cd + 20), usz = u32(cd + 24), nl = u16(cd + 28), xl = u16(cd + 30), cl = u16(cd + 32);
                size_t lho = u32(cd + 42);
                std::string nm = z.substr(cd + 46, nl);
                unsigned attr = u32(cd + 38);
                cd += 46 + nl + xl + cl;
                bool isLink = ((attr >> 16) & 0170000) == 0120000;
                if (!isLink && !tar.want(nm)) continue;
                if (lho + 30 > z.size() || u32(lho) != 0x04034b50) continue;
                size_t dp = lho + 30 + u16(lho + 26) + u16(lho + 28);
                if (dp + csz > z.size() || usz > 8 * 1024 * 1024) continue;
                std::string data;
                if (method == 0) data = z.substr(dp, csz);
                else if (method == 8) { data.resize(usz); unsigned dl = usz; if (tinf_uncompress(&data[0], &dl, z.data() + dp, csz) != TINF_OK) continue; data.resize(dl); }
                else continue;
                if (isLink) tar.links[nm] = data; else tar.files[nm] = data;
            }
            ok = true;
        } else err = "zip";
    } else err = "format";
    CloseHandle(fh);
    return ok;
}

// ---------------------------------------------------------------- из распакованного — значки для Windows
struct IcoNames { std::unordered_map<std::string, std::vector<std::string>> cands; std::unordered_map<std::string, std::vector<std::pair<std::string, int>>> byName; };
// из каталога: «names <id> <имя> <имя>…» — какие имена значка искать в теме (по порядку)
static void icoNamesParse(const std::string& cat, IcoNames& nm) {
    for (size_t p = 0; p < cat.size();) {
        size_t e = cat.find('\n', p); if (e == std::string::npos) e = cat.size();
        std::string line = cat.substr(p, e - p); p = e + 1;
        if (line.rfind("names\t", 0) != 0) continue;
        size_t t = line.find('\t', 6);
        if (t == std::string::npos) continue;
        std::string id = line.substr(6, t - 6), rest = line.substr(t + 1);
        std::vector<std::string> v;
        for (size_t a = 0; a < rest.size();) { size_t b = rest.find(' ', a); if (b == std::string::npos) b = rest.size(); if (b > a) v.push_back(rest.substr(a, b - a)); a = b + 1; }
        for (size_t i = 0; i < v.size(); ++i) { nm.byName[v[i]].push_back({id, (int)i}); nm.byName["default-" + v[i]].push_back({id, (int)i}); }
        nm.cands[id] = v;
    }
}
static std::string icoBase(const std::string& path) {
    size_t s = path.find_last_of('/');
    std::string b = s == std::string::npos ? path : path.substr(s + 1);
    size_t d = b.rfind('.');
    return d == std::string::npos ? b : b.substr(0, d);
}
static std::string icoExt(const std::string& path) {
    size_t d = path.rfind('.'), s = path.find_last_of('/');
    if (d == std::string::npos || (s != std::string::npos && d < s)) return "";
    std::string e = path.substr(d + 1); for (auto& c : e) c = (char)tolower((unsigned char)c);
    return e;
}
static std::string icoNorm(const std::string& p) {
    std::vector<std::string> parts;
    for (size_t a = 0; a <= p.size();) { size_t b = p.find('/', a); if (b == std::string::npos) b = p.size();
        std::string s = p.substr(a, b - a);
        if (s == "..") { if (!parts.empty()) parts.pop_back(); } else if (!s.empty() && s != ".") parts.push_back(s);
        a = b + 1; }
    std::string o; for (auto& s : parts) { if (!o.empty()) o += '/'; o += s; }
    return o;
}
// размер по папкам пути: scalable → 1000, 256x256 → 256 …; маленькие и symbolic — плохо
static int icoSizeScore(const std::string& path) {
    if (path.find("symbolic") != std::string::npos) return -1;
    int best = 0;
    for (size_t a = 0; a < path.size();) {
        size_t b = path.find('/', a); if (b == std::string::npos) b = path.size();
        std::string s = path.substr(a, b - a);
        if (s == "scalable") best = std::max(best, 1000);
        else if (!s.empty() && isdigit((unsigned char)s[0])) { int n = atoi(s.c_str()); if (s.find("@2x") != std::string::npos) n *= 2; if (s.find("@3x") != std::string::npos) n *= 3; best = std::max(best, n); }
        a = b + 1;
    }
    return best ? best : 64;
}
static bool icoSvgToPixels(std::string svg, std::vector<uint8_t>& px) {
    svg.push_back('\0');
    NSVGimage* im = nsvgParse(&svg[0], "px", 96.0f);
    if (!im) return false;
    bool ok = false;
    if (im->width > 0 && im->height > 0 && im->shapes) {
        NSVGrasterizer* r = nsvgCreateRasterizer();
        std::vector<uint8_t> rgba(256 * 256 * 4, 0);
        float sc = 256.0f / std::max(im->width, im->height);
        float ox = (256 - im->width * sc) / 2, oy = (256 - im->height * sc) / 2;
        nsvgRasterize(r, im, ox, oy, sc, rgba.data(), 256, 256, 256 * 4);
        nsvgDeleteRasterizer(r);
        px.resize(rgba.size());
        bool any = false;
        for (size_t i = 0; i < 256 * 256; ++i) {   // RGBA → премультиплированный BGRA
            unsigned a = rgba[i * 4 + 3];
            px[i * 4 + 0] = (uint8_t)(rgba[i * 4 + 2] * a / 255); px[i * 4 + 1] = (uint8_t)(rgba[i * 4 + 1] * a / 255);
            px[i * 4 + 2] = (uint8_t)(rgba[i * 4 + 0] * a / 255); px[i * 4 + 3] = (uint8_t)a;
            if (a) any = true;
        }
        ok = any;
    }
    nsvgDelete(im);
    return ok;
}
// какой файл темы — значок id: подходящая папка (apps/places/devices), самый крупный, ссылки — до настоящего файла
static bool icoPickFrom(const IcoTar& tar, const std::string& root, const std::string& id, const IcoNames& nm,
                        const std::unordered_map<std::string, std::vector<std::string>>& byBase, std::string& outPath, std::string& outData) {
    auto it = nm.cands.find(id);
    if (it == nm.cands.end()) return false;
    bool place = id.rfind("folder", 0) == 0 || id == "user-home" || id == "trash" || id == "trash-full", dev = id == "computer";
    auto catOk = [&](const std::string& p) {
        if (place) return p.find("/places/") != std::string::npos || p.find("places/") == 0;
        if (dev) return p.find("/devices/") != std::string::npos || p.find("/places/") != std::string::npos || p.find("/apps/") != std::string::npos || p.find("/preferences/") != std::string::npos;
        return p.find("/apps/") != std::string::npos || p.find("apps/") == 0;
    };
    auto resolve = [&](std::string p, std::string& data) -> bool {
        for (int k = 0; k < 10; ++k) {
            auto f = tar.files.find(p);
            if (f != tar.files.end()) { data = f->second; outPath = p; return true; }
            auto l = tar.links.find(p);
            if (l == tar.links.end()) return false;
            std::string dir = p.substr(0, p.find_last_of('/') == std::string::npos ? 0 : p.find_last_of('/'));
            std::string t = l->second.size() && l->second[0] == '/' ? l->second.substr(1) : icoNorm(dir + "/" + l->second);
            if (!tar.files.count(t) && !tar.links.count(t)) {   // ссылка на файл, которого нет по этому пути — ищем по имени в теме
                auto bb = byBase.find(icoBase(t));
                if (bb == byBase.end()) return false;
                std::string best;
                for (auto& c : bb->second) if (c.compare(0, root.size(), root) == 0 && (best.empty() || icoSizeScore(c) > icoSizeScore(best))) best = c;
                if (best.empty() || best == p) return false;
                t = best;
            }
            p = t;
        }
        return false;
    };
    for (const std::string& cand : it->second) {
        for (const std::string& n : {cand, std::string("default-") + cand}) {
            auto bb = byBase.find(n);
            if (bb == byBase.end()) continue;
            std::vector<std::string> opts;
            for (auto& p : bb->second) if (p.compare(0, root.size(), root) == 0 && catOk(p) && icoSizeScore(p) >= 0) opts.push_back(p);
            std::sort(opts.begin(), opts.end(), [&](const std::string& a, const std::string& b) {
                int sa = icoSizeScore(a) + (icoExt(a) == "svg" ? 1 : 0), sb = icoSizeScore(b) + (icoExt(b) == "svg" ? 1 : 0);
                return sa > sb; });
            for (auto& p : opts) if (resolve(p, outData)) return true;
        }
    }
    return false;
}

// скачать и разобрать тему с сайта → icons\web-<id>: .ico, list.txt, name.txt, tile.png, style.txt
static bool icoWebPrepare(const std::string& pack, const std::string& cat, std::string& err, std::function<void(int)> prog) {
    std::string id = pack.substr(4);
    std::wstring dir = icoDir() + L"\\" + W16(pack), list = dir + L"\\list.txt";
    std::string have;
    if (readFile(list, have) && !have.empty()) return true;   // уже разобрана
    IcoWebItem item;
    {
        if (!gIcoWebCsInit) { InitializeCriticalSection(&gIcoWebCs); gIcoWebCsInit = true; }
        EnterCriticalSection(&gIcoWebCs);
        auto f = gIcoWeb.find(id);
        if (f != gIcoWeb.end()) item = f->second;
        LeaveCriticalSection(&gIcoWebCs);
    }
    {   // свежие ссылки на скачивание (они живут пару дней)
        std::string body;
        if (httpsGet(kPlingHost, W16("/ocs/v1/content/data/" + id + "?format=json"), body, 4 * 1024 * 1024)) {
            js::Value v = js::parse(body);
            const js::Value* d = v.get("data");
            if (d && d->type == js::Value::Arr && !d->a.empty()) { icoWebRemember(d->a[0]); EnterCriticalSection(&gIcoWebCs); item = gIcoWeb[id]; LeaveCriticalSection(&gIcoWebCs); }
        }
    }
    std::vector<IcoWebFile> files;
    for (auto& f : item.files) if (icoWebUsable(f)) files.push_back(f);
    std::sort(files.begin(), files.end(), [](const IcoWebFile& a, const IcoWebFile& b) { return a.kb < b.kb; });
    if (files.empty()) { err = T8("У этой темы нет архива, который Подоконник умеет открыть", "This theme has no archive Podokonnik can open"); return false; }
    IcoNames nm;
    icoNamesParse(cat, nm);
    SHCreateDirectoryExW(nullptr, dir.c_str(), nullptr);
    std::wstring tmp = icoDir() + L"\\web-download.tmp";
    bool done = false;
    for (size_t fi = 0; fi < files.size() && fi < 3 && !done; ++fi) {
        const IcoWebFile& f = files[fi];
        alog("icons web: %s — %s (%lld KB)", item.name.c_str(), f.name.c_str(), f.kb);
        if (!icoDownload(f.url, tmp, [&](int p) { prog(p * 60 / 100); })) { err = T8("Не удалось скачать тему с gnome-look.org", "Couldn't download the theme from gnome-look.org"); continue; }
        prog(62);
        IcoTar tar;
        tar.want = [&](const std::string& p) {
            std::string e = icoExt(p);
            if (e == "theme") return true;
            if (e != "svg" && e != "png") return false;
            std::string b = icoBase(p);
            return nm.byName.count(b) > 0 || (b.rfind("steam_icon_", 0) == 0);
        };
        std::string uerr;
        if (!icoUnpack(tmp, tar, uerr)) { alog("icons web: unpack failed: %s", uerr.c_str()); err = T8("Не удалось открыть архив темы", "Couldn't open the theme archive"); continue; }
        DeleteFileW(tmp.c_str());
        prog(75);
        // папки тем — где лежит index.theme; если таких нет — весь архив
        std::vector<std::string> roots;
        for (auto& kv : tar.files) if (icoBase(kv.first) == "index" && icoExt(kv.first) == "theme") { size_t s = kv.first.find_last_of('/'); roots.push_back(s == std::string::npos ? "" : kv.first.substr(0, s + 1)); }
        if (roots.empty()) roots.push_back("");
        std::unordered_map<std::string, std::vector<std::string>> byBase;
        for (auto& kv : tar.files) byBase[icoBase(kv.first)].push_back(kv.first);
        for (auto& kv : tar.links) byBase[icoBase(kv.first)].push_back(kv.first);
        // какая из тем в архиве знает больше наших значков (светлую — чуть охотнее)
        std::string root; int bestN = -1;
        for (auto& r : roots) {
            int n = 0; std::string p, d;
            for (auto& c : nm.cands) if (icoPickFrom(tar, r, c.first, nm, byBase, p, d)) ++n;
            std::string lr = r; for (auto& c : lr) c = (char)tolower((unsigned char)c);
            int bonus = lr.find("dark") != std::string::npos ? 0 : 1;
            if (n * 2 + bonus > bestN) { bestN = n * 2 + bonus; root = r; }
        }
        std::vector<std::string> ids;
        for (auto& c : nm.cands) ids.push_back(c.first);
        for (auto& kv : byBase) if (kv.first.rfind("steam_icon_", 0) == 0) { std::string sid = "steam_" + kv.first.substr(11); nm.cands[sid] = {kv.first}; ids.push_back(sid); }
        std::vector<std::string> got(ids.size());
        volatile LONG cnt = 0;
        icoParallel((int)ids.size(), 6, [&](int i, IcoHttp&) {
            std::string p, d;
            const std::string& iid = ids[i];
            bool ok = false;
            if (iid.rfind("steam_", 0) == 0) {   // игры Steam: любой файл с этим именем
                auto bb = byBase.find(nm.cands.at(iid)[0]);
                if (bb != byBase.end()) for (auto& c : bb->second) { auto f2 = tar.files.find(c); if (f2 != tar.files.end() && c.compare(0, root.size(), root) == 0) { p = c; d = f2->second; ok = true; break; } }
            } else ok = icoPickFrom(tar, root, iid, nm, byBase, p, d);
            if (!ok) return;
            std::wstring out = dir + L"\\" + W16(iid) + L"-2.ico";
            bool made = false;
            if (icoExt(p) == "png") made = icoFromPng(d, out);
            else {
                std::vector<uint8_t> px;
                IWICImagingFactory* f = nullptr;
                if (icoSvgToPixels(d, px) && SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f)))) { made = icoFromPixels(f, px, 256, 256, out); f->Release(); }
            }
            if (made) { got[i] = iid; InterlockedIncrement(&cnt); }
        });
        std::string lst;
        for (auto& g : got) if (!g.empty()) lst += g + "\n";
        alog("icons web: %s root=%s icons=%ld", item.name.c_str(), root.c_str(), (long)cnt);
        if (!cnt) { err = T8("В этой теме не нашлось значков для Windows", "No Windows icons found in this theme"); continue; }
        // рамка для остальных программ — светлая, как у Fluent
        std::string tile, style;
        IcoHttp h;
        if (icoGet(h, L"fluent/tile.png", tile)) { writeFile(dir + L"\\tile.png", tile); lst += "tile\n"; if (icoGet(h, L"fluent/style.txt", style)) writeFile(dir + L"\\style.txt", style); }
        writeFile(dir + L"\\name.txt", item.name);
        writeFile(list, lst);
        done = true;
        prog(100);
    }
    DeleteFileW(tmp.c_str());
    return done;
}
