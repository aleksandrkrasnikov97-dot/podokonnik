; Установщик Подоконника: без прав администратора, в %LOCALAPPDATA%\Programs\Podokonnik,
; ярлык в «Пуске» (и по желанию на рабочем столе), удаление через «Приложения».
; Сборка: makensis installer.nsi (рядом build\Podokonnik.exe и build\pkg\WebView2Loader.dll из SDK WebView2).

Target amd64-unicode
!include "MUI2.nsh"
!include "FileFunc.nsh"
!include "LogicLib.nsh"

!ifndef VERSION
  !define VERSION "5.0.3"
!endif
Name "Подоконник"
OutFile "build\Podokonnik-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\Podokonnik"
InstallDirRegKey HKCU "Software\Podokonnik" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "Подоконник ${VERSION}"
VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=1049 "ProductName" "Подоконник"
VIAddVersionKey /LANG=1049 "FileDescription" "Установщик Подоконника"
VIAddVersionKey /LANG=1049 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=1049 "LegalCopyright" "Красников Александр"

!define MUI_ICON "app.ico"
!define MUI_UNICON "app.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\Подоконник.exe"
!define MUI_FINISHPAGE_RUN_TEXT "$(RunNow)"
!define MUI_FINISHPAGE_SHOWREADME ""
!define MUI_FINISHPAGE_SHOWREADME_TEXT "$(DesktopIcon)"
!define MUI_FINISHPAGE_SHOWREADME_FUNCTION MakeDesktopIcon

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Russian"
!insertmacro MUI_LANGUAGE "English"

LangString RunNow ${LANG_RUSSIAN} "Запустить Подоконник"
LangString RunNow ${LANG_ENGLISH} "Run Podokonnik"
LangString DesktopIcon ${LANG_RUSSIAN} "Ярлык на рабочем столе"
LangString DesktopIcon ${LANG_ENGLISH} "Desktop shortcut"
LangString AppName ${LANG_RUSSIAN} "Подоконник"
LangString AppName ${LANG_ENGLISH} "Podokonnik"
LangString KeepData ${LANG_RUSSIAN} "Удалить и настройки, скачанные видео и музыку?"
LangString KeepData ${LANG_ENGLISH} "Also delete settings, downloaded videos and music?"

; закрыть запущенный Подоконник, чтобы заменить файлы
; Закрыть запущенный Подоконник и Студию: вежливо, ждём до 10 с, потом принудительно —
; иначе файлы заняты, удаление не удаляет exe, и программа продолжает работать в фоне
!macro CLOSEAPP_FN un
Function ${un}CloseAppFn
  FindWindow $0 "SugrobMsg" ""
  IntCmp $0 0 closeapp_kill
  SendMessage $0 ${WM_CLOSE} 0 0 /TIMEOUT=5000
  StrCpy $1 0
  closeapp_wait:
    Sleep 250
    FindWindow $0 "SugrobMsg" ""
    IntCmp $0 0 closeapp_kill
    IntOp $1 $1 + 1
    IntCmp $1 40 closeapp_kill closeapp_wait closeapp_kill
  closeapp_kill:
  nsExec::Exec 'taskkill /F /T /IM "Подоконник.exe"'
  Pop $0
  nsExec::Exec 'taskkill /F /T /IM "Студия Подоконника.exe"'
  Pop $0
  Sleep 500
FunctionEnd
!macroend
!insertmacro CLOSEAPP_FN ""
!insertmacro CLOSEAPP_FN "un."

Function MakeDesktopIcon
  CreateShortcut "$DESKTOP\$(AppName).lnk" "$INSTDIR\Подоконник.exe" "" "$INSTDIR\Подоконник.exe" 0
FunctionEnd

Section "Install"
  Call CloseAppFn
  SetOutPath "$INSTDIR"
  File "/oname=Подоконник.exe" "build\Podokonnik.exe"
  File "build\pkg\WebView2Loader.dll"
  File "/oname=Прочитай меня.txt" "installer\readme.txt"
  File "/oname=WebWallGL — лицензия.txt" "third_party\webwallgl\LICENSE"
  File "/oname=GPL-3.0 — лицензия.txt" "xstyle\COPYING"
  File "/oname=LGPL-3.0 — лицензия.txt" "third_party\ExplorerBlurMica\COPYING.LESSER"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateShortcut "$SMPROGRAMS\$(AppName).lnk" "$INSTDIR\Подоконник.exe" "" "$INSTDIR\Подоконник.exe" 0
  WriteRegStr HKCU "Software\Podokonnik" "InstallDir" "$INSTDIR"
  ; автозапуск с Windows — включён сразу, если программа ещё ни разу не запускалась
  ReadRegDWORD $0 HKCU "Software\Sugrob" "AutoInit"
  ${If} $0 == ""
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "Podokonnik" '"$INSTDIR\Подоконник.exe" --autostart'
  ${EndIf}
  !define UK "Software\Microsoft\Windows\CurrentVersion\Uninstall\Podokonnik"
  WriteRegStr HKCU "${UK}" "DisplayName" "$(AppName)"
  WriteRegStr HKCU "${UK}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UK}" "Publisher" "Красников Александр"
  WriteRegStr HKCU "${UK}" "DisplayIcon" "$INSTDIR\Подоконник.exe"
  WriteRegStr HKCU "${UK}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UK}" "URLInfoAbout" "https://aleksandrkrasnikov97-dot.github.io/podokonnik/"
  WriteRegStr HKCU "${UK}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "${UK}" "NoModify" 1
  WriteRegDWORD HKCU "${UK}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  WriteRegDWORD HKCU "${UK}" "EstimatedSize" $0
SectionEnd

Section "Uninstall"
  Call un.CloseAppFn
  ; курсоры мыши из Подоконника — вернуть те, что были до него
  IfFileExists "$INSTDIR\Подоконник.exe" 0 +4
    ExecWait '"$INSTDIR\Подоконник.exe" --restore-cursors'
    ExecWait '"$INSTDIR\Подоконник.exe" --restore-theme'
    ExecWait '"$INSTDIR\Подоконник.exe" --restore-icons'
  Delete "$INSTDIR\Подоконник.exe"
  Delete "$INSTDIR\Подоконник.exe.old"
  Delete "$INSTDIR\Подоконник.exe.new"
  Delete "$INSTDIR\WebView2Loader.dll"
  Delete "$INSTDIR\Студия Подоконника.exe"
  Delete "$INSTDIR\Студия Подоконника.exe.new"
  Delete "$INSTDIR\Прочитай меня.txt"
  Delete "$INSTDIR\WebWallGL — лицензия.txt"
  Delete "$INSTDIR\GPL-3.0 — лицензия.txt"
  Delete "$INSTDIR\LGPL-3.0 — лицензия.txt"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\$(AppName).lnk"
  Delete "$DESKTOP\$(AppName).lnk"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "Podokonnik"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Podokonnik"
  DeleteRegKey HKCU "Software\Podokonnik"
  MessageBox MB_YESNO|MB_ICONQUESTION "$(KeepData)" /SD IDNO IDNO done
    RMDir /r "$LOCALAPPDATA\Sugrob"
    DeleteRegKey HKCU "Software\Sugrob"
  done:
SectionEnd
