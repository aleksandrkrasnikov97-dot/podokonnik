; Установщик Подоконника: без прав администратора, в %LOCALAPPDATA%\Programs\Podokonnik,
; ярлык в «Пуске» (и по желанию на рабочем столе), удаление через «Приложения».
; Сборка: makensis installer.nsi (рядом build\Podokonnik.exe и build\pkg\WebView2Loader.dll из SDK WebView2).

Target amd64-unicode
!include "MUI2.nsh"
!include "FileFunc.nsh"
!include "LogicLib.nsh"

!ifndef VERSION
  !define VERSION "2.5"
!endif
Name "Подоконник"
OutFile "build\Podokonnik-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\Podokonnik"
InstallDirRegKey HKCU "Software\Podokonnik" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "Подоконник ${VERSION}"
VIProductVersion "${VERSION}.0.0"
VIAddVersionKey /LANG=1049 "ProductName" "Подоконник"
VIAddVersionKey /LANG=1049 "FileDescription" "Установщик Подоконника"
VIAddVersionKey /LANG=1049 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=1049 "LegalCopyright" "Красников Александр"

!define MUI_ICON "app.ico"
!define MUI_UNICON "app.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\Подоконник.exe"
!define MUI_FINISHPAGE_RUN_TEXT "$(RunNow)"
!define MUI_FINISHPAGE_SHOWREADME ""
!define MUI_FINISHPAGE_SHOWREADME_TEXT "$(DesktopIcon)"
!define MUI_FINISHPAGE_SHOWREADME_FUNCTION MakeDesktopIcon

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Russian"
!insertmacro MUI_LANGUAGE "English"

LangString RunNow ${LANG_RUSSIAN} "Запустить Подоконник"
LangString RunNow ${LANG_ENGLISH} "Run Podokonnik"
LangString DesktopIcon ${LANG_RUSSIAN} "Ярлык на рабочем столе"
LangString DesktopIcon ${LANG_ENGLISH} "Desktop shortcut"
LangString AppName ${LANG_RUSSIAN} "Подоконник"
LangString AppName ${LANG_ENGLISH} "Podokonnik"
LangString KeepData ${LANG_RUSSIAN} "Удалить и настройки, скачанные видео и музыку?"
LangString KeepData ${LANG_ENGLISH} "Also delete settings, downloaded videos and music?"

; закрыть запущенный Подоконник, чтобы заменить файлы
!macro CloseApp
  FindWindow $0 "SugrobMsg" ""
  IntCmp $0 0 +3
  SendMessage $0 ${WM_CLOSE} 0 0
  Sleep 1500
!macroend

Function MakeDesktopIcon
  CreateShortcut "$DESKTOP\$(AppName).lnk" "$INSTDIR\Подоконник.exe" "" "$INSTDIR\Подоконник.exe" 0
FunctionEnd

Section "Install"
  !insertmacro CloseApp
  SetOutPath "$INSTDIR"
  File "/oname=Подоконник.exe" "build\Podokonnik.exe"
  File "build\pkg\WebView2Loader.dll"
  File "/oname=Прочитай меня.txt" "installer\readme.txt"
  File "/oname=WebWallGL — лицензия.txt" "third_party\webwallgl\LICENSE"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateShortcut "$SMPROGRAMS\$(AppName).lnk" "$INSTDIR\Подоконник.exe" "" "$INSTDIR\Подоконник.exe" 0
  WriteRegStr HKCU "Software\Podokonnik" "InstallDir" "$INSTDIR"
  ; автозапуск с Windows — включён сразу, если программа ещё ни разу не запускалась
  ReadRegDWORD $0 HKCU "Software\Sugrob" "AutoInit"
  ${If} $0 == ""
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "Podokonnik" '"$INSTDIR\Подоконник.exe"'
  ${EndIf}
  !define UK "Software\Microsoft\Windows\CurrentVersion\Uninstall\Podokonnik"
  WriteRegStr HKCU "${UK}" "DisplayName" "$(AppName)"
  WriteRegStr HKCU "${UK}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UK}" "Publisher" "Красников Александр"
  WriteRegStr HKCU "${UK}" "DisplayIcon" "$INSTDIR\Подоконник.exe"
  WriteRegStr HKCU "${UK}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UK}" "URLInfoAbout" "https://aleksandrkrasnikov97-dot.github.io/podokonnik/"
  WriteRegStr HKCU "${UK}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "${UK}" "NoModify" 1
  WriteRegDWORD HKCU "${UK}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  WriteRegDWORD HKCU "${UK}" "EstimatedSize" $0
SectionEnd

Section "Uninstall"
  !insertmacro CloseApp
  Delete "$INSTDIR\Подоконник.exe"
  Delete "$INSTDIR\Подоконник.exe.old"
  Delete "$INSTDIR\Подоконник.exe.new"
  Delete "$INSTDIR\WebView2Loader.dll"
  Delete "$INSTDIR\Прочитай меня.txt"
  Delete "$INSTDIR\WebWallGL — лицензия.txt"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\$(AppName).lnk"
  Delete "$DESKTOP\$(AppName).lnk"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "Podokonnik"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Podokonnik"
  DeleteRegKey HKCU "Software\Podokonnik"
  MessageBox MB_YESNO|MB_ICONQUESTION "$(KeepData)" /SD IDNO IDNO done
    RMDir /r "$LOCALAPPDATA\Sugrob"
    DeleteRegKey HKCU "Software\Sugrob"
  done:
SectionEnd
