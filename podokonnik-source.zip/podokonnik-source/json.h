// Небольшой разборщик JSON (для сообщений интерфейса и project.json Wallpaper Engine)
#pragma once
#include <string>
#include <vector>
#include <utility>
#include <cstdlib>
#include <cstdio>

namespace js {

struct Value {
    enum Type { Null, Bool, Num, Str, Arr, Obj } type = Null;
    bool b = false;
    double n = 0;
    std::string s;
    std::vector<Value> a;
    std::vector<std::pair<std::string, Value>> o;

    const Value* get(const char* key) const {
        if (type != Obj) return nullptr;
        for (auto& kv : o) if (kv.first == key) return &kv.second;
        return nullptr;
    }
    std::string str(const char* key, const std::string& def = "") const {
        const Value* v = get(key);
        return v && v->type == Str ? v->s : def;
    }
    double num(const char* key, double def = 0) const {
        const Value* v = get(key);
        if (!v) return def;
        if (v->type == Num) return v->n;
        if (v->type == Bool) return v->b ? 1 : 0;
        if (v->type == Str) return atof(v->s.c_str());
        return def;
    }
    bool boolean(const char* key, bool def = false) const {
        const Value* v = get(key);
        if (!v) return def;
        if (v->type == Bool) return v->b;
        if (v->type == Num) return v->n != 0;
        return def;
    }
};

struct Parser {
    const char* p;
    const char* e;
    bool ok = true;

    void ws() {
        while (p < e) {
            if (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') { p++; continue; }
            if (*p == '/' && p + 1 < e && p[1] == '/') { while (p < e && *p != '\n') p++; continue; }   // // комментарии
            if (*p == '/' && p + 1 < e && p[1] == '*') { p += 2; while (p + 1 < e && !(*p == '*' && p[1] == '/')) p++; p += 2; continue; }
            break;
        }
    }
    static void putUtf8(std::string& out, unsigned cp) {
        if (cp < 0x80) out += (char)cp;
        else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 63)); }
        else if (cp < 0x10000) { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 63)); out += (char)(0x80 | (cp & 63)); }
        else { out += (char)(0xF0 | (cp >> 18)); out += (char)(0x80 | ((cp >> 12) & 63)); out += (char)(0x80 | ((cp >> 6) & 63)); out += (char)(0x80 | (cp & 63)); }
    }
    unsigned hex4() {
        unsigned v = 0;
        for (int i = 0; i < 4 && p < e; ++i, ++p) {
            char c = *p;
            v <<= 4;
            if (c >= '0' && c <= '9') v |= c - '0';
            else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10;
        }
        return v;
    }
    std::string string() {
        std::string out;
        p++;   // "
        while (p < e && *p != '"') {
            if (*p == '\\' && p + 1 < e) {
                p++;
                char c = *p++;
                switch (c) {
                case 'n': out += '\n'; break;
                case 't': out += '\t'; break;
                case 'r': out += '\r'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'u': {
                    unsigned cp = hex4();
                    if (cp >= 0xD800 && cp < 0xDC00 && p + 1 < e && p[0] == '\\' && p[1] == 'u') {
                        p += 2;
                        unsigned lo = hex4();
                        cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                    }
                    putUtf8(out, cp);
                    break;
                }
                default: out += c;
                }
            } else out += *p++;
        }
        if (p < e) p++;
        return out;
    }
    Value value(int depth = 0) {
        Value v;
        ws();
        if (p >= e || depth > 64) { ok = false; return v; }
        char c = *p;
        if (c == '{') {
            v.type = Value::Obj;
            p++;
            ws();
            if (p < e && *p == '}') { p++; return v; }
            while (p < e) {
                ws();
                if (p >= e || *p != '"') { ok = false; return v; }
                std::string k = string();
                ws();
                if (p < e && *p == ':') p++;
                v.o.emplace_back(k, value(depth + 1));
                ws();
                if (p < e && *p == ',') { p++; ws(); if (p < e && *p == '}') { p++; break; } continue; }
                if (p < e && *p == '}') { p++; break; }
                ok = false; break;
            }
        } else if (c == '[') {
            v.type = Value::Arr;
            p++;
            ws();
            if (p < e && *p == ']') { p++; return v; }
            while (p < e) {
                v.a.push_back(value(depth + 1));
                ws();
                if (p < e && *p == ',') { p++; ws(); if (p < e && *p == ']') { p++; break; } continue; }
                if (p < e && *p == ']') { p++; break; }
                ok = false; break;
            }
        } else if (c == '"') {
            v.type = Value::Str;
            v.s = string();
        } else if (c == 't' || c == 'f') {
            v.type = Value::Bool;
            v.b = c == 't';
            p += v.b ? 4 : 5;
        } else if (c == 'n') {
            p += 4;
        } else {
            v.type = Value::Num;
            char* end = nullptr;
            v.n = strtod(p, &end);
            if (end == p) { ok = false; p++; } else p = end;
        }
        return v;
    }
};

inline Value parse(const std::string& s, bool* okOut = nullptr) {
    Parser ps{s.data(), s.data() + s.size()};
    if (s.size() >= 3 && (unsigned char)s[0] == 0xEF && (unsigned char)s[1] == 0xBB && (unsigned char)s[2] == 0xBF) ps.p += 3;
    Value v = ps.value();
    if (okOut) *okOut = ps.ok;
    return v;
}

inline std::string esc(const std::string& s) {
    std::string o = "\"";
    for (unsigned char c : s) {
        switch (c) {
        case '"': o += "\\\""; break;
        case '\\': o += "\\\\"; break;
        case '\n': o += "\\n"; break;
        case '\r': o += "\\r"; break;
        case '\t': o += "\\t"; break;
        default:
            if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
            else o += (char)c;
        }
    }
    return o + "\"";
}

inline std::string dump(const Value& v) {
    switch (v.type) {
    case Value::Null: return "null";
    case Value::Bool: return v.b ? "true" : "false";
    case Value::Num: { char b[40]; snprintf(b, sizeof b, "%.10g", v.n); return b; }
    case Value::Str: return esc(v.s);
    case Value::Arr: {
        std::string o = "[";
        for (size_t i = 0; i < v.a.size(); ++i) { if (i) o += ","; o += dump(v.a[i]); }
        return o + "]";
    }
    case Value::Obj: {
        std::string o = "{";
        for (size_t i = 0; i < v.o.size(); ++i) { if (i) o += ","; o += esc(v.o[i].first) + ":" + dump(v.o[i].second); }
        return o + "}";
    }
    }
    return "null";
}

}  // namespace js
