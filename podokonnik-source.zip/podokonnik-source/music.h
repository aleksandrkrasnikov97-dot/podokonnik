// Новогодняя музыка для «Сугроба»: синтез в памяти (музыкальная шкатулка,
// бас, бубенцы, реверберация). Мелодии — старинные, общественное достояние.
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>

namespace music {

static const int SR = 32000;

struct SongDef {
    const wchar_t* name;
    float bpm;            // четвертей в минуту
    int beatsPerBar;
    bool jingle;          // бубенцы
    std::string lead, second, bass;
};

// ---------------------------------------------------------------- ноты
static float noteFreq(const std::string& n) {
    if (n.empty() || n[0] == 'r') return 0;
    static const int semi[7] = {9, 11, 0, 2, 4, 5, 7};   // A B C D E F G
    int s = semi[n[0] - 'A'];
    size_t i = 1;
    if (i < n.size() && n[i] == '#') { s++; i++; }
    else if (i < n.size() && n[i] == 'b') { s--; i++; }
    int oct = (i < n.size()) ? n[i] - '0' : 4;
    int midi = 12 * (oct + 1) + s;
    return 440.0f * std::pow(2.0f, (midi - 69) / 12.0f);
}

struct Ev { float t, dur, f; };

// формат: "C5:1 A4:.5 r:2 |" — нота:длительность в четвертях; '|' игнорируется
static float parse(const std::string& s, float beat, std::vector<Ev>& out) {
    float t = 0;
    size_t p = 0;
    while (p < s.size()) {
        while (p < s.size() && (s[p] == ' ' || s[p] == '|' || s[p] == '\n')) p++;
        if (p >= s.size()) break;
        size_t e = s.find_first_of(" |\n", p);
        if (e == std::string::npos) e = s.size();
        std::string tok = s.substr(p, e - p);
        p = e;
        size_t c = tok.find(':');
        if (c == std::string::npos) continue;
        float d = (float)atof(tok.substr(c + 1).c_str()) * beat;
        float f = noteFreq(tok.substr(0, c));
        if (f > 0) out.push_back({t, d, f});
        t += d;
    }
    return t;
}

static std::string rep(const std::string& s, int n) {
    std::string r;
    for (int i = 0; i < n; ++i) r += s + " ";
    return r;
}

// ---------------------------------------------------------------- мелодии
static std::vector<SongDef> songs() {
    std::vector<SongDef> v;

    {   // Jingle Bells (Дж. Пьерпонт, 1857)
        std::string v1 = "G4:1 E5:1 D5:1 C5:1 | G4:3 G4:.5 G4:.5 | G4:1 E5:1 D5:1 C5:1 | A4:4 | A4:1 F5:1 E5:1 D5:1 | B4:4 | G5:1 G5:1 F5:1 D5:1 | E5:4 ";
        std::string v2 = "G4:1 E5:1 D5:1 C5:1 | G4:4 | G4:1 E5:1 D5:1 C5:1 | A4:3 A4:1 | A4:1 F5:1 E5:1 D5:1 | G5:1 G5:1 G5:1 G5:1 | A5:1 G5:1 F5:1 D5:1 | C5:4 ";
        std::string c1 = "E5:1 E5:1 E5:2 | E5:1 E5:1 E5:2 | E5:1 G5:1 C5:1.5 D5:.5 | E5:4 | F5:1 F5:1 F5:1.5 F5:.5 | F5:1 E5:1 E5:1 E5:.5 E5:.5 | E5:1 D5:1 D5:1 E5:1 | D5:2 G5:2 ";
        std::string c2 = "E5:1 E5:1 E5:2 | E5:1 E5:1 E5:2 | E5:1 G5:1 C5:1.5 D5:.5 | E5:4 | F5:1 F5:1 F5:1.5 F5:.5 | F5:1 E5:1 E5:1 E5:.5 E5:.5 | G5:1 G5:1 F5:1 D5:1 | C5:4 ";
        std::string bv = "C3:4 C3:4 C3:4 F3:4 D3:4 G3:4 G3:4 C3:4 ";
        std::string bc1 = "C3:4 C3:4 C3:4 C3:4 F3:4 C3:4 D3:4 G3:4 ";
        std::string bc2 = "C3:4 C3:4 C3:4 C3:4 F3:4 C3:4 G3:4 C3:4 ";
        v.push_back({L"Jingle Bells", 168, 4, true,
                     v1 + v2 + c1 + c2 + c1 + c2, "",
                     bv + bv + bc1 + bc2 + bc1 + bc2});
    }
    {   // В лесу родилась ёлочка (Л. Бекман, 1905)
        std::string m = "C5:.5 A5:.5 A5:.5 G5:.5 A5:.5 F5:.5 C5:.5 C5:.5 | "
                        "C5:.5 A5:.5 A5:.5 Bb5:.5 G5:.5 C6:1.5 | "
                        "C6:.5 D6:.5 D6:.5 Bb5:.5 Bb5:.5 A5:.5 G5:.5 F5:.5 | "
                        "C6:.5 A5:.5 A5:.5 G5:.5 A5:.5 F5:1.5 ";
        std::string b = "F3:2 F3:2 F3:2 C3:2 Bb2:2 C3:2 F3:2 F3:2 ";
        v.push_back({L"В лесу родилась ёлочка", 116, 2, true, rep(m, 4), "", rep(b, 4)});
    }
    {   // Щедрик / Carol of the Bells (М. Леонтович, 1914)
        std::string ost = "Bb4:1 A4:.5 Bb4:.5 G4:1 ";
        std::string up3 = "D5:1 C5:.5 D5:.5 Bb4:1 ";
        std::string ding = "G5:.5 G5:.5 G5:.5 G5:.5 F5:.5 Eb5:.5 | D5:.5 D5:.5 D5:.5 D5:.5 C5:.5 Bb4:.5 | "
                           "C5:.5 C5:.5 C5:.5 C5:.5 D5:.5 C5:.5 | G4:3 ";
        std::string ostHi = "Bb5:1 A5:.5 Bb5:.5 G5:1 ";
        std::string lead = rep(ost, 4) + rep(up3, 4) + rep(ding, 2) + rep(ostHi, 4) + rep(ost, 2) + "G4:3 ";
        std::string second = "r:12 " + rep(ost, 4) + rep(ost, 8) + rep(up3, 4) + "r:9 ";
        std::string bass = rep("G2:6 ", 2) + rep("G2:6 ", 2) + rep("G2:6 Eb2:6 ", 2) + rep("G2:6 ", 2) + "G2:6 G2:3 ";
        v.push_back({L"Щедрик (Carol of the Bells)", 172, 3, false, lead + lead, second + second, bass + bass});
    }
    {   // We Wish You a Merry Christmas (народная)
        std::string main = "D5:1 | G5:1 G5:.5 A5:.5 G5:.5 F#5:.5 | E5:1 E5:1 E5:1 | A5:1 A5:.5 B5:.5 A5:.5 G5:.5 | "
                           "F#5:1 D5:1 D5:1 | B5:1 B5:.5 C6:.5 B5:.5 A5:.5 | G5:1 E5:1 D5:.5 D5:.5 | E5:1 A5:1 F#5:1 | G5:2 ";
        std::string tid = "D5:1 | G5:1 G5:1 G5:1 | F#5:2 F#5:1 | G5:1 F#5:1 E5:1 | D5:2 A5:1 | B5:1 A5:1 G5:1 | "
                          "D6:1 D5:1 D5:.5 D5:.5 | E5:1 A5:1 F#5:1 | G5:2 ";
        std::string bm = "r:1 G3:3 C3:3 A2:3 D3:3 B2:3 E3:3 D3:3 G3:2 ";
        std::string bt = "r:1 G3:3 D3:3 C3:3 D3:3 G3:3 B2:3 D3:3 G3:2 ";
        v.push_back({L"We Wish You a Merry Christmas", 160, 3, true,
                     main + main + tid + main, "", bm + bm + bt + bm});
    }
    {   // Deck the Halls (валлийская народная)
        std::string l1 = "D6:1.5 C6:.5 B5:1 A5:1 | G5:1 A5:1 B5:1 G5:1 | A5:.5 B5:.5 C6:.5 A5:.5 B5:1.5 A5:.5 | G5:1 F#5:1 G5:2 ";
        std::string l2 = "A5:1.5 B5:.5 C6:1 A5:1 | B5:1.5 C6:.5 D6:1 A5:1 | B5:.5 C#6:.5 D6:1 B5:.5 C#6:.5 D6:1 | "
                         "E6:.5 F#6:.5 G6:1 F#6:1 E6:1 | D6:4 ";
        std::string l3 = "D6:1.5 C6:.5 B5:1 A5:1 | G5:1 A5:1 B5:1 G5:1 | E6:.5 E6:.5 E6:.5 E6:.5 D6:1.5 C6:.5 | B5:1 A5:1 G5:2 ";
        std::string b1 = "G3:4 G3:4 D3:4 G3:4 ";
        std::string b2 = "D3:4 G3:4 A2:4 A2:4 D3:4 ";
        std::string b3 = "G3:4 G3:4 C3:4 D3:2 G3:2 ";
        std::string all = l1 + l1 + l2 + l3, ball = b1 + b1 + b2 + b3;
        v.push_back({L"Deck the Halls", 132, 4, true, all + all, "", ball + ball});
    }
    return v;
}

// ---------------------------------------------------------------- синтез
struct Rng { uint32_t s = 22222; float next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (s >> 8) * (1.0f / 8388608.0f) - 1.0f; } };

static void addBox(std::vector<float>& o, float t0, float dur, float f, float amp) {
    // музыкальная шкатулка / челеста: несколько затухающих гармоник
    static const float pm[5] = {1.0f, 2.0f, 3.0f, 4.16f, 1.003f};
    static const float pa[5] = {1.0f, 0.42f, 0.16f, 0.09f, 0.35f};
    static const float pd[5] = {1.0f, 1.8f, 2.9f, 4.2f, 1.0f};
    float dec = 1.6f + f / 1400.0f;
    float len = std::min(dur + 1.4f, 3.2f);
    int i0 = (int)(t0 * SR), n = (int)(len * SR);
    if (i0 + n > (int)o.size()) n = (int)o.size() - i0;
    float rel = dur + 0.25f;
    for (int i = 0; i < n; ++i) {
        float t = (float)i / SR;
        float env = (1.0f - std::exp(-t / 0.002f));
        if (t > rel) env *= std::exp(-(t - rel) * 5.0f);
        float s = 0;
        for (int k = 0; k < 5; ++k) {
            float ff = f * pm[k];
            if (ff > SR * 0.45f) continue;
            s += pa[k] * std::exp(-t * dec * pd[k]) * std::sin(6.2831853f * ff * t);
        }
        o[i0 + i] += amp * env * s;
    }
}

static void addBass(std::vector<float>& o, float t0, float dur, float f, float amp) {
    float len = dur + 0.4f;
    int i0 = (int)(t0 * SR), n = (int)(len * SR);
    if (i0 + n > (int)o.size()) n = (int)o.size() - i0;
    for (int i = 0; i < n; ++i) {
        float t = (float)i / SR;
        float env = (1.0f - std::exp(-t / 0.008f)) * std::exp(-t * 2.2f);
        if (t > dur) env *= std::exp(-(t - dur) * 14.0f);
        float w = 6.2831853f * f * t;
        float s = std::sin(w) + 0.28f * std::sin(2 * w) + 0.08f * std::sin(3 * w);
        o[i0 + i] += amp * env * s;
    }
}

static void addJingle(std::vector<float>& o, float t0, float amp, Rng& rng) {
    int i0 = (int)(t0 * SR), n = (int)(0.28f * SR);
    if (i0 + n > (int)o.size()) n = (int)o.size() - i0;
    float lp = 0, lp2 = 0;
    for (int i = 0; i < n; ++i) {
        float t = (float)i / SR;
        float x = rng.next();
        lp += 0.35f * (x - lp);
        float hp = x - lp;            // высокие частоты
        lp2 += 0.6f * (hp - lp2);     // чуть смягчить
        float env = std::exp(-t * 22.0f) * (0.75f + 0.25f * std::sin(6.2831853f * 38.0f * t));
        o[i0 + i] += amp * env * lp2;
    }
}

// простая реверберация Шрёдера
static void reverb(std::vector<float>& x, float wet) {
    const int cd[4] = {(int)(0.0297f * SR), (int)(0.0371f * SR), (int)(0.0411f * SR), (int)(0.0437f * SR)};
    const int ad[2] = {(int)(0.005f * SR), (int)(0.0017f * SR)};
    std::vector<float> out(x.size(), 0.0f);
    for (int c = 0; c < 4; ++c) {
        std::vector<float> buf(cd[c], 0.0f);
        int p = 0; float filt = 0;
        for (size_t i = 0; i < x.size(); ++i) {
            float y = buf[p];
            filt = y * 0.7f + filt * 0.3f;
            buf[p] = x[i] + filt * 0.80f;
            if (++p >= cd[c]) p = 0;
            out[i] += y * 0.25f;
        }
    }
    for (int a = 0; a < 2; ++a) {
        std::vector<float> buf(ad[a], 0.0f);
        int p = 0;
        for (size_t i = 0; i < out.size(); ++i) {
            float b = buf[p];
            float y = -0.7f * out[i] + b;
            buf[p] = out[i] + 0.7f * y;
            if (++p >= ad[a]) p = 0;
            out[i] = y;
        }
    }
    for (size_t i = 0; i < x.size(); ++i) x[i] = x[i] * (1.0f - wet * 0.5f) + out[i] * wet;
}

static std::vector<int16_t> render(const SongDef& d) {
    float beat = 60.0f / d.bpm;
    std::vector<Ev> lead, second, bass;
    float len = parse(d.lead, beat, lead);
    len = std::max(len, parse(d.second, beat, second));
    len = std::max(len, parse(d.bass, beat, bass));
    std::vector<float> o((size_t)((len + 2.5f) * SR), 0.0f);

    for (auto& e : lead) addBox(o, e.t, e.dur, e.f, 0.50f);
    for (auto& e : second) addBox(o, e.t, e.dur, e.f, 0.30f);
    for (auto& e : bass) {
        // «ум-па»: основной тон, потом квинта
        if (e.dur >= 2 * beat - 0.001f) {
            float h = e.dur / 2;
            addBass(o, e.t, h * 0.9f, e.f, 0.36f);
            addBass(o, e.t + h, h * 0.9f, e.f * 1.5f, 0.26f);
        } else addBass(o, e.t, e.dur * 0.9f, e.f, 0.36f);
    }
    if (d.jingle) {
        Rng rng;
        int beats = (int)(len / beat);
        for (int b = 0; b < beats; ++b) {
            bool accent = (b % d.beatsPerBar) == (d.beatsPerBar == 3 ? 0 : 1) || (d.beatsPerBar == 4 && b % 4 == 3);
            addJingle(o, b * beat, accent ? 0.16f : 0.09f, rng);
            if (d.beatsPerBar == 4 && (b % 2 == 1)) addJingle(o, b * beat + beat * 0.5f, 0.05f, rng);
        }
    }
    reverb(o, 0.32f);

    float peak = 1e-6f;
    for (float v : o) peak = std::max(peak, std::fabs(v));
    float g = 0.85f / peak;
    std::vector<int16_t> pcm(o.size());
    size_t fadeN = (size_t)(0.6f * SR);
    for (size_t i = 0; i < o.size(); ++i) {
        float v = o[i] * g;
        if (i + fadeN > o.size()) v *= (float)(o.size() - i) / fadeN;   // мягкий конец
        pcm[i] = (int16_t)std::max(-32767.0f, std::min(32767.0f, v * 32767.0f));
    }
    return pcm;
}

}  // namespace music
