// Конструктор своей темы (вкладка «Оформление»): панель задач, меню «Пуск», окна Проводника, рамки всех окон.
// Параметры — объект JSON из интерфейса, хранится в <данные>\mytheme.json. Из него собираются:
//  • настройки стилизаторов панели и «Пуска» (xstyle.h): основа — темы DockLike / TranslucentStartMenu из сообщества
//    Windows 11 Taskbar/Start Menu Styler, поверх — наши стили и константы (цвет, прозрачность, размытие, углы, кромка);
//  • стекло Проводника и рамки окон (winstyle.h);
//  • настройки Windows: значки по центру/слева, светлые/тёмные панель и окна, цвет выделения (с резервной копией, theme.h).
// Панель, «Пуск» и рамки меняются сразу; стекло Проводника — после перезапуска Проводника (кнопка «Применить»).
#pragma once

static js::Value gMy;   // параметры своей темы
static std::wstring myPath() { return baseDataDir() + L"\\mytheme.json"; }
static void mySave() { writeFile(myPath(), js::dump(gMy)); }
static void myLoad() {
    std::string t;
    bool ok = false;
    if (readFile(myPath(), t)) gMy = js::parse(t, &ok);
    if (!ok || gMy.type != js::Value::Obj) { gMy = js::Value(); gMy.type = js::Value::Obj; }
}
static void mySetNum(const char* k, double n) {
    for (auto& kv : gMy.o) if (kv.first == k) { kv.second = js::Value(); kv.second.type = js::Value::Num; kv.second.n = n; return; }
    js::Value v; v.type = js::Value::Num; v.n = n; gMy.o.emplace_back(k, v);
}

// «#RRGGBB» → 0xRRGGBB
static DWORD myRgb(const js::Value& p, const char* k, DWORD def) {
    std::string s = p.str(k);
    if (s.size() == 7 && s[0] == '#') return (DWORD)strtoul(s.c_str() + 1, nullptr, 16) & 0xFFFFFF;
    return def;
}
static int myInt(const js::Value& p, const char* k, int def, int lo, int hi) { return std::max(lo, std::min(hi, (int)p.num(k, def))); }
static std::string myArgb(DWORD rgb, int pct) {   // #AARRGGBB для XAML
    char b[16]; snprintf(b, sizeof b, "#%02X%06X", std::max(0, std::min(255, pct * 255 / 100)), (unsigned)(rgb & 0xFFFFFF));
    return b;
}
static std::string myBrush(DWORD rgb, int pct, int blur) {
    if (blur > 0) return "<WindhawkBlur BlurAmount=\"" + std::to_string(blur) + "\" TintColor=\"" + myArgb(rgb, pct) + "\"/>";
    return "<SolidColorBrush Color=\"" + myArgb(rgb, pct) + "\"/>";
}

// сборка файла настроек мода: тема-основа + константы + стили + ресурсы
struct MyBody {
    std::string s;
    int ci = 0, sc = 0, rv = 0;
    explicit MyBody(const char* base) { s = std::string("theme\t") + base + "\n"; }
    void style(const std::string& target, const std::vector<std::string>& st) {
        std::string i = std::to_string(ci++);
        s += "controlStyles[" + i + "].target\t" + target + "\n";
        for (size_t j = 0; j < st.size(); ++j) s += "controlStyles[" + i + "].styles[" + std::to_string(j) + "]\t" + st[j] + "\n";
    }
    void constant(const std::string& c) { s += "styleConstants[" + std::to_string(sc++) + "]\t" + c + "\n"; }
    void resvar(const std::string& c) { s += "themeResourceVariables[" + std::to_string(rv++) + "]\t" + c + "\n"; }
};

static std::string myTaskbarBody(const js::Value& p) {
    if (!p.boolean("tbOn")) return "";
    bool dock = myInt(p, "tbLayout", 1, 0, 1) == 1;
    DWORD col = myRgb(p, "tbColor", 0x000000), bcol = myRgb(p, "tbBorderColor", 0xFFFFFF);
    int alpha = myInt(p, "tbAlpha", 10, 0, 100), blur = myInt(p, "tbBlur", 10, 0, 60);
    int radius = myInt(p, "tbRadius", 10, 0, 24), border = myInt(p, "tbBorder", 0, 0, 3), balpha = myInt(p, "tbBorderAlpha", 25, 0, 100);
    int icon = myInt(p, "tbIcon", 25, 16, 32), gap = myInt(p, "tbGap", 4, 0, 8);
    std::string brush = myBrush(col, alpha, blur), stroke = "<SolidColorBrush Color=\"" + myArgb(bcol, border ? balpha : 0) + "\"/>";
    MyBody b(dock ? "DockLike" : "");
    if (dock) {
        std::string R = std::to_string(radius);
        b.constant("DockBackground=" + brush);
        b.constant("DockTopGap=" + std::to_string(gap));
        b.constant("DockBottomGap=" + std::to_string(gap));
        // док касается низа экрана (без отступа) — скругляем только верхние углы
        std::string cr = gap ? R : "{{DockNativeAlignment==`Left`?`0," + R + ",0,0`:`" + R + "," + R + ",0,0`}}";
        b.style("Taskbar.TaskbarFrame > Grid#RootGrid > Taskbar.TaskbarBackground > Grid",
                {"CornerRadius=" + cr, "BorderThickness=" + std::to_string(border), "BorderBrush:=" + stroke});
        b.style("StackPanel#SystemTrayFrameGrid, Grid#SystemTrayFrameGrid", {"CornerRadius=" + std::to_string(std::max(radius, 4))});
        // погода и проценты батареи на доке обрезаются
        b.style("Taskbar.AugmentedEntryPointButton", {"Visibility=Collapsed"});
        b.style("TextBlock#BatteryTextBlock", {"Visibility=Collapsed"});
    } else {
        b.style("Taskbar.TaskbarFrame > Grid#RootGrid > Taskbar.TaskbarBackground > Grid > Rectangle#BackgroundFill", {"Fill:=" + brush});
        b.style("Rectangle#BackgroundStroke", border ? std::vector<std::string>{"Fill:=" + stroke} : std::vector<std::string>{"Visibility=Collapsed"});
    }
    b.style("Taskbar.TaskbarBackground#HoverFlyoutBackgroundControl > Grid > Rectangle#BackgroundFill", {"Fill:=" + brush});   // превью окон
    // анимация значков при наведении (заготовки). Состояния задают CompositeTransform, а наш стилизатор (xsSmoothIcons)
    // переводит его в UIElement.Scale/Translation/Rotation с переходами — плавно; при нажатии значок чуть сжимается
    if (int hv = myInt(p, "tbHover", 1, 0, 4)) {
        if (hv == 3) hv = 2;   // «Как на Mac» убрали — сохранённый выбор становится «Увеличивается»
        static const char* kHov[] = {"PointerOver", "ActivePointerOver", "InactivePointerOver", "MultiWindowPointerOver", "RequestingAttentionPointerOver"};
        static const char* kPrs[] = {"Pressed", "ActivePressed", "InactivePressed", "MultiWindowPressed"};
        const char* tr = hv == 1 ? "TranslateY=\"-7\"" : hv == 2 ? "ScaleX=\"1.25\" ScaleY=\"1.25\"" : "Rotation=\"-12\" ScaleX=\"1.08\" ScaleY=\"1.08\"";
        std::vector<std::string> st = {"RenderTransform:=<CompositeTransform/>"};
        for (const char* h : kHov) st.push_back(std::string("RenderTransform@") + h + ":=<CompositeTransform " + tr + "/>");
        for (const char* h : kPrs) st.push_back(std::string("RenderTransform@") + h + ":=<CompositeTransform ScaleX=\"0.86\" ScaleY=\"0.86\"/>");
        b.style("Grid#IconPanel@CommonStates > Image#Icon, Taskbar.TaskListLabeledButtonPanel#IconPanel@CommonStates > Image#Icon", st);
        b.s += "xsSmoothIcons\t1\n";
    }
    if (icon != 24) {
        b.style("Grid#IconPanel > Image#Icon, Taskbar.TaskListLabeledButtonPanel#IconPanel > Image#Icon",
                {"Width=" + std::to_string(icon), "Height=" + std::to_string(icon)});
        b.resvar("MediumTaskbarButtonExtent=" + std::to_string(icon + 20));
        b.resvar("SmallTaskbarButtonExtent=" + std::to_string(icon + 16));
    }
    return b.s;
}

static std::string myStartBody(const js::Value& p) {
    if (!p.boolean("smOn")) return "";
    DWORD col = myRgb(p, "smColor", 0x000000), bcol = myRgb(p, "smBorderColor", 0xFFFFFF);
    int alpha = myInt(p, "smAlpha", 10, 0, 100), blur = myInt(p, "smBlur", 10, 0, 60);
    int radius = myInt(p, "smRadius", 10, 0, 24), border = myInt(p, "smBorder", 0, 0, 3), balpha = myInt(p, "smBorderAlpha", 25, 0, 100);
    std::string R = std::to_string(radius);
    MyBody b("TranslucentStartMenu");
    b.constant("CommonBgBrush=" + myBrush(col, alpha, blur));
    b.style("Border#AcrylicBorder", {"CornerRadius=" + R, "BorderThickness=" + std::to_string(border),
                                     "BorderBrush:=<SolidColorBrush Color=\"" + myArgb(bcol, border ? balpha : 0) + "\"/>"});
    b.style("Border#AppBorder, Border#AccentAppBorder", {"CornerRadius=" + R});
    b.style("Border#StartDropShadow", {"CornerRadius=" + R});
    b.style("Border#dropshadow", {"CornerRadius=" + std::to_string(radius + 1)});
    b.style("TextBlock#Text", {std::string("Foreground=") + (myInt(p, "smText", 0, 0, 1) ? "Black" : "White")});
    if (p.boolean("smRec", false)) b.style("Grid#TopLevelSuggestionsRoot", {"Visibility=Visible"});   // основа прячет «Рекомендуем»
    return b.s;
}

static EbmLook myEbm(const js::Value& p) {
    EbmLook L;
    L.effect = myInt(p, "exEffect", 3, 0, 4);
    L.rgb = myRgb(p, "exColor", 0x000000);
    L.alpha = myInt(p, "exAlpha", 10, 0, 100) * 255 / 100;
    return L;
}
static WinFrame myFrame(const js::Value& p) {
    WinFrame f;
    f.on = p.boolean("frOn");
    f.corner = myInt(p, "frCorner", 2, 0, 3);
    auto bgr = [](DWORD rgb) { return ((rgb & 255) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 255); };
    if (p.boolean("frBorderOn", false)) f.border = bgr(myRgb(p, "frBorder", 0xFFFFFF));
    if (p.boolean("frCaptionOn", false)) {
        DWORD c = myRgb(p, "frCaption", 0x1E3A6E);
        f.caption = bgr(c);
        int lum = (int)(((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
        f.text = lum > 140 ? 0x00000000 : 0x00FFFFFF;   // текст заголовка — читаемый на его цвете
    }
    return f;
}

// настройки Windows под тему; без темы (раздел выключен) — как было до Подоконника
static void myWindowsSettings(const js::Value& p) {
    const wchar_t* adv = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced";
    const wchar_t* pers = L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize";
    bool tb = p.boolean("tbOn"), ex = p.boolean("exOn");
    auto snap = [&] { return std::to_string(thRegGet(HKEY_CURRENT_USER, adv, L"TaskbarAl", 9)) + "," +
                             std::to_string(thRegGet(HKEY_CURRENT_USER, pers, L"SystemUsesLightTheme", 9)) + "," +
                             std::to_string(thRegGet(HKEY_CURRENT_USER, pers, L"AppsUseLightTheme", 9)); };
    std::string before = snap();
    if (tb) thSet(adv, L"TaskbarAl", myInt(p, "tbAlign", 0, 0, 1) ? 0 : 1); else thRestoreOne(adv, L"TaskbarAl");
    int tt = tb ? myInt(p, "tbText", 0, 0, 2) : 0;   // 1 — светлый текст (тёмная панель), 2 — тёмный текст
    if (tt) thSet(pers, L"SystemUsesLightTheme", tt == 2 ? 1 : 0); else thRestoreOne(pers, L"SystemUsesLightTheme");
    int md = ex ? myInt(p, "exMode", 0, 0, 2) : 0;   // окна: 1 — светлые, 2 — тёмные
    if (md) thSet(pers, L"AppsUseLightTheme", md == 1 ? 1 : 0); else thRestoreOne(pers, L"AppsUseLightTheme");
    xsSearchFix(tb && myInt(p, "tbLayout", 1, 0, 1) == 1);   // на доке поиск — значком
    if (snap() != before) { thBroadcast(L"ImmersiveColorSet"); thBroadcast(L"TraySettings"); }   // только если что-то поменялось
    bool acc = p.boolean("frOn") && p.boolean("frAccentOn", false);
    if (acc) { winAccentSet((int)myRgb(p, "frAccent", 0x4CC2FF)); regSet(L"MyAccentSet", 1); }
    else if (regGet(L"MyAccentSet", 0)) { winAccentSet(-1); regSet(L"MyAccentSet", 0); }
}

// Развёрнутые окна: 0 — до панели (как в Windows), 1 — на весь экран, док висит поверх, 2 — на весь экран,
// панель всплывает (автоскрытие Windows). Для «на весь экран» рабочая область — весь монитор без 2 px снизу:
// так окно не считается полноэкранным (иначе Windows прячет панель под него), и мышь у края всё равно доходит до панели.
// Проводник иногда пересчитывает рабочую область сам — раз в 2 с (xsTick) возвращаем свою
static int gMyMax = 0;
static std::vector<RECT> gMyWorkOrig;   // мониторы, где меняли рабочую область
struct MyTbMon { RECT mon, tb; };
static BOOL CALLBACK MyTbEnum(HWND h, LPARAM lp) {
    wchar_t cls[64] = {0}; GetClassNameW(h, cls, 63);
    if (wcscmp(cls, L"Shell_TrayWnd") && wcscmp(cls, L"Shell_SecondaryTrayWnd")) return TRUE;
    RECT r; MONITORINFO mi{sizeof mi};
    if (!GetWindowRect(h, &r) || !GetMonitorInfoW(MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST), &mi)) return TRUE;
    if (r.top <= (mi.rcMonitor.top + mi.rcMonitor.bottom) / 2 || r.right - r.left < r.bottom - r.top) return TRUE;   // только панель снизу
    ((std::vector<MyTbMon>*)lp)->push_back({mi.rcMonitor, r});
    return TRUE;
}
// уже развёрнутые окна на этом мониторе — развернуть заново под новую рабочую область
static void myRemaximize(const RECT& mon) {
    struct Ctx { RECT mon; } ctx{mon};
    EnumWindows([](HWND h, LPARAM lp) -> BOOL {
        const RECT& mon = ((Ctx*)lp)->mon;
        if (!IsWindowVisible(h) || !IsZoomed(h)) return TRUE;
        DWORD pid = 0; GetWindowThreadProcessId(h, &pid);
        MONITORINFO mi{sizeof mi};
        if (!GetMonitorInfoW(MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST), &mi) || !EqualRect(&mi.rcMonitor, &mon)) return TRUE;
        RECT wr; GetWindowRect(h, &wr);
        // рамка развёрнутого окна выходит за рабочую область на ширину невидимой границы — растягиваем низ так же
        LONG border = std::max(0L, mi.rcWork.top - wr.top);
        if (wr.bottom - border == mi.rcWork.bottom) return TRUE;
        SetWindowPos(h, nullptr, wr.left, wr.top, wr.right - wr.left, mi.rcWork.bottom + border - wr.top, SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOOWNERZORDER);
        return TRUE;
    }, (LPARAM)&ctx);
}
static void myWorkTick() {
    if (gMyMax != 1) return;
    std::vector<MyTbMon> v;
    EnumWindows(MyTbEnum, (LPARAM)&v);
    for (auto& m : v) {
        RECT want = m.mon; want.bottom -= 2;
        MONITORINFO mi{sizeof mi};
        if (!GetMonitorInfoW(MonitorFromRect(&m.mon, MONITOR_DEFAULTTONEAREST), &mi) || EqualRect(&mi.rcWork, &want)) continue;
        bool known = false;
        for (auto& o : gMyWorkOrig) if (o.left == m.mon.left && o.top == m.mon.top) known = true;
        if (!known) gMyWorkOrig.push_back(m.mon);
        // без рассылки WM_SETTINGCHANGE: на неё Проводник сразу пересчитывает рабочую область обратно до панели
        SystemParametersInfoW(SPI_SETWORKAREA, 0, &want, 0);
        static int n = 0;
        if (n++ < 20) alog("work area %ld,%ld-%ld,%ld -> %ld,%ld-%ld,%ld", mi.rcWork.left, mi.rcWork.top, mi.rcWork.right, mi.rcWork.bottom, want.left, want.top, want.right, want.bottom);
        myRemaximize(m.mon);
    }
}
static void myWorkRestore() {   // рабочая область — снова до панели
    std::vector<MyTbMon> v;
    EnumWindows(MyTbEnum, (LPARAM)&v);
    for (auto& m : v) {
        bool ours = false;
        for (auto& o : gMyWorkOrig) if (o.left == m.mon.left && o.top == m.mon.top) ours = true;
        if (!ours) continue;
        RECT r = m.mon; r.bottom = std::max(m.mon.top + 100, (LONG)m.tb.top);
        SystemParametersInfoW(SPI_SETWORKAREA, 0, &r, 0);
        myRemaximize(m.mon);
    }
    gMyWorkOrig.clear();
}
// развёрнутое на весь экран окно Windows считает полноэкранным и опускает панель под него — в режиме «на весь экран»
// возвращаем панель наверх (только для развёрнутых окон: игры и видео на весь экран её по-прежнему прячут); 4 раза в секунду
static void myKeepTaskbarTop() {
    if (gMyMax != 1) return;
    HWND fg = GetForegroundWindow();
    if (!fg || !IsZoomed(fg)) return;
    auto lift = [](HWND t) {
        if (t && !(GetWindowLongPtrW(t, GWL_EXSTYLE) & WS_EX_TOPMOST))
            SetWindowPos(t, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER);
    };
    lift(FindWindowW(L"Shell_TrayWnd", nullptr));
    for (HWND t = nullptr; (t = FindWindowExW(nullptr, t, L"Shell_SecondaryTrayWnd", nullptr));) lift(t);
}
static void myMaxApply(int mode) {
    HWND tray = FindWindowW(L"Shell_TrayWnd", nullptr);
    APPBARDATA ab{sizeof ab};
    ab.hWnd = tray;
    UINT st = tray ? (UINT)SHAppBarMessage(ABM_GETSTATE, &ab) : 0;
    if (mode == 2) {   // автоскрытие; если у тебя оно уже было — потом не выключаем
        if (tray && !(st & ABS_AUTOHIDE)) {
            regSet(L"MyAutoHideOurs", 1);
            ab.lParam = st | ABS_AUTOHIDE;
            SHAppBarMessage(ABM_SETSTATE, &ab);
        }
    } else if (regGet(L"MyAutoHideOurs", 0) && tray) {
        regSet(L"MyAutoHideOurs", 0);
        ab.lParam = st & ~ABS_AUTOHIDE;
        SHAppBarMessage(ABM_SETSTATE, &ab);
    }
    if (mode != 1 && gMyMax == 1) myWorkRestore();
    gMyMax = mode;
    myWorkTick();
}

// применить всё; exRestart — перезапустить Проводник, если стекло в нём уже загружено (новый вид стекла / светлые-тёмные)
static void myApply(bool exRestart) {
    xsPrepare();
    myWindowsSettings(gMy);
    xsWriteSettings(gXs[0], myTaskbarBody(gMy));
    xsWriteSettings(gXs[1], myStartBody(gMy));
    if (!gMy.boolean("tbOn")) gXs[0].pid = 0;
    if (!gMy.boolean("smOn")) gXs[1].pid = 0;
    xsTick();
    myMaxApply(gMy.boolean("tbOn") ? myInt(gMy, "tbMax", 0, 0, 1) : 0);   // «панель всплывает» убрали — теперь «на весь экран»
    // сугробы на доке — по его форме (tbshape.h)
    gTbShapeRadius = (float)myInt(gMy, "tbRadius", 10, 0, 24);
    gTbShapeVisible = myInt(gMy, "tbAlpha", 10, 0, 100) >= 5 || myInt(gMy, "tbBlur", 10, 0, 60) > 0 || myInt(gMy, "tbBorder", 0, 0, 3) > 0;
    tbShapeWant(gMy.boolean("tbOn") && myInt(gMy, "tbLayout", 1, 0, 1) == 1);
    gWinsDirty = true;
    WinFrame f = myFrame(gMy);
    if (f.on != gWinFrame.on || f.corner != gWinFrame.corner || f.border != gWinFrame.border || f.caption != gWinFrame.caption || f.text != gWinFrame.text)
        winFrameSet(f);
    else if (f.on) EnumWindows(WinFrameEnum, 0);
    if (gMy.boolean("exOn")) { EbmLook L = myEbm(gMy); ebmSet(&L, exRestart); }
    else ebmSet(nullptr, exRestart);
}
static void myAllOff() {   // «Вернуть как было»: всё выключить, параметры остаются для следующего раза
    for (const char* k : {"tbOn", "smOn", "exOn", "frOn"}) mySetNum(k, 0);
    mySave();
    myApply(true);
}
// защита от петли (xstyle.h) выключила панель или «Пуск» — запоминаем, чтобы переключатель в интерфейсе был честным
static void myDisabledByGuard(int mod) { mySetNum(mod ? "smOn" : "tbOn", 0); mySave(); if (!mod) tbShapeWant(false); }

static void xsStart() {
    winLookLegacyCleanup();
    myLoad();
    // готовые темы тестовых версий убраны: стоящую тему снимаем, дальше — только своя
    for (auto& m : gXs) {
        std::string t;
        if (readFile(xsSettingsPath(m), t) && t.find("xsName\tmy") == std::string::npos && t.find("unload\t1") == std::string::npos) xsWriteSettings(m, "");
    }
    myApply(false);   // настройки заново по текущим правилам — после обновления Подоконника тема сразу получает исправления
    SetTimer(gMsgWnd, 42, 2000, nullptr);
}
static void xsState(js::Value& v) {
    v.o.emplace_back("my", gMy);
    js::Value b; b.type = js::Value::Bool; b.b = ebmLoaded(); v.o.emplace_back("myGlassLive", b);
}
static bool xsUi(const std::string& cmd, const js::Value& m) {
    if (cmd != "myTheme") return false;
    const js::Value* p = m.get("p");
    if (!p || p->type != js::Value::Obj) return true;
    js::Value old = gMy;
    gMy = *p;
    mySave();
    // стекло: новый вид — только по кнопке «Применить» (перезапуск Проводника); выключили — сразу
    bool restart = m.boolean("exApply") || (old.boolean("exOn") && !gMy.boolean("exOn"));
    myApply(restart);
    appPushState();
    return true;
}
static void xsReload() {   // выгрузить DLL и внедрить заново (тема та же)
    for (auto& m : gXs) {
        std::string body;
        if (xsTheme(m).empty() || !readFile(xsSettingsPath(m), body)) continue;
        writeFile(xsSettingsPath(m), "theme\t\nunload\t1\n");
        Sleep(1000);
        writeFile(xsSettingsPath(m), body);
        m.pid = 0;
    }
}
