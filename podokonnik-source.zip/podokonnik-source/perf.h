// Замер нагрузки (только в тестовых сборках, SUGROB_PERFLOG): раз в 20 секунд пишет в журнал,
// сколько процессора, видеокарты и памяти занимает программа вместе со своими процессами WebView2
// (окно, обои, радио). Так оптимизацию можно проверить цифрами, а не на глаз.
#pragma once
#ifdef SUGROB_PERFLOG
#include <tlhelp32.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <psapi.h>
#include <map>
#include <set>

namespace perf {
static PDH_HQUERY gQ = nullptr;
static PDH_HCOUNTER gGpu = nullptr;
static std::map<DWORD, ULONGLONG> gPrevCpu;
static ULONGLONG gPrevWall = 0;
static int gCores = 1;

static std::set<DWORD> tree() {
    std::set<DWORD> out{GetCurrentProcessId()};
    HANDLE s = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (s == INVALID_HANDLE_VALUE) return out;
    std::multimap<DWORD, DWORD> kids;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    for (BOOL ok = Process32FirstW(s, &pe); ok; ok = Process32NextW(s, &pe)) kids.emplace(pe.th32ParentProcessID, pe.th32ProcessID);
    CloseHandle(s);
    std::vector<DWORD> st{GetCurrentProcessId()};
    while (!st.empty()) {
        DWORD p = st.back(); st.pop_back();
        auto r = kids.equal_range(p);
        for (auto it = r.first; it != r.second; ++it)
            if (it->second != p && out.insert(it->second).second) st.push_back(it->second);
    }
    return out;
}
static void init() {
    SYSTEM_INFO si{};
    GetSystemInfo(&si);
    gCores = std::max(1, (int)si.dwNumberOfProcessors);
    if (PdhOpenQueryW(nullptr, 0, &gQ) == ERROR_SUCCESS &&
        PdhAddEnglishCounterW(gQ, L"\\GPU Engine(*)\\Utilization Percentage", 0, &gGpu) == ERROR_SUCCESS)
        PdhCollectQueryData(gQ);
    SetTimer(gMsgWnd, 77, 20000, nullptr);
}
static void sample() {
    auto pids = tree();
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    ULONGLONG wall = ((ULONGLONG)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
    double cpuMain = 0, cpuWeb = 0, memMB = 0;
    std::map<DWORD, ULONGLONG> now;
    std::map<DWORD, double> pcpu, pmem, pgpu;
    for (DWORD pid : pids) {
        HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (!h) continue;
        FILETIME c, e, k, u;
        if (GetProcessTimes(h, &c, &e, &k, &u)) {
            ULONGLONG t = (((ULONGLONG)k.dwHighDateTime << 32) | k.dwLowDateTime) + (((ULONGLONG)u.dwHighDateTime << 32) | u.dwLowDateTime);
            now[pid] = t;
            auto it = gPrevCpu.find(pid);
            if (it != gPrevCpu.end() && gPrevWall && wall > gPrevWall) {
                double pct = 100.0 * (double)(t - it->second) / (double)(wall - gPrevWall) / gCores;
                if (pid == GetCurrentProcessId()) cpuMain += pct; else cpuWeb += pct;
                pcpu[pid] = pct;
            }
        }
        PROCESS_MEMORY_COUNTERS_EX pm{};
        pm.cb = sizeof(pm);
        if (GetProcessMemoryInfo(h, (PROCESS_MEMORY_COUNTERS*)&pm, sizeof(pm))) { memMB += pm.PrivateUsage / 1048576.0; pmem[pid] = pm.PrivateUsage / 1048576.0; }
        CloseHandle(h);
    }
    bool haveCpu = gPrevWall != 0;
    gPrevCpu = now;
    gPrevWall = wall;
    double gpuOurs = 0, gpuAll = 0;
    if (gQ && PdhCollectQueryData(gQ) == ERROR_SUCCESS) {
        DWORD size = 0, count = 0;
        if (PdhGetFormattedCounterArrayW(gGpu, PDH_FMT_DOUBLE, &size, &count, nullptr) == (PDH_STATUS)PDH_MORE_DATA) {
            std::vector<BYTE> buf(size);
            auto* items = (PDH_FMT_COUNTERVALUE_ITEM_W*)buf.data();
            if (PdhGetFormattedCounterArrayW(gGpu, PDH_FMT_DOUBLE, &size, &count, items) == ERROR_SUCCESS) {
                std::map<std::wstring, double> engines;   // занятость каждого движка видеокарты — по всем процессам
                for (DWORD i = 0; i < count; ++i) {
                    if (items[i].FmtValue.CStatus != PDH_CSTATUS_VALID_DATA && items[i].FmtValue.CStatus != PDH_CSTATUS_NEW_DATA) continue;
                    const wchar_t* n = items[i].szName;
                    if (!wcsstr(n, L"engtype_3D")) continue;
                    double v = items[i].FmtValue.doubleValue;
                    const wchar_t* pp = wcsstr(n, L"pid_");
                    DWORD pid = pp ? (DWORD)_wtoi(pp + 4) : 0;
                    if (pids.count(pid)) { gpuOurs += v; pgpu[pid] += v; }
                    const wchar_t* lu = wcsstr(n, L"luid_");
                    engines[lu ? std::wstring(lu) : L"?"] += v;
                }
                for (auto& e : engines) gpuAll = std::max(gpuAll, e.second);
            }
        }
    }
    if (!haveCpu) return;
    {   // по процессам: pid — процессор / видеокарта / память
        std::string d;
        char b[96];
        for (DWORD pid : pids) {
            snprintf(b, sizeof b, " %lu%s:%.1f/%.1f/%.0f", (unsigned long)pid, pid == GetCurrentProcessId() ? "*" : "", pcpu[pid], pgpu[pid], pmem[pid]);
            d += b;
        }
        alogFwd("perf procs:%s", d.c_str());
    }
    static ULONGLONG lastFrames = 0, lastT = 0;
    ULONGLONG tnow = GetTickCount64();
    double sfps = lastT ? (double)(gPerfFrames - lastFrames) * 1000.0 / (double)(tnow - lastT) : 0;
    lastFrames = gPerfFrames; lastT = tnow;
    alogFwd("perf: cpu %.1f%% (app %.1f, webview %.1f) gpu3d %.1f%% (all %.1f%%) mem %.0f MB, procs %zu, snow %.1f fps %s %s, wallpapers %zu",
            cpuMain + cpuWeb, cpuMain, cpuWeb, gpuOurs, gpuAll, memMB, pids.size(), sfps, gHiddenFS ? "hidden" : "shown", gGpuOn ? (gGpuSprOn ? "gpu+spr" : "gpu") : "cpu", gWpWins.size());
}
// замер по шагам: файл perf-phases.txt в папке данных — шаги по 40 секунд, потом всё как было
static int gPhase = -1;
static int gSaveFps = 0;
static const char* kPhaseNames[] = {"normal", "snow 30 fps", "snow on CPU (no GPU)", "wallpaper lite (post-processing low)", "wallpaper 30 fps"};
static const int kPhases = 5;
static void phaseRestore() {
    if (gFps != gSaveFps) { gFps = gSaveFps; applyActivePace(); }
    if (!gGpuWanted) gpuSetWanted(true);
    for (auto& w : gWpWins) if (w.scene) {
        wv::post(w.host, "{\"cmd\":\"lite\",\"value\":0}");
        wv::post(w.host, "{\"cmd\":\"fps\",\"value\":" + std::to_string(gFps) + "}");
    }
}
static void phaseSet(int p) {
    phaseRestore();
    gPhase = p;
    if (p == 1) { gFps = 30; applyActivePace(); }
    if (p == 2) gpuSetWanted(false);
    for (auto& w : gWpWins) if (w.scene) {
        if (p == 3) wv::post(w.host, "{\"cmd\":\"lite\",\"value\":1}");
        if (p == 4) wv::post(w.host, "{\"cmd\":\"fps\",\"value\":30}");
    }
    alogFwd("perf phase %d: %s", p, kPhaseNames[p]);
}
static void phaseTick() {
    if (gPhase >= 0) return;
    std::wstring f = dataPath(L"perf-phases.txt");
    if (GetFileAttributesW(f.c_str()) == INVALID_FILE_ATTRIBUTES) return;
    DeleteFileW(f.c_str());
    gSaveFps = gFps;
    phaseSet(0);
    SetTimer(gMsgWnd, 79, 40000, nullptr);
}
static void phaseNext() {
    if (gPhase + 1 >= kPhases) { KillTimer(gMsgWnd, 79); phaseRestore(); gPhase = -1; alogFwd("perf phases done"); return; }
    phaseSet(gPhase + 1);
}
}  // namespace perf
#endif
