// Питомец на подоконнике: кот или снегирь живёт на верхних краях окон и на панели задач.
// Кот гуляет, сидит, спит, бежит за курсором и мурлычет, если его погладить мышкой;
// снегирь прыгает по краю, клюёт и улетает от курсора, а потом возвращается.
#pragma once

static int gPetMode = 0;    // 0 — нет, 1 — кот, 2 — снегирь
static int gPetCoat = 0;    // окрас кота: 0 рыжий, 1 серый, 2 чёрный, 3 белый

enum { PS_WALK = 0, PS_SIT, PS_SLEEP, PS_CHASE, PS_JUMP, PS_FALL, PS_AWAY, PS_FLYIN };
struct PetT {
    bool alive = false;
    int state = PS_FALL;
    float timer = 0, anim = 0, idle = 0, love = 0, heartT = 0, look = 0;
    float x = 0, y = 0, vx = 0, vy = 0;
    int dir = 1;
    HWND cap = nullptr;          // на каком окне сидит (nullptr — на краю рабочей области монитора)
    float relX = 0;              // смещение от левого края окна
    int mon = 0;                 // монитор, если сидит на краю рабочей области
    // прыжок / перелёт
    float jx0 = 0, jy0 = 0, jx1 = 0, jy1 = 0, jt = 0, jdur = 1;
    HWND jcap = nullptr; float jrel = 0; int jmon = 0;
    float lastCx = 0, lastCy = 0, cursorMoveT = 99;
};
static PetT gPet;
struct PetHeart { float x, y, age; bool z; };
static std::vector<PetHeart> gPetHearts;

static bool petActive() { return gPetMode != 0 && gSnowOn; }

// края рабочих областей мониторов (над панелью задач)
static std::vector<RECT> gWorkAreas;
static void petUpdateWork() {
    static double last = -10;
    if (gTime - last < 2 && !gWorkAreas.empty()) return;
    last = gTime;
    gWorkAreas.clear();
    for (const RECT& m : gMons) {
        MONITORINFO mi{}; mi.cbSize = sizeof(mi);
        POINT c{(m.left + m.right) / 2, (m.top + m.bottom) / 2};
        if (GetMonitorInfoW(MonitorFromPoint(c, MONITOR_DEFAULTTONEAREST), &mi)) gWorkAreas.push_back(mi.rcWork);
        else gWorkAreas.push_back(m);
    }
}
static Cap* petCapLive(HWND h) {
    if (!h) return nullptr;
    for (size_t i = 0; i < gWins.size(); ++i) if (gCapPtr[i] && gCapPtr[i]->h == h) return gCapPtr[i];
    return nullptr;
}
// где поверхность под питомцем: true — стоит на чём-то видимом
static bool petSurfaceAt(HWND cap, float relX, int mon, float& x, float& y) {
    if (cap) {
        Cap* c = petCapLive(cap);
        if (!c) return false;
        x = c->r.left + relX;
        if (x < c->r.left + 4 * S || x > c->r.right - 4 * S) return false;
        int j = (int)(relX / CW);
        if (j < 0 || j >= c->n() || !c->vis[j]) return false;
        y = c->surfY(j);
        return true;
    }
    if (mon < 0 || mon >= (int)gWorkAreas.size()) return false;
    const RECT& w = gWorkAreas[mon];
    x = clampf(relX, (float)w.left + 20 * S, (float)w.right - 20 * S);
    y = (float)w.bottom;
    return true;
}
// куда можно встать: окно или край рабочей области
struct PetSpot { HWND cap; float rel; int mon; float x, y; };
static std::vector<PetSpot> petSpots(float fromX, float fromY, float maxDx, float maxUp, float maxDown, HWND not_) {
    std::vector<PetSpot> out;
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->h == not_ || c->n() < 30) continue;
        for (int k = 0; k < 6; ++k) {
            float x = c->r.left + (c->r.right - c->r.left) * (0.08f + 0.84f * frand());
            int j = (int)((x - c->r.left) / CW);
            if (j < 0 || j >= c->n() || !c->vis[j]) continue;
            float y = c->surfY(j);
            if (std::fabs(x - fromX) > maxDx || y < fromY - maxUp || y > fromY + maxDown) continue;
            out.push_back({c->h, x - c->r.left, 0, x, y});
            break;
        }
    }
    if (out.empty() || frand() < 0.25f) {
        bool anyTb = false;
        for (size_t i = 0; i < gWins.size(); ++i) if (gCapPtr[i] && gCapPtr[i]->taskbar) anyTb = true;
        if (!anyTb)
            for (size_t m = 0; m < gWorkAreas.size(); ++m) {
                const RECT& w = gWorkAreas[m];
                float x = clampf(fromX + frange(-maxDx, maxDx) * 0.5f, (float)w.left + 40 * S, (float)w.right - 40 * S);
                if (fromX < w.left - maxDx || fromX > w.right + maxDx) continue;
                float y = (float)w.bottom;
                if (y < fromY - maxUp || y > fromY + maxDown) continue;
                out.push_back({nullptr, x, (int)m, x, y});
            }
    }
    return out;
}
static void petJumpTo(const PetSpot& s, float dur) {
    gPet.state = PS_JUMP;
    gPet.jx0 = gPet.x; gPet.jy0 = gPet.y; gPet.jx1 = s.x; gPet.jy1 = s.y;
    gPet.jt = 0; gPet.jdur = dur;
    gPet.jcap = s.cap; gPet.jrel = s.rel; gPet.jmon = s.mon;
    gPet.dir = s.x >= gPet.x ? 1 : -1;
}
static void petLand(HWND cap, float rel, int mon) {
    gPet.cap = cap; gPet.relX = rel; gPet.mon = mon;
    gPet.vx = gPet.vy = 0;
    gPet.state = PS_SIT;
    gPet.timer = frange(1.0f, 3.0f);
}
// появиться: кот — на панели задач или окне, снегирь — прилетает из-за края экрана
static void petSpawn() {
    petUpdateWork();
    gPet = PetT();
    gPet.alive = true;
    gPet.dir = frand() < 0.5f ? 1 : -1;
    float cx = (float)gCursor.x, cy = (float)gCursor.y;
    std::vector<PetSpot> sp = petSpots(cx, cy, 1e6f, 1e6f, 1e6f, nullptr);
    PetSpot best{nullptr, 0, 0, 0, 0};
    bool have = false;
    for (auto& s : sp) if (!s.cap || (petCapLive(s.cap) && petCapLive(s.cap)->taskbar)) { best = s; have = true; break; }
    if (!have && !sp.empty()) { best = sp[xr() % sp.size()]; have = true; }
    if (!have) { gPet.alive = false; return; }
    if (gPetMode == 2) {
        gPet.x = best.x - 400 * S * gPet.dir; gPet.y = best.y - 300 * S;
        PetSpot s = best;
        petJumpTo(s, 2.2f);
        gPet.state = PS_FLYIN;
    } else {
        gPet.x = best.x; gPet.y = best.y;
        petLand(best.cap, best.rel, best.mon);
    }
}

static void petHeart(float x, float y, bool z) { if (gPetHearts.size() < 30) gPetHearts.push_back({x, y, 0, z}); }

static void updatePet(float dt) {
    for (auto& h : gPetHearts) { h.age += dt; h.y -= 22 * S * dt; h.x += std::sin(h.age * 4 + h.y) * 8 * S * dt; }
    gPetHearts.erase(std::remove_if(gPetHearts.begin(), gPetHearts.end(), [](const PetHeart& h) { return h.age > 1.6f; }), gPetHearts.end());
    if (!petActive()) { gPet.alive = false; return; }
    petUpdateWork();
    if (!gPet.alive) { petSpawn(); if (!gPet.alive) return; }
    PetT& p = gPet;
    bool bird = gPetMode == 2;
    float cx = (float)gCursor.x, cy = (float)gCursor.y;
    float cmove = std::hypot(cx - p.lastCx, cy - p.lastCy);
    if (cmove > 1.5f) p.cursorMoveT = 0; else p.cursorMoveT += dt;
    p.lastCx = cx; p.lastCy = cy;
    float dxc = cx - p.x, dyc = cy - p.y;
    float dc = std::hypot(dxc, dyc);
    p.anim += dt;
    p.idle += dt;
    p.look = clampf(dxc / (200 * S), -1, 1);

    // в полёте / прыжке / падении
    if (p.state == PS_JUMP || p.state == PS_FLYIN) {
        p.jt += dt / p.jdur;
        float t = std::min(1.0f, p.jt);
        // цель могла сдвинуться (окно перетащили) — тянемся к новой точке
        float tx, ty;
        if (petSurfaceAt(p.jcap, p.jrel, p.jmon, tx, ty)) { p.jx1 = tx; p.jy1 = ty; }
        float arc = p.state == PS_FLYIN ? 60 * S : std::max(25 * S, std::fabs(p.jx1 - p.jx0) * 0.25f + std::max(0.0f, p.jy0 - p.jy1) * 0.4f);
        float e = p.state == PS_FLYIN ? 1 - (1 - t) * (1 - t) : t;
        p.x = p.jx0 + (p.jx1 - p.jx0) * e;
        p.y = p.jy0 + (p.jy1 - p.jy0) * e - arc * 4 * t * (1 - t);
        if (t >= 1) {
            if (petSurfaceAt(p.jcap, p.jrel, p.jmon, tx, ty)) { p.x = tx; p.y = ty; petLand(p.jcap, p.jrel, p.jmon); }
            else { p.state = PS_FALL; p.vy = 0; }
        }
        return;
    }
    if (p.state == PS_AWAY) {   // снегирь улетел — вернётся
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= 60 * S * dt;
        p.timer -= dt;
        if (p.timer <= 0) {
            std::vector<PetSpot> sp = petSpots(p.x, p.y, 1e6f, 1e6f, 1e6f, nullptr);
            if (sp.empty()) { p.timer = 3; return; }
            PetSpot s = sp[xr() % sp.size()];
            p.dir = frand() < 0.5f ? 1 : -1;
            p.x = s.x - p.dir * 500 * S; p.y = s.y - 350 * S;
            petJumpTo(s, 2.4f);
            p.state = PS_FLYIN;
        }
        return;
    }
    if (p.state == PS_FALL) {
        float y0 = p.y;
        p.vy += 900 * S * dt;
        p.y += p.vy * dt;
        // ловим поверхность под собой
        for (size_t i = 0; i < gWins.size(); ++i) {
            Cap* c = gCapPtr[i];
            if (!c || p.x < c->r.left + 6 * S || p.x > c->r.right - 6 * S) continue;
            int j = (int)((p.x - c->r.left) / CW);
            if (j < 0 || j >= c->n() || !c->vis[j]) continue;
            float s = c->surfY(j);
            if (y0 <= s + 2 && p.y >= s) { p.y = s; petLand(c->h, p.x - c->r.left, 0); return; }
        }
        for (size_t m = 0; m < gWorkAreas.size(); ++m) {
            const RECT& w = gWorkAreas[m];
            if (p.x >= w.left && p.x < w.right && p.y >= w.bottom) { p.y = (float)w.bottom; petLand(nullptr, p.x, (int)m); return; }
        }
        if (p.y > gVY + gH + 200 * S) gPet.alive = false;   // упал за экран — появится заново
        return;
    }

    // стоим на поверхности
    float sx, sy;
    if (!petSurfaceAt(p.cap, p.relX, p.mon, sx, sy)) {
        // окно закрыли, свернули или его закрыло другое — спрыгиваем
        if (bird) { p.state = PS_AWAY; p.timer = frange(3, 8); return; }
        p.state = PS_FALL; p.vy = -120 * S;
        return;
    }
    p.x = sx; p.y = sy;
    Cap* cc = petCapLive(p.cap);
    float left = cc ? (float)cc->r.left + 14 * S : (p.mon < (int)gWorkAreas.size() ? (float)gWorkAreas[p.mon].left + 20 * S : p.x);
    float right = cc ? (float)cc->r.right - 14 * S : (p.mon < (int)gWorkAreas.size() ? (float)gWorkAreas[p.mon].right - 20 * S : p.x);
    auto moveBy = [&](float d) {
        float nx = clampf(p.x + d, left, right);
        float base = cc ? (float)cc->r.left : 0.0f;
        float tx, ty;
        if (petSurfaceAt(p.cap, nx - base, p.mon, tx, ty)) { p.relX = nx - base; p.x = tx; p.y = ty; return true; }
        return false;
    };

    // гладят: курсор медленно водят по питомцу
    bool over = std::fabs(dxc) < 30 * S && dyc > -42 * S && dyc < 4 * S;
    if (!bird && over && p.cursorMoveT < 0.15f) {
        p.love = std::min(3.0f, p.love + dt * 2);
        p.idle = 0;
        if (p.state != PS_SIT) { p.state = PS_SIT; p.timer = 3; }
    } else p.love = std::max(0.0f, p.love - dt * 0.7f);
    if (p.love > 0.6f) {
        p.heartT -= dt;
        if (p.heartT <= 0) { p.heartT = 0.35f; petHeart(p.x + p.dir * 16 * S, p.y - 40 * S, false); }
        return;
    }

    if (bird) {
        // снегирь: от курсора улетает
        if (dc < 110 * S && p.cursorMoveT < 0.3f) {
            p.state = PS_AWAY; p.timer = frange(12, 25);
            p.jx0 = p.x; p.jy0 = p.y;
            // улетаем вверх и в сторону от курсора — просто исчезаем за краем
            p.dir = dxc > 0 ? -1 : 1;
            gPet.x = p.x; gPet.y = p.y;
            p.vx = p.dir * 380 * S; p.vy = -260 * S;
            return;
        }
        p.timer -= dt;
        if (p.state == PS_WALK) {   // прыжки по краю
            float hop = std::fmod(p.anim, 0.45f);
            if (hop < dt) { if (!moveBy(p.dir * 9 * S) || frand() < 0.12f) p.dir = -p.dir; }
            if (p.timer <= 0) { p.state = PS_SIT; p.timer = frange(1.5f, 5); }
        } else {
            if (p.timer <= 0) {
                if (frand() < 0.25f) {   // перелететь на другое окно
                    std::vector<PetSpot> sp = petSpots(p.x, p.y, 700 * S, 500 * S, 500 * S, p.cap);
                    if (!sp.empty()) { petJumpTo(sp[xr() % sp.size()], 1.1f); p.state = PS_FLYIN; p.jx0 = p.x; p.jy0 = p.y; return; }
                }
                p.state = PS_WALK; p.timer = frange(2, 5);
                if (frand() < 0.5f) p.dir = -p.dir;
            }
        }
        return;
    }

    // кот: курсор рядом и двигается — бежит к нему
    bool nearC = std::fabs(dxc) < 320 * S && dyc > -180 * S && dyc < 60 * S;
    if (nearC && p.cursorMoveT < 0.4f && p.state != PS_SLEEP) {
        p.idle = 0;
        if (std::fabs(dxc) > 26 * S) {
            p.state = PS_CHASE;
            p.dir = dxc > 0 ? 1 : -1;
            if (!moveBy(p.dir * 120 * S * dt)) { p.state = PS_SIT; p.timer = 1; }
        } else if (p.state == PS_CHASE) { p.state = PS_SIT; p.timer = frange(1.5f, 3); }
        return;
    }
    if (p.state == PS_SLEEP) {
        if (dc < 90 * S && p.cursorMoveT < 0.2f) { p.state = PS_SIT; p.timer = 2; p.idle = 0; return; }   // разбудили
        p.heartT -= dt;
        if (p.heartT <= 0) { p.heartT = 1.1f; petHeart(p.x + p.dir * 10 * S, p.y - 22 * S, true); }
        p.timer -= dt;
        if (p.timer <= 0) { p.state = PS_SIT; p.timer = 2; p.idle = 0; }
        return;
    }
    if (p.state == PS_CHASE) { p.state = PS_SIT; p.timer = frange(2, 4); }
    p.timer -= dt;
    if (p.state == PS_WALK) {
        if (!moveBy(p.dir * 36 * S * dt) || p.x <= left + 1 || p.x >= right - 1) {
            // край окна: развернуться или перепрыгнуть
            if (frand() < 0.45f) {
                std::vector<PetSpot> sp = petSpots(p.x, p.y, 380 * S, 220 * S, 420 * S, p.cap);
                std::vector<PetSpot> ahead;
                for (auto& s : sp) if ((s.x - p.x) * p.dir > 0) ahead.push_back(s);
                const std::vector<PetSpot>& use = ahead.empty() ? sp : ahead;
                if (!use.empty()) { const PetSpot& s = use[xr() % use.size()]; petJumpTo(s, 0.45f + std::hypot(s.x - p.x, s.y - p.y) / (900 * S)); return; }
            }
            p.dir = -p.dir;
        }
        if (p.timer <= 0) { p.state = PS_SIT; p.timer = frange(3, 8); }
    } else if (p.state == PS_SIT) {
        if (p.timer <= 0) {
            if (p.idle > 40 && frand() < 0.4f) { p.state = PS_SLEEP; p.timer = frange(25, 70); p.heartT = 1; }
            else { p.state = PS_WALK; p.timer = frange(3, 9); if (frand() < 0.5f) p.dir = -p.dir; }
        }
    }
}

// ---------------------------------------------------------------- рисование
static void petThick(float x0, float y0, float x1, float y1, float r, float R, float G, float B) {
    float len = std::hypot(x1 - x0, y1 - y0);
    int n = std::max(1, (int)(len / std::max(0.8f, r * 0.7f)));
    for (int i = 0; i <= n; ++i) { float t = (float)i / n; drawDisc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, r, R, G, B, 1, 1, 0); }
}
static void petZ(float x, float y, float s, float a) {   // буква «z»
    thinLine(x, y, x + s, y, 230, 235, 255, a);
    thinLine(x + s, y, x, y + s, 230, 235, 255, a);
    thinLine(x, y + s, x + s, y + s, 230, 235, 255, a);
}
static void drawCat() {
    const PetT& p = gPet;
    static const RGB8 coats[4] = {{232, 142, 62}, {150, 152, 162}, {48, 46, 52}, {244, 242, 238}};
    static const RGB8 dark[4] = {{196, 98, 36}, {112, 114, 126}, {30, 28, 34}, {214, 210, 204}};
    RGB8 c = coats[gPetCoat & 3], d = dark[gPetCoat & 3];
    float s = 15 * S, X = p.x - gVX, Y = p.y - gVY;
    float dir = (float)p.dir;
    bool purr = p.love > 0.6f;
    RGB8 eye = gPetCoat == 2 ? RGB8{140, 220, 90} : RGB8{40, 40, 40};
    auto ear = [&](float hx, float hy, float side) {
        float bx = hx + side * s * 0.32f;
        float ex[3] = {bx - s * 0.22f, bx + s * 0.22f, bx + side * s * 0.05f};
        float ey[3] = {hy - s * 0.28f, hy - s * 0.28f, hy - s * 0.82f};
        fillPoly(ex, ey, 3, c.r, c.g, c.b, 1);
        float ix[3] = {bx - s * 0.1f, bx + s * 0.1f, bx + side * s * 0.04f};
        float iy[3] = {hy - s * 0.34f, hy - s * 0.34f, hy - s * 0.66f};
        fillPoly(ix, iy, 3, 240, 160, 170, 0.9f);
    };
    auto head = [&](float hx, float hy, bool closed) {
        ear(hx, hy, -1); ear(hx, hy, 1);
        drawDisc(hx, hy, s * 0.56f, c.r, c.g, c.b, 1, 1, 0);
        if (gPetCoat == 0) for (int k = -1; k <= 1; ++k) thinLine(hx + k * s * 0.14f, hy - s * 0.52f, hx + k * s * 0.12f, hy - s * 0.3f, d.r, d.g, d.b, 0.9f);
        float ex = hx + dir * s * 0.12f + p.look * s * 0.06f;
        for (int sd = -1; sd <= 1; sd += 2) {
            float x = ex + sd * s * 0.22f, y = hy - s * 0.06f;
            if (closed) thinLine(x - s * 0.1f, y, x + s * 0.1f, y + s * 0.03f, 40, 30, 30, 1);
            else { drawDisc(x, y, s * 0.11f, eye.r, eye.g, eye.b, 1, 1, 0); drawDisc(x + s * 0.03f, y - s * 0.04f, s * 0.035f, 255, 255, 255, 0.9f, 1, 0); }
        }
        drawDisc(hx + dir * s * 0.18f, hy + s * 0.16f, s * 0.07f, 230, 120, 130, 1, 1, 0);
        for (int sd = -1; sd <= 1; sd += 2)
            for (int k = 0; k < 2; ++k)
                thinLine(hx + sd * s * 0.25f, hy + s * 0.2f + k * s * 0.08f, hx + sd * s * 0.75f, hy + s * 0.12f + k * s * 0.18f, 250, 250, 250, 0.55f);
    };
    if (p.state == PS_SLEEP) {
        float br = 1 + 0.04f * std::sin(p.anim * 2.2f);
        petThick(X - dir * s * 1.1f, Y - s * 0.25f, X + dir * s * 0.6f, Y - s * 0.12f, s * 0.17f, d.r, d.g, d.b);   // хвост вокруг
        drawEllipse(X, Y - s * 0.5f * br, s * 1.25f, s * 0.55f * br, c.r, c.g, c.b, 1);
        if (gPetCoat == 0) for (int k = -2; k <= 2; ++k) thinLine(X + k * s * 0.3f, Y - s * 0.98f, X + k * s * 0.35f, Y - s * 0.6f, d.r, d.g, d.b, 0.8f);
        float hx = X + dir * s * 0.85f, hy = Y - s * 0.55f;
        ear(hx, hy + s * 0.1f, -1); ear(hx, hy + s * 0.1f, 1);
        drawDisc(hx, hy, s * 0.48f, c.r, c.g, c.b, 1, 1, 0);
        for (int sd = -1; sd <= 1; sd += 2) thinLine(hx + sd * s * 0.2f - s * 0.08f, hy, hx + sd * s * 0.2f + s * 0.08f, hy + s * 0.03f, 40, 30, 30, 1);
        return;
    }
    if (p.state == PS_SIT || p.love > 0.6f) {
        float tail = std::sin(p.anim * (purr ? 1.0f : 2.4f)) * 0.5f;
        float tx = X - dir * s * 0.7f, ty = Y - s * 0.12f;
        petThick(tx, ty, tx - dir * s * 0.9f, ty - s * (0.2f + 0.5f * tail), s * 0.16f, d.r, d.g, d.b);
        drawEllipse(X - dir * s * 0.15f, Y - s * 0.85f, s * 0.78f, s * 0.86f, c.r, c.g, c.b, 1);
        drawEllipse(X + dir * s * 0.2f, Y - s * 0.75f, s * 0.38f, s * 0.6f, std::min(255.0f, c.r + 18.0f), std::min(255.0f, c.g + 18.0f), std::min(255.0f, c.b + 18.0f), 0.9f);
        petThick(X + dir * s * 0.12f, Y - s * 0.5f, X + dir * s * 0.12f, Y - s * 0.05f, s * 0.14f, c.r, c.g, c.b);
        petThick(X + dir * s * 0.42f, Y - s * 0.5f, X + dir * s * 0.42f, Y - s * 0.05f, s * 0.14f, c.r, c.g, c.b);
        head(X + dir * s * 0.25f, Y - s * 1.82f, purr);
        return;
    }
    // идёт или бежит
    float run = p.state == PS_CHASE ? 1.6f : 1.0f;
    float ph = p.anim * 9 * run;
    float bob = std::fabs(std::sin(ph)) * s * 0.06f;
    float by = Y - s * 0.92f - bob;
    float tail = std::sin(p.anim * 3) * 0.3f;
    petThick(X - dir * s * 1.1f, by - s * 0.15f, X - dir * s * 1.75f, by - s * (0.95f + tail), s * 0.16f, d.r, d.g, d.b);
    for (int k = 0; k < 4; ++k) {   // лапы
        float lx = X + dir * (k < 2 ? s * 0.75f : -s * 0.75f) + (k & 1 ? s * 0.18f : -s * 0.18f) * dir;
        float sw = std::sin(ph + (k & 1 ? PI : 0) + (k < 2 ? 0 : PI * 0.5f)) * s * 0.28f * run;
        RGB8 lc = (k & 1) ? c : d;
        petThick(lx, by + s * 0.25f, lx + sw * dir, Y - s * 0.06f, s * 0.13f, lc.r, lc.g, lc.b);
    }
    drawEllipse(X, by, s * 1.25f, s * 0.55f, c.r, c.g, c.b, 1);
    if (gPetCoat == 0) for (int k = -2; k <= 2; ++k) thinLine(X + k * s * 0.32f, by - s * 0.52f, X + k * s * 0.36f, by - s * 0.15f, d.r, d.g, d.b, 0.8f);
    head(X + dir * s * 1.25f, by - s * 0.55f, false);
}
static void drawBird() {
    const PetT& p = gPet;
    float s = 9 * S;
    float X = p.x - gVX, Y = p.y - gVY;
    float dir = (float)p.dir;
    bool fly = p.state == PS_FLYIN || p.state == PS_JUMP || p.state == PS_AWAY;
    if (p.state == PS_AWAY && (p.x < gVX - 40 * S || p.x > gVX + gW + 40 * S || p.y < gVY - 40 * S)) return;
    float hop = (p.state == PS_WALK) ? std::fabs(std::sin(std::fmod(p.anim, 0.45f) / 0.45f * PI)) * s * 0.9f : 0;
    float by = Y - s * 1.05f - hop;
    if (!fly) {   // лапки
        thinLine(X - s * 0.2f, by + s * 0.8f, X - s * 0.25f, Y - hop, 60, 50, 50, 1);
        thinLine(X + s * 0.2f, by + s * 0.8f, X + s * 0.25f, Y - hop, 60, 50, 50, 1);
    }
    float peck = (p.state == PS_SIT) ? std::max(0.0f, std::sin(p.anim * 3.0f)) * s * 0.35f : 0;
    // хвост
    float tx[3] = {X - dir * s * 0.8f, X - dir * s * 1.9f, X - dir * s * 1.7f};
    float ty[3] = {by - s * 0.1f, by - s * 0.5f, by + s * 0.15f};
    fillPoly(tx, ty, 3, 40, 40, 48, 1);
    drawDisc(X, by, s, 105, 110, 128, 1, 1, 0);                                  // спинка
    drawEllipse(X + dir * s * 0.2f, by + s * 0.25f, s * 0.75f, s * 0.68f, 228, 82, 58, 1);   // красная грудка
    if (fly) {   // крылья машут
        float w = std::sin(p.anim * 22) * 0.9f;
        for (int sd = -1; sd <= 1; sd += 2)
            drawLeaf(X - dir * s * 0.1f, by - s * 0.3f - s * 0.6f * w * sd * 0.5f, s * 1.8f, s * 0.7f, -PI / 2 + sd * (0.6f + w * 0.6f), 55, 58, 70, 1, false);
    } else drawEllipse(X - dir * s * 0.25f, by - s * 0.05f, s * 0.6f, s * 0.4f, 60, 64, 78, 1);
    float hx = X + dir * s * 0.75f, hy = by - s * 0.7f + peck;
    drawDisc(hx, hy, s * 0.55f, 30, 30, 36, 1, 1, 0);                             // чёрная шапочка
    drawDisc(hx + dir * s * 0.1f, hy + s * 0.22f, s * 0.35f, 228, 82, 58, 1, 1, 0);
    drawDisc(hx + dir * s * 0.12f, hy - s * 0.1f, s * 0.09f, 250, 250, 250, 1, 1, 0);
    float bx[3] = {hx + dir * s * 0.45f, hx + dir * s * 0.8f, hx + dir * s * 0.45f};
    float byy[3] = {hy - s * 0.08f, hy + s * 0.05f, hy + s * 0.18f};
    fillPoly(bx, byy, 3, 40, 40, 40, 1);
}
static void drawPet() {
    for (auto& h : gPetHearts) {
        float a = clampf(1.6f - h.age, 0, 1) * clampf(h.age * 4, 0, 1);
        if (h.z) petZ(h.x - gVX, h.y - gVY, (5 + h.age * 4) * S, a);
        else drawHeart(h.x - gVX, h.y - gVY, 4.5f * S, 255, 90, 120, a, 0);
    }
    if (!gPet.alive || !petActive()) return;
    if (gPetMode == 2) drawBird(); else drawCat();
}
