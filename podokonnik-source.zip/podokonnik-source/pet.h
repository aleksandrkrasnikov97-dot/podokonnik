// Питомец на подоконнике: кот или снегирь живёт на верхних краях окон и на панели задач.
// Кот гуляет, сидит, спит, бежит за курсором и мурлычет, если его погладить мышкой;
// снегирь прыгает по краю, клюёт и улетает от курсора, а потом возвращается.
#pragma once

static int gPetMode = 0;    // 0 — нет питомца, 1 — есть (какой — в gPetCfg)
static int gPetCoat = 0;    // старая настройка окраса кота (до 2.5) — только для переноса

#include <wincodec.h>
#include <unordered_map>
#include "pet_atlas.h"

// свой питомец: собирается из частей во вкладке «Питомец»
struct PetCfg {
    int kind = 0;      // 0 — зверёк, 1 — птичка
    int body = 0;      // 0 обычное, 1 пушистое, 2 стройное, 3 пухлое
    int face = 0;      // 0 кошачья, 1 собачья, 2 лисья, 3 мишкина
    int ears = 0;      // 0 острые, 1 висячие, 2 большие, 3 длинные, 4 круглые
    int tail = 0;      // 0 тонкий, 1 пушистый, 2 помпон, 3 колечком, 4 нет
    int eyes = 0;      // 0 обычные, 1 большие, 2 сонные, 3 пуговки
    int pattern = 1;   // 0 однотонный, 1 полоски, 2 пятна, 3 носочки, 4 светлая грудка
    int acc = 0;       // 0 нет, 1 бантик, 2 ошейник, 3 шапка, 4 шарф, 5 корона
    int mood = 0;      // 0 спокойный, 1 игривый, 2 соня
    int size = 100;    // процентов
    RGB8 c1{232, 142, 62}, c2{196, 98, 36}, c3{40, 40, 40}, c4{214, 52, 64};   // основной, второй, глаза, аксессуар
    std::string name;
};
static PetCfg gPetCfg;
static bool petBird() { return gPetCfg.kind == 1; }
static float petScale() { return gPetCfg.size / 100.0f; }
static std::string petCfgStr() {
    const PetCfg& g = gPetCfg;
    auto hx = [](RGB8 c) { return (unsigned)((c.r << 16) | (c.g << 8) | c.b); };
    char b[200];
    snprintf(b, sizeof b, "1|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%06x|%06x|%06x|%06x", g.kind, g.body, g.face, g.ears, g.tail, g.eyes,
             g.pattern, g.acc, g.mood, g.size, hx(g.c1), hx(g.c2), hx(g.c3), hx(g.c4));
    return b;
}
static bool petCfgParse(const std::string& s) {
    int v[11]; unsigned c[4];
    if (sscanf(s.c_str(), "1|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%x|%x|%x|%x", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7], &v[8], &v[9],
               &c[0], &c[1], &c[2], &c[3]) != 14) return false;
    PetCfg& g = gPetCfg;
    auto cl = [](int x, int a, int b) { return x < a ? a : x > b ? b : x; };
    g.kind = cl(v[0], 0, 1); g.body = cl(v[1], 0, 3); g.face = cl(v[2], 0, 3); g.ears = cl(v[3], 0, 4); g.tail = cl(v[4], 0, 4);
    g.eyes = cl(v[5], 0, 3); g.pattern = cl(v[6], 0, 4); g.acc = cl(v[7], 0, 5); g.mood = cl(v[8], 0, 2); g.size = cl(v[9], 60, 160);
    RGB8* cc[4] = {&g.c1, &g.c2, &g.c3, &g.c4};
    for (int k = 0; k < 4; ++k) *cc[k] = RGB8{(uint8_t)(c[k] >> 16), (uint8_t)(c[k] >> 8), (uint8_t)c[k]};
    return true;
}
// старые настройки (кот с окрасом или снегирь) → свой питомец
static void petFromOld(int mode, int coat) {
    static const RGB8 coats[4] = {{232, 142, 62}, {150, 152, 162}, {48, 46, 52}, {244, 242, 238}};
    static const RGB8 dark[4] = {{196, 98, 36}, {112, 114, 126}, {30, 28, 34}, {214, 210, 204}};
    gPetCfg = PetCfg();
    if (mode == 2) { gPetCfg.kind = 1; gPetCfg.c1 = {105, 110, 128}; gPetCfg.c2 = {228, 82, 58}; gPetCfg.c3 = {30, 30, 36}; return; }
    coat &= 3;
    gPetCfg.c1 = coats[coat]; gPetCfg.c2 = dark[coat];
    gPetCfg.pattern = coat == 0 ? 1 : 0;
    if (coat == 2) gPetCfg.c3 = {140, 220, 90};
}

enum { PS_WALK = 0, PS_SIT, PS_SLEEP, PS_CHASE, PS_JUMP, PS_FALL, PS_AWAY, PS_FLYIN };
struct PetT {
    bool alive = false;
    int state = PS_FALL;
    float timer = 0, anim = 0, idle = 0, love = 0, heartT = 0, look = 0;
    float x = 0, y = 0, vx = 0, vy = 0;
    int dir = 1;
    HWND cap = nullptr;          // на каком окне сидит (nullptr — на краю рабочей области монитора)
    float relX = 0;              // смещение от левого края окна
    int mon = 0;                 // монитор, если сидит на краю рабочей области
    // прыжок / перелёт
    float jx0 = 0, jy0 = 0, jx1 = 0, jy1 = 0, jt = 0, jdur = 1;
    HWND jcap = nullptr; float jrel = 0; int jmon = 0;
    float lastCx = 0, lastCy = 0, cursorMoveT = 99;
};
static PetT gPet;
struct PetHeart { float x, y, age; bool z; };
static std::vector<PetHeart> gPetHearts;

static bool petActive() { return gPetMode != 0; }   // от эффектов погоды не зависит

// края рабочих областей мониторов (над панелью задач)
static std::vector<RECT> gWorkAreas;
static void petUpdateWork() {
    static double last = -10;
    if (gTime - last < 2 && !gWorkAreas.empty()) return;
    last = gTime;
    gWorkAreas.clear();
    for (const RECT& m : gMons) {
        MONITORINFO mi{}; mi.cbSize = sizeof(mi);
        POINT c{(m.left + m.right) / 2, (m.top + m.bottom) / 2};
        if (GetMonitorInfoW(MonitorFromPoint(c, MONITOR_DEFAULTTONEAREST), &mi)) gWorkAreas.push_back(mi.rcWork);
        else gWorkAreas.push_back(m);
    }
}
static Cap* petCapLive(HWND h) {
    if (!h) return nullptr;
    for (size_t i = 0; i < gWins.size(); ++i) if (gCapPtr[i] && gCapPtr[i]->h == h) return gCapPtr[i];
    return nullptr;
}
// где поверхность под питомцем: true — стоит на чём-то видимом
static bool petSurfaceAt(HWND cap, float relX, int mon, float& x, float& y) {
    if (cap) {
        Cap* c = petCapLive(cap);
        if (!c) return false;
        x = c->r.left + relX;
        if (x < c->r.left + 4 * S || x > c->r.right - 4 * S) return false;
        int j = (int)(relX / CW);
        if (j < 0 || j >= c->n() || !c->vis[j]) return false;
        y = c->surfY(j);
        return true;
    }
    if (mon < 0 || mon >= (int)gWorkAreas.size()) return false;
    const RECT& w = gWorkAreas[mon];
    x = clampf(relX, (float)w.left + 20 * S, (float)w.right - 20 * S);
    y = (float)w.bottom;
    return true;
}
// куда можно встать: окно или край рабочей области
struct PetSpot { HWND cap; float rel; int mon; float x, y; };
static std::vector<PetSpot> petSpots(float fromX, float fromY, float maxDx, float maxUp, float maxDown, HWND not_) {
    std::vector<PetSpot> out;
    bool tbSpot = false;   // нашлось место на панели задач
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->h == not_ || c->n() < 30) continue;
        for (int k = 0; k < 6; ++k) {
            float x = c->r.left + (c->r.right - c->r.left) * (0.08f + 0.84f * frand());
            int j = (int)((x - c->r.left) / CW);
            if (j < 0 || j >= c->n() || !c->vis[j]) continue;
            float y = c->surfY(j);
            if (std::fabs(x - fromX) > maxDx || y < fromY - maxUp || y > fromY + maxDown) continue;
            out.push_back({c->h, x - c->r.left, 0, x, y});
            if (c->taskbar) tbSpot = true;
            break;
        }
    }
    if (out.empty() || frand() < 0.25f) {
        // панели задач нет или на неё не встать (скрыта, вертикальная) — нижний край рабочей области
        bool anyTb = tbSpot;
        if (!anyTb)
            for (size_t i = 0; i < gWins.size(); ++i)
                if (gCapPtr[i] && gCapPtr[i]->taskbar && gCapPtr[i]->r.right - gCapPtr[i]->r.left > 3 * (gCapPtr[i]->r.bottom - gCapPtr[i]->r.top)) {
                    int v = 0; for (auto x : gCapPtr[i]->vis) v += x;
                    if (v * CW > 200 * S) anyTb = true;
                }
        if (!anyTb)
            for (size_t m = 0; m < gWorkAreas.size(); ++m) {
                const RECT& w = gWorkAreas[m];
                float x = clampf(fromX + frange(-maxDx, maxDx) * 0.5f, (float)w.left + 40 * S, (float)w.right - 40 * S);
                if (fromX < w.left - maxDx || fromX > w.right + maxDx) continue;
                float y = (float)w.bottom;
                if (y < fromY - maxUp || y > fromY + maxDown) continue;
                out.push_back({nullptr, x, (int)m, x, y});
            }
    }
    return out;
}
static void petJumpTo(const PetSpot& s, float dur) {
    gPet.state = PS_JUMP;
    gPet.jx0 = gPet.x; gPet.jy0 = gPet.y; gPet.jx1 = s.x; gPet.jy1 = s.y;
    gPet.jt = 0; gPet.jdur = dur;
    gPet.jcap = s.cap; gPet.jrel = s.rel; gPet.jmon = s.mon;
    gPet.dir = s.x >= gPet.x ? 1 : -1;
}
static void petLand(HWND cap, float rel, int mon) {
    gPet.cap = cap; gPet.relX = rel; gPet.mon = mon;
    gPet.vx = gPet.vy = 0;
    gPet.state = PS_SIT;
    gPet.timer = frange(1.0f, 3.0f);
}
// появиться: кот — на панели задач или окне, снегирь — прилетает из-за края экрана
static void petSpawn() {
    petUpdateWork();
    gPet = PetT();
    gPet.alive = true;
    gPet.dir = frand() < 0.5f ? 1 : -1;
    float cx = (float)gCursor.x, cy = (float)gCursor.y;
    std::vector<PetSpot> sp = petSpots(cx, cy, 1e6f, 1e6f, 1e6f, nullptr);
    PetSpot best{nullptr, 0, 0, 0, 0};
    bool have = false;
    for (auto& s : sp) if (!s.cap || (petCapLive(s.cap) && petCapLive(s.cap)->taskbar)) { best = s; have = true; break; }
    if (!have && !sp.empty()) { best = sp[xr() % sp.size()]; have = true; }
    if (!have) { gPet.alive = false; return; }
    if (petBird()) {
        gPet.x = best.x - 400 * S * gPet.dir; gPet.y = best.y - 300 * S;
        PetSpot s = best;
        petJumpTo(s, 2.2f);
        gPet.state = PS_FLYIN;
    } else {
        gPet.x = best.x; gPet.y = best.y;
        petLand(best.cap, best.rel, best.mon);
    }
}

static void petHeart(float x, float y, bool z) { if (gPetHearts.size() < 30) gPetHearts.push_back({x, y, 0, z}); }

static void updatePet(float dt) {
    for (auto& h : gPetHearts) { h.age += dt; h.y -= 22 * S * dt; h.x += std::sin(h.age * 4 + h.y) * 8 * S * dt; }
    gPetHearts.erase(std::remove_if(gPetHearts.begin(), gPetHearts.end(), [](const PetHeart& h) { return h.age > 1.6f; }), gPetHearts.end());
    if (!petActive()) { gPet.alive = false; return; }
    petUpdateWork();
    if (!gPet.alive) { petSpawn(); if (!gPet.alive) return; }
    PetT& p = gPet;
    bool bird = petBird();
    const float k = petScale();
    const int mood = gPetCfg.mood;
    float cx = (float)gCursor.x, cy = (float)gCursor.y;
    float cmove = std::hypot(cx - p.lastCx, cy - p.lastCy);
    if (cmove > 1.5f) p.cursorMoveT = 0; else p.cursorMoveT += dt;
    p.lastCx = cx; p.lastCy = cy;
    float dxc = cx - p.x, dyc = cy - p.y;
    float dc = std::hypot(dxc, dyc);
    p.anim += dt;
    p.idle += dt;
    p.look = clampf(dxc / (200 * S), -1, 1);

    // в полёте / прыжке / падении
    if (p.state == PS_JUMP || p.state == PS_FLYIN) {
        p.jt += dt / p.jdur;
        float t = std::min(1.0f, p.jt);
        // цель могла сдвинуться (окно перетащили) — тянемся к новой точке
        float tx, ty;
        if (petSurfaceAt(p.jcap, p.jrel, p.jmon, tx, ty)) { p.jx1 = tx; p.jy1 = ty; }
        float arc = p.state == PS_FLYIN ? 60 * S : std::max(25 * S, std::fabs(p.jx1 - p.jx0) * 0.25f + std::max(0.0f, p.jy0 - p.jy1) * 0.4f);
        float e = p.state == PS_FLYIN ? 1 - (1 - t) * (1 - t) : t;
        p.x = p.jx0 + (p.jx1 - p.jx0) * e;
        p.y = p.jy0 + (p.jy1 - p.jy0) * e - arc * 4 * t * (1 - t);
        if (t >= 1) {
            if (petSurfaceAt(p.jcap, p.jrel, p.jmon, tx, ty)) { p.x = tx; p.y = ty; petLand(p.jcap, p.jrel, p.jmon); }
            else { p.state = PS_FALL; p.vy = 0; }
        }
        return;
    }
    if (p.state == PS_AWAY) {   // снегирь улетел — вернётся
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= 60 * S * dt;
        p.timer -= dt;
        if (p.timer <= 0) {
            std::vector<PetSpot> sp = petSpots(p.x, p.y, 1e6f, 1e6f, 1e6f, nullptr);
            if (sp.empty()) { p.timer = 3; return; }
            PetSpot s = sp[xr() % sp.size()];
            p.dir = frand() < 0.5f ? 1 : -1;
            p.x = s.x - p.dir * 500 * S; p.y = s.y - 350 * S;
            petJumpTo(s, 2.4f);
            p.state = PS_FLYIN;
        }
        return;
    }
    if (p.state == PS_FALL) {
        float y0 = p.y;
        p.vy += 900 * S * dt;
        p.y += p.vy * dt;
        // ловим поверхность под собой
        for (size_t i = 0; i < gWins.size(); ++i) {
            Cap* c = gCapPtr[i];
            if (!c || p.x < c->r.left + 6 * S || p.x > c->r.right - 6 * S) continue;
            int j = (int)((p.x - c->r.left) / CW);
            if (j < 0 || j >= c->n() || !c->vis[j]) continue;
            float s = c->surfY(j);
            if (y0 <= s + 2 && p.y >= s) { p.y = s; petLand(c->h, p.x - c->r.left, 0); return; }
        }
        for (size_t m = 0; m < gWorkAreas.size(); ++m) {
            const RECT& w = gWorkAreas[m];
            if (p.x >= w.left && p.x < w.right && p.y >= w.bottom) { p.y = (float)w.bottom; petLand(nullptr, p.x, (int)m); return; }
        }
        if (p.y > gVY + gH + 200 * S) gPet.alive = false;   // упал за экран — появится заново
        return;
    }

    // стоим на поверхности
    float sx, sy;
    if (!petSurfaceAt(p.cap, p.relX, p.mon, sx, sy)) {
        // окно закрыли, свернули или его закрыло другое — спрыгиваем
        if (bird) { p.state = PS_AWAY; p.timer = frange(3, 8); return; }
        p.state = PS_FALL; p.vy = -120 * S;
        return;
    }
    p.x = sx; p.y = sy;
    Cap* cc = petCapLive(p.cap);
    float left = cc ? (float)cc->r.left + 14 * S : (p.mon < (int)gWorkAreas.size() ? (float)gWorkAreas[p.mon].left + 20 * S : p.x);
    float right = cc ? (float)cc->r.right - 14 * S : (p.mon < (int)gWorkAreas.size() ? (float)gWorkAreas[p.mon].right - 20 * S : p.x);
    auto moveBy = [&](float d) {
        float nx = clampf(p.x + d, left, right);
        float base = cc ? (float)cc->r.left : 0.0f;
        float tx, ty;
        if (petSurfaceAt(p.cap, nx - base, p.mon, tx, ty)) { p.relX = nx - base; p.x = tx; p.y = ty; return true; }
        return false;
    };

    // гладят: курсор медленно водят по питомцу
    bool over = std::fabs(dxc) < 30 * S * k && dyc > -42 * S * k && dyc < 4 * S;
    if (!bird && over && p.cursorMoveT < 0.15f) {
        p.love = std::min(3.0f, p.love + dt * 2);
        p.idle = 0;
        if (p.state != PS_SIT) { p.state = PS_SIT; p.timer = 3; }
    } else p.love = std::max(0.0f, p.love - dt * 0.7f);
    if (p.love > 0.6f) {
        p.heartT -= dt;
        if (p.heartT <= 0) { p.heartT = 0.35f; petHeart(p.x + p.dir * 16 * S * k, p.y - 40 * S * k, false); }
        return;
    }

    if (bird) {
        // снегирь: от курсора улетает
        if (dc < 110 * S && p.cursorMoveT < 0.3f) {
            p.state = PS_AWAY; p.timer = frange(12, 25);
            p.jx0 = p.x; p.jy0 = p.y;
            // улетаем вверх и в сторону от курсора — просто исчезаем за краем
            p.dir = dxc > 0 ? -1 : 1;
            gPet.x = p.x; gPet.y = p.y;
            p.vx = p.dir * 380 * S; p.vy = -260 * S;
            return;
        }
        p.timer -= dt;
        if (p.state == PS_WALK) {   // прыжки по краю
            float hop = std::fmod(p.anim, 0.45f);
            if (hop < dt) { if (!moveBy(p.dir * 9 * S) || frand() < 0.12f) p.dir = -p.dir; }
            if (p.timer <= 0) { p.state = PS_SIT; p.timer = frange(1.5f, 5); }
        } else {
            if (p.timer <= 0) {
                if (frand() < 0.25f) {   // перелететь на другое окно
                    std::vector<PetSpot> sp = petSpots(p.x, p.y, 700 * S, 500 * S, 500 * S, p.cap);
                    if (!sp.empty()) { petJumpTo(sp[xr() % sp.size()], 1.1f); p.state = PS_FLYIN; p.jx0 = p.x; p.jy0 = p.y; return; }
                }
                p.state = PS_WALK; p.timer = frange(2, 5);
                if (frand() < 0.5f) p.dir = -p.dir;
            }
        }
        return;
    }

    // кот: курсор рядом и двигается — бежит к нему
    float chaseR = mood == 1 ? 520.0f : mood == 2 ? 200.0f : 320.0f;   // игривый бегает за курсором издалека, соня — нехотя
    bool nearC = std::fabs(dxc) < chaseR * S && dyc > -180 * S && dyc < 60 * S;
    if (nearC && p.cursorMoveT < 0.4f && p.state != PS_SLEEP) {
        p.idle = 0;
        if (std::fabs(dxc) > 26 * S) {
            p.state = PS_CHASE;
            p.dir = dxc > 0 ? 1 : -1;
            if (!moveBy(p.dir * (mood == 1 ? 160 : 120) * S * dt)) { p.state = PS_SIT; p.timer = 1; }
        } else if (p.state == PS_CHASE) { p.state = PS_SIT; p.timer = frange(1.5f, 3); }
        return;
    }
    if (p.state == PS_SLEEP) {
        if (dc < 90 * S && p.cursorMoveT < 0.2f) { p.state = PS_SIT; p.timer = 2; p.idle = 0; return; }   // разбудили
        p.heartT -= dt;
        if (p.heartT <= 0) { p.heartT = 1.1f; petHeart(p.x + p.dir * 10 * S * k, p.y - 22 * S * k, true); }
        p.timer -= dt;
        if (p.timer <= 0) { p.state = PS_SIT; p.timer = 2; p.idle = 0; }
        return;
    }
    if (p.state == PS_CHASE) { p.state = PS_SIT; p.timer = frange(2, 4); }
    p.timer -= dt;
    if (p.state == PS_WALK) {
        if (!moveBy(p.dir * (mood == 1 ? 52 : mood == 2 ? 26 : 36) * S * dt) || p.x <= left + 1 || p.x >= right - 1) {
            // край окна: развернуться или перепрыгнуть
            if (frand() < (mood == 1 ? 0.7f : 0.45f)) {
                std::vector<PetSpot> sp = petSpots(p.x, p.y, 380 * S, 220 * S, 420 * S, p.cap);
                std::vector<PetSpot> ahead;
                for (auto& s : sp) if ((s.x - p.x) * p.dir > 0) ahead.push_back(s);
                const std::vector<PetSpot>& use = ahead.empty() ? sp : ahead;
                if (!use.empty()) { const PetSpot& s = use[xr() % use.size()]; petJumpTo(s, 0.45f + std::hypot(s.x - p.x, s.y - p.y) / (900 * S)); return; }
            }
            p.dir = -p.dir;
        }
        if (p.timer <= 0) { p.state = PS_SIT; p.timer = frange(3, 8); }
    } else if (p.state == PS_SIT) {
        if (p.timer <= 0) {
            float sleepAfter = mood == 2 ? 12.0f : mood == 1 ? 90.0f : 40.0f;
            if (p.idle > sleepAfter && frand() < (mood == 2 ? 0.75f : 0.4f)) { p.state = PS_SLEEP; p.timer = mood == 2 ? frange(60, 150) : frange(25, 70); p.heartT = 1; }
            else { p.state = PS_WALK; p.timer = frange(3, 9); if (frand() < 0.5f) p.dir = -p.dir; }
        }
    }
}

// ---------------------------------------------------------------- рисование
static void petThick(float x0, float y0, float x1, float y1, float r, float R, float G, float B) {
    float len = std::hypot(x1 - x0, y1 - y0);
    int n = std::max(1, (int)(len / std::max(0.8f, r * 0.7f)));
    for (int i = 0; i <= n; ++i) { float t = (float)i / n; drawDisc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, r, R, G, B, 1, 1, 0); }
}
static void petZ(float x, float y, float s, float a) {   // буква «z»
    thinLine(x, y, x + s, y, 230, 235, 255, a);
    thinLine(x + s, y, x, y + s, 230, 235, 255, a);
    thinLine(x, y + s, x + s, y + s, 230, 235, 255, a);
}
// ================================================================ питомец из картинок
// Части нарисованы ChatGPT (art/src), собраны в атлас art/petatlas.png (ресурс 109) скриптом art/build_atlas.py.
// Атлас — три полосы RGB: (c1·k, c2·k, c3·k), (c4·k, alpha, —), свой цвет (premultiplied). Та же раскладка — в ui/petdraw.js.
static std::vector<uint8_t> gPetAtlas;     // RGB, kPetAtlasW × 3·kPetAtlasBand
static int gPetAtlasState = 0;             // 0 — не грузили, 1 — готово, -1 — ошибка
static void petAtlasLoad() {
    gPetAtlasState = -1;
    HRSRC r = FindResourceW(nullptr, MAKEINTRESOURCEW(109), (LPCWSTR)RT_RCDATA);
    HGLOBAL hg = r ? LoadResource(nullptr, r) : nullptr;
    const BYTE* mem = hg ? (const BYTE*)LockResource(hg) : nullptr;
    DWORD sz = r ? SizeofResource(nullptr, r) : 0;
    if (!mem || !sz) return;
    IWICImagingFactory* f = nullptr; IWICStream* st = nullptr; IWICBitmapDecoder* dec = nullptr;
    IWICBitmapFrameDecode* fr = nullptr; IWICFormatConverter* cv = nullptr;
    if (SUCCEEDED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&f))) &&
        SUCCEEDED(f->CreateStream(&st)) && SUCCEEDED(st->InitializeFromMemory((BYTE*)mem, sz)) &&
        SUCCEEDED(f->CreateDecoderFromStream(st, nullptr, WICDecodeMetadataCacheOnLoad, &dec)) &&
        SUCCEEDED(dec->GetFrame(0, &fr)) && SUCCEEDED(f->CreateFormatConverter(&cv)) &&
        SUCCEEDED(cv->Initialize(fr, GUID_WICPixelFormat24bppRGB, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom))) {
        UINT w = 0, h = 0;
        cv->GetSize(&w, &h);
        if ((int)w == kPetAtlasW && (int)h >= 3 * kPetAtlasBand) {
            gPetAtlas.resize((size_t)w * h * 3);
            if (SUCCEEDED(cv->CopyPixels(nullptr, w * 3, (UINT)gPetAtlas.size(), gPetAtlas.data()))) gPetAtlasState = 1;
        }
    }
    if (cv) cv->Release(); if (fr) fr->Release(); if (dec) dec->Release(); if (st) st->Release(); if (f) f->Release();
}
static int petSprIndex(const char* name) {
    static std::unordered_map<std::string, int> idx;
    if (idx.empty()) for (int i = 0; i < (int)(sizeof kPetSprites / sizeof kPetSprites[0]); ++i) idx[kPetSprites[i].name] = i;
    auto it = idx.find(name);
    return it == idx.end() ? -1 : it->second;
}
struct PetBaked { int w = 0, h = 0; std::vector<float> px; };   // premultiplied RGBA, уже в цветах питомца и нужном размере
static std::unordered_map<uint64_t, PetBaked> gPetBaked;
static uint32_t gPetBakedColors = 0;
static const PetBaked* petBake(int si, float sc, float k) {
    const PetCfg& g = gPetCfg;
    uint32_t ch = 2166136261u;
    for (RGB8 c : {g.c1, g.c2, g.c3, g.c4}) for (uint8_t v : {c.r, c.g, c.b}) ch = (ch ^ v) * 16777619u;
    if (ch != gPetBakedColors || gPetBaked.size() > 400) { gPetBaked.clear(); gPetBakedColors = ch; }
    int qs = std::max(1, (int)std::lround(sc * 128)), qk = (int)std::lround(k * 100);
    uint64_t key = ((uint64_t)si << 40) | ((uint64_t)qk << 24) | (uint64_t)qs;
    auto it = gPetBaked.find(key);
    if (it != gPetBaked.end()) return &it->second;
    const PetSpriteDef& d = kPetSprites[si];
    float s = qs / 128.0f;
    PetBaked& b = gPetBaked[key];
    b.w = std::max(1, (int)std::ceil(d.w * s)); b.h = std::max(1, (int)std::ceil(d.h * s));
    b.px.assign((size_t)b.w * b.h * 4, 0.0f);
    const float K = kPetAtlasKmax / 255.0f;
    const RGB8 cols[4] = {g.c1, g.c2, g.c3, g.c4};
    const size_t W = kPetAtlasW, band = (size_t)kPetAtlasBand * W * 3;
    float foot = std::max(1.0f, 1.0f / s);   // сколько пикселей атласа приходится на один пиксель результата
    for (int y = 0; y < b.h; ++y)
        for (int x = 0; x < b.w; ++x) {
            float sx0 = x / s, sy0 = y / s;
            int x0 = (int)sx0, y0 = (int)sy0, x1 = std::min(d.w, (int)std::ceil(sx0 + foot)), y1 = std::min(d.h, (int)std::ceil(sy0 + foot));
            float acc[4] = {0, 0, 0, 0}; int n = 0;
            for (int yy = y0; yy < std::max(y1, y0 + 1) && yy < d.h; ++yy)
                for (int xx = x0; xx < std::max(x1, x0 + 1) && xx < d.w; ++xx) {
                    const uint8_t* p0 = &gPetAtlas[((size_t)(d.y + yy) * W + d.x + xx) * 3];
                    const uint8_t* p1 = p0 + band; const uint8_t* p2 = p1 + band;
                    float w4[4] = {p0[0] * K, p0[1] * K, p0[2] * K, p1[0] * K};
                    float a = p1[1] / 255.0f;
                    float rgb[3] = {(float)p2[0], (float)p2[1], (float)p2[2]};
                    for (int c = 0; c < 4; ++c) { rgb[0] += w4[c] * cols[c].r; rgb[1] += w4[c] * cols[c].g; rgb[2] += w4[c] * cols[c].b; }
                    acc[0] += rgb[0] * k; acc[1] += rgb[1] * k; acc[2] += rgb[2] * k; acc[3] += a;
                    ++n;
                }
            float* o = &b.px[((size_t)y * b.w + x) * 4];
            if (n) for (int c = 0; c < 4; ++c) o[c] = acc[c] / n;
        }
    return &b;
}
// нарисовать часть: точка крепления (piv: 'c' или 'n' — шея) попадает в (x, y) экрана;
// size — высота (или ширина при byW), rot — поворот вокруг точки, flip — отражение
static void petSpr(const char* name, float x, float y, float size, bool byW = false, float rot = 0, bool flip = false, float k = 1, char piv = 'c') {
    if (gPetAtlasState == 0) petAtlasLoad();
    if (gPetAtlasState != 1) return;
    int si = petSprIndex(name);
    if (si < 0) return;
    const PetSpriteDef& d = kPetSprites[si];
    float sc = byW ? size / d.w : size / d.h;
    if (sc <= 0.01f) return;
    const PetBaked* b = petBake(si, sc, k);
    float bs = b->w / (float)d.w;   // реальный масштаб запечённого спрайта
    float pvx = (piv == 'n' ? d.nx : d.px) * d.w * bs, pvy = (piv == 'n' ? d.ny : d.py) * d.h * bs;
    float fix = sc / bs;            // доводка до точного размера
    float cs = std::cos(rot), sn = std::sin(rot);
    float minx = 1e9f, miny = 1e9f, maxx = -1e9f, maxy = -1e9f;
    for (int c = 0; c < 4; ++c) {
        float u = ((c & 1) ? b->w : 0) - pvx, v = ((c & 2) ? b->h : 0) - pvy;
        u *= fix * (flip ? -1 : 1); v *= fix;
        float X = x + u * cs - v * sn, Y = y + u * sn + v * cs;
        minx = std::min(minx, X); maxx = std::max(maxx, X); miny = std::min(miny, Y); maxy = std::max(maxy, Y);
    }
    int ix0 = std::max(0, (int)std::floor(minx)), ix1 = std::min(gW - 1, (int)std::ceil(maxx));
    int iy0 = std::max(0, (int)std::floor(miny)), iy1 = std::min(gH - 1, (int)std::ceil(maxy));
    float inv = 1.0f / fix;
    for (int py = iy0; py <= iy1; ++py)
        for (int px = ix0; px <= ix1; ++px) {
            float rx = px + 0.5f - x, ry = py + 0.5f - y;
            float u = (rx * cs + ry * sn) * inv, v = (-rx * sn + ry * cs) * inv;
            if (flip) u = -u;
            float bx = u + pvx - 0.5f, by = v + pvy - 0.5f;
            int x0 = (int)std::floor(bx), y0 = (int)std::floor(by);
            if (x0 < -1 || y0 < -1 || x0 >= b->w || y0 >= b->h) continue;
            float fx = bx - x0, fy = by - y0;
            float acc[4] = {0, 0, 0, 0};
            for (int j = 0; j < 4; ++j) {
                int sx = x0 + (j & 1), sy = y0 + (j >> 1);
                if (sx < 0 || sy < 0 || sx >= b->w || sy >= b->h) continue;
                float wgt = ((j & 1) ? fx : 1 - fx) * ((j >> 1) ? fy : 1 - fy);
                const float* q = &b->px[((size_t)sy * b->w + sx) * 4];
                for (int c = 0; c < 4; ++c) acc[c] += q[c] * wgt;
            }
            if (acc[3] > 0.004f) blendPx(px, py, acc[0] / acc[3], acc[1] / acc[3], acc[2] / acc[3], acc[3]);
        }
}
static float petAspect(const char* n) { int i = petSprIndex(n); return i < 0 ? 1.0f : kPetSprites[i].h / (float)kPetSprites[i].w; }

static const int kPat[5] = {0, 1, 2, 0, 4}, kSitPat[5] = {0, 1, 2, 3, 4};
static const float kTW[4] = {2.5f, 2.6f, 2.9f, 2.3f}, kLeg[4] = {1.0f, 0.95f, 1.15f, 0.72f}, kSitH[4] = {2.15f, 2.2f, 2.4f, 2.05f}, kLW[4] = {2.6f, 2.7f, 2.95f, 2.4f};

static void petEars(float hx, float hy, float hr, float dir, bool front) {
    const PetCfg& g = gPetCfg;
    if (g.ears == 1) {   // висячие — поверх головы
        if (front) petSpr("ear1", hx - dir * hr * 0.12f, hy - hr * 0.7f, hr * 1.55f, false, 0, dir < 0, 0.82f);
        return;
    }
    if (front) return;
    static const float hk[5] = {1.0f, 0, 1.5f, 2.0f, 0.62f};
    char n[8]; snprintf(n, sizeof n, "ear%d", g.ears);
    float H = hr * hk[g.ears], by = hy - hr * (g.ears == 4 ? 0.62f : 0.55f);
    petSpr(n, hx - dir * hr * 0.42f, by, H, false, -dir * 0.32f, dir < 0, 0.8f);
    petSpr(n, hx + dir * hr * 0.18f, by - hr * 0.08f, H, false, dir * 0.12f, dir < 0);
}
static void petEyes(float hx, float hy, float hr, float dir, float look, bool closed) {
    const PetCfg& g = gPetCfg;
    char n[8]; snprintf(n, sizeof n, closed ? "eyeC" : "eye%d", g.eyes);
    static const float ew[4] = {0.36f, 0.46f, 0.4f, 0.24f};
    float W = closed ? hr * 0.42f : hr * ew[g.eyes], lx = look * hr * 0.05f;
    if (g.face == 1 || g.face == 2) petSpr(n, hx + dir * hr * 0.42f + lx, hy - hr * 0.22f, W, true, 0, dir < 0);
    else {
        float ey = hy - hr * (g.face == 3 ? 0.18f : 0.12f);
        petSpr(n, hx + dir * hr * 0.08f + lx, ey, W * 0.9f, true, 0, dir < 0);
        petSpr(n, hx + dir * hr * 0.58f + lx, ey, W, true, 0, dir < 0);
    }
}
static void petHeadAcc(float hx, float hy, float hr, float dir) {
    const PetCfg& g = gPetCfg;
    if (g.acc == 1) petSpr("acc1", hx - dir * hr * 0.45f, hy - hr * 0.78f, hr * 0.85f, true, -dir * 0.35f, dir < 0);
    else if (g.acc == 3) petSpr("acc3", hx + dir * hr * 0.05f, hy - hr * 0.38f, hr * 1.75f, true, dir * 0.08f, dir < 0);
    else if (g.acc == 5) petSpr("acc5", hx, hy - hr * 0.82f, hr * 1.0f, true, dir * 0.1f, dir < 0);
}
static void petNeckAcc(float nx, float ny, float hr, float dir, float rot) {
    const PetCfg& g = gPetCfg;
    if (g.acc == 2) petSpr("acc2", nx, ny, hr * 1.25f, true, rot, dir < 0);
    else if (g.acc == 4) petSpr("acc4", nx, ny, hr * 1.4f, true, rot, dir < 0);
}
static void petHead(float hx, float hy, float hr, float dir, float look, bool closed) {
    const PetCfg& g = gPetCfg;
    petEars(hx, hy, hr, dir, false);
    char n[16]; snprintf(n, sizeof n, "head%d_%d", g.face, kPat[g.pattern]);
    petSpr(n, hx, hy, hr * 2, false, 0, dir < 0);
    petEyes(hx, hy, hr, dir, look, closed);
    petEars(hx, hy, hr, dir, true);
    petHeadAcc(hx, hy, hr, dir);
}
static void petTail(float x, float y, float s, float dir, float wag, float rot0) {
    const PetCfg& g = gPetCfg;
    if (g.tail == 4) return;
    if (g.tail == 2) { petSpr("tail2", x - dir * s * 0.1f, y, s * 0.62f, false, 0, dir < 0); return; }
    static const float th[4] = {1.3f, 1.5f, 0, 0.95f};
    char n[8]; snprintf(n, sizeof n, "tail%d", g.tail);
    petSpr(n, x, y, s * th[g.tail], false, -dir * (rot0 + wag), dir > 0);
}
static void drawBeast() {
    const PetT& p = gPet;
    const PetCfg& g = gPetCfg;
    float s = 15 * S * petScale(), X = p.x - gVX, Y = p.y - gVY + s * 0.22f;   // чуть ниже края: лапы стоят на окне, а не парят
    float dir = (float)p.dir, hr = s * 0.62f;
    int b = g.body;
    bool love = p.love > 0.6f;
    char n[16];
    if (p.state == PS_SLEEP) {
        snprintf(n, sizeof n, "sleep%d_%d", b, kPat[g.pattern]);
        float W = s * kLW[b], H = W * petAspect(n), br = 1 + 0.03f * std::sin(p.anim * 2.2f);
        if (g.tail == 2) petSpr("tail2", X - dir * W * 0.46f, Y - H * 0.35f, s * 0.55f);
        petSpr(n, X, Y - H * br / 2, W, true, 0, dir < 0);
        if (g.tail == 0 || g.tail == 1)
            petSpr(g.tail ? "tail1" : "tail0", X - dir * W * 0.42f, Y - H * 0.06f, s * (g.tail ? 1.25f : 1.15f), false, dir * (g.tail ? 0.85f : 1.0f), dir < 0);
        petHead(X + dir * W * 0.36f, Y - H * 0.55f, hr * 0.92f, dir, 0, true);
        return;
    }
    if (p.state == PS_SIT || love) {
        snprintf(n, sizeof n, "sit%d_%d", b, kSitPat[g.pattern]);
        float H = s * kSitH[b], W = H / petAspect(n);
        int si = petSprIndex(n);
        float nkx = si >= 0 ? kPetSprites[si].nx : 0.75f, nky = si >= 0 ? kPetSprites[si].ny : 0;
        float nx = X + dir * (nkx - 0.5f) * W, ny = Y - H + nky * H;
        float tw = std::sin(p.anim * (love ? 1.0f : 2.0f)) * 0.12f;
        petTail(X - dir * W * 0.32f, Y - H * 0.12f, s, dir, tw, 0.35f);
        petSpr(n, X, Y, H, false, 0, dir < 0);
        float hx = nx + dir * hr * 0.05f, hy = ny - hr * 0.6f;
        petHead(hx, hy, hr, dir, p.look, love && g.face != 1);
        petNeckAcc(hx - dir * hr * 0.1f, hy + hr * 0.82f, hr, dir, 0);
        return;
    }
    // идёт или бежит
    snprintf(n, sizeof n, "torso%d_%d", b, kPat[g.pattern]);
    float W = s * kTW[b], H = W * petAspect(n);
    float run = p.state == PS_CHASE ? 1.6f : 1.0f;
    float ph = p.anim * 9 * run, bob = std::fabs(std::sin(ph)) * s * 0.05f;
    float legVis = s * 0.62f * kLeg[b], bodyBot = Y - legVis - bob, cy = bodyBot - H / 2;
    float legTop = bodyBot - H * 0.32f, legLen = Y - legTop;
    const char* leg = g.pattern == 3 ? "leg3" : "leg0";
    const float lx[4] = {W * 0.3f, W * 0.3f - s * 0.32f, -W * 0.3f + s * 0.3f, -W * 0.3f};
    for (int isFar = 1; isFar >= 0; --isFar)
        for (int i = 0; i < 4; ++i) {
            if ((i % 2 == 0) != (isFar == 1)) continue;
            float sw = std::sin(ph + (i % 2 ? PI : 0) + (i < 2 ? 0 : PI * 0.5f)) * 0.32f * std::min(run, 1.3f);
            petSpr(leg, X + dir * lx[i], legTop, legLen, false, -dir * sw, dir < 0, isFar ? 0.78f : 1.0f);
        }
    petTail(X - dir * W * 0.42f, cy - H * 0.05f, s, dir, std::sin(p.anim * 3) * 0.12f, 0.2f);
    petSpr(n, X, cy, W, true, 0, dir < 0);
    float hx = X + dir * W * 0.4f, hy = cy - H * 0.42f - hr * 0.2f;
    petHead(hx, hy, hr, dir, p.look, false);
    petNeckAcc(hx - dir * hr * 0.35f, hy + hr * 0.78f, hr, dir, dir * 0.45f);
}
static void drawBird() {
    const PetT& p = gPet;
    const PetCfg& g = gPetCfg;
    float sb = 9 * S * petScale(), X = p.x - gVX, Y = p.y - gVY + sb * 0.2f, dir = (float)p.dir, W = sb * 2.7f;
    if (p.state == PS_AWAY && (p.x < gVX - 40 * S || p.x > gVX + gW + 40 * S || p.y < gVY - 40 * S)) return;
    bool fly = p.state == PS_FLYIN || p.state == PS_JUMP || p.state == PS_AWAY;
    if (fly) {   // в полёте точка питомца — под ним
        petSpr("bird_fly", X, Y - sb * 1.2f + std::sin(p.anim * 10) * sb * 0.2f, W, true, 0, dir < 0);
        return;
    }
    float hop = p.state == PS_WALK ? std::fabs(std::sin(std::fmod(p.anim, 0.45f) / 0.45f * PI)) * sb * 0.8f : 0;
    bool peck = p.state == PS_SIT && std::sin(p.anim * 3.0f) > 0.2f;
    petSpr(peck ? "bird_peck" : "bird_stand", X, Y - hop, W, true, 0, dir < 0);
    if (!peck && g.acc && g.acc != 2 && g.acc != 4) {
        float H = W * petAspect("bird_stand"), hr = W * 0.17f;
        petHeadAcc(X + dir * W * 0.2f, Y - hop - H * 0.8f, hr, dir);
    }
}
static void drawPet() {
    for (auto& h : gPetHearts) {
        float a = clampf(1.6f - h.age, 0, 1) * clampf(h.age * 4, 0, 1);
        if (h.z) petZ(h.x - gVX, h.y - gVY, (5 + h.age * 4) * S, a);
        else drawHeart(h.x - gVX, h.y - gVY, 4.5f * S, 255, 90, 120, a, 0);
    }
    if (!gPet.alive || !petActive()) return;
    if (petBird()) drawBird(); else drawBeast();
}
