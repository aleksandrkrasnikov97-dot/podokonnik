// Питомец на подоконнике: кот или снегирь живёт на верхних краях окон и на панели задач.
// Кот гуляет, сидит, спит, бежит за курсором и мурлычет, если его погладить мышкой;
// снегирь прыгает по краю, клюёт и улетает от курсора, а потом возвращается.
#pragma once

static int gPetMode = 0;    // 0 — нет питомца, 1 — есть (какой — в gPetCfg)
static int gPetCoat = 0;    // старая настройка окраса кота (до 2.5) — только для переноса

// свой питомец: собирается из частей во вкладке «Питомец»
struct PetCfg {
    int kind = 0;      // 0 — зверёк, 1 — птичка
    int body = 0;      // 0 обычное, 1 пушистое, 2 стройное, 3 пухлое
    int face = 0;      // 0 кошачья, 1 собачья, 2 лисья, 3 мишкина
    int ears = 0;      // 0 острые, 1 висячие, 2 большие, 3 длинные, 4 круглые
    int tail = 0;      // 0 тонкий, 1 пушистый, 2 помпон, 3 колечком, 4 нет
    int eyes = 0;      // 0 обычные, 1 большие, 2 сонные, 3 пуговки
    int pattern = 1;   // 0 однотонный, 1 полоски, 2 пятна, 3 носочки, 4 светлая грудка
    int acc = 0;       // 0 нет, 1 бантик, 2 ошейник, 3 шапка, 4 шарф, 5 корона
    int mood = 0;      // 0 спокойный, 1 игривый, 2 соня
    int size = 100;    // процентов
    RGB8 c1{232, 142, 62}, c2{196, 98, 36}, c3{40, 40, 40}, c4{214, 52, 64};   // основной, второй, глаза, аксессуар
    std::string name;
};
static PetCfg gPetCfg;
static bool petBird() { return gPetCfg.kind == 1; }
static float petScale() { return gPetCfg.size / 100.0f; }
static std::string petCfgStr() {
    const PetCfg& g = gPetCfg;
    auto hx = [](RGB8 c) { return (unsigned)((c.r << 16) | (c.g << 8) | c.b); };
    char b[200];
    snprintf(b, sizeof b, "1|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%06x|%06x|%06x|%06x", g.kind, g.body, g.face, g.ears, g.tail, g.eyes,
             g.pattern, g.acc, g.mood, g.size, hx(g.c1), hx(g.c2), hx(g.c3), hx(g.c4));
    return b;
}
static bool petCfgParse(const std::string& s) {
    int v[11]; unsigned c[4];
    if (sscanf(s.c_str(), "1|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d|%x|%x|%x|%x", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7], &v[8], &v[9],
               &c[0], &c[1], &c[2], &c[3]) != 14) return false;
    PetCfg& g = gPetCfg;
    auto cl = [](int x, int a, int b) { return x < a ? a : x > b ? b : x; };
    g.kind = cl(v[0], 0, 1); g.body = cl(v[1], 0, 3); g.face = cl(v[2], 0, 3); g.ears = cl(v[3], 0, 4); g.tail = cl(v[4], 0, 4);
    g.eyes = cl(v[5], 0, 3); g.pattern = cl(v[6], 0, 4); g.acc = cl(v[7], 0, 5); g.mood = cl(v[8], 0, 2); g.size = cl(v[9], 60, 160);
    RGB8* cc[4] = {&g.c1, &g.c2, &g.c3, &g.c4};
    for (int k = 0; k < 4; ++k) *cc[k] = RGB8{(uint8_t)(c[k] >> 16), (uint8_t)(c[k] >> 8), (uint8_t)c[k]};
    return true;
}
// старые настройки (кот с окрасом или снегирь) → свой питомец
static void petFromOld(int mode, int coat) {
    static const RGB8 coats[4] = {{232, 142, 62}, {150, 152, 162}, {48, 46, 52}, {244, 242, 238}};
    static const RGB8 dark[4] = {{196, 98, 36}, {112, 114, 126}, {30, 28, 34}, {214, 210, 204}};
    gPetCfg = PetCfg();
    if (mode == 2) { gPetCfg.kind = 1; gPetCfg.c1 = {105, 110, 128}; gPetCfg.c2 = {228, 82, 58}; gPetCfg.c3 = {30, 30, 36}; return; }
    coat &= 3;
    gPetCfg.c1 = coats[coat]; gPetCfg.c2 = dark[coat];
    gPetCfg.pattern = coat == 0 ? 1 : 0;
    if (coat == 2) gPetCfg.c3 = {140, 220, 90};
}

enum { PS_WALK = 0, PS_SIT, PS_SLEEP, PS_CHASE, PS_JUMP, PS_FALL, PS_AWAY, PS_FLYIN };
struct PetT {
    bool alive = false;
    int state = PS_FALL;
    float timer = 0, anim = 0, idle = 0, love = 0, heartT = 0, look = 0;
    float x = 0, y = 0, vx = 0, vy = 0;
    int dir = 1;
    HWND cap = nullptr;          // на каком окне сидит (nullptr — на краю рабочей области монитора)
    float relX = 0;              // смещение от левого края окна
    int mon = 0;                 // монитор, если сидит на краю рабочей области
    // прыжок / перелёт
    float jx0 = 0, jy0 = 0, jx1 = 0, jy1 = 0, jt = 0, jdur = 1;
    HWND jcap = nullptr; float jrel = 0; int jmon = 0;
    float lastCx = 0, lastCy = 0, cursorMoveT = 99;
};
static PetT gPet;
struct PetHeart { float x, y, age; bool z; };
static std::vector<PetHeart> gPetHearts;

static bool petActive() { return gPetMode != 0; }   // от эффектов погоды не зависит

// края рабочих областей мониторов (над панелью задач)
static std::vector<RECT> gWorkAreas;
static void petUpdateWork() {
    static double last = -10;
    if (gTime - last < 2 && !gWorkAreas.empty()) return;
    last = gTime;
    gWorkAreas.clear();
    for (const RECT& m : gMons) {
        MONITORINFO mi{}; mi.cbSize = sizeof(mi);
        POINT c{(m.left + m.right) / 2, (m.top + m.bottom) / 2};
        if (GetMonitorInfoW(MonitorFromPoint(c, MONITOR_DEFAULTTONEAREST), &mi)) gWorkAreas.push_back(mi.rcWork);
        else gWorkAreas.push_back(m);
    }
}
static Cap* petCapLive(HWND h) {
    if (!h) return nullptr;
    for (size_t i = 0; i < gWins.size(); ++i) if (gCapPtr[i] && gCapPtr[i]->h == h) return gCapPtr[i];
    return nullptr;
}
// где поверхность под питомцем: true — стоит на чём-то видимом
static bool petSurfaceAt(HWND cap, float relX, int mon, float& x, float& y) {
    if (cap) {
        Cap* c = petCapLive(cap);
        if (!c) return false;
        x = c->r.left + relX;
        if (x < c->r.left + 4 * S || x > c->r.right - 4 * S) return false;
        int j = (int)(relX / CW);
        if (j < 0 || j >= c->n() || !c->vis[j]) return false;
        y = c->surfY(j);
        return true;
    }
    if (mon < 0 || mon >= (int)gWorkAreas.size()) return false;
    const RECT& w = gWorkAreas[mon];
    x = clampf(relX, (float)w.left + 20 * S, (float)w.right - 20 * S);
    y = (float)w.bottom;
    return true;
}
// куда можно встать: окно или край рабочей области
struct PetSpot { HWND cap; float rel; int mon; float x, y; };
static std::vector<PetSpot> petSpots(float fromX, float fromY, float maxDx, float maxUp, float maxDown, HWND not_) {
    std::vector<PetSpot> out;
    bool tbSpot = false;   // нашлось место на панели задач
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->h == not_ || c->n() < 30) continue;
        for (int k = 0; k < 6; ++k) {
            float x = c->r.left + (c->r.right - c->r.left) * (0.08f + 0.84f * frand());
            int j = (int)((x - c->r.left) / CW);
            if (j < 0 || j >= c->n() || !c->vis[j]) continue;
            float y = c->surfY(j);
            if (std::fabs(x - fromX) > maxDx || y < fromY - maxUp || y > fromY + maxDown) continue;
            out.push_back({c->h, x - c->r.left, 0, x, y});
            if (c->taskbar) tbSpot = true;
            break;
        }
    }
    if (out.empty() || frand() < 0.25f) {
        // панели задач нет или на неё не встать (скрыта, вертикальная) — нижний край рабочей области
        bool anyTb = tbSpot;
        if (!anyTb)
            for (size_t i = 0; i < gWins.size(); ++i)
                if (gCapPtr[i] && gCapPtr[i]->taskbar && gCapPtr[i]->r.right - gCapPtr[i]->r.left > 3 * (gCapPtr[i]->r.bottom - gCapPtr[i]->r.top)) {
                    int v = 0; for (auto x : gCapPtr[i]->vis) v += x;
                    if (v * CW > 200 * S) anyTb = true;
                }
        if (!anyTb)
            for (size_t m = 0; m < gWorkAreas.size(); ++m) {
                const RECT& w = gWorkAreas[m];
                float x = clampf(fromX + frange(-maxDx, maxDx) * 0.5f, (float)w.left + 40 * S, (float)w.right - 40 * S);
                if (fromX < w.left - maxDx || fromX > w.right + maxDx) continue;
                float y = (float)w.bottom;
                if (y < fromY - maxUp || y > fromY + maxDown) continue;
                out.push_back({nullptr, x, (int)m, x, y});
            }
    }
    return out;
}
static void petJumpTo(const PetSpot& s, float dur) {
    gPet.state = PS_JUMP;
    gPet.jx0 = gPet.x; gPet.jy0 = gPet.y; gPet.jx1 = s.x; gPet.jy1 = s.y;
    gPet.jt = 0; gPet.jdur = dur;
    gPet.jcap = s.cap; gPet.jrel = s.rel; gPet.jmon = s.mon;
    gPet.dir = s.x >= gPet.x ? 1 : -1;
}
static void petLand(HWND cap, float rel, int mon) {
    gPet.cap = cap; gPet.relX = rel; gPet.mon = mon;
    gPet.vx = gPet.vy = 0;
    gPet.state = PS_SIT;
    gPet.timer = frange(1.0f, 3.0f);
}
// появиться: кот — на панели задач или окне, снегирь — прилетает из-за края экрана
static void petSpawn() {
    petUpdateWork();
    gPet = PetT();
    gPet.alive = true;
    gPet.dir = frand() < 0.5f ? 1 : -1;
    float cx = (float)gCursor.x, cy = (float)gCursor.y;
    std::vector<PetSpot> sp = petSpots(cx, cy, 1e6f, 1e6f, 1e6f, nullptr);
    PetSpot best{nullptr, 0, 0, 0, 0};
    bool have = false;
    for (auto& s : sp) if (!s.cap || (petCapLive(s.cap) && petCapLive(s.cap)->taskbar)) { best = s; have = true; break; }
    if (!have && !sp.empty()) { best = sp[xr() % sp.size()]; have = true; }
    if (!have) { gPet.alive = false; return; }
    if (petBird()) {
        gPet.x = best.x - 400 * S * gPet.dir; gPet.y = best.y - 300 * S;
        PetSpot s = best;
        petJumpTo(s, 2.2f);
        gPet.state = PS_FLYIN;
    } else {
        gPet.x = best.x; gPet.y = best.y;
        petLand(best.cap, best.rel, best.mon);
    }
}

static void petHeart(float x, float y, bool z) { if (gPetHearts.size() < 30) gPetHearts.push_back({x, y, 0, z}); }

static void updatePet(float dt) {
    for (auto& h : gPetHearts) { h.age += dt; h.y -= 22 * S * dt; h.x += std::sin(h.age * 4 + h.y) * 8 * S * dt; }
    gPetHearts.erase(std::remove_if(gPetHearts.begin(), gPetHearts.end(), [](const PetHeart& h) { return h.age > 1.6f; }), gPetHearts.end());
    if (!petActive()) { gPet.alive = false; return; }
    petUpdateWork();
    if (!gPet.alive) { petSpawn(); if (!gPet.alive) return; }
    PetT& p = gPet;
    bool bird = petBird();
    const float k = petScale();
    const int mood = gPetCfg.mood;
    float cx = (float)gCursor.x, cy = (float)gCursor.y;
    float cmove = std::hypot(cx - p.lastCx, cy - p.lastCy);
    if (cmove > 1.5f) p.cursorMoveT = 0; else p.cursorMoveT += dt;
    p.lastCx = cx; p.lastCy = cy;
    float dxc = cx - p.x, dyc = cy - p.y;
    float dc = std::hypot(dxc, dyc);
    p.anim += dt;
    p.idle += dt;
    p.look = clampf(dxc / (200 * S), -1, 1);

    // в полёте / прыжке / падении
    if (p.state == PS_JUMP || p.state == PS_FLYIN) {
        p.jt += dt / p.jdur;
        float t = std::min(1.0f, p.jt);
        // цель могла сдвинуться (окно перетащили) — тянемся к новой точке
        float tx, ty;
        if (petSurfaceAt(p.jcap, p.jrel, p.jmon, tx, ty)) { p.jx1 = tx; p.jy1 = ty; }
        float arc = p.state == PS_FLYIN ? 60 * S : std::max(25 * S, std::fabs(p.jx1 - p.jx0) * 0.25f + std::max(0.0f, p.jy0 - p.jy1) * 0.4f);
        float e = p.state == PS_FLYIN ? 1 - (1 - t) * (1 - t) : t;
        p.x = p.jx0 + (p.jx1 - p.jx0) * e;
        p.y = p.jy0 + (p.jy1 - p.jy0) * e - arc * 4 * t * (1 - t);
        if (t >= 1) {
            if (petSurfaceAt(p.jcap, p.jrel, p.jmon, tx, ty)) { p.x = tx; p.y = ty; petLand(p.jcap, p.jrel, p.jmon); }
            else { p.state = PS_FALL; p.vy = 0; }
        }
        return;
    }
    if (p.state == PS_AWAY) {   // снегирь улетел — вернётся
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= 60 * S * dt;
        p.timer -= dt;
        if (p.timer <= 0) {
            std::vector<PetSpot> sp = petSpots(p.x, p.y, 1e6f, 1e6f, 1e6f, nullptr);
            if (sp.empty()) { p.timer = 3; return; }
            PetSpot s = sp[xr() % sp.size()];
            p.dir = frand() < 0.5f ? 1 : -1;
            p.x = s.x - p.dir * 500 * S; p.y = s.y - 350 * S;
            petJumpTo(s, 2.4f);
            p.state = PS_FLYIN;
        }
        return;
    }
    if (p.state == PS_FALL) {
        float y0 = p.y;
        p.vy += 900 * S * dt;
        p.y += p.vy * dt;
        // ловим поверхность под собой
        for (size_t i = 0; i < gWins.size(); ++i) {
            Cap* c = gCapPtr[i];
            if (!c || p.x < c->r.left + 6 * S || p.x > c->r.right - 6 * S) continue;
            int j = (int)((p.x - c->r.left) / CW);
            if (j < 0 || j >= c->n() || !c->vis[j]) continue;
            float s = c->surfY(j);
            if (y0 <= s + 2 && p.y >= s) { p.y = s; petLand(c->h, p.x - c->r.left, 0); return; }
        }
        for (size_t m = 0; m < gWorkAreas.size(); ++m) {
            const RECT& w = gWorkAreas[m];
            if (p.x >= w.left && p.x < w.right && p.y >= w.bottom) { p.y = (float)w.bottom; petLand(nullptr, p.x, (int)m); return; }
        }
        if (p.y > gVY + gH + 200 * S) gPet.alive = false;   // упал за экран — появится заново
        return;
    }

    // стоим на поверхности
    float sx, sy;
    if (!petSurfaceAt(p.cap, p.relX, p.mon, sx, sy)) {
        // окно закрыли, свернули или его закрыло другое — спрыгиваем
        if (bird) { p.state = PS_AWAY; p.timer = frange(3, 8); return; }
        p.state = PS_FALL; p.vy = -120 * S;
        return;
    }
    p.x = sx; p.y = sy;
    Cap* cc = petCapLive(p.cap);
    float left = cc ? (float)cc->r.left + 14 * S : (p.mon < (int)gWorkAreas.size() ? (float)gWorkAreas[p.mon].left + 20 * S : p.x);
    float right = cc ? (float)cc->r.right - 14 * S : (p.mon < (int)gWorkAreas.size() ? (float)gWorkAreas[p.mon].right - 20 * S : p.x);
    auto moveBy = [&](float d) {
        float nx = clampf(p.x + d, left, right);
        float base = cc ? (float)cc->r.left : 0.0f;
        float tx, ty;
        if (petSurfaceAt(p.cap, nx - base, p.mon, tx, ty)) { p.relX = nx - base; p.x = tx; p.y = ty; return true; }
        return false;
    };

    // гладят: курсор медленно водят по питомцу
    bool over = std::fabs(dxc) < 30 * S * k && dyc > -42 * S * k && dyc < 4 * S;
    if (!bird && over && p.cursorMoveT < 0.15f) {
        p.love = std::min(3.0f, p.love + dt * 2);
        p.idle = 0;
        if (p.state != PS_SIT) { p.state = PS_SIT; p.timer = 3; }
    } else p.love = std::max(0.0f, p.love - dt * 0.7f);
    if (p.love > 0.6f) {
        p.heartT -= dt;
        if (p.heartT <= 0) { p.heartT = 0.35f; petHeart(p.x + p.dir * 16 * S * k, p.y - 40 * S * k, false); }
        return;
    }

    if (bird) {
        // снегирь: от курсора улетает
        if (dc < 110 * S && p.cursorMoveT < 0.3f) {
            p.state = PS_AWAY; p.timer = frange(12, 25);
            p.jx0 = p.x; p.jy0 = p.y;
            // улетаем вверх и в сторону от курсора — просто исчезаем за краем
            p.dir = dxc > 0 ? -1 : 1;
            gPet.x = p.x; gPet.y = p.y;
            p.vx = p.dir * 380 * S; p.vy = -260 * S;
            return;
        }
        p.timer -= dt;
        if (p.state == PS_WALK) {   // прыжки по краю
            float hop = std::fmod(p.anim, 0.45f);
            if (hop < dt) { if (!moveBy(p.dir * 9 * S) || frand() < 0.12f) p.dir = -p.dir; }
            if (p.timer <= 0) { p.state = PS_SIT; p.timer = frange(1.5f, 5); }
        } else {
            if (p.timer <= 0) {
                if (frand() < 0.25f) {   // перелететь на другое окно
                    std::vector<PetSpot> sp = petSpots(p.x, p.y, 700 * S, 500 * S, 500 * S, p.cap);
                    if (!sp.empty()) { petJumpTo(sp[xr() % sp.size()], 1.1f); p.state = PS_FLYIN; p.jx0 = p.x; p.jy0 = p.y; return; }
                }
                p.state = PS_WALK; p.timer = frange(2, 5);
                if (frand() < 0.5f) p.dir = -p.dir;
            }
        }
        return;
    }

    // кот: курсор рядом и двигается — бежит к нему
    float chaseR = mood == 1 ? 520.0f : mood == 2 ? 200.0f : 320.0f;   // игривый бегает за курсором издалека, соня — нехотя
    bool nearC = std::fabs(dxc) < chaseR * S && dyc > -180 * S && dyc < 60 * S;
    if (nearC && p.cursorMoveT < 0.4f && p.state != PS_SLEEP) {
        p.idle = 0;
        if (std::fabs(dxc) > 26 * S) {
            p.state = PS_CHASE;
            p.dir = dxc > 0 ? 1 : -1;
            if (!moveBy(p.dir * (mood == 1 ? 160 : 120) * S * dt)) { p.state = PS_SIT; p.timer = 1; }
        } else if (p.state == PS_CHASE) { p.state = PS_SIT; p.timer = frange(1.5f, 3); }
        return;
    }
    if (p.state == PS_SLEEP) {
        if (dc < 90 * S && p.cursorMoveT < 0.2f) { p.state = PS_SIT; p.timer = 2; p.idle = 0; return; }   // разбудили
        p.heartT -= dt;
        if (p.heartT <= 0) { p.heartT = 1.1f; petHeart(p.x + p.dir * 10 * S * k, p.y - 22 * S * k, true); }
        p.timer -= dt;
        if (p.timer <= 0) { p.state = PS_SIT; p.timer = 2; p.idle = 0; }
        return;
    }
    if (p.state == PS_CHASE) { p.state = PS_SIT; p.timer = frange(2, 4); }
    p.timer -= dt;
    if (p.state == PS_WALK) {
        if (!moveBy(p.dir * (mood == 1 ? 52 : mood == 2 ? 26 : 36) * S * dt) || p.x <= left + 1 || p.x >= right - 1) {
            // край окна: развернуться или перепрыгнуть
            if (frand() < (mood == 1 ? 0.7f : 0.45f)) {
                std::vector<PetSpot> sp = petSpots(p.x, p.y, 380 * S, 220 * S, 420 * S, p.cap);
                std::vector<PetSpot> ahead;
                for (auto& s : sp) if ((s.x - p.x) * p.dir > 0) ahead.push_back(s);
                const std::vector<PetSpot>& use = ahead.empty() ? sp : ahead;
                if (!use.empty()) { const PetSpot& s = use[xr() % use.size()]; petJumpTo(s, 0.45f + std::hypot(s.x - p.x, s.y - p.y) / (900 * S)); return; }
            }
            p.dir = -p.dir;
        }
        if (p.timer <= 0) { p.state = PS_SIT; p.timer = frange(3, 8); }
    } else if (p.state == PS_SIT) {
        if (p.timer <= 0) {
            float sleepAfter = mood == 2 ? 12.0f : mood == 1 ? 90.0f : 40.0f;
            if (p.idle > sleepAfter && frand() < (mood == 2 ? 0.75f : 0.4f)) { p.state = PS_SLEEP; p.timer = mood == 2 ? frange(60, 150) : frange(25, 70); p.heartT = 1; }
            else { p.state = PS_WALK; p.timer = frange(3, 9); if (frand() < 0.5f) p.dir = -p.dir; }
        }
    }
}

// ---------------------------------------------------------------- рисование
static void petThick(float x0, float y0, float x1, float y1, float r, float R, float G, float B) {
    float len = std::hypot(x1 - x0, y1 - y0);
    int n = std::max(1, (int)(len / std::max(0.8f, r * 0.7f)));
    for (int i = 0; i <= n; ++i) { float t = (float)i / n; drawDisc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, r, R, G, B, 1, 1, 0); }
}
static void petZ(float x, float y, float s, float a) {   // буква «z»
    thinLine(x, y, x + s, y, 230, 235, 255, a);
    thinLine(x + s, y, x, y + s, 230, 235, 255, a);
    thinLine(x, y + s, x + s, y + s, 230, 235, 255, a);
}
static RGB8 petMix(RGB8 c, float k) {   // k<1 — темнее, k>1 — светлее (к белому)
    if (k <= 1) return RGB8{(uint8_t)(c.r * k), (uint8_t)(c.g * k), (uint8_t)(c.b * k)};
    float t = std::min(1.0f, k - 1);
    return RGB8{(uint8_t)(c.r + (255 - c.r) * t), (uint8_t)(c.g + (255 - c.g) * t), (uint8_t)(c.b + (255 - c.b) * t)};
}
static void pDisc(float x, float y, float r, RGB8 c, float a = 1) { drawDisc(x, y, r, c.r, c.g, c.b, a, 1, 0); }
static void pEll(float x, float y, float rx, float ry, RGB8 c, float a = 1) { drawEllipse(x, y, rx, ry, c.r, c.g, c.b, a); }
static void pThick(float x0, float y0, float x1, float y1, float r, RGB8 c) { petThick(x0, y0, x1, y1, r, c.r, c.g, c.b); }
static void pLine(float x0, float y0, float x1, float y1, RGB8 c, float a = 1) { thinLine(x0, y0, x1, y1, c.r, c.g, c.b, a); }
static void pPoly(const float* x, const float* y, int n, RGB8 c, float a = 1) { fillPoly(x, y, n, c.r, c.g, c.b, a); }
static void pLeaf(float x, float y, float len, float wid, float ang, RGB8 c, float a = 1) { drawLeaf(x, y, len, wid, ang, c.r, c.g, c.b, a, false); }

static const float kBodyRx[4] = {1.25f, 1.35f, 1.42f, 1.18f}, kBodyRy[4] = {0.55f, 0.64f, 0.46f, 0.70f}, kLeg[4] = {1.0f, 0.95f, 1.18f, 0.72f};
static const RGB8 kPink{240, 160, 170}, kNose{50, 38, 40}, kWhite{250, 250, 250}, kGold{246, 196, 64};

// уши (кроме висячих) — рисуются до головы
static void petEarsBack(float hx, float hy, float hr, float s, float dir, RGB8 c) {
    const PetCfg& g = gPetCfg;
    for (int side = -1; side <= 1; side += 2) {
        if (g.ears == 0 || g.ears == 2) {
            float k = g.ears == 2 ? 1.45f : 1.0f;
            float bx = hx + side * s * 0.32f * (g.ears == 2 ? 1.1f : 1.0f);
            float ex[3] = {bx - s * 0.22f * k, bx + s * 0.22f * k, bx + side * s * 0.05f * k};
            float ey[3] = {hy - s * 0.28f, hy - s * 0.28f, hy - s * 0.28f - s * 0.54f * k};
            pPoly(ex, ey, 3, c);
            float ix[3] = {bx - s * 0.1f * k, bx + s * 0.1f * k, bx + side * s * 0.04f * k};
            float iy[3] = {hy - s * 0.34f, hy - s * 0.34f, hy - s * 0.34f - s * 0.32f * k};
            pPoly(ix, iy, 3, kPink, 0.9f);
        } else if (g.ears == 3) {
            float ex = hx + side * hr * 0.32f, ey = hy - hr * 1.25f;
            pLeaf(ex, ey, hr * 1.9f, hr * 0.62f, -PI / 2 + side * 0.2f, c);
            pLeaf(ex, ey + hr * 0.08f, hr * 1.45f, hr * 0.3f, -PI / 2 + side * 0.2f, kPink, 0.9f);
        } else if (g.ears == 4) {
            pDisc(hx + side * hr * 0.66f, hy - hr * 0.68f, hr * 0.36f, c);
            pDisc(hx + side * hr * 0.66f, hy - hr * 0.68f, hr * 0.2f, petMix(c, 0.75f));
        }
    }
    (void)dir;
}
static void petEarsFront(float hx, float hy, float hr, float dir, RGB8 c) {
    if (gPetCfg.ears != 1) return;
    RGB8 d = petMix(c, 0.72f);
    for (int side = -1; side <= 1; side += 2)
        pLeaf(hx + side * hr * 0.8f - dir * hr * 0.1f, hy + hr * 0.12f, hr * 1.25f, hr * 0.6f, PI / 2 - side * 0.35f, d);
}
// украшение на голове: бантик, шапка, корона
static void petHeadAcc(float hx, float hy, float hr, float dir) {
    const PetCfg& g = gPetCfg;
    RGB8 a = g.c4;
    if (g.acc == 1) {   // бантик сбоку
        float bx = hx - dir * hr * 0.42f, by = hy - hr * 0.78f;
        float l1[3] = {bx, bx - hr * 0.42f, bx - hr * 0.42f}, t1[3] = {by, by - hr * 0.26f, by + hr * 0.26f};
        float l2[3] = {bx, bx + hr * 0.42f, bx + hr * 0.42f};
        pPoly(l1, t1, 3, a); pPoly(l2, t1, 3, a);
        pDisc(bx, by, hr * 0.12f, petMix(a, 0.8f));
    } else if (g.acc == 3) {   // зимняя шапка с помпоном
        float cy = hy - hr * 0.42f, rx = hr * 0.9f, ry = hr * 0.66f;
        float px[13], py[13];
        for (int i = 0; i <= 12; ++i) { float t = PI + PI * i / 12; px[i] = hx + std::cos(t) * rx; py[i] = cy + std::sin(t) * ry; }
        pPoly(px, py, 13, a);
        pThick(hx - rx * 0.95f, cy, hx + rx * 0.95f, cy, hr * 0.13f, kWhite);
        pDisc(hx, cy - ry - hr * 0.08f, hr * 0.2f, kWhite);
    } else if (g.acc == 5) {   // корона
        float by = hy - hr * 0.72f, w = hr * 0.5f, h = hr * 0.5f;
        float cx[7] = {hx - w, hx - w, hx - w * 0.5f, hx, hx + w * 0.5f, hx + w, hx + w};
        float cyy[7] = {by, by - h, by - h * 0.5f, by - h * 1.1f, by - h * 0.5f, by - h, by};
        pPoly(cx, cyy, 7, kGold);
        pDisc(hx, by - h * 0.35f, hr * 0.08f, a);
    }
}
// на шее: ошейник с колокольчиком или шарф
static void petNeckAcc(float hx, float hy, float hr, float s, float dir) {
    const PetCfg& g = gPetCfg;
    if (g.acc == 2) {
        pThick(hx - hr * 0.55f, hy + hr * 0.86f, hx + hr * 0.55f, hy + hr * 0.9f, s * 0.08f, g.c4);
        pDisc(hx + dir * hr * 0.12f, hy + hr * 1.04f, s * 0.1f, kGold);
    } else if (g.acc == 4) {
        pThick(hx - hr * 0.62f, hy + hr * 0.86f, hx + hr * 0.62f, hy + hr * 0.92f, s * 0.13f, g.c4);
        pThick(hx - dir * hr * 0.3f, hy + hr * 0.95f, hx - dir * hr * 0.5f, hy + hr * 1.55f, s * 0.1f, petMix(g.c4, 0.85f));
    }
}
// голова: уши, морда, глаза, нос, узор, украшения
static void petHead(float hx, float hy, float s, float dir, float look, bool closed, bool happy) {
    const PetCfg& g = gPetCfg;
    RGB8 c = g.c1, d = g.c2;
    float hr = s * (g.face == 3 ? 0.62f : g.face == 2 ? 0.5f : 0.56f);
    petEarsBack(hx, hy, hr, s, dir, c);
    pDisc(hx, hy, hr, c);
    RGB8 light = g.pattern == 4 ? d : petMix(c, 1.18f);
    if (g.pattern == 1) for (int k = -1; k <= 1; ++k) pLine(hx + k * s * 0.14f, hy - hr * 0.93f, hx + k * s * 0.12f, hy - hr * 0.54f, d, 0.9f);
    if (g.pattern == 2) pDisc(hx - dir * hr * 0.35f, hy - hr * 0.35f, hr * 0.28f, d);
    // морда
    float nx = hx + dir * s * 0.18f, ny = hy + s * 0.16f, nr = s * 0.07f;
    RGB8 nc = kPink;
    float eyeX = hx + dir * s * 0.12f;
    if (g.face == 1) {
        pEll(hx + dir * hr * 0.72f, hy + hr * 0.32f, hr * 0.55f, hr * 0.38f, light);
        nx = hx + dir * hr * 1.18f; ny = hy + hr * 0.2f; nr = s * 0.11f; nc = kNose;
        eyeX = hx + dir * s * 0.04f;
        if (happy) pEll(hx + dir * hr * 0.85f, hy + hr * 0.72f, hr * 0.14f, hr * 0.2f, RGB8{230, 100, 120});
    } else if (g.face == 2) {
        float tx[3] = {hx + dir * hr * 0.2f, hx + dir * hr * 1.42f, hx + dir * hr * 0.2f};
        float ty[3] = {hy - hr * 0.1f, hy + hr * 0.32f, hy + hr * 0.7f};
        pPoly(tx, ty, 3, c);
        float wx[3] = {hx - dir * hr * 0.2f, hx + dir * hr * 1.3f, hx + dir * hr * 0.1f};
        float wy[3] = {hy + hr * 0.35f, hy + hr * 0.4f, hy + hr * 0.85f};
        pPoly(wx, wy, 3, g.pattern == 4 ? d : kWhite);
        nx = hx + dir * hr * 1.38f; ny = hy + hr * 0.3f; nr = s * 0.08f; nc = kNose;
        eyeX = hx + dir * s * 0.06f;
    } else if (g.face == 3) {
        pDisc(hx + dir * hr * 0.32f, hy + hr * 0.34f, hr * 0.4f, light);
        nx = hx + dir * hr * 0.48f; ny = hy + hr * 0.18f; nr = s * 0.09f; nc = kNose;
    } else if (g.pattern == 4) {
        pEll(hx + dir * s * 0.12f, hy + s * 0.2f, hr * 0.55f, hr * 0.38f, d);
    }
    // глаза
    float ex = eyeX + look * s * 0.06f;
    for (int sd = -1; sd <= 1; sd += 2) {
        float x = ex + sd * s * 0.22f, y = hy - s * 0.06f;
        if (closed) { pLine(x - s * 0.1f, y, x + s * 0.1f, y + s * 0.03f, RGB8{40, 30, 30}); continue; }
        if (g.eyes == 3) { pDisc(x, y, s * 0.065f, RGB8{25, 22, 26}); continue; }
        float er = g.eyes == 1 ? s * 0.16f : s * 0.11f;
        pDisc(x, y, er, g.c3);
        pDisc(x + er * 0.3f, y - er * 0.35f, er * (g.eyes == 1 ? 0.42f : 0.32f), kWhite, 0.9f);
        if (g.eyes == 2) pEll(x, y - er * 0.55f, er * 1.25f, er * 0.62f, c);   // сонные веки
    }
    pDisc(nx, ny, nr, nc);
    if (g.face == 0)   // усы
        for (int sd = -1; sd <= 1; sd += 2)
            for (int k = 0; k < 2; ++k)
                pLine(hx + sd * s * 0.25f, hy + s * 0.2f + k * s * 0.08f, hx + sd * s * 0.75f, hy + s * 0.12f + k * s * 0.18f, kWhite, 0.55f);
    petEarsFront(hx, hy, hr, dir, c);
    petHeadAcc(hx, hy, hr, dir);
}
// хвост от основания (bx, by) к концу (ex, ey)
static void petTail(float bx, float by, float ex, float ey, float s, float dir) {
    const PetCfg& g = gPetCfg;
    RGB8 dk = g.pattern == 1 ? g.c2 : petMix(g.c1, 0.82f);
    if (g.tail == 0) pThick(bx, by, ex, ey, s * 0.16f, dk);
    else if (g.tail == 1) {
        for (int i = 0; i <= 8; ++i) {
            float t = i / 8.0f, r = s * (0.16f + 0.26f * std::sin(t * PI * 0.85f));
            float x = bx + (ex - bx) * t, y = by + (ey - by) * t - std::sin(t * PI) * s * 0.18f;
            pDisc(x, y, r, i >= 7 ? (g.pattern == 4 ? g.c2 : kWhite) : g.c1);
        }
    } else if (g.tail == 2) pDisc(bx - dir * s * 0.1f, by - s * 0.05f, s * 0.26f, petMix(g.pattern == 4 ? g.c2 : g.c1, 1.1f));
    else if (g.tail == 3) {
        float cx = bx - dir * s * 0.05f, cy = by - s * 0.42f, r = s * 0.34f;
        float px = bx, py = by;
        for (int i = 1; i <= 14; ++i) {
            float a = PI * 0.5f + dir * (PI * 1.75f * i / 14);
            float x = cx + std::cos(a) * r, y = cy + std::sin(a) * r;
            pThick(px, py, x, y, s * 0.15f, g.c1);
            px = x; py = y;
        }
    }
}
// узор на туловище: эллипс (x, y, rx, ry)
static void petBodyPattern(float x, float y, float rx, float ry, float dir) {
    const PetCfg& g = gPetCfg;
    if (g.pattern == 1) for (int k = -2; k <= 2; ++k) pLine(x + k * rx * 0.26f, y - ry * 0.95f, x + k * rx * 0.29f, y - ry * 0.25f, g.c2, 0.85f);
    else if (g.pattern == 2) {
        static const float sp[4][3] = {{-0.45f, -0.25f, 0.3f}, {0.22f, -0.4f, 0.24f}, {0.05f, 0.28f, 0.22f}, {0.55f, 0.08f, 0.2f}};
        for (auto& q : sp) pDisc(x + dir * q[0] * rx, y + q[1] * ry, q[2] * std::min(rx, ry), g.c2);
    } else if (g.pattern == 4) pEll(x + dir * rx * 0.12f, y + ry * 0.38f, rx * 0.66f, ry * 0.42f, g.c2);
}
static void drawBeast() {
    const PetT& p = gPet;
    const PetCfg& g = gPetCfg;
    RGB8 c = g.c1;
    RGB8 farC = petMix(c, 0.8f);
    RGB8 paw = g.pattern == 3 ? g.c2 : c;
    float s = 15 * S * petScale(), X = p.x - gVX, Y = p.y - gVY;
    float dir = (float)p.dir;
    bool purr = p.love > 0.6f;
    float brx = kBodyRx[g.body] * s, bry = kBodyRy[g.body] * s, leg = kLeg[g.body];
    auto fluff = [&](float x, float y, float rx, float ry) {   // пушистая шерсть по краю
        if (g.body != 1) return;
        for (int i = 0; i < 14; ++i) { float a = PI + PI * i / 13.0f; pDisc(x + std::cos(a) * rx * 0.95f, y + std::sin(a) * ry * 0.95f, s * 0.13f, c); }
    };
    if (p.state == PS_SLEEP) {
        float br = 1 + 0.04f * std::sin(p.anim * 2.2f);
        float rx = brx, ry = bry * br, cy = Y - ry * 0.92f;
        if (g.tail == 0 || g.tail == 1) petTail(X - dir * rx * 0.85f, Y - s * 0.2f, X + dir * rx * 0.5f, Y - s * 0.1f, s, dir);
        else if (g.tail == 2) pDisc(X - dir * rx * 0.95f, cy, s * 0.24f, petMix(c, 1.1f));
        fluff(X, cy, rx, ry);
        pEll(X, cy, rx, ry, c);
        petBodyPattern(X, cy, rx, ry, dir);
        float hx = X + dir * rx * 0.68f, hy = Y - s * 0.55f;
        petHead(hx, hy, s * 0.86f, dir, 0, true, false);
        return;
    }
    if (p.state == PS_SIT || purr) {
        float tail = std::sin(p.anim * (purr ? 1.0f : 2.4f)) * 0.5f;
        float rx = s * 0.62f * kBodyRx[g.body], ry = s * 0.86f * (0.6f + 0.4f * kBodyRy[g.body] / 0.55f);
        float cx = X - dir * s * 0.15f, cy = Y - ry * 0.99f;
        float tx = X - dir * rx * 0.9f, ty = Y - s * 0.12f;
        petTail(tx, ty, tx - dir * s * 0.9f, ty - s * (0.2f + 0.5f * tail), s, dir);
        fluff(cx, cy, rx, ry);
        pEll(cx, cy, rx, ry, c);
        if (g.pattern == 1) for (int k = -1; k <= 1; ++k) pLine(cx - dir * rx * 0.35f + k * rx * 0.25f, cy - ry * 0.7f + std::abs(k) * ry * 0.1f, cx - dir * rx * 0.6f + k * rx * 0.25f, cy - ry * 0.2f, g.c2, 0.85f);
        if (g.pattern == 2) { pDisc(cx - dir * rx * 0.45f, cy - ry * 0.2f, rx * 0.28f, g.c2); pDisc(cx - dir * rx * 0.2f, cy + ry * 0.45f, rx * 0.22f, g.c2); }
        pEll(X + dir * s * 0.2f, Y - ry * 0.87f, rx * 0.5f, ry * 0.7f, g.pattern == 4 ? g.c2 : petMix(c, 1.08f), 0.92f);
        float legTop = Y - ry * 0.6f;
        pThick(X + dir * s * 0.12f, legTop, X + dir * s * 0.12f, Y - s * 0.05f, s * 0.14f, c);
        pThick(X + dir * s * 0.42f, legTop, X + dir * s * 0.42f, Y - s * 0.05f, s * 0.14f, c);
        if (g.pattern == 3) { pDisc(X + dir * s * 0.12f, Y - s * 0.08f, s * 0.15f, paw); pDisc(X + dir * s * 0.42f, Y - s * 0.08f, s * 0.15f, paw); }
        float hx = X + dir * s * 0.25f, hy = Y - 2 * ry - s * 0.1f;
        petHead(hx, hy, s, dir, p.look, purr && g.face != 1, purr);
        petNeckAcc(hx, hy, s * (g.face == 3 ? 0.62f : g.face == 2 ? 0.5f : 0.56f), s, dir);
        return;
    }
    // идёт или бежит
    float run = p.state == PS_CHASE ? 1.6f : 1.0f;
    float ph = p.anim * 9 * run;
    float bob = std::fabs(std::sin(ph)) * s * 0.06f;
    float legLen = s * 0.61f * leg;
    float by = Y - s * 0.06f - legLen - s * 0.25f - bob;
    float tail = std::sin(p.anim * 3) * 0.3f;
    petTail(X - dir * brx * 0.88f, by - s * 0.15f, X - dir * (brx + s * 0.5f), by - s * (0.95f + tail), s, dir);
    for (int k = 0; k < 4; ++k) {   // лапы
        float lx = X + dir * (k < 2 ? brx * 0.6f : -brx * 0.6f) + (k & 1 ? s * 0.18f : -s * 0.18f) * dir;
        float sw = std::sin(ph + (k & 1 ? PI : 0) + (k < 2 ? 0 : PI * 0.5f)) * s * 0.28f * run * leg;
        pThick(lx, by + s * 0.25f, lx + sw * dir, Y - s * 0.06f, s * 0.13f, (k & 1) ? c : farC);
        if (g.pattern == 3) pDisc(lx + sw * dir, Y - s * 0.08f, s * 0.14f, (k & 1) ? paw : petMix(paw, 0.88f));
    }
    fluff(X, by, brx, bry);
    pEll(X, by, brx, bry, c);
    petBodyPattern(X, by, brx, bry, dir);
    float hx = X + dir * brx, hy = by - bry;
    petHead(hx, hy, s, dir, p.look, false, p.state == PS_CHASE);
    float hr = s * (g.face == 3 ? 0.62f : g.face == 2 ? 0.5f : 0.56f);
    petNeckAcc(hx - dir * hr * 0.35f, hy - hr * 0.12f, hr, s, dir);   // на ходу шея — позади и выше подбородка
}
static void drawBird() {
    const PetT& p = gPet;
    const PetCfg& g = gPetCfg;
    float s = 9 * S * petScale();
    float X = p.x - gVX, Y = p.y - gVY;
    float dir = (float)p.dir;
    bool fly = p.state == PS_FLYIN || p.state == PS_JUMP || p.state == PS_AWAY;
    if (p.state == PS_AWAY && (p.x < gVX - 40 * S || p.x > gVX + gW + 40 * S || p.y < gVY - 40 * S)) return;
    float hop = (p.state == PS_WALK) ? std::fabs(std::sin(std::fmod(p.anim, 0.45f) / 0.45f * PI)) * s * 0.9f : 0;
    float by = Y - s * 1.05f - hop;
    if (!fly) {   // лапки
        pLine(X - s * 0.2f, by + s * 0.8f, X - s * 0.25f, Y - hop, RGB8{60, 50, 50});
        pLine(X + s * 0.2f, by + s * 0.8f, X + s * 0.25f, Y - hop, RGB8{60, 50, 50});
    }
    float peck = (p.state == PS_SIT) ? std::max(0.0f, std::sin(p.anim * 3.0f)) * s * 0.35f : 0;
    float tx[3] = {X - dir * s * 0.8f, X - dir * s * 1.9f, X - dir * s * 1.7f};
    float ty[3] = {by - s * 0.1f, by - s * 0.5f, by + s * 0.15f};
    pPoly(tx, ty, 3, petMix(g.c1, 0.4f));
    pDisc(X, by, s, g.c1);                                                    // спинка
    pEll(X + dir * s * 0.2f, by + s * 0.25f, s * 0.75f, s * 0.68f, g.c2);       // грудка
    RGB8 wing = petMix(g.c1, 0.6f);
    if (fly) {   // крылья машут
        float w = std::sin(p.anim * 22) * 0.9f;
        for (int sd = -1; sd <= 1; sd += 2)
            pLeaf(X - dir * s * 0.1f, by - s * 0.3f - s * 0.6f * w * sd * 0.5f, s * 1.8f, s * 0.7f, -PI / 2 + sd * (0.6f + w * 0.6f), wing);
    } else pEll(X - dir * s * 0.25f, by - s * 0.05f, s * 0.6f, s * 0.4f, wing);
    float hx = X + dir * s * 0.75f, hy = by - s * 0.7f + peck;
    pDisc(hx, hy, s * 0.55f, g.c3);                                           // шапочка
    pDisc(hx + dir * s * 0.1f, hy + s * 0.22f, s * 0.35f, g.c2);
    pDisc(hx + dir * s * 0.12f, hy - s * 0.1f, s * 0.09f, kWhite);
    float bx[3] = {hx + dir * s * 0.45f, hx + dir * s * 0.8f, hx + dir * s * 0.45f};
    float byy[3] = {hy - s * 0.08f, hy + s * 0.05f, hy + s * 0.18f};
    pPoly(bx, byy, 3, RGB8{40, 40, 40});
    if (g.acc == 1 || g.acc == 3 || g.acc == 5) petHeadAcc(hx, hy, s * 0.55f, dir);
}
static void drawPet() {
    for (auto& h : gPetHearts) {
        float a = clampf(1.6f - h.age, 0, 1) * clampf(h.age * 4, 0, 1);
        if (h.z) petZ(h.x - gVX, h.y - gVY, (5 + h.age * 4) * S, a);
        else drawHeart(h.x - gVX, h.y - gVY, 4.5f * S, 255, 90, 120, a, 0);
    }
    if (!gPet.alive || !petActive()) return;
    if (petBird()) drawBird(); else drawBeast();
}
