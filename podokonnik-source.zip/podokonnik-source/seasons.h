// Сезоны «Сугроба»: весна (сакура, трава с цветами, бабочки), лето (пух, луг,
// светлячки, газонокосилка), осень (листопад, листва на окнах, птицы, дождь).
// Подключается внутрь sugrob.cpp — использует его структуры и функции рисования.
#pragma once

enum { SEA_WINTER = 0, SEA_SPRING = 1, SEA_SUMMER = 2, SEA_AUTUMN = 3 };
enum { T_SNOW = 0, T_CLUMP = 1, T_LEAF = 2, T_PETAL = 3, T_FLUFF = 4, T_RAIN = 5, T_DROP = 6, T_BIT = 7 };

struct RGB8 { uint8_t r, g, b; };
static const RGB8 kPal[] = {
    {214, 72, 30}, {236, 122, 32}, {242, 178, 40}, {166, 92, 42}, {200, 140, 44},   // 0-4 осенние листья
    {255, 183, 197}, {255, 207, 218}, {248, 160, 186}, {255, 232, 238},             // 5-8 сакура
    {250, 250, 245},                                                                // 9 пух
    {252, 252, 252}, {255, 150, 190}, {255, 214, 52}, {222, 42, 44}, {96, 126, 236},// 10-14 цветы
    {255, 140, 40}, {176, 104, 226},                                                // 15-16 цветы
    {96, 168, 64}, {70, 140, 52},                                                   // 17-18 зелень (обрезки)
};

static inline uint32_t hash2(int x, int y) {
    uint32_t h = (uint32_t)x * 374761393u + (uint32_t)y * 668265263u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}

static float intensityK() { return clampf(gIntensityPct / 50.0f, 0.0f, 2.0f); }
static float baseWind() {
    float w = (float)((std::sin(gTime * 0.07) * 12 + std::sin(gTime * 0.023 + 1.0) * 9) * S);
    w += (gWindPct - 50) * 1.4f * S;
    w += weatherWindX();   // ветер за окном, если включена погода
    if (gSeason == SEA_WINTER && gIntensityPct > 75) w += (float)(28 + std::sin(gTime * 0.3) * 18) * S;
    if (gSeason == SEA_AUTUMN) w += (float)(std::max(0.0, std::sin(gTime * 0.11)) * 35) * S;   // порывы
    return w;
}

// ---------------------------------------------------------------- рисование примитивов
// тонкая линия со сглаживанием (быстрее drawLine)
static void thinLine(float x0, float y0, float x1, float y1, float R, float G, float B, float a) {
    float dx = x1 - x0, dy = y1 - y0;
    float len = std::max(std::fabs(dx), std::fabs(dy));
    int n = std::max(1, (int)std::ceil(len));
    for (int i = 0; i <= n; ++i) {
        float t = (float)i / n;
        float x = x0 + dx * t, y = y0 + dy * t;
        if (std::fabs(dx) < std::fabs(dy)) {
            int X = (int)std::floor(x); float f = x - X;
            blendPx(X, (int)y, R, G, B, a * (1 - f));
            blendPx(X + 1, (int)y, R, G, B, a * f);
        } else {
            int Y = (int)std::floor(y); float f = y - Y;
            blendPx((int)x, Y, R, G, B, a * (1 - f));
            blendPx((int)x, Y + 1, R, G, B, a * f);
        }
    }
}

// лист/лепесток: вытянутая форма с острыми концами и прожилкой
static void drawLeaf(float cx, float cy, float len, float wid, float ang,
                     float R, float G, float B, float alpha, bool vein) {
    float L = len * 0.5f, W = std::max(0.35f, wid * 0.5f);
    float rad = L + 1.5f;
    int x0 = (int)std::floor(cx - rad), x1 = (int)std::ceil(cx + rad);
    int y0 = (int)std::floor(cy - rad), y1 = (int)std::ceil(cy + rad);
    if (x1 < 0 || y1 < 0 || x0 >= gW || y0 >= gH) return;
    float ca = std::cos(ang), sa = std::sin(ang);
    for (int Y = std::max(y0, 0); Y <= std::min(y1, gH - 1); ++Y) {
        float dy = Y + 0.5f - cy;
        for (int X = std::max(x0, 0); X <= std::min(x1, gW - 1); ++X) {
            float dx = X + 0.5f - cx;
            float u = dx * ca + dy * sa, v = -dx * sa + dy * ca;
            float t = u / L;
            if (t <= -1.05f || t >= 1.05f) continue;
            float tt = clampf(t, -1, 1);
            float prof = W * std::sqrt(std::max(0.0f, 1 - tt * tt)) * (1.0f - 0.22f * tt);
            float edge = prof - std::fabs(v);
            float cov = clampf(edge + 0.5f, 0, 1) * clampf((L - std::fabs(u)) + 0.5f, 0, 1);
            if (cov <= 0) continue;
            float l = 0.82f + 0.18f * clampf(edge / std::max(W, 0.5f), 0, 1);
            if (vein && prof > 1.2f && std::fabs(v) < 0.45f) l *= 0.78f;
            blendPx(X, Y, R * l, G * l, B * l, alpha * cov);
        }
    }
}

// эллипс по осям (крылья бабочек)
static void drawEllipse(float cx, float cy, float rx, float ry, float R, float G, float B, float a) {
    rx = std::max(rx, 0.3f); ry = std::max(ry, 0.3f);
    int x0 = (int)std::floor(cx - rx - 1), x1 = (int)std::ceil(cx + rx + 1);
    int y0 = (int)std::floor(cy - ry - 1), y1 = (int)std::ceil(cy + ry + 1);
    for (int Y = std::max(y0, 0); Y <= std::min(y1, gH - 1); ++Y)
        for (int X = std::max(x0, 0); X <= std::min(x1, gW - 1); ++X) {
            float nx = (X + 0.5f - cx) / rx, ny = (Y + 0.5f - cy) / ry;
            float d = std::sqrt(nx * nx + ny * ny);
            float cov = clampf((1 - d) * std::min(rx, ry) + 0.5f, 0, 1);
            if (cov > 0) blendPx(X, Y, R, G, B, a * cov);
        }
}

// ---------------------------------------------------------------- погода
static bool gRaining = false;
static float gRainTimer = 60;
static float gRainLevel = 0;   // 0..1 плавное начало/конец

static int weatherRainState();   // погода за окном: -1 — не знаем, 0 — сухо, 1 — дождь
static void updateWeather(float dt) {
    bool allow = gSeason != SEA_WINTER && gSnowOn;
    if (!allow || gRainMode == 0) gRaining = false;
    else if (gRainMode == 2) gRaining = true;
    else if (weatherRainState() >= 0) gRaining = weatherRainState() == 1;   // как на улице
    else {
        gRainTimer -= dt;
        if (gRainTimer <= 0) {
            gRaining = !gRaining;
            if (gRaining) gRainTimer = frange(40, 90);
            else gRainTimer = gSeason == SEA_SUMMER ? frange(300, 600) : frange(120, 300);
        }
    }
    gRainLevel = clampf(gRainLevel + (gRaining ? dt / 6 : -dt / 6), 0, 1);
}

// ---------------------------------------------------------------- появление частиц
static P makeP(int type) { P p{}; p.type = (uint8_t)type; p.a = 1; return p; }

static void seasonSpawn(float dt) {
    static float acc = 0, racc = 0;
    if (!gSnowOn) { acc = 0; racc = 0; return; }
    float k = intensityK();
    float width = gW / 1000.0f / S;
    float rate = 0;
    if (gSeason == SEA_AUTUMN) rate = 7.0f * k * width;
    else if (gSeason == SEA_SPRING) rate = 16.0f * k * width;
    else if (gSeason == SEA_SUMMER) rate = 0.8f * k * width;
    acc += rate * dt;
    while (acc >= 1 && gP.size() < kMaxParticles) {
        acc -= 1;
        P p;
        float z = frand();
        if (gSeason == SEA_AUTUMN) {
            p = makeP(T_LEAF);
            p.r = (3.4f + 3.0f * z) * S;
            p.col = (uint8_t)(xr() % 5);
            p.vy = (30 + 30 * z) * S;
            p.amp = frange(25, 55) * S;
            p.freq = frange(0.35f, 0.7f);
        } else if (gSeason == SEA_SPRING) {
            p = makeP(T_PETAL);
            p.r = (1.6f + 1.3f * z) * S;
            p.col = (uint8_t)(5 + xr() % 4);
            p.vy = (20 + 22 * z) * S;
            p.amp = frange(12, 30) * S;
            p.freq = frange(0.5f, 1.1f);
        } else {
            p = makeP(T_FLUFF);
            p.r = (2.4f + 1.5f * z) * S;
            p.col = 9;
            p.vy = (6 + 8 * z) * S;
            p.amp = frange(10, 25) * S;
            p.freq = frange(0.15f, 0.35f);
            p.life = frange(25, 45);
        }
        p.z = z;
        p.a = 0.75f + 0.25f * z;
        p.x = gVX + frange(-200 * S, gW + 200 * S);
        p.y = gVY - p.r * 3 - frange(0, 30);
        p.ph = frange(0, 6.283f);
        p.rot = frange(0, 6.283f);
        p.vrot = frange(-2.5f, 2.5f);
        gP.push_back(p);
    }
    // дождь
    racc += 160.0f * width * gRainLevel * std::max(0.4f, k) * dt;
    while (racc >= 1 && gP.size() < kMaxParticles) {
        racc -= 1;
        P p = makeP(T_RAIN);
        p.x = gVX + frange(-200 * S, gW + 200 * S);
        p.y = gVY - frange(0, 40) * S;
        p.vy = frange(780, 980) * S;
        p.z = frand();
        p.a = 0.22f + 0.2f * p.z;
        gP.push_back(p);
    }
}

// ---------------------------------------------------------------- приземление
static void capAddDecor(Cap& c, int kind, float x, float ang, float size, int col, float life) {
    Decor d;
    d.rx = x - c.r.left; d.ang = ang; d.size = size; d.kind = (uint8_t)kind; d.col = (uint8_t)col;
    d.age = 0; d.life = life;
    size_t maxN = (size_t)std::max(8.0f, (c.r.right - c.r.left) / (4.5f * S));
    if (c.decor.size() >= maxN) c.decor.erase(c.decor.begin());
    c.decor.push_back(d);
}

static bool seasonCollide(P& p, float yPrev) {
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->noSnow) continue;
        const RECT& r = c->r;
        if (p.x < r.left || p.x >= r.right) continue;
        int j = (int)((p.x - r.left) / CW);
        if (j < 0 || j >= c->n() || !c->vis[j]) continue;
        float surf = c->edgeY(j) - (gSeason == SEA_AUTUMN ? c->d[j] : c->d[j] * 0.5f);
        if (p.type == T_RAIN) surf = c->edgeY(j) - c->d[j] * 0.6f;
        float b0 = yPrev, b1 = p.y;
        if (!(b0 <= surf && b1 > surf)) continue;
        switch (p.type) {
        case T_LEAF:
            deposit(*c, j, 0.55f * S * frange(0.7f, 1.3f));
            capAddDecor(*c, 0, p.x, p.rot, p.r, p.col, 1e9f);
            return true;
        case T_PETAL:
            if (frand() < 0.6f) capAddDecor(*c, 1, p.x, p.rot, p.r, p.col, frange(25, 45));
            return true;
        case T_FLUFF:
            if (frand() < 0.4f) { capAddDecor(*c, 2, p.x, p.rot, p.r, p.col, frange(8, 16)); return true; }
            return false;   // большинство пушинок пролетает дальше
        case T_RAIN:
            for (int k = 0; k < 2; ++k) {
                P d = makeP(T_DROP);
                d.x = p.x; d.y = surf - 1; d.vx = frange(-60, 60) * S; d.vy = frange(-140, -60) * S;
                d.life = 0.45f; d.a = 0.5f;
                if (gP.size() < kMaxParticles) gP.push_back(d);
            }
            return true;
        }
        return false;
    }
    return false;
}

// обновление «сезонной» частицы; true — удалить
static bool seasonUpdateP(P& p, float dt, float wind) {
    float yPrev = p.y;
    switch (p.type) {
    case T_LEAF: case T_PETAL: {
        p.ph += p.freq * dt * 6.283f;
        float vt = p.vy;                                   // «скорость падения»
        p.vx += (0 - p.vx) * 1.5f * dt;                    // затухание пинка
        float sway = std::cos(p.ph) * p.amp * p.freq * 2.2f;
        p.x += (p.vx + wind * (p.type == T_LEAF ? 1.1f : 0.9f) + sway) * dt;
        float fall = vt * (0.75f + 0.45f * std::fabs(std::sin(p.ph)));
        p.life += dt;
        if (p.life < 0) {                                  // подброшенный лист: вверх, потом вниз
            p.y += p.vrot * dt;                            // vrot тут временно — вертикальная скорость
            p.vrot += 500 * S * dt;
            if (p.vrot > 0) { p.life = 0; p.vrot = frange(-2.5f, 2.5f); }
        } else p.y += fall * dt;
        p.rot += (p.type == T_LEAF ? 1.2f : 2.4f) * std::sin(p.ph * 0.5f) * dt + 0.6f * dt;
        break;
    }
    case T_FLUFF:
        p.ph += p.freq * dt * 6.283f;
        p.x += (wind * 1.4f + std::cos(p.ph) * p.amp * 0.6f) * dt;
        p.y += (p.vy * (0.6f + 0.8f * std::sin(p.ph * 0.37f + p.z * 5)) - 4 * S * std::max(0.0f, std::sin(p.ph * 0.13f))) * dt;
        p.life -= dt;
        if (p.life <= 0) return true;
        break;
    case T_RAIN:
        p.x += wind * 1.6f * dt;
        p.y += p.vy * dt;
        break;
    case T_DROP: case T_BIT:
        p.vy += 900 * S * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.vrot * dt;
        p.life -= dt;
        if (p.life <= 0) return true;
        return p.y > gVY + gH;
    }
    if (p.y - p.r > gVY + gH || p.x < gVX - 400 * S || p.x > gVX + gW + 400 * S) return true;
    if (anyCaps() && p.life >= 0 && seasonCollide(p, yPrev)) return true;
    return false;
}

static void seasonDrawP(const P& p) {
    float x = p.x - gVX, y = p.y - gVY;
    const RGB8& c = kPal[p.col % (sizeof(kPal) / sizeof(kPal[0]))];
    switch (p.type) {
    case T_LEAF: {
        float flip = 0.35f + 0.65f * std::fabs(std::cos(p.ph * 0.5f + p.z * 3));
        drawLeaf(x, y, p.r * 2.3f, p.r * 1.25f * flip, p.rot, c.r, c.g, c.b, p.a, true);
        break;
    }
    case T_PETAL: {
        float flip = 0.3f + 0.7f * std::fabs(std::cos(p.ph * 0.8f + p.z * 3));
        drawLeaf(x, y, p.r * 1.7f, p.r * 1.25f * flip, p.rot, c.r, c.g, c.b, p.a, false);
        break;
    }
    case T_FLUFF: {
        float a = p.a * clampf(p.life / 3.0f, 0, 1);
        for (int i = 0; i < 8; ++i) {
            float ang = -PI * 0.5f + (i - 3.5f) * 0.32f + std::sin(p.ph) * 0.1f;
            float ex = x + std::cos(ang) * p.r * 1.6f, ey = y + std::sin(ang) * p.r * 1.6f;
            thinLine(x, y, ex, ey, 245, 245, 240, a * 0.55f);
            drawDisc(ex, ey, 0.55f * S, 250, 250, 248, a * 0.7f, 1, 0);
        }
        thinLine(x, y, x, y + p.r * 1.3f, 200, 190, 160, a * 0.8f);
        drawDisc(x, y + p.r * 1.3f, 0.7f * S, 150, 120, 80, a, 1, 0);
        break;
    }
    case T_RAIN: {
        float w = baseWind() * 1.6f;
        float len = 12 * S;
        float nx = w / p.vy, n = std::sqrt(1 + nx * nx);
        thinLine(x, y, x - nx / n * len, y - len / n, 200, 215, 238, p.a);
        break;
    }
    case T_DROP:
        drawDisc(x, y, 0.8f * S, 210, 225, 245, p.a * clampf(p.life / 0.45f, 0, 1), 1, 0);
        break;
    case T_BIT: {
        float ca = std::cos(p.rot) * 1.6f * S, sa = std::sin(p.rot) * 1.6f * S;
        thinLine(x - ca, y - sa, x + ca, y + sa, c.r, c.g, c.b, 0.9f);
        break;
    }
    }
}

// ---------------------------------------------------------------- трава, цветы, листва на окнах
static void capGrow(Cap& c, float dt) {
    int n = c.n();
    float md = maxDepth(c);
    bool grass = gSeason == SEA_SPRING || gSeason == SEA_SUMMER;
    for (auto& d : c.decor) d.age += dt;
    c.decor.erase(std::remove_if(c.decor.begin(), c.decor.end(), [](const Decor& d) { return d.age > d.life; }), c.decor.end());
    if (grass) {
        if (gSnowOn) {
            for (int j = 0; j < n; ++j) {
                if (!c.vis[j]) continue;
                float target = md * (0.55f + 0.45f * ((hash2(j + c.r.left / CW, 7) & 255) / 255.0f));
                c.d[j] += (target - c.d[j]) * std::min(1.0f, dt / 35.0f);
            }
            // цветы распускаются, когда трава подросла
            float sum = 0; int v = 0;
            for (int j = 0; j < n; ++j) if (c.vis[j]) { sum += c.d[j]; ++v; }
            size_t maxF = (size_t)(v * CW / (48 * S));
            if (v && sum / v > 0.55f * md && c.flowers.size() < maxF) {
                c.flowerT += dt;
                if (c.flowerT > c.manDelay) {
                    c.flowerT = 0;
                    c.manDelay = frange(3, 10);
                    int j = (int)(frand() * n);
                    if (c.vis[j]) {
                        Flower f;
                        f.rx = (j + 0.5f) * CW;
                        if (gSeason == SEA_SPRING) { static const int sc[] = {10, 11, 12, 13, 16}; f.col = (uint8_t)sc[xr() % 5]; f.kind = (uint8_t)(xr() % 2); }
                        else { static const int uc[] = {10, 12, 13, 14, 15}; f.col = (uint8_t)uc[xr() % 5]; f.kind = (uint8_t)(2 + xr() % 2); if (f.kind == 2) f.col = 12; }
                        f.grow = 0;
                        c.flowers.push_back(f);
                    }
                }
            }
            for (auto& f : c.flowers) f.grow = std::min(1.0f, f.grow + dt / 2.5f);
        } else {
            for (float& v : c.d) v = std::max(0.0f, v - 0.6f * S * dt);
            for (auto& f : c.flowers) f.grow -= dt / 3.0f;
            c.flowers.erase(std::remove_if(c.flowers.begin(), c.flowers.end(), [](const Flower& f) { return f.grow <= 0; }), c.flowers.end());
        }
    } else if (gSeason == SEA_AUTUMN && !gSnowOn) {
        for (float& v : c.d) v = std::max(0.0f, v - 0.5f * S * dt);
        if (!c.decor.empty() && frand() < dt * 3) c.decor.erase(c.decor.begin());
    }
}

static void drawLitterCap(Cap& c) {
    int n = c.n();
    int left = c.r.left - gVX;
    for (int j = 0; j < n; ++j) {
        if (!c.vis[j]) continue;
        float d0 = c.smoothD(j);
        float d1 = (j + 1 < n && c.vis[j + 1]) ? c.smoothD(j + 1) : d0;
        if (d0 < 0.3f && d1 < 0.3f) continue;
        float e0 = c.edgeY(j) - gVY, e1 = (j + 1 < n) ? c.edgeY(j + 1) - gVY : e0;
        for (int px = 0; px < CW; ++px) {
            int X = left + j * CW + px;
            if (X < 0 || X >= gW) continue;
            float t = (px + 0.5f) / CW;
            float h = d0 * (1 - t) + d1 * t;
            if (h < 0.3f) continue;
            h *= 0.85f + 0.3f * ((hash2((X + gVX) / 3, 1) & 255) / 255.0f);   // неровный верх
            float edge = e0 * (1 - t) + e1 * t;
            float yTop = edge - h;
            int ys = (int)std::floor(yTop), ye = (int)std::ceil(edge);
            for (int Y = ys; Y < ye; ++Y) {
                float a = (Y == ys) ? 1 - (yTop - ys) : 1;
                const RGB8& cc = kPal[hash2((X + gVX) / 3, (Y + gVY) / 2) % 5];
                float dark = 0.62f + 0.38f * clampf((float)(ye - Y) / std::max(h, 1.0f), 0, 1);
                blendPx(X, Y, cc.r * dark, cc.g * dark, cc.b * dark, a);
            }
            if (h > 1 && ye >= 0 && ye < gH) blendPx(X, ye, 30, 20, 10, 0.15f);
        }
    }
    for (auto& d : c.decor) {
        int j = (int)(d.rx / CW);
        if (j < 0 || j >= n || !c.vis[j]) continue;
        const RGB8& cc = kPal[d.col % 5];
        drawLeaf(c.r.left + d.rx - gVX, c.surfY(j) - gVY - d.size * 0.3f, d.size * 2.3f, d.size * 1.25f, d.ang,
                 cc.r, cc.g, cc.b, 1.0f, true);
    }
}

static void drawFlower(float x, float y, const Flower& f, float sway) {
    float g = f.grow;
    const RGB8& c = kPal[f.col % (sizeof(kPal) / sizeof(kPal[0]))];
    float s = S * g;
    x += sway;
    switch (f.kind) {
    case 0: // ромашка
        for (int i = 0; i < 6; ++i) {
            float a = i * PI / 3 + 0.3f;
            drawDisc(x + std::cos(a) * 1.5f * s, y + std::sin(a) * 1.5f * s, 1.1f * s, c.r, c.g, c.b, 1, 1, 0);
        }
        drawDisc(x, y, 0.95f * s, 250, 200, 40, 1, 1, 0);
        break;
    case 1: // тюльпан
        drawEllipse(x, y, 1.7f * s, 2.2f * s, c.r * 0.85f, c.g * 0.85f, c.b * 0.85f, 1);
        drawEllipse(x - 0.9f * s, y - 0.6f * s, 0.9f * s, 1.9f * s, c.r, c.g, c.b, 1);
        drawEllipse(x + 0.9f * s, y - 0.6f * s, 0.9f * s, 1.9f * s, c.r, c.g, c.b, 1);
        break;
    case 2: // подсолнух
        for (int i = 0; i < 10; ++i) {
            float a = i * PI / 5;
            drawLeaf(x + std::cos(a) * 2.6f * s, y + std::sin(a) * 2.6f * s, 3.0f * s, 1.4f * s, a, 255, 205, 30, 1, false);
        }
        drawDisc(x, y, 1.9f * s, 110, 65, 25, 1, 1, 0.2f);
        break;
    default: // мак / василёк
        for (int i = 0; i < 5; ++i) {
            float a = i * 2 * PI / 5 - 0.2f;
            drawDisc(x + std::cos(a) * 1.3f * s, y + std::sin(a) * 1.3f * s, 1.35f * s, c.r, c.g, c.b, 1, 1, 0);
        }
        drawDisc(x, y, 0.75f * s, 40, 30, 40, 1, 1, 0);
        break;
    }
}

static void drawGrassCap(Cap& c) {
    int n = c.n();
    int left = c.r.left - gVX;
    bool summer = gSeason == SEA_SUMMER;
    float wind = baseWind();
    float t = (float)gTime;
    for (int j = 0; j < n; ++j) {
        if (!c.vis[j]) continue;
        float h = c.d[j];
        if (h < 0.4f) continue;
        float edge = c.edgeY(j) - gVY;
        uint32_t hs = hash2(j + c.r.left / CW, 3);
        float bh = h * (0.5f + 0.5f * ((hs & 255) / 255.0f));
        float bx = (float)(left + j * CW) + (hs >> 8 & 1);
        float sway = (std::sin(t * 1.6f + (bx + gVX) * 0.045f) * 0.22f + wind * 0.004f / S) * bh;
        // основание
        int ey = (int)std::floor(edge);
        blendPx((int)bx, ey - 1, 40, 90, 35, 0.9f);
        blendPx((int)bx + 1, ey - 1, 40, 90, 35, 0.9f);
        int steps = std::max(1, (int)std::ceil(bh));
        for (int k = 0; k < steps; ++k) {
            float tt = (float)k / steps;
            float x = bx + sway * tt * tt;
            float y = edge - 1 - k;
            float R = summer ? 70 + 90 * tt : 52 + 80 * tt;
            float G = summer ? 120 + 70 * tt : 130 + 80 * tt;
            float B = summer ? 40 + 20 * tt : 45 + 30 * tt;
            int X = (int)std::floor(x); float f = x - X;
            blendPx(X, (int)y, R, G, B, 1 - f);
            blendPx(X + 1, (int)y, R, G, B, f);
        }
    }
    // цветы
    for (auto& f : c.flowers) {
        int j = (int)(f.rx / CW);
        if (j < 0 || j >= n || !c.vis[j]) continue;
        float edge = c.edgeY(j) - gVY;
        float stem = c.d[j] + 3.5f * S * f.grow;
        float x = c.r.left + f.rx - gVX;
        float sway = std::sin(t * 1.6f + (x + gVX) * 0.045f) * 0.15f * stem;
        thinLine(x, edge - 1, x + sway, edge - stem, 50, 110, 40, 1);
        drawFlower(x, edge - stem, f, sway);
    }
    // лепестки/пух на траве
    for (auto& d : c.decor) {
        int j = (int)(d.rx / CW);
        if (j < 0 || j >= n || !c.vis[j]) continue;
        float fade = clampf((d.life - d.age) / 4.0f, 0, 1);
        const RGB8& cc = kPal[d.col % (sizeof(kPal) / sizeof(kPal[0]))];
        float x = c.r.left + d.rx - gVX, y = c.edgeY(j) - gVY - c.d[j] * 0.7f;
        if (d.kind == 2) drawDisc(x, y, d.size * 0.7f, 250, 250, 245, 0.8f * fade, 1.2f, 0);
        else drawLeaf(x, y, d.size * 1.7f, d.size * 1.25f, d.ang, cc.r, cc.g, cc.b, fade, false);
    }
}

// ---------------------------------------------------------------- живность
enum { CR_BUTTERFLY = 0, CR_FIREFLY = 1, CR_BIRD = 2 };
struct Critter {
    int type;
    float x, y, vx, vy, tx, ty, ph, t, size, alpha;
    int col;
    int state;          // бабочка: 0 летит, 1 сидит
    HWND capH;
    float relX;
    float slot;         // птица: место в клине
};
static std::vector<Critter> gCritters;
static float gBirdTimer = 40;

static bool firefliesTime() {
    if (gFireflyMode == 2) return true;
    if (gFireflyMode == 0) return false;
    SYSTEMTIME st;
    GetLocalTime(&st);
    return st.wHour >= 19 || st.wHour < 6;
}

static void pickButterflyTarget(Critter& c) {
    // иногда садимся на цветок или траву
    if (frand() < 0.45f && !gWins.empty()) {
        Cap* cap = gCapPtr[xr() % gWins.size()];
        if (cap && !cap->taskbar && !cap->flowers.empty()) {
            Flower& f = cap->flowers[xr() % cap->flowers.size()];
            int j = (int)(f.rx / CW);
            if (j >= 0 && j < cap->n() && cap->vis[j] && f.grow > 0.9f) {
                c.tx = cap->r.left + f.rx;
                c.ty = cap->edgeY(j) - cap->d[j] - 3.5f * S - 2 * S;
                c.capH = cap->h; c.relX = f.rx;
                c.state = 2;   // летит садиться
                return;
            }
        }
    }
    c.tx = gVX + frange(0.05f, 0.95f) * gW;
    c.ty = gVY + frange(0.08f, 0.75f) * gH;
    c.state = 0;
}

static void updateCritters(float dt, POINT cur) {
    bool butterflies = gCrittersOn && gSnowOn && (gSeason == SEA_SPRING || gSeason == SEA_SUMMER);
    bool flies = gSnowOn && gSeason == SEA_SUMMER && firefliesTime();
    int wantB = butterflies ? (gSeason == SEA_SUMMER ? 5 : 3) : 0;
    int wantF = flies ? (int)(14 + 10 * intensityK()) : 0;
    int nb = 0, nf = 0;
    for (auto& c : gCritters) { if (c.type == CR_BUTTERFLY) nb++; else if (c.type == CR_FIREFLY) nf++; }

    if (nb < wantB && frand() < dt * 0.5f) {
        Critter c{};
        c.type = CR_BUTTERFLY;
        bool leftSide = frand() < 0.5f;
        c.x = leftSide ? gVX - 20 * S : gVX + gW + 20 * S;
        c.y = gVY + frange(0.1f, 0.6f) * gH;
        c.size = frange(6.0f, 8.5f) * S;
        static const int cols[] = {0, 1, 2, 3};
        c.col = cols[xr() % 4];
        c.ph = frange(0, 6.28f);
        c.alpha = 1;
        pickButterflyTarget(c);
        gCritters.push_back(c);
    }
    while (nf < wantF) {
        Critter c{};
        c.type = CR_FIREFLY;
        c.x = gVX + frand() * gW;
        c.y = gVY + frange(0.2f, 0.95f) * gH;
        c.ph = frange(0, 6.28f);
        c.size = frange(0.9f, 1.4f) * S;
        c.t = frange(0, 10);
        c.alpha = 0;
        gCritters.push_back(c);
        nf++;
    }
    // птицы осенью — клин пролетает время от времени
    if (gCrittersOn && gSnowOn && gSeason == SEA_AUTUMN) {
        gBirdTimer -= dt;
        if (gBirdTimer <= 0) {
            gBirdTimer = frange(70, 160);
            int cnt = 5 + (int)(xr() % 5);
            int dir = frand() < 0.5f ? 1 : -1;
            float y0 = gVY + frange(0.08f, 0.3f) * gH;
            for (int i = 0; i < cnt; ++i) {
                Critter b{};
                b.type = CR_BIRD;
                int side = (i % 2) ? 1 : -1, rank = (i + 1) / 2;
                b.x = (dir > 0 ? gVX - 60 * S : gVX + gW + 60 * S) - dir * rank * 16 * S;
                b.y = y0 + side * rank * 9 * S;
                b.vx = dir * frange(105, 115) * S;
                b.size = frange(4.5f, 5.5f) * S;
                b.ph = frange(0, 6.28f);
                gCritters.push_back(b);
            }
        }
    }

    for (auto& c : gCritters) {
        c.t += dt;
        float dxm = c.x - cur.x, dym = c.y - cur.y;
        float dm = std::sqrt(dxm * dxm + dym * dym) + 0.01f;
        if (c.type == CR_BUTTERFLY) {
            if (c.state == 1) {   // сидит
                Cap* cap = findCap(c.capH);
                c.ph += dt * 2.5f;
                if (!cap || dm < 80 * S || c.t > c.ty) {
                    c.state = 0;
                    c.vy = -60 * S;
                    pickButterflyTarget(c);
                    if (c.state == 2) c.state = 0;
                } else {
                    int j = (int)(c.relX / CW);
                    if (j >= 0 && j < cap->n()) {
                        c.x = cap->r.left + c.relX;
                        c.y = cap->edgeY(j) - cap->d[j] - 3.5f * S - 2.5f * S;
                    }
                    continue;
                }
            }
            c.ph += dt * 16;
            float ax = (c.tx - c.x), ay = (c.ty - c.y);
            float dl = std::sqrt(ax * ax + ay * ay) + 0.01f;
            float sp = 55 * S;
            c.vx += (ax / dl * sp - c.vx) * 1.6f * dt + frange(-120, 120) * S * dt;
            c.vy += (ay / dl * sp - c.vy) * 1.6f * dt + frange(-160, 160) * S * dt + std::sin(c.ph * 0.35f) * 40 * S * dt;
            if (dm < 110 * S) {   // улетает от курсора
                c.vx += dxm / dm * 900 * S * dt;
                c.vy += dym / dm * 900 * S * dt;
                if (c.state == 2) c.state = 0;
            }
            c.x += c.vx * dt;
            c.y += c.vy * dt;
            if (c.state == 2 && dl < 4 * S) { c.state = 1; c.t = 0; c.ty = frange(4, 10); c.vx = c.vy = 0; }
            else if (dl < 10 * S || frand() < dt * 0.15f) pickButterflyTarget(c);
            if (!butterflies) c.tx = c.x < gVX + gW / 2 ? gVX - 100 * S : gVX + gW + 100 * S;
        } else if (c.type == CR_FIREFLY) {
            c.ph += dt;
            c.vx += frange(-50, 50) * S * dt;
            c.vy += frange(-50, 50) * S * dt;
            if (dm < 260 * S && dm > 25 * S) {   // тянутся к курсору
                c.vx -= dxm / dm * 30 * S * dt;
                c.vy -= dym / dm * 30 * S * dt;
            }
            c.vx *= (1 - 0.6f * dt); c.vy *= (1 - 0.6f * dt);
            c.x += c.vx * dt; c.y += c.vy * dt;
            if (c.y < gVY + gH * 0.15f) c.vy += 20 * S * dt;
            float target = flies ? 1.0f : 0.0f;
            c.alpha += (target - c.alpha) * std::min(1.0f, dt * 0.5f);
        } else {   // птица
            c.ph += dt * 9;
            c.x += c.vx * dt;
            c.y += std::sin(c.t * 0.8f + c.size) * 6 * S * dt;
        }
    }
    gCritters.erase(std::remove_if(gCritters.begin(), gCritters.end(), [&](const Critter& c) {
        bool out = c.x < gVX - 200 * S || c.x > gVX + gW + 200 * S || c.y < gVY - 200 * S || c.y > gVY + gH + 200 * S;
        if (c.type == CR_BUTTERFLY) return out && (!butterflies || c.t > 5);
        if (c.type == CR_FIREFLY) return (!flies && c.alpha < 0.02f) || out;
        return out && c.t > 3;
    }), gCritters.end());
}

static void drawCritters() {
    static const RGB8 bcol[4][2] = {
        {{245, 140, 30}, {40, 25, 15}},    // монарх
        {{248, 248, 240}, {90, 90, 90}},   // капустница
        {{80, 150, 245}, {25, 40, 90}},    // голубянка
        {{250, 225, 70}, {120, 90, 20}},   // лимонница
    };
    for (auto& c : gCritters) {
        float x = c.x - gVX, y = c.y - gVY;
        if (c.type == CR_BUTTERFLY) {
            float f = std::fabs(std::sin(c.ph));
            float w = c.size;
            const RGB8& wc = bcol[c.col][0];
            const RGB8& ec = bcol[c.col][1];
            float span = 0.15f + 0.85f * f;
            for (int s = -1; s <= 1; s += 2) {
                drawEllipse(x + s * w * 0.55f * span, y - w * 0.25f, w * 0.6f * span + 0.6f, w * 0.55f + 0.6f, ec.r, ec.g, ec.b, 0.9f);
                drawEllipse(x + s * w * 0.55f * span, y - w * 0.25f, w * 0.6f * span, w * 0.55f, wc.r, wc.g, wc.b, 1);
                drawEllipse(x + s * w * 0.4f * span, y + w * 0.35f, w * 0.4f * span + 0.5f, w * 0.38f + 0.5f, ec.r, ec.g, ec.b, 0.9f);
                drawEllipse(x + s * w * 0.4f * span, y + w * 0.35f, w * 0.4f * span, w * 0.38f, wc.r, wc.g, wc.b, 1);
            }
            drawEllipse(x, y, 0.55f * S, w * 0.6f, 35, 30, 30, 1);
            thinLine(x, y - w * 0.55f, x - w * 0.35f, y - w * 1.0f, 35, 30, 30, 0.8f);
            thinLine(x, y - w * 0.55f, x + w * 0.35f, y - w * 1.0f, 35, 30, 30, 0.8f);
        } else if (c.type == CR_FIREFLY) {
            float glow = 0.5f + 0.5f * std::sin(c.ph * 2.2f + c.size * 7);
            glow = glow * glow;
            float a = c.alpha;
            drawDisc(x, y, 7 * S, 190, 255, 110, 0.10f * glow * a, 4.0f, 0);
            drawDisc(x, y, 3 * S, 210, 255, 140, 0.28f * glow * a, 2.0f, 0);
            drawDisc(x, y, c.size, 245, 255, 190, (0.4f + 0.6f * glow) * a, 1.0f, 0);
        } else {
            float wing = std::sin(c.ph) * 0.6f;
            float s = c.size;
            thinLine(x, y, x - s, y - s * (0.5f + wing), 40, 40, 50, 0.9f);
            thinLine(x, y, x + s, y - s * (0.5f + wing), 40, 40, 50, 0.9f);
            drawDisc(x, y, 0.7f * S, 40, 40, 50, 0.9f, 1, 0);
        }
    }
}

// ---------------------------------------------------------------- взаимодействие мышью (не зима)
static void kickLeaves(Cap& c, int j, float power) {
    int n = c.n();
    int R = (int)(9 * S);
    float sum = 0;
    for (int k = std::max(0, j - R); k <= std::min(n - 1, j + R); ++k) {
        if (!c.vis[k]) continue;
        float take = c.d[k] * (1.0f - std::fabs((float)(k - j)) / (R + 1));
        c.d[k] -= take;
        sum += take;
    }
    float cx = c.r.left + (j + 0.5f) * CW;
    int removed = 0;
    for (size_t i = 0; i < c.decor.size();) {
        if (std::fabs(c.r.left + c.decor[i].rx - cx) < R * CW) { c.decor.erase(c.decor.begin() + i); removed++; }
        else ++i;
    }
    int cnt = std::min(30, (int)(sum / (0.8f * S)) + removed);
    for (int i = 0; i < cnt && gP.size() < kMaxParticles; ++i) {
        P p = makeP(T_LEAF);
        p.r = frange(3.0f, 5.6f) * S;
        p.col = (uint8_t)(xr() % 5);
        p.x = cx + frange(-R, R) * CW * 0.6f;
        p.y = c.edgeY(j) - frange(2, 8) * S;
        p.vx = frange(-160, 160) * S * power;
        p.vrot = -frange(220, 420) * S * power;   // начальная скорость вверх
        p.life = -1;                              // режим «подброшен»
        p.vy = frange(30, 55) * S;
        p.amp = frange(25, 50) * S;
        p.freq = frange(0.35f, 0.7f);
        p.ph = frange(0, 6.28f);
        p.rot = frange(0, 6.28f);
        p.z = frand();
        gP.push_back(p);
    }
}

static void popFlower(Cap& c, size_t fi) {
    Flower f = c.flowers[fi];
    c.flowers.erase(c.flowers.begin() + fi);
    int j = (int)(f.rx / CW);
    float x = c.r.left + f.rx, y = c.edgeY(j) - c.d[j] - 3.5f * S;
    for (int i = 0; i < 10 && gP.size() < kMaxParticles; ++i) {
        P p = makeP(T_PETAL);
        p.r = frange(1.5f, 2.4f) * S;
        p.col = f.col;
        p.x = x; p.y = y;
        p.vx = frange(-120, 120) * S;
        p.vrot = -frange(120, 260) * S;
        p.life = -1;
        p.vy = frange(18, 35) * S;
        p.amp = frange(10, 25) * S; p.freq = frange(0.5f, 1.0f);
        p.ph = frange(0, 6.28f); p.rot = frange(0, 6.28f); p.z = frand();
        gP.push_back(p);
    }
}

static void rustleGrass(Cap& c, int j) {
    float x = c.r.left + (j + 0.5f) * CW, y = c.edgeY(j) - c.d[j];
    for (int i = 0; i < 6 && gP.size() < kMaxParticles; ++i) {
        P p = makeP(T_BIT);
        p.col = (uint8_t)(17 + xr() % 2);
        p.x = x + frange(-6, 6) * S; p.y = y;
        p.vx = frange(-90, 90) * S; p.vy = frange(-260, -120) * S;
        p.vrot = frange(-12, 12); p.life = 1.5f;
        gP.push_back(p);
    }
    // сидящие рядом лепестки взлетают
    for (size_t i = 0; i < c.decor.size();) {
        Decor& d = c.decor[i];
        if (std::fabs(c.r.left + d.rx - x) < 14 * S && d.kind == 1) {
            P p = makeP(T_PETAL);
            p.r = d.size; p.col = d.col; p.x = c.r.left + d.rx; p.y = y;
            p.vx = frange(-80, 80) * S; p.vrot = -frange(100, 200) * S; p.life = -1;
            p.vy = frange(18, 35) * S; p.amp = frange(10, 25) * S; p.freq = frange(0.5f, 1.0f);
            p.ph = frange(0, 6.28f); p.rot = d.ang; p.z = frand();
            gP.push_back(p);
            c.decor.erase(c.decor.begin() + i);
        } else ++i;
    }
}

// лежат ли рядом с ячейкой листья (слой или отдельные листики)
static bool leavesNear(const Cap& c, int j) {
    if (c.d[j] > 0.5f * S) return true;
    float x = (j + 0.5f) * CW;
    for (const Decor& d : c.decor) if (std::fabs(d.rx - x) < 10 * S) return true;
    return false;
}

static bool gRaking = false;
static POINT gRakePrev{};

// нажатие мышью в не-зимний сезон; true — нажатие «по природе», его не пропускаем дальше
static bool seasonMouseDown(float x, float y) {
    Cap* c; int j;
    if (!capAtXY(x, y, c, j)) return false;
    float edge = c->edgeY(j), surf = edge - c->d[j];
    if (gSeason == SEA_AUTUMN) {
        if (!leavesNear(*c, j) || y < surf - 10 * S || y > edge + 2 * S) return false;
        kickLeaves(*c, j, 1.0f);
        gRaking = true;
        gRakePrev = POINT{(LONG)x, (LONG)y};
        return true;
    }
    // весна/лето: цветок или трава
    for (size_t i = 0; i < c->flowers.size(); ++i) {
        Flower& f = c->flowers[i];
        int fj = (int)(f.rx / CW);
        if (fj < 0 || fj >= c->n()) continue;
        float fx = c->r.left + f.rx, fy = c->edgeY(fj) - c->d[fj] - 3.5f * S * f.grow;
        if (std::fabs(fx - x) < 6 * S && std::fabs(fy - y) < 7 * S) { popFlower(*c, i); return true; }
    }
    if (c->d[j] < 2 * S || y < surf - 4 * S || y > edge + 2 * S) return false;
    rustleGrass(*c, j);
    return true;
}

// пока кнопка зажата осенью — «грабли»: ведёшь по листве, она разлетается
static void seasonRake() {
    if (!gRaking) return;
    POINT pt;
    GetCursorPos(&pt);
    float dx = (float)(pt.x - gRakePrev.x);
    if (std::fabs(dx) < 6 * S && std::abs(pt.y - gRakePrev.y) < 6 * S) return;
    gRakePrev = pt;
    Cap* c; int j;
    if (!capAtXY((float)pt.x, (float)pt.y, c, j)) return;
    float edge = c->edgeY(j);
    if (leavesNear(*c, j) && pt.y > edge - c->d[j] - 10 * S && pt.y < edge + 3 * S) kickLeaves(*c, j, 0.6f);
}

// осенью быстрый взмах мышью над листвой стряхивает её — без нажатия
static POINT gBrushPrev{-99999, -99999};
static void seasonBrush(float dt) {
    POINT pt = gCursor;
    POINT pr = gBrushPrev;
    gBrushPrev = pt;
    if (!gInteract || gHiddenFS || gRaking || gSeason != SEA_AUTUMN || pr.x == -99999 || dt <= 0) return;
    float dx = (float)(pt.x - pr.x), dy = (float)(pt.y - pr.y);
    float dist = std::sqrt(dx * dx + dy * dy);
    float speed = dist / dt;
    if (speed < 650 * S) return;   // медленное движение листья не трогает
    float power = std::min(1.0f, 0.4f + speed / (4000 * S));
    int steps = std::max(1, (int)(dist / (6 * S)));
    float skipUntil = -1;
    for (int i = 0; i <= steps; ++i) {
        float k = (float)i / steps;
        float x = pr.x + dx * k, y = pr.y + dy * k;
        if (k < skipUntil) continue;
        Cap* c; int j;
        if (!capAtXY(x, y, c, j)) continue;
        float edge = c->edgeY(j);
        if (leavesNear(*c, j) && y > edge - c->d[j] - 12 * S && y < edge + 4 * S) {
            kickLeaves(*c, j, power);
            skipUntil = k + (14 * S) / std::max(1.0f, dist);
        }
    }
}

// ---------------------------------------------------------------- снег/листья/трава слетают, когда окно двигают
static void seasonShake(Cap& c, float pushX) {
    float cx0 = (float)c.r.left;
    if (gSeason == SEA_AUTUMN) {
        for (int j = 0; j < c.n(); j += 4) {
            if (!c.vis[j] || c.d[j] < 1.5f * S || gP.size() >= kMaxParticles) continue;
            P p = makeP(T_LEAF);
            p.r = frange(3.0f, 5.2f) * S; p.col = (uint8_t)(xr() % 5);
            p.x = cx0 + (j + 0.5f) * CW; p.y = c.edgeY(j) - c.d[j];
            p.vx = pushX * 0.5f + frange(-60, 60) * S; p.vrot = -frange(60, 160) * S; p.life = -1;
            p.vy = frange(30, 55) * S; p.amp = frange(25, 50) * S; p.freq = frange(0.35f, 0.7f);
            p.ph = frange(0, 6.28f); p.rot = frange(0, 6.28f); p.z = frand();
            gP.push_back(p);
        }
    } else {
        for (auto& f : c.flowers) {
            if (gP.size() >= kMaxParticles) break;
            P p = makeP(T_PETAL);
            p.r = 2.0f * S; p.col = f.col; p.x = cx0 + f.rx; p.y = (float)c.r.top - 4 * S;
            p.vx = pushX * 0.5f + frange(-50, 50) * S; p.vrot = -frange(60, 140) * S; p.life = -1;
            p.vy = frange(18, 35) * S; p.amp = frange(10, 25) * S; p.freq = frange(0.5f, 1.0f);
            p.ph = frange(0, 6.28f); p.rot = frange(0, 6.28f); p.z = frand();
            gP.push_back(p);
        }
    }
    for (auto& d : c.decor) {
        if (gP.size() >= kMaxParticles) break;
        if (d.kind == 0 && gSeason == SEA_AUTUMN && frand() < 0.5f) continue;
        P p = makeP(d.kind == 0 ? T_LEAF : d.kind == 1 ? T_PETAL : T_FLUFF);
        p.r = d.size; p.col = d.col; p.x = cx0 + d.rx; p.y = (float)c.r.top - 3 * S;
        p.vx = pushX * 0.5f + frange(-50, 50) * S; p.vrot = -frange(60, 140) * S; p.life = p.type == T_FLUFF ? 20 : -1;
        p.vy = d.kind == 2 ? 10 * S : frange(20, 50) * S; p.amp = frange(10, 40) * S; p.freq = frange(0.3f, 0.8f);
        p.ph = frange(0, 6.28f); p.rot = d.ang; p.z = frand();
        gP.push_back(p);
    }
    c.decor.clear();
    c.flowers.clear();
}

static int autoSeason() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    int m = st.wMonth;
    if (m == 12 || m <= 2) return SEA_WINTER;
    if (m <= 5) return SEA_SPRING;
    if (m <= 8) return SEA_SUMMER;
    return SEA_AUTUMN;
}
