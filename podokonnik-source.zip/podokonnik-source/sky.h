// Гроза по погоде: молнии бьют из-за верхнего края монитора, обои на миг вспыхивают.
#pragma once

struct BoltSeg { float x0, y0, x1, y1, w; };
struct Bolt { std::vector<BoltSeg> seg; float age = 0, life = 0.5f; };
static std::vector<Bolt> gBolts;
static float gBoltNext = 8;

static void boltBranch(Bolt& b, float x, float y, float yEnd, float w, int depth, float drift) {
    while (y < yEnd) {
        float ny = y + frange(14, 30) * S;
        float nx = x + frange(-16, 16) * S + drift * S;
        b.seg.push_back({x, y, nx, ny, w});
        if (depth < 2 && frand() < 0.22f) {
            float len = frange(60, 160) * S;
            boltBranch(b, nx, ny, std::min(yEnd, ny + len), w * 0.55f, depth + 1, frand() < 0.5f ? -10.0f : 10.0f);
        }
        x = nx; y = ny;
        if (depth > 0 && frand() < 0.08f) break;
    }
}
static void spawnBolt() {
    if (gMons.empty()) return;
    const RECT& m = gMons[xr() % gMons.size()];
    Bolt b;
    float x = m.left + (m.right - m.left) * frange(0.1f, 0.9f);
    float yEnd = m.top + (m.bottom - m.top) * frange(0.35f, 0.7f);
    boltBranch(b, x, (float)m.top - 5 * S, yEnd, 2.4f * S, 0, frange(-4, 4));
    b.life = frange(0.4f, 0.6f);
    gBolts.push_back(std::move(b));
    wpFlash();
}
static void updateSky(float dt) {
    for (auto& b : gBolts) b.age += dt;
    gBolts.erase(std::remove_if(gBolts.begin(), gBolts.end(), [](const Bolt& b) { return b.age > b.life; }), gBolts.end());
    if (!gSnowOn || !weatherThunderNow()) { gBoltNext = frange(3, 8); return; }
    gBoltNext -= dt;
    if (gBoltNext <= 0) { spawnBolt(); gBoltNext = frange(6, 20); }
}
static void drawSky() {
    for (const Bolt& b : gBolts) {
        float t = b.age;
        bool on = t < 0.08f || (t > 0.14f && t < 0.22f) || (t > 0.30f && t < 0.36f);
        if (!on) continue;
        float fade = 1.0f - t / b.life * 0.5f;
        for (const BoltSeg& s : b.seg) {
            float x0 = s.x0 - gVX, y0 = s.y0 - gVY, x1 = s.x1 - gVX, y1 = s.y1 - gVY;
            for (int k = -2; k <= 2; ++k) {
                if (k == 0) continue;
                float o = k * s.w * 0.9f;
                thinLine(x0 + o, y0, x1 + o, y1, 170, 190, 255, 0.16f * fade);
            }
            thinLine(x0, y0, x1, y1, 235, 240, 255, fade);
            if (s.w > 1.5f * S) thinLine(x0 + 1, y0, x1 + 1, y1, 255, 255, 255, 0.8f * fade);
        }
    }
}
