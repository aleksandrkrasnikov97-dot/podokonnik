// Студия Подоконника — отдельная программа: редактор своих живых обоев (слои с параллаксом, слежка за мышкой,
// частицы, видео). Внутри — редактор на основе Parallax Designer (Robert Hoffmann, MIT), собранный в один HTML.
// Готовые обои пишем в папку данных Подоконника и передаём ему через WM_COPYDATA — он добавляет их и включает.
#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <dwmapi.h>
#include <algorithm>
#include <string>
#include <vector>
#include "webview.h"
#include "json.h"

#define IDI_APP 1
#define IDR_STUDIO_HTML 201
static const ULONG_PTR kCopyStudioWallpaper = 0x53545544;   // 'STUD': «добавь и включи обои из этой папки»

static HWND gWnd = nullptr;
static wv::Host gHost;
static std::wstring gExeDir, gDataDir;
static int gLang = 0;

static std::wstring W16(const std::string& s) { return wv::toWide(s); }
static std::string U8(const std::wstring& w) { return wv::toUtf8(w.c_str()); }

static bool writeFile(const std::wstring& p, const std::string& data) {
    HANDLE f = CreateFileW(p.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    DWORD w = 0;
    bool ok = WriteFile(f, data.data(), (DWORD)data.size(), &w, nullptr) && w == data.size();
    CloseHandle(f);
    return ok;
}
static void makeDirs(const std::wstring& dir) {
    for (size_t i = 3; i <= dir.size(); ++i)
        if (i == dir.size() || dir[i] == L'\\') CreateDirectoryW(dir.substr(0, i).c_str(), nullptr);
}
static void deleteTree(const std::wstring& dir) {
    std::wstring from = dir + L'\0';
    SHFILEOPSTRUCTW op{};
    op.wFunc = FO_DELETE;
    op.pFrom = from.c_str();
    op.fFlags = FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT;
    SHFileOperationW(&op);
}
static std::string b64decode(const std::string& in) {
    static int T[256]; static bool init = false;
    if (!init) { for (int i = 0; i < 256; ++i) T[i] = -1; const char* a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; for (int i = 0; i < 64; ++i) T[(unsigned char)a[i]] = i; init = true; }
    std::string out; out.reserve(in.size() * 3 / 4);
    int val = 0, bits = -8;
    for (unsigned char c : in) {
        if (T[c] < 0) continue;
        val = (val << 6) + T[c]; bits += 6;
        if (bits >= 0) { out.push_back((char)((val >> bits) & 0xFF)); bits -= 8; }
    }
    return out;
}
static std::string resourceText(int id) {
    HRSRC r = FindResourceW(nullptr, MAKEINTRESOURCEW(id), RT_RCDATA);
    if (!r) return "";
    HGLOBAL g = LoadResource(nullptr, r);
    return g ? std::string((const char*)LockResource(g), SizeofResource(nullptr, r)) : "";
}

// папка данных — та же, что у Подоконника (переносной режим: «Данные» рядом с программой)
static void initPaths() {
    wchar_t p[MAX_PATH * 2] = {0};
    GetModuleFileNameW(nullptr, p, MAX_PATH * 2);
    std::wstring s = p;
    gExeDir = s.substr(0, s.find_last_of(L'\\'));
    if (GetFileAttributesW((gExeDir + L"\\Подоконник.ini").c_str()) != INVALID_FILE_ATTRIBUTES) gDataDir = gExeDir + L"\\Данные";
    else {
        wchar_t base[MAX_PATH] = {0};
        if (!GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH)) GetTempPathW(MAX_PATH, base);
        gDataDir = std::wstring(base) + L"\\Sugrob";
    }
    makeDirs(gDataDir);
    DWORD v = 0, sz = sizeof(v);
    if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\Sugrob", L"Lang", RRF_RT_REG_DWORD, nullptr, &v, &sz) == ERROR_SUCCESS) gLang = (int)v;
    else { WORD pl = PRIMARYLANGID(GetUserDefaultUILanguage()); gLang = (pl == LANG_RUSSIAN || pl == LANG_UKRAINIAN || pl == LANG_BELARUSIAN || pl == LANG_KAZAK) ? 0 : 1; }
}

static std::wstring safeName(std::wstring n) {
    for (auto& c : n) if (wcschr(L"<>:\"/\\|?*", c) || c < 32) c = L'_';
    while (!n.empty() && (n.back() == L' ' || n.back() == L'.')) n.pop_back();
    while (!n.empty() && n.front() == L' ') n.erase(0, 1);
    if (n.empty()) n = L"Мои обои";
    if (n.size() > 60) n.resize(60);
    return n;
}
static std::string jsonEsc(const std::string& s) {
    std::string o = "\"";
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { o += '\\'; o += (char)c; }
        else if (c < 32) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
        else o += (char)c;
    }
    return o + "\"";
}

// Подоконник: найти (или запустить) и попросить добавить и включить обои
static bool tellPodokonnik(const std::wstring& folder) {
    HWND main = FindWindowW(L"SugrobMsg", nullptr);
    if (!main) {
        const wchar_t* names[] = {L"Подоконник.exe", L"Podokonnik.exe"};
        for (auto n : names) {
            std::wstring exe = gExeDir + L"\\" + n;
            if (GetFileAttributesW(exe.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            ShellExecuteW(nullptr, L"open", exe.c_str(), L"--autostart", gExeDir.c_str(), SW_SHOWNORMAL);
            break;
        }
        for (int i = 0; i < 100 && !(main = FindWindowW(L"SugrobMsg", nullptr)); ++i) Sleep(100);
        if (main) Sleep(1500);   // даём ему проснуться
    }
    if (!main) return false;
    COPYDATASTRUCT cd{};
    cd.dwData = kCopyStudioWallpaper;
    cd.cbData = (DWORD)((folder.size() + 1) * sizeof(wchar_t));
    cd.lpData = (void*)folder.c_str();
    DWORD_PTR r = 0;
    return SendMessageTimeoutW(main, WM_COPYDATA, (WPARAM)gWnd, (LPARAM)&cd, SMTO_ABORTIFHUNG, 8000, &r) && r == 1;
}

static void reply(bool ok, const std::string& err = "") {
    wv::post(&gHost, std::string("{\"type\":\"saved\",\"ok\":") + (ok ? "true" : "false") + ",\"error\":" + jsonEsc(err) + "}");
}

static void onSave(const js::Value& m) {
    std::wstring name = safeName(W16(m.str("name")));
    std::wstring root = gDataDir + L"\\Мои обои", dir = root + L"\\" + name;
    makeDirs(root);
    deleteTree(dir);   // то же название — обновляем обои целиком
    makeDirs(dir + L"\\assets");
    bool ok = true;
    std::string html = m.str("html");   // старый формат: страница отдельно; новый — index.html среди файлов
    if (!html.empty()) ok = writeFile(dir + L"\\index.html", html);
    if (const js::Value* files = m.get("files")) {
        for (auto& f : files->a) {
            std::string fn = f.str("name");
            if (fn.empty() || fn.find("..") != std::string::npos || fn.find(':') != std::string::npos) continue;
            std::wstring p = dir + L"\\" + W16(fn);
            for (auto& c : p) if (c == L'/') c = L'\\';
            makeDirs(p.substr(0, p.find_last_of(L'\\')));
            ok = writeFile(p, b64decode(f.str("base64"))) && ok;
        }
    }
    std::string prev = m.str("preview");
    size_t comma = prev.find(',');
    bool hasPrev = comma != std::string::npos && writeFile(dir + L"\\preview.jpg", b64decode(prev.substr(comma + 1)));
    std::string title = U8(name);
    std::string pj = "{\n  \"title\": " + jsonEsc(title) + ",\n  \"type\": \"web\",\n  \"file\": \"index.html\",\n" +
                     (hasPrev ? "  \"preview\": \"preview.jpg\",\n" : "") +
                     "  \"description\": \"Сделано в Студии Подоконника\",\n  \"general\": { \"properties\": {} }\n}\n";
    ok = writeFile(dir + L"\\project.json", pj) && ok;
    if (const js::Value* proj = m.get("project")) writeFile(dir + L"\\studio-project.json", js::dump(*proj));
    if (!ok) { reply(false, gLang ? "(could not write files)" : "(не получилось записать файлы)"); return; }
    if (!tellPodokonnik(dir)) { reply(false, gLang ? "— Podokonnik didn't respond. The wallpaper is saved; add it in Live wallpapers" : "— Подоконник не ответил. Обои сохранены, их можно добавить в «Живых обоях»"); return; }
    reply(true);
}

static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_SIZE: wv::fit(&gHost); return 0;
    case WM_GETMINMAXINFO: { auto* mm = (MINMAXINFO*)lp; mm->ptMinTrackSize = {900, 600}; return 0; }
    case WM_DESTROY: wv::destroy(&gHost); PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, LPWSTR, int show) {
    HANDLE mutex = CreateMutexW(nullptr, TRUE, L"PodokonnikStudio_SingleInstance");
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        if (HWND w = FindWindowW(L"PodokonnikStudio", nullptr)) { ShowWindow(w, SW_RESTORE); SetForegroundWindow(w); }
        return 0;
    }
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    initPaths();

    std::wstring uiDir = gDataDir + L"\\studio";
    makeDirs(uiDir);
    std::string html = resourceText(IDR_STUDIO_HTML);
    writeFile(uiDir + L"\\index.html", html);

    WNDCLASSEXW wc{sizeof(wc)};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = inst;
    wc.lpszClassName = L"PodokonnikStudio";
    wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(IDI_APP));
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = CreateSolidBrush(RGB(11, 16, 38));
    RegisterClassExW(&wc);
    UINT dpi = GetDpiForSystem();
    int W = MulDiv(1400, dpi, 96), H = MulDiv(880, dpi, 96);
    RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    W = std::min<int>(W, wa.right - wa.left); H = std::min<int>(H, wa.bottom - wa.top);
    gWnd = CreateWindowExW(0, L"PodokonnikStudio", gLang ? L"Podokonnik Studio — your own live wallpapers" : L"Студия Подоконника — свои живые обои",
                           WS_OVERLAPPEDWINDOW, wa.left + (wa.right - wa.left - W) / 2, wa.top + (wa.bottom - wa.top - H) / 2, W, H,
                           nullptr, nullptr, inst, nullptr);
    BOOL dark = TRUE;
    DwmSetWindowAttribute(gWnd, 20 /*DWMWA_USE_IMMERSIVE_DARK_MODE*/, &dark, sizeof(dark));
    ShowWindow(gWnd, show);
    UpdateWindow(gWnd);

    gHost.hwnd = gWnd;
    gHost.onMessage = [](const std::string& raw) {
        js::Value v = js::parse(raw);
        if (v.str("cmd") == "save") onSave(v);
    };
    std::wstring url = L"file:///" + uiDir + L"/index.html?lang=" + (gLang ? L"en" : L"ru");
    for (auto& c : url) if (c == L'\\') c = L'/';
    wv::create(&gHost, gDataDir + L"\\WebView2Studio", url, {}, true, [](bool ok) {
        if (!ok) MessageBoxW(gWnd, gLang ? L"Couldn't start the built-in browser (WebView2). Install Microsoft Edge WebView2 Runtime."
                                         : L"Не удалось запустить встроенный браузер (WebView2). Установи Microsoft Edge WebView2 Runtime.",
                             L"Студия Подоконника", MB_ICONERROR);
    });

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    if (mutex) CloseHandle(mutex);
    return 0;
}
