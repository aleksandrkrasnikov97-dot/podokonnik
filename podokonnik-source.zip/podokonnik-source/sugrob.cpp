// Подоконник — живой рабочий стол на все четыре сезона (раньше «Сугроб»).
// Прозрачное окно поверх всего: снежинки падают и копятся сугробами на окнах
// (с учётом скруглённых углов Windows 11) и на панели задач. Из снега можно
// лепить снежки и снеговиков, кидаться ими; по панели задач ездит бульдозер.
// Сборка (mingw-w64):
//   windres res.rc -O coff -o res.o
//   g++ -O2 -municode -mwindows -static sugrob.cpp res.o -ldwmapi -o Sugrob.exe

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <dwmapi.h>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cwchar>
#include <cstdio>
#include <cstdarg>
#include <climits>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <mmsystem.h>
#include <commctrl.h>
#include <winhttp.h>

#ifndef DWMWA_CLOAKED
#define DWMWA_CLOAKED 14
#endif
#ifndef DWMWA_EXTENDED_FRAME_BOUNDS
#define DWMWA_EXTENDED_FRAME_BOUNDS 9
#endif
#define SUGROB_DWMWA_WINDOW_CORNER_PREFERENCE 33
#ifndef LLMHF_INJECTED
#define LLMHF_INJECTED 1
#endif

#define IDI_APP 1

// ---------------------------------------------------------------- настройки
static const wchar_t* kRegKey   = L"Software\\Sugrob";
static const wchar_t* kRunKey   = L"Software\\Microsoft\\Windows\\CurrentVersion\\Run";
static const wchar_t* kRunValue = L"Podokonnik";
static const wchar_t* kRunValueOld = L"Sugrob";

// портативный режим: рядом с программой лежит «Подоконник.ini» — настройки в нём, данные в папке «Данные»
static bool gPortable = false;
static std::wstring gExeDir, gIniPath;
static void detectPortable() {
    wchar_t p[MAX_PATH * 2] = {0};
    GetModuleFileNameW(nullptr, p, MAX_PATH * 2);
    std::wstring s = p;
    size_t sl = s.find_last_of(L'\\');
    gExeDir = sl == std::wstring::npos ? L"." : s.substr(0, sl);
    gIniPath = gExeDir + L"\\Подоконник.ini";
    WIN32_FILE_ATTRIBUTE_DATA fa{};
    gPortable = GetFileAttributesExW(gIniPath.c_str(), GetFileExInfoStandard, &fa) != 0;
    if (gPortable && fa.nFileSizeLow == 0) {   // пустой файл создали руками — делаем его юникодным
        HANDLE f = CreateFileW(gIniPath.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
        if (f != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(f, "\xFF\xFE", 2, &w, nullptr); CloseHandle(f); }
    }
}
static std::wstring baseDataDir() {
    if (gPortable) return gExeDir + L"\\Данные";
    wchar_t base[MAX_PATH] = {0};
    if (!GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH)) GetTempPathW(MAX_PATH, base);
    return std::wstring(base) + L"\\Sugrob";
}
// строковые настройки (реестр или ini)
static bool cfgGetStr(const wchar_t* name, std::wstring& out) {
    if (gPortable) {
        std::vector<wchar_t> buf(32768);
        DWORD n = GetPrivateProfileStringW(L"Settings", name, L"\x01", buf.data(), (DWORD)buf.size(), gIniPath.c_str());
        if (n == 1 && buf[0] == 1) return false;
        out.assign(buf.data(), n);
        return true;
    }
    DWORD sz = 0;
    if (RegGetValueW(HKEY_CURRENT_USER, kRegKey, name, RRF_RT_REG_SZ, nullptr, nullptr, &sz) != ERROR_SUCCESS || sz < 2) return false;
    std::vector<wchar_t> buf(sz / 2 + 1);
    if (RegGetValueW(HKEY_CURRENT_USER, kRegKey, name, RRF_RT_REG_SZ, nullptr, buf.data(), &sz) != ERROR_SUCCESS) return false;
    out = buf.data();
    return true;
}
static void cfgSetStr(const wchar_t* name, const std::wstring& v) {
    if (gPortable) { WritePrivateProfileStringW(L"Settings", name, v.c_str(), gIniPath.c_str()); return; }
    RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, name, REG_SZ, v.c_str(), (DWORD)((v.size() + 1) * sizeof(wchar_t)));
}

static int  gIntensityPct = 50;  // сила снегопада/листопада 0..100
static int  gWindPct   = 50;     // ветер 0..100 (50 — без постоянного ветра)
static int  gSeasonMode = 4;     // 0 зима, 1 весна, 2 лето, 3 осень, 4 — по календарю
static int  gSeason    = 0;      // текущий сезон
static int  gRainMode  = 1;      // дождь: 0 никогда, 1 иногда, 2 всегда
static bool gCrittersOn = false; // бабочки, птицы
// язык интерфейса: 0 — русский, 1 — английский
static int gLang = 0;
static const char* T8(const char* ru, const char* en) { return gLang == 1 ? en : ru; }
static const wchar_t* TW(const wchar_t* ru, const wchar_t* en) { return gLang == 1 ? en : ru; }
// экономия: от батареи (0 — как обычно, 1 — меньше кадров, 2 — ещё и обои на паузе) и лёгкий режим
static int gBatteryMode = 0;
static bool gOnBattery = false;
static bool gLightMode = false;
// смена обоев по расписанию, горячие клавиши, погода
static int gRotMin = 0;            // каждые N минут (0 — не менять)
static bool gRotRandom = true;
static double gRotLast = 0;
static bool gHotkeys = true;
static bool gWeatherOn = false;
static std::wstring gWeatherCity;
static double gLat = 0, gLon = 0;
static int  gFireflyMode = 0;    // светлячки летом: 0 нет, 1 вечером, 2 всегда
static bool gSnowOn    = true;   // эффекты включены
static int  gWpMode = 0;         // способ встраивания живых обоев (0..2)
static bool gWpMuted = true;     // звук видео-обоев выключен
static bool gWpPauseMax = true;  // пауза обоев за развёрнутым окном
static bool gWpFollowSeason = true;  // встроенные обои меняются вместе с сезоном
static bool gCapsOn    = false;  // сугробы/листва/трава на окнах
static bool gCapsTaskbar = false; // то же на панели задач
static bool gHideFullscreen = true; // прятать эффекты в играх и видео на весь экран
static inline bool anyCaps() { return gCapsOn || gCapsTaskbar; }
static bool gMenOn     = false;  // снеговики сами появляются
static bool gInteract  = false;  // играть со снегом мышкой
static bool gDozerOn   = false;  // бульдозер на панели задач
static int  gDozerEvery = 0;     // как часто приезжает, секунд; 0 — когда накопится
static float gDozerTimer = 0;
static bool gMusicOn = false;          // играет ли музыка
static int  gMusicVol = 50;            // громкость 0..100
static int  gTrack = 0;                // текущая мелодия (номер в плейлисте)
static int  gPl = 0;                   // плейлист: 0..3 — сезоны, 4 — своя музыка
static bool gMusicFollow = true;       // плейлист меняется вместе с сезоном
static HWND gVolWnd = nullptr;
static void musicSetPaused(bool p);

enum {
    ID_TOGGLE = 100, ID_I0, ID_I1, ID_I2, ID_CAPS, ID_MEN, ID_SHAKE, ID_AUTO, ID_EXIT,
    ID_INTERACT, ID_DOZER, ID_DOZER_NOW, ID_HELP,
    ID_MUSIC, ID_MUSIC_NEXT, ID_MUSIC_VOL, ID_MUSIC_CREDITS,
    ID_SONG0 = 200   // + номер мелодии
};
#define WM_TRAY (WM_APP + 1)

// ---------------------------------------------------------------- глобальные
static HINSTANCE gInst;
static HWND gOverlay = nullptr, gMsgWnd = nullptr;
static UINT gTaskbarCreated = 0;
static NOTIFYICONDATAW gNid{};
static HHOOK gMouseHook = nullptr;

static int gVX = 0, gVY = 0, gW = 0, gH = 0;   // виртуальный экран
static HDC gMemDC = nullptr;
static HBITMAP gDib = nullptr, gOldBmp = nullptr;
static uint32_t* gPix = nullptr;
static std::vector<RECT> gMons;
static float S = 1.0f;                          // масштаб DPI
static float gCornerR = 0;                      // радиус скругления окон (Win11)
static bool gDrewLast = false;
// грязные плитки 64×64: стираем и отправляем на экран только то, где что-то нарисовано
static const int kTileShift = 6;
static int gTW = 0, gTH = 0;
static std::vector<uint8_t> gTileNow, gTilePrev;
static uint64_t gFrameHash = 0;
static int gStaticFrames = 0;
static UINT gTickMs = 0;            // текущий шаг таймера
static int gFps = 0;                // кадров в секунду: 20 — экономно, 30 — обычно, 60 — плавно
static POINT gCursor{};              // курсор, один раз за кадр
static bool gHiddenFS = false;
static bool gScrActive = false;     // идёт заставка Подоконника
static LARGE_INTEGER gFreq, gLast;
static double gTime = 0;
static double gTopmostTimer = 0;
static int gClipY = INT_MAX;                    // рисовать только выше этой строки

// ---------------------------------------------------------------- случайные
static uint32_t gRs = 0x9E3779B9u;
static inline uint32_t xr() { gRs ^= gRs << 13; gRs ^= gRs >> 17; gRs ^= gRs << 5; return gRs; }
static inline float frand() { return (xr() >> 8) * (1.0f / 16777216.0f); }
static inline float frange(float a, float b) { return a + (b - a) * frand(); }
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static const float PI = 3.14159265f;

// ---------------------------------------------------------------- частицы
struct P {
    float x, y, vx, vy, r, a, ph, amp, freq, z;
    bool clump;
    uint8_t type, col;
    float rot, vrot, life;
};
static std::vector<P> gP;
static const size_t kMaxParticles = 5000;

// ---------------------------------------------------------------- сугробы
static const int CW = 2;   // ширина ячейки сугроба, px
struct Decor { float rx, ang, size, age, life; uint8_t kind, col; };   // лист/лепесток на окне
struct Flower { float rx, grow; uint8_t kind, col; };
struct Cap {
    HWND h = nullptr;
    RECT r{};
    std::vector<float> d;        // высота снега по ячейкам
    std::vector<float> base;     // опускание края окна (скруглённые углы)
    std::vector<uint8_t> vis;    // видна ли ячейка
    float roundR = 0;
    bool seen = false;
    bool taskbar = false;
    bool zoomed = false;
    bool noSnow = false;         // сугробы тут выключены: окно нужно только питомцу и праздничным украшениям
    float manTimer = 0, manDelay = 10;
    std::vector<Decor> decor;
    std::vector<Flower> flowers;
    float flowerT = 0;
    int n() const { return (int)d.size(); }
    float edgeY(int j) const { return r.top + (j >= 0 && j < (int)base.size() ? base[j] : 0.0f); }
    float smoothD(int j) const {
        int nn = n();
        if (nn == 0) return 0;
        j = std::max(0, std::min(j, nn - 1));
        float a = d[std::max(j - 1, 0)], b = d[j], e = d[std::min(j + 1, nn - 1)];
        return (a + 2 * b + e) * 0.25f;
    }
    float surfY(int j) const { return edgeY(j) - smoothD(j); }
};
static std::unordered_map<HWND, Cap> gCaps;

struct WI { HWND h; RECT r; bool tb; bool zoomed; bool round; bool topmost; bool noSnow; };   // noSnow — окно только для питомца и украшений
static std::vector<WI> gWins;          // подходящие окна, сверху вниз по Z
static std::vector<Cap*> gCapPtr;      // параллельно gWins

static inline float maxDepth(const Cap& c) {
    switch (gSeason) {
    case 1: return (c.taskbar ? 10.0f : 9.0f) * S;    // весенняя трава
    case 2: return (c.taskbar ? 13.0f : 12.0f) * S;   // летняя трава
    case 3: return (c.taskbar ? 11.0f : 9.0f) * S;    // листва
    default: return (c.taskbar ? 16.0f : 13.0f) * S;  // снег
    }
}

static Cap* findCap(HWND h) {
    auto it = gCaps.find(h);
    return it == gCaps.end() ? nullptr : &it->second;
}

// ---------------------------------------------------------------- снежки
enum { B_FLY = 0, B_HELD = 1, B_REST = 2 };
struct Ball {
    int id;
    float x, y, vx, vy, r;
    int state;
    HWND capH;       // на каком окне лежит (если belowId < 0)
    float relX;      // смещение по X относительно окна или нижнего шара
    int belowId;     // на каком шаре лежит
    bool autoMan;
    int face;        // куда смотрит снеговик (+1/-1)
    bool dead;
};
static std::vector<Ball> gBalls;
static int gNextBallId = 1;
static int gHeldId = -1;
static float gHeldVX = 0, gHeldVY = 0;
static POINT gHeldPrev{};
static bool gSwallowLUp = false, gSwallowRUp = false;
static const size_t kMaxBalls = 80;

// плевки снега на «стекле» экрана
struct Splat { float x, y, r, age; uint32_t seed; };
static std::vector<Splat> gSplats;

// бульдозер
struct Dozer {
    bool active = false;
    float x = 0;           // центр корпуса
    int dir = 1;
    float pile = 0;        // сколько снега перед отвалом (площадь, px²)
    float cooldown = 25;
    float puffT = 0;
    bool dumped = false;
    HWND capH = nullptr;
} gDozer;
struct Puff { float x, y, r, age; };
static std::vector<Puff> gPuffs;
static int gDozerNextDir = 1;
static bool gDozerRequested = false;

// ================================================================ рисование
static inline void blendPx(int X, int Y, float r, float g, float b, float a) {
    if (X < 0 || Y < 0 || X >= gW || Y >= gH || Y >= gClipY || a <= 0.004f) return;
    if (a > 1) a = 1;
#ifdef SUGROB_DEMO
    if (a < 0.35f) return;   // для роликов из Wine: там нет полупрозрачности, полутени выходят тёмными
    a = 1;
#endif
    gTileNow[(size_t)(Y >> kTileShift) * gTW + (X >> kTileShift)] = 1;
    uint32_t& p = gPix[(size_t)Y * gW + X];
    float inv = 1.0f - a;
    int B = (int)(b * a + (p & 255) * inv + 0.5f);
    int G = (int)(g * a + ((p >> 8) & 255) * inv + 0.5f);
    int R = (int)(r * a + ((p >> 16) & 255) * inv + 0.5f);
    int A = (int)(255.0f * a + ((p >> 24) & 255) * inv + 0.5f);
    p = (uint32_t)(std::min(B, 255) | (std::min(G, 255) << 8) | (std::min(R, 255) << 16) | (std::min(A, 255) << 24));
}

// круг со сглаживанием; shade>0 — объёмная заливка (снежки, комья)
static void drawDisc(float cx, float cy, float r, float R, float G, float B,
                     float alpha, float soft, float shade) {
    int x0 = (int)std::floor(cx - r - soft - 1), x1 = (int)std::ceil(cx + r + soft + 1);
    int y0 = (int)std::floor(cy - r - soft - 1), y1 = (int)std::ceil(cy + r + soft + 1);
    if (x1 < 0 || y1 < 0 || x0 >= gW || y0 >= gH) return;
    x0 = std::max(x0, 0); y0 = std::max(y0, 0);
    x1 = std::min(x1, gW - 1); y1 = std::min(y1, gH - 1);
    for (int Y = y0; Y <= y1; ++Y) {
        float dy = Y + 0.5f - cy;
        for (int X = x0; X <= x1; ++X) {
            float dx = X + 0.5f - cx;
            float dist = std::sqrt(dx * dx + dy * dy);
            float cov = clampf((r - dist) / soft + 0.5f, 0.0f, 1.0f);
            if (cov <= 0) continue;
            float l = 1.0f;
            if (shade > 0 && r > 0.5f) {
                float nx = dx / r, ny = dy / r;
                l = 1.0f - shade * clampf(0.45f + 0.45f * nx + 0.6f * ny, 0.0f, 1.0f);
                if (dist > r - 1.1f) l *= 0.86f;   // контур, чтобы было видно на белом
            }
            blendPx(X, Y, R * l, G * l, B * l, alpha * cov);
        }
    }
}

static void drawLine(float x0, float y0, float x1, float y1, float w,
                     float R, float G, float B, float alpha = 0.55f) {
    float len = std::hypot(x1 - x0, y1 - y0);
    int steps = std::max(1, (int)(len / 0.6f));
    for (int i = 0; i <= steps; ++i) {
        float t = (float)i / steps;
        drawDisc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, w, R, G, B, alpha, 1.0f, 0);
    }
}

// прямоугольник со сглаженными краями (координаты в пикселях буфера)
static void fillRect(float x0, float y0, float x1, float y1, float R, float G, float B, float a = 1.0f) {
    if (x1 < x0) std::swap(x0, x1);
    if (y1 < y0) std::swap(y0, y1);
    int X0 = (int)std::floor(x0), X1 = (int)std::ceil(x1);
    int Y0 = (int)std::floor(y0), Y1 = (int)std::ceil(y1);
    for (int Y = Y0; Y < Y1; ++Y) {
        float cy = std::min(y1, Y + 1.0f) - std::max(y0, (float)Y);
        if (cy <= 0) continue;
        for (int X = X0; X < X1; ++X) {
            float cx = std::min(x1, X + 1.0f) - std::max(x0, (float)X);
            if (cx <= 0) continue;
            blendPx(X, Y, R, G, B, a * cx * cy);
        }
    }
}

// ================================================================ экран
#include "gpu.h"
static void freeBuffer() {
    if (gMemDC) {
        if (gOldBmp) SelectObject(gMemDC, gOldBmp);
        DeleteDC(gMemDC);
        gMemDC = nullptr;
    }
    if (gDib) { DeleteObject(gDib); gDib = nullptr; }
    gPix = nullptr;
}

static BOOL CALLBACK MonEnum(HMONITOR, HDC, LPRECT r, LPARAM) {
    gMons.push_back(*r);
    return TRUE;
}

static void setupScreen() {
    freeBuffer();
    gVX = GetSystemMetrics(SM_XVIRTUALSCREEN);
    gVY = GetSystemMetrics(SM_YVIRTUALSCREEN);
    gW  = std::max(1, GetSystemMetrics(SM_CXVIRTUALSCREEN));
    gH  = std::max(1, GetSystemMetrics(SM_CYVIRTUALSCREEN));
    gMons.clear();
    EnumDisplayMonitors(nullptr, nullptr, MonEnum, 0);

    BITMAPINFO bi{};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = gW;
    bi.bmiHeader.biHeight = -gH;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    HDC screen = GetDC(nullptr);
    gMemDC = CreateCompatibleDC(screen);
    void* bits = nullptr;
    gDib = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    ReleaseDC(nullptr, screen);
    gPix = (uint32_t*)bits;
    gOldBmp = (HBITMAP)SelectObject(gMemDC, gDib);
    if (gPix) memset(gPix, 0, (size_t)gW * gH * 4);
    gTW = (gW + (1 << kTileShift) - 1) >> kTileShift;
    gTH = (gH + (1 << kTileShift) - 1) >> kTileShift;
    gTileNow.assign((size_t)gTW * gTH, 0);
    gTilePrev.assign((size_t)gTW * gTH, 0);
    gFrameHash = 0;
    if (gOverlay)
        SetWindowPos(gOverlay, HWND_TOPMOST, gVX, gVY, gW, gH, SWP_NOACTIVATE);
    if (gGpuOn) gpu::resize(gW, gH);
    gCaps.clear();
    gBalls.clear();
    gHeldId = -1;
    gDozer.active = false;
    gDrewLast = true;  // заставить перерисовать
}

static void present(const RECT* dirty = nullptr) {
    if (!gPix) return;
    if (gGpuOn) { gpu::clearAll(); return; }   // вызывается, когда всё стёрто
    POINT dst{gVX, gVY}, src{0, 0};
    SIZE sz{gW, gH};
    BLENDFUNCTION bf{AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    UPDATELAYEREDWINDOWINFO info{};
    info.cbSize = sizeof(info);
    info.pptDst = &dst;
    info.psize = &sz;
    info.hdcSrc = gMemDC;
    info.pptSrc = &src;
    info.pblend = &bf;
    info.dwFlags = ULW_ALPHA;
    info.prcDirty = dirty;
    if (!UpdateLayeredWindowIndirect(gOverlay, &info) && dirty) {
        info.prcDirty = nullptr;   // старые системы: целиком
        UpdateLayeredWindowIndirect(gOverlay, &info);
    }
}

// стереть всё, что было нарисовано в прошлом кадре (только эти плитки)
static void clearDirtyTiles() {
    const int T = 1 << kTileShift;
    for (int ty = 0; ty < gTH; ++ty) {
        int y0 = ty * T, y1 = std::min(gH, y0 + T);
        for (int tx = 0; tx < gTW; ++tx) {
            if (!gTilePrev[(size_t)ty * gTW + tx]) continue;
            // соседние грязные плитки в ряду стираем одним куском
            int tx1 = tx;
            while (tx1 + 1 < gTW && gTilePrev[(size_t)ty * gTW + tx1 + 1]) ++tx1;
            int x0 = tx * T, x1 = std::min(gW, (tx1 + 1) * T);
            for (int y = y0; y < y1; ++y) memset(gPix + (size_t)y * gW + x0, 0, (size_t)(x1 - x0) * 4);
            tx = tx1;
        }
    }
    std::fill(gTileNow.begin(), gTileNow.end(), 0);
}

static void alogFwd(const char* fmt, ...);
static void gpuFallback();
// видеокарта: отправляем только изменившиеся плитки (сейчас или в прошлом кадре), соседние склеиваем в полосы
static bool gpuPresentTiles() {
    const int T = 1 << kTileShift;
    struct Run { int x0, x1, y0, y1; };
    auto dirty = [](int ty, int tx) { size_t k = (size_t)ty * gTW + tx; return gTilePrev[k] || gTileNow[k]; };
    std::vector<Run> open, done, cur, nopen;
    for (int ty = 0; ty < gTH; ++ty) {
        cur.clear();
        for (int tx = 0; tx < gTW; ++tx) {
            if (!dirty(ty, tx)) continue;
            int a = tx, b = tx, t = tx + 1;
            while (t < gTW) {
                if (dirty(ty, t)) { b = t; ++t; }
                else if (t + 1 < gTW && dirty(ty, t + 1)) { b = t + 1; t += 2; }
                else break;
            }
            cur.push_back({a, b + 1, ty, ty + 1});
            tx = b;
        }
        nopen.clear();
        for (auto& c : cur) {
            bool merged = false;
            for (auto& o : open) if (o.x0 == c.x0 && o.x1 == c.x1 && o.y1 == ty) { o.y1 = ty + 1; nopen.push_back(o); o.x0 = -1; merged = true; break; }
            if (!merged) nopen.push_back(c);
        }
        for (auto& o : open) if (o.x0 >= 0) done.push_back(o);
        open.swap(nopen);
    }
    for (auto& o : open) done.push_back(o);
    if (done.size() > 160) {   // слишком много кусочков — одним прямоугольником
        Run all{INT_MAX, -1, INT_MAX, -1};
        for (auto& r : done) { all.x0 = std::min(all.x0, r.x0); all.x1 = std::max(all.x1, r.x1); all.y0 = std::min(all.y0, r.y0); all.y1 = std::max(all.y1, r.y1); }
        done.assign(1, all);
    }
    for (auto& r : done) {
        RECT rc{r.x0 * T, r.y0 * T, std::min(gW, r.x1 * T), std::min(gH, r.y1 * T)};
        if (!gpu::upload(gPix, gW, rc)) return false;
    }
    return gpu::commit();
}
// отправить кадр на экран; false — кадр такой же, как прошлый, отправлять нечего
static bool presentFrame(bool checkSame) {
    const int T = 1 << kTileShift;
    int bx0 = INT_MAX, by0 = INT_MAX, bx1 = -1, by1 = -1;
    uint64_t h = 1469598103934665603ull;
    size_t nowCount = 0;
    for (int ty = 0; ty < gTH; ++ty)
        for (int tx = 0; tx < gTW; ++tx) {
            size_t k = (size_t)ty * gTW + tx;
            bool now = gTileNow[k], prev = gTilePrev[k];
            if (!now && !prev) continue;
            bx0 = std::min(bx0, tx); by0 = std::min(by0, ty);
            bx1 = std::max(bx1, tx); by1 = std::max(by1, ty);
            if (!now) { h = (h ^ (k * 2654435761u)) * 1099511628211ull; continue; }
            ++nowCount;
            h = (h ^ (k + 0x9e37)) * 1099511628211ull;
            if (!checkSame) continue;   // кадр точно новый — пиксели не сравниваем
            int x0 = tx * T, x1 = std::min(gW, x0 + T), y0 = ty * T, y1 = std::min(gH, y0 + T);
            for (int y = y0; y < y1; ++y) {
                const uint32_t* row = gPix + (size_t)y * gW;
                uint64_t acc = 0;
                for (int x = x0; x < x1; ++x) acc = acc * 31 + row[x];
                h = (h ^ acc) * 1099511628211ull;
            }
        }
    if (bx1 < 0) { gTilePrev.swap(gTileNow); gFrameHash = 0; return false; }   // ни сейчас, ни раньше ничего не было
    bool same = checkSame && h == gFrameHash;
    gFrameHash = checkSame ? h : 0;
    if (same) { gTilePrev.swap(gTileNow); return false; }
    if (gGpuOn) {
        bool ok = gpuPresentTiles();
        gTilePrev.swap(gTileNow);
        if (!ok) gpuFallback();
        return true;
    }
    gTilePrev.swap(gTileNow);
    RECT d{bx0 * T, by0 * T, std::min(gW, (bx1 + 1) * T), std::min(gH, (by1 + 1) * T)};
#ifdef SUGROB_PROF
    LARGE_INTEGER a0, a1; QueryPerformanceCounter(&a0);
#endif
    present(&d);
#ifdef SUGROB_PROF
    QueryPerformanceCounter(&a1);
    static double ms = 0, area = 0, tiles = 0; static int n = 0;
    ms += (a1.QuadPart - a0.QuadPart) * 1000.0 / gFreq.QuadPart;
    area += (double)(d.right - d.left) * (d.bottom - d.top) / ((double)gW * gH);
    tiles += (double)nowCount / ((double)gTW * gTH);
    if (++n >= 150) { alogFwd("prof present %.3f ms, dirty rect %.0f%%, drawn tiles %.0f%%", ms / n, area / n * 100, tiles / n * 100); ms = area = tiles = 0; n = 0; }
#endif
    return true;
}

// ---- частые кадры (больше 60 в секунду): обычный таймер Windows так часто не умеет,
// поэтому кадры отсчитывает отдельный поток — точным таймером или по обновлению экрана
#define WM_FASTTICK (WM_APP + 11)
#ifndef CREATE_WAITABLE_TIMER_HIGH_RESOLUTION
#define CREATE_WAITABLE_TIMER_HIGH_RESOLUTION 0x00000002
#endif
static volatile LONG gPaceQuit = 0, gTickPending = 0, gPaceUs = 0;   // gPaceUs = 0 — по кадрам монитора
static HANDLE gPaceThread = nullptr;
static DWORD WINAPI PaceThread(LPVOID) {
    HANDLE t = CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);
    bool hires = t != nullptr;
    if (!t) { t = CreateWaitableTimerW(nullptr, FALSE, nullptr); timeBeginPeriod(1); }
    LARGE_INTEGER f, next, now;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&next);
    while (!gPaceQuit) {
        LONG us = gPaceUs;
        if (us <= 0) {
            if (FAILED(DwmFlush())) Sleep(6);   // ждём, пока экран обновится
        } else {
            next.QuadPart += (LONGLONG)us * f.QuadPart / 1000000;
            QueryPerformanceCounter(&now);
            if (next.QuadPart < now.QuadPart) next = now;   // не успели — не копим долг
            LARGE_INTEGER due;
            due.QuadPart = -(LONGLONG)((next.QuadPart - now.QuadPart) * 10000000 / f.QuadPart);
            if (due.QuadPart < 0 && t && SetWaitableTimer(t, &due, 0, nullptr, nullptr, FALSE)) WaitForSingleObject(t, 100);
        }
        if (!InterlockedExchange(&gTickPending, 1)) PostMessageW(gMsgWnd, WM_FASTTICK, 0, 0);
    }
    if (t) CloseHandle(t);
    if (!hires) timeEndPeriod(1);
    return 0;
}
static void stopFastPace() {
    if (!gPaceThread) return;
    InterlockedExchange(&gPaceQuit, 1);
    WaitForSingleObject(gPaceThread, 300);
    CloseHandle(gPaceThread);
    gPaceThread = nullptr;
}
static void startFastPace(LONG us) {
    gPaceUs = us;
    if (gPaceThread) return;
    KillTimer(gMsgWnd, 1);
    gTickMs = 0;
    InterlockedExchange(&gPaceQuit, 0);
    InterlockedExchange(&gTickPending, 0);
    gPaceThread = CreateThread(nullptr, 0, PaceThread, nullptr, 0, nullptr);
    if (gPaceThread) SetThreadPriority(gPaceThread, THREAD_PRIORITY_ABOVE_NORMAL);
}

// частота обновления монитора (самого быстрого)
static int gMonitorHz = 60;
static BOOL CALLBACK HzEnum(HMONITOR m, HDC, LPRECT, LPARAM) {
    MONITORINFOEXW mi{};
    mi.cbSize = sizeof(mi);
    if (GetMonitorInfoW(m, &mi)) {
        DEVMODEW dm{};
        dm.dmSize = sizeof(dm);
        if (EnumDisplaySettingsW(mi.szDevice, ENUM_CURRENT_SETTINGS, &dm) && dm.dmDisplayFrequency > 1)
            gMonitorHz = std::max(gMonitorHz, (int)dm.dmDisplayFrequency);
    }
    return TRUE;
}
static void updateMonitorHz() {
    gMonitorHz = 1;
    EnumDisplayMonitors(nullptr, nullptr, HzEnum, 0);
    if (gMonitorHz < 30) gMonitorHz = 60;
}
static bool liteNow() { return gLightMode || (gOnBattery && gBatteryMode >= 1); }
static int effectiveFps() { int f = gFps > 0 ? gFps : gMonitorHz; return liteNow() ? std::min(f, 30) : f; }
// кадры для живых обоев: 0 — «как у монитора»
static int wpFps() { return liteNow() ? std::min(gFps > 0 ? gFps : gMonitorHz, 30) : gFps; }
static bool validFps(int f) { return f == 0 || f == 20 || f == 30 || f == 60 || f == 90 || f == 120 || f == 144 || f == 165 || f == 240; }

// шаг таймера: 30 кадров в секунду, когда что-то движется, реже — когда всё замерло
static void setPace(UINT ms) {
    if (gPaceThread) stopFastPace();
    if (ms == gTickMs || !gMsgWnd) return;
    // для 60 кадров нужен точный системный таймер — включаем его только на это время
    static bool fine = false;
    bool wantFine = ms < 30;
    if (wantFine != fine) { if (wantFine) timeBeginPeriod(1); else timeEndPeriod(1); fine = wantFine; }
    gTickMs = ms;
    SetTimer(gMsgWnd, 1, ms, nullptr);
}
static UINT activePace() { int f = effectiveFps(); return f >= 60 ? 16 : f <= 20 ? 50 : 33; }
// кадры, пока что-то движется: до 60 — обычным таймером, больше — отдельным потоком
static void applyActivePace() {
    int f = effectiveFps();
    if (f <= 60) { setPace(activePace()); return; }
    startFastPace(gFps > 0 ? 1000000 / gFps : 0);
}

// ================================================================ окна
static bool classIs(const wchar_t* cls, const wchar_t* name) { return wcscmp(cls, name) == 0; }

static bool petActive();
static bool holidayNeedsWindows();
static bool eligible(HWND h, WI& out) {
    if (h == gOverlay || h == gMsgWnd) return false;
    if (!IsWindowVisible(h) || IsIconic(h)) return false;
    wchar_t cls[96] = {0};
    GetClassNameW(h, cls, 95);
    bool tb = classIs(cls, L"Shell_TrayWnd") || classIs(cls, L"Shell_SecondaryTrayWnd");
    out.noSnow = tb ? !gCapsTaskbar : !gCapsOn;   // сугробы выключены пользователем
    if (out.noSnow && !petActive() && !holidayNeedsWindows()) return false;
#ifdef SUGROB_DEBUG
    if (classIs(cls, L"Notepad")) tb = true;
#endif
    if (!tb) {
        if (classIs(cls, L"Progman") || classIs(cls, L"WorkerW") ||
            classIs(cls, L"Windows.UI.Core.CoreWindow") || classIs(cls, L"#32768"))
            return false;
        LONG_PTR ex = GetWindowLongPtrW(h, GWL_EXSTYLE);
        if (ex & WS_EX_TOOLWINDOW) return false;
        if ((ex & WS_EX_TRANSPARENT) && (ex & WS_EX_LAYERED)) return false;
        if (GetWindowTextLengthW(h) == 0) return false;
    }
    RECT wr, r;
    if (!GetWindowRect(h, &wr)) return false;
    if (!tb && (wr.right - wr.left < 100 * S || wr.bottom - wr.top < 50 * S)) return false;
    // запросы к DWM — только для окон, прошедших дешёвые проверки
    DWORD cloaked = 0;
    if (SUCCEEDED(DwmGetWindowAttribute(h, DWMWA_CLOAKED, &cloaked, sizeof(cloaked))) && cloaked)
        return false;
    // DWM даёт рамку без невидимых краёв (Win10/11); если ответ странный — берём обычный
    if (FAILED(DwmGetWindowAttribute(h, DWMWA_EXTENDED_FRAME_BOUNDS, &r, sizeof(r))) ||
        r.left < wr.left - 2 || r.top < wr.top - 2 || r.right > wr.right + 2 || r.bottom > wr.bottom + 2 ||
        r.right - r.left < (wr.right - wr.left) / 2 || r.bottom - r.top < (wr.bottom - wr.top) / 2)
        r = wr;
    int w = r.right - r.left, hh = r.bottom - r.top;
    if (!tb && (w < 100 * S || hh < 50 * S)) return false;
    if (w <= 0 || hh <= 0) return false;

    out.h = h; out.r = r; out.tb = tb;
    out.topmost = (GetWindowLongPtrW(h, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0;
    out.zoomed = IsZoomed(h) != 0;
    out.round = false;
    if (!tb && !out.zoomed && gCornerR > 0) {
        // скругление окна почти не меняется — спрашиваем раз в 3 секунды
        struct CornerInfo { double t; bool round; };
        static std::unordered_map<HWND, CornerInfo> cache;
        auto it = cache.find(h);
        if (it == cache.end() || gTime - it->second.t > 3.0) {
            if (cache.size() > 400) cache.clear();
            DWORD pref = 0;   // 1 = DWMWCP_DONOTROUND
            bool round = !(SUCCEEDED(DwmGetWindowAttribute(h, SUGROB_DWMWA_WINDOW_CORNER_PREFERENCE, &pref, sizeof(pref))) && pref == 1);
            it = cache.insert_or_assign(h, CornerInfo{gTime, round}).first;
        }
        out.round = it->second.round;
    }
    return true;
}

static BOOL CALLBACK WinEnum(HWND h, LPARAM) {
    WI w;
    if (eligible(h, w)) gWins.push_back(w);
    return TRUE;
}

static void alogFwd(const char* fmt, ...);
static bool isFullscreenForeground() {
    if (!gHideFullscreen || gScrActive) return false;
    HWND f = GetForegroundWindow();
    bool fs = false;
    if (f && f != gOverlay) {
        wchar_t cls[96] = {0};
        GetClassNameW(f, cls, 95);
        if (!(classIs(cls, L"Progman") || classIs(cls, L"WorkerW") || classIs(cls, L"Shell_TrayWnd")) && !IsZoomed(f)) {
            // развёрнутое окно — не «на весь экран»: панель задач видна, прятать нечего
            RECT r;
            MONITORINFO mi{};
            mi.cbSize = sizeof(mi);
            if (GetWindowRect(f, &r) && GetMonitorInfoW(MonitorFromWindow(f, MONITOR_DEFAULTTONEAREST), &mi))
                fs = r.left <= mi.rcMonitor.left && r.top <= mi.rcMonitor.top &&
                     r.right >= mi.rcMonitor.right && r.bottom >= mi.rcMonitor.bottom;
        }
    }
    // так же, как Windows решает, прятать ли уведомления
    QUERY_USER_NOTIFICATION_STATE q = QUNS_ACCEPTS_NOTIFICATIONS;
    if (SUCCEEDED(SHQueryUserNotificationState(&q)) && (q == QUNS_RUNNING_D3D_FULL_SCREEN || q == QUNS_PRESENTATION_MODE)) fs = true;
    static bool last = false;
    if (fs != last) {
        last = fs;
        wchar_t cls[96] = {0}, title[96] = {0};
        RECT r{};
        if (f) { GetClassNameW(f, cls, 95); GetWindowTextW(f, title, 95); GetWindowRect(f, &r); }
        alogFwd("hide=%d (state %d): %ls «%ls» %ld,%ld,%ld,%ld zoomed=%d", fs, (int)q, cls, title, r.left, r.top, r.right, r.bottom, f ? (int)IsZoomed(f) : 0);
    }
    return fs;
}

// ================================================================ частицы
static void spawnClump(float x, float y, float r, float vx, float vy) {
    if (gP.size() >= kMaxParticles) return;
    P p{};
    p.x = x; p.y = y; p.r = r; p.vx = vx; p.vy = vy; p.a = 1.0f; p.clump = true; p.type = 1;
    gP.push_back(p);
}

// снежок разлетается на комья
static void burstBall(const Ball& b, float vxBias = 0, float vyBias = 0) {
    int cnt = (int)clampf(b.r / S * 1.4f, 5, 34);
    for (int i = 0; i < cnt; ++i) {
        float a = frange(0, 2 * PI);
        float sp = frange(40, 170) * S;
        spawnClump(b.x + std::cos(a) * b.r * 0.5f, b.y + std::sin(a) * b.r * 0.5f,
                   clampf(b.r * frange(0.12f, 0.3f), 1.0f * S, 3.6f * S),
                   std::cos(a) * sp + vxBias * 0.3f, std::sin(a) * sp - 80 * S + vyBias * 0.2f);
    }
}

static Ball* ballById(int id) {
    if (id < 0) return nullptr;
    for (auto& b : gBalls) if (b.id == id && !b.dead) return &b;
    return nullptr;
}

static Ball* ballAbove(int id) {
    for (auto& b : gBalls) if (!b.dead && b.state == B_REST && b.belowId == id) return &b;
    return nullptr;
}

static Ball& newBall(float x, float y, float r, int state) {
    if (gBalls.size() >= kMaxBalls) {   // выкидываем самый старый лежащий шар
        for (auto& b : gBalls)
            if (!b.dead && b.state == B_REST && !ballAbove(b.id)) { b.dead = true; burstBall(b); break; }
        gBalls.erase(std::remove_if(gBalls.begin(), gBalls.end(), [](const Ball& b) { return b.dead; }), gBalls.end());
    }
    Ball b{};
    b.id = gNextBallId++;
    b.x = x; b.y = y; b.r = r; b.state = state;
    b.belowId = -1; b.capH = nullptr;
    b.face = (xr() & 1) ? 1 : -1;
    gBalls.push_back(b);
    return gBalls.back();
}

// ================================================================ физика сугробов
static void shakeRange(Cap& c, int j0, int j1, float pushX) {
    if (gSeason != 0) return;
    j0 = std::max(j0, 0);
    j1 = std::min(j1, c.n());
    for (int j = j0; j < j1; j += 3) {
        float mass = 0;
        int cnt = 0;
        bool vis = false;
        for (int k = j; k < std::min(j + 3, j1); ++k) {
            mass += c.d[k]; ++cnt;
            if (k < (int)c.vis.size() && c.vis[k]) vis = true;
        }
        if (!vis || mass * CW < 3.0f * S) continue;
        float avg = mass / cnt;
        float x = c.r.left + (j + 1.5f) * CW;
        float rr = clampf(std::sqrt(mass * CW / PI) * 0.75f, 1.0f * S, 3.4f * S);
        spawnClump(x + frange(-1, 1), c.edgeY(j) - avg * 0.5f, rr,
                   pushX + frange(-35, 35) * S, frange(-90, 5) * S);
    }
}

// шары, лежащие на окне, слетают
static void releaseBallsOn(Cap& c, int j0, int j1) {
    for (auto& b : gBalls) {
        if (b.dead || b.state != B_REST || b.belowId >= 0 || b.capH != c.h) continue;
        int j = (int)((b.x - c.r.left) / CW);
        if (j < j0 || j >= j1) continue;
        b.state = B_FLY;
        b.vx = frange(-60, 60) * S;
        b.vy = frange(-160, -40) * S;
        b.capH = nullptr;
    }
}

static void seasonShake(Cap& c, float pushX);
static void shakeAll(Cap& c, float pushX = 0) {
    if (gSeason != 0) {   // не зима: листья/лепестки/цветы слетают, трава отрастёт заново
        seasonShake(c, pushX);
        std::fill(c.d.begin(), c.d.end(), 0.0f);
        return;
    }
    shakeRange(c, 0, c.n(), pushX);
    releaseBallsOn(c, INT_MIN, INT_MAX);
    std::fill(c.d.begin(), c.d.end(), 0.0f);
}

static void relax(Cap& c, int j) {
    int n = c.n();
    if (n == 0) return;
    int lo = std::max(0, j - 18), hi = std::min(n - 1, j + 18);
    const float repose = CW * 0.45f;
    for (int it = 0; it < 6; ++it) {
        for (int k = lo; k < hi; ++k) {
            float diff = c.d[k] - c.d[k + 1];
            if (diff > repose) {
                float m = (diff - repose) * 0.5f;
                c.d[k] -= m; c.d[k + 1] += m;
            } else if (-diff > repose) {
                float m = (-diff - repose) * 0.5f;
                c.d[k + 1] -= m; c.d[k] += m;
            }
        }
    }
    float md = maxDepth(c);
    for (int k = lo; k <= hi; ++k) {
        float edge = (std::min(k, n - 1 - k) + 0.6f) * CW * 0.9f + 0.6f;
        float lim = std::min(md, edge);
        if (c.d[k] > lim) c.d[k] = lim;
    }
}

static void deposit(Cap& c, int j, float amt) {
    // снег ложится мягким бугорком на несколько ячеек
    static const float w[9] = {0.03f, 0.07f, 0.12f, 0.17f, 0.22f, 0.17f, 0.12f, 0.07f, 0.03f};
    int n = c.n();
    for (int k = -4; k <= 4; ++k) {
        int t = j + k;
        if (t >= 0 && t < n) c.d[t] += amt * w[k + 4];
    }
    relax(c, j);
}

static void computeBase(Cap& c) {
    int n = c.n();
    c.base.assign(n, 0.0f);
    float R = c.roundR;
    if (R <= 0) return;
    float width = (float)(c.r.right - c.r.left);
    for (int j = 0; j < n; ++j) {
        float xc = (j + 0.5f) * CW;
        float dx = std::min(xc, width - xc);
        if (dx < R) {
            float t = R - dx;
            c.base[j] = R - std::sqrt(std::max(0.0f, R * R - t * t));
        }
    }
}

static bool holidayNeedsWindows();
static void gatherWindows(float dt) {
    gWins.clear();
    if (anyCaps() || holidayNeedsWindows() || petActive()) EnumWindows(WinEnum, 0);

    for (auto& kv : gCaps) kv.second.seen = false;
    gCapPtr.assign(gWins.size(), nullptr);

    for (size_t i = 0; i < gWins.size(); ++i) {
        const WI& w = gWins[i];
        int n = std::max(1, (int)((w.r.right - w.r.left) / CW));
        float wantR = w.round ? gCornerR : 0.0f;
        auto it = gCaps.find(w.h);
        if (it == gCaps.end()) {
            Cap c;
            c.h = w.h;
            c.r = w.r; c.taskbar = w.tb;
            c.d.assign(n, 0.0f); c.vis.assign(n, 0);
            c.manDelay = frange(6, 18);
            c.roundR = wantR;
            computeBase(c);
            it = gCaps.emplace(w.h, std::move(c)).first;
        } else {
            Cap& c = it->second;
            if (c.r.top != w.r.top || c.r.left != w.r.left) {
                float push = (float)((w.r.left - c.r.left) / std::max(dt, 0.016f)) * 0.25f;
                push = clampf(push, -400 * S, 400 * S);
                shakeAll(c, push);
                c.r = w.r;
                c.d.assign(n, 0.0f);
                c.vis.assign(n, 0);
                c.roundR = wantR;
                computeBase(c);
            } else if (c.r.right != w.r.right || c.roundR != wantR) {
                if (n < c.n()) {
                    shakeRange(c, n - 8, c.n(), 0);
                    releaseBallsOn(c, n - 8, INT_MAX);
                }
                c.d.resize(n, 0.0f);
                c.vis.resize(n, 0);
                c.r = w.r;
                c.roundR = wantR;
                computeBase(c);
                for (int k = std::max(0, n - 10); k < n; ++k) c.d[k] = 0;   // у нового правого угла
                if (n > 0) relax(c, n - 1);
            } else {
                c.r = w.r;
            }
            c.zoomed = w.zoomed;
        }
        it->second.seen = true;
        it->second.taskbar = w.tb;
        if (w.noSnow && !it->second.noSnow) {   // сугробы выключили — всё с окна осыпается
            shakeAll(it->second);
            it->second.decor.clear(); it->second.flowers.clear();
        }
        it->second.noSnow = w.noSnow;
        gCapPtr[i] = &it->second;
    }

    // окна, которые закрыли/свернули — снег осыпается
    for (auto it = gCaps.begin(); it != gCaps.end();) {
        if (!it->second.seen) {
            shakeAll(it->second);
            it = gCaps.erase(it);
        } else ++it;
    }

    // видимость ячеек: в пределах монитора и не закрыто окнами выше по Z
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap& c = *gCapPtr[i];
        int n = c.n();
        std::fill(c.vis.begin(), c.vis.end(), 0);
        LONG top = c.r.top, left = c.r.left;
        auto mark = [&](LONG a, LONG b, uint8_t v) {
            int j0 = (int)std::floor((double)(a - left) / CW);
            int j1 = (int)std::ceil((double)(b - left) / CW);
            j0 = std::max(j0, 0); j1 = std::min(j1, n);
            for (int j = j0; j < j1; ++j) c.vis[j] = v;
        };
        for (const RECT& m : gMons)
            if (top - 1 >= m.top && top - 1 < m.bottom)
                mark(std::max(left, m.left), std::min(c.r.right, m.right), 1);
        for (size_t k = 0; k < i; ++k) {
            const RECT& a = gWins[k].r;
            if (c.taskbar) {   // панель задач всегда поверх обычных окон
                if (!gWins[k].topmost || gWins[k].tb) continue;
                if (!(a.top < top && a.bottom > top + 1)) continue;
            } else if (!(a.top < top + 2 && a.bottom > top - 2)) continue;
            mark(std::max(left, a.left), std::min(c.r.right, a.right), 0);
        }
    }
}

// какой сугроб под точкой (x) — первый сверху по Z, видимый
static bool capAt(float x, Cap*& out, int& j) {
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->noSnow) continue;
        if (x < c->r.left || x >= c->r.right) continue;
        int k = (int)((x - c->r.left) / CW);
        if (k < 0 || k >= c->n() || !c->vis[k]) continue;
        out = c; j = k;
        return true;
    }
    return false;
}

// то же, но выбирает окно, у верхнего края которого сейчас курсор (панель задач не перекрывает остальные)
static bool capAtXY(float x, float y, Cap*& out, int& j) {
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->noSnow) continue;
        if (x < c->r.left || x >= c->r.right) continue;
        int k = (int)((x - c->r.left) / CW);
        if (k < 0 || k >= c->n() || !c->vis[k]) continue;
        float edge = c->edgeY(k);
        if (y < edge - c->d[k] - 14 * S || y > edge + 6 * S) continue;
        out = c; j = k;
        return true;
    }
    return false;
}

// проверка, упала ли частица на сугроб
static bool collide(P& p, float yPrev) {
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || c->noSnow) continue;
        const RECT& r = c->r;
        if (p.x < r.left || p.x >= r.right) continue;
        int j = (int)((p.x - r.left) / CW);
        if (j < 0 || j >= c->n() || !c->vis[j]) continue;
        float surf = c->edgeY(j) - c->d[j];
        float b0 = yPrev + p.r * 0.5f, b1 = p.y + p.r * 0.5f;
        if (b0 <= surf && b1 > surf) {
            float amt = p.clump ? p.r * p.r * 0.55f / S : p.r * 0.85f;
            deposit(*c, j, amt * frange(0.7f, 1.3f));
            return true;
        }
    }
    return false;
}

// погода и обои — определены дальше (features.h)
static float weatherWindX();
static bool weatherThunderNow();
static void wpFlash();
// интернет-радио (extras.h)
static void radioStop();
static void radioVolume();
static void radioSetPaused(bool p);
static std::string radioTitle();
#include "seasons.h"
#include "holidays.h"
#include "pet.h"
#include "sky.h"

static void spawnFlakes(float dt) {
    if (gSeason != SEA_WINTER) { seasonSpawn(dt); return; }
    static float acc = 0;
    if (!gSnowOn) { acc = 0; return; }
    float rate = 38.0f * std::pow(gIntensityPct / 50.0f, 1.4f) * (gW / 1000.0f) / S;
    acc += rate * dt;
    float blizz = gIntensityPct > 75 ? 1.35f : 1.0f;
    while (acc >= 1.0f) {
        acc -= 1.0f;
        if (gP.size() >= kMaxParticles) continue;
        P p{};
        float z = frand();
        p.z = z;
        p.r = (0.7f + 2.1f * z * z) * S;
        p.a = 0.45f + 0.5f * z;
        p.x = gVX + frange(-150 * S, gW + 150 * S);
        p.y = gVY - p.r - frange(0, 20);
        p.vy = (22 + 50 * z) * S * blizz;
        p.amp = frange(5, 16) * S;
        p.freq = frange(0.5f, 1.4f);
        p.ph = frange(0, 6.283f);
        p.clump = false;
        gP.push_back(p);
    }
}

static void updateParticles(float dt) {
    float wind = baseWind();
    float bottom = (float)(gVY + gH);
    size_t w = 0;
    for (size_t i = 0; i < gP.size(); ++i) {
        P p = gP[i];
        if (p.type >= T_LEAF) {
            if (!seasonUpdateP(p, dt, wind)) gP[w++] = p;
            continue;
        }
        float yPrev = p.y;
        if (p.clump) {
            p.vy += 950 * S * dt;
            p.vx *= (1.0f - 0.8f * dt);
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        } else {
            p.ph += p.freq * dt * 6.283f * 0.35f;
            p.x += (wind * (0.4f + 0.8f * p.z) + std::cos(p.ph) * p.amp * p.freq) * dt;
            p.y += p.vy * dt;
        }
        bool dead = false;
        if (p.y - p.r > bottom || p.x < gVX - 300 * S || p.x > gVX + gW + 300 * S) dead = true;
        else if (anyCaps() && collide(p, yPrev)) dead = true;
        if (!dead) gP[w++] = p;
    }
    gP.resize(w);
}

// ================================================================ снежки и снеговики
static void addSplat(float x, float y, float r) {
    if (gSplats.size() >= 30) gSplats.erase(gSplats.begin());
    gSplats.push_back({x, y, r, 0.0f, xr()});
}

// попробовать набрать снег из сугроба в точке (x,y); возвращает радиус снежка
static float scoopAt(float x, float y) {
    Cap* c; int j;
    if (!capAtXY(x, y, c, j)) return 0;
    float surf = c->surfY(j), edge = c->edgeY(j);
    if (y < surf - 4 * S || y > edge + 2 * S || c->d[j] < 1.5f * S) return 0;
    float area = 0;
    int R = (int)(7 * S);
    for (int k = j - R; k <= j + R; ++k) {
        if (k < 0 || k >= c->n() || !c->vis[k]) continue;
        float fall = 1.0f - std::fabs((float)(k - j)) / (R + 1);
        float take = c->d[k] * clampf(fall * 1.6f, 0.0f, 1.0f);
        c->d[k] -= take;
        area += take * CW;
    }
    relax(*c, j);
    if (area < 12 * S * S) return 0;
    return std::max(4.0f * S, std::sqrt(area / PI) * 1.15f);
}

// по шару в точке — для подбора
static Ball* ballAtPoint(float x, float y) {
    Ball* best = nullptr;
    for (auto& b : gBalls) {
        if (b.dead || b.state != B_REST) continue;
        float dx = x - b.x, dy = y - b.y;
        if (dx * dx + dy * dy <= (b.r + 2 * S) * (b.r + 2 * S))
            if (!best || b.y < best->y) best = &b;   // верхний из стопки
    }
    return best;
}

static bool snowAtPoint(float x, float y) {
    Cap* c; int j;
    if (!capAtXY(x, y, c, j)) return false;
    return c->d[j] >= 1.5f * S && y >= c->surfY(j) - 4 * S && y <= c->edgeY(j) + 2 * S;
}

// хук мыши: ловим нажатия только по снегу, всё остальное проходит как обычно
static LRESULT CALLBACK MouseHook(int code, WPARAM wp, LPARAM lp) {
    if (code == HC_ACTION && gInteract && !gHiddenFS && gPix) {
        auto* m = (MSLLHOOKSTRUCT*)lp;
        float x = (float)m->pt.x, y = (float)m->pt.y;
        switch (wp) {
        case WM_LBUTTONDOWN: {
            if (gSeason != SEA_WINTER) {
                if (seasonMouseDown(x, y)) { gSwallowLUp = true; return 1; }
                break;
            }
            if (gHeldId >= 0) break;
            Ball* b = ballAtPoint(x, y);
            if (b) {
                b->state = B_HELD;
                b->belowId = -1; b->capH = nullptr;
                gHeldId = b->id;
            } else if (snowAtPoint(x, y)) {
                float r = scoopAt(x, y);
                if (r <= 0) break;
                gHeldId = newBall(x, y, r, B_HELD).id;
            } else break;
            gHeldVX = gHeldVY = 0;
            gHeldPrev = m->pt;
            gSwallowLUp = true;
            return 1;
        }
        case WM_LBUTTONUP:
            gRaking = false;
            if (gSwallowLUp) {
                gSwallowLUp = false;
                if (Ball* b = ballById(gHeldId)) {
                    b->state = B_FLY;
                    b->x = x; b->y = y;
                    b->vx = clampf(gHeldVX, -2600 * S, 2600 * S);
                    b->vy = clampf(gHeldVY, -2600 * S, 2600 * S);
                }
                gHeldId = -1;
                return 1;
            }
            break;
        case WM_RBUTTONDOWN:
            if (gHeldId >= 0) {   // бросок прямо в экран
                if (Ball* b = ballById(gHeldId)) {
                    addSplat(x, y, std::max(14.0f * S, b->r * 1.8f));
                    b->dead = true;
                }
                gHeldId = -1;
                gSwallowRUp = true;
                // кнопку левую ещё держат — её отпускание тоже проглотим (gSwallowLUp остаётся)
                return 1;
            }
            break;
        case WM_RBUTTONUP:
            if (gSwallowRUp) { gSwallowRUp = false; return 1; }
            break;
        }
    }
    return CallNextHookEx(gMouseHook, code, wp, lp);
}

static void setHook(bool on) {
    if (on && !gMouseHook)
        gMouseHook = SetWindowsHookExW(WH_MOUSE_LL, MouseHook, gInst, 0);
    else if (!on && gMouseHook) {
        UnhookWindowsHookEx(gMouseHook);
        gMouseHook = nullptr;
        if (Ball* b = ballById(gHeldId)) { b->state = B_FLY; b->vx = b->vy = 0; }
        gHeldId = -1;
        gSwallowLUp = gSwallowRUp = false;
    }
}

static void splatBallOnCap(Ball& b, Cap* c, int j) {
    if (c) deposit(*c, j, PI * b.r * b.r * 0.35f / CW);
    burstBall(b, b.vx, 0);
    b.dead = true;
}

static void updateBalls(float dt) {
    // держим в руке: следует за курсором и катится по снегу
    if (Ball* h = ballById(gHeldId)) {
        POINT pt;
        GetCursorPos(&pt);
        float ivx = (pt.x - gHeldPrev.x) / std::max(dt, 0.001f);
        float ivy = (pt.y - gHeldPrev.y) / std::max(dt, 0.001f);
        gHeldVX = gHeldVX * 0.45f + ivx * 0.55f;
        gHeldVY = gHeldVY * 0.45f + ivy * 0.55f;
        gHeldPrev = pt;
        h->x = (float)pt.x; h->y = (float)pt.y;
        // налипание снега
        float grow = 0;
        for (size_t i = 0; i < gWins.size(); ++i) {
            Cap* c = gCapPtr[i];
            if (!c || c->noSnow) continue;
            if (h->x + h->r < c->r.left || h->x - h->r >= c->r.right) continue;
            int j0 = std::max(0, (int)((h->x - h->r - c->r.left) / CW));
            int j1 = std::min(c->n() - 1, (int)((h->x + h->r - c->r.left) / CW));
            for (int j = j0; j <= j1; ++j) {
                if (!c->vis[j] || c->d[j] <= 0.3f) continue;
                float surf = c->edgeY(j) - c->d[j];
                float bottom = h->y + h->r;
                if (bottom > surf && h->y < c->edgeY(j)) {
                    float take = std::min(c->d[j], (bottom - surf) * 0.35f);
                    c->d[j] -= take;
                    grow += take * CW;
                }
            }
        }
        if (grow > 0) h->r = std::min(30.0f * S, std::sqrt(h->r * h->r + grow / PI * 0.9f));
    } else {
        gHeldId = -1;
    }

    // лежащие: пересчитать позицию снизу вверх
    for (auto& b : gBalls) {
        if (b.dead || b.state != B_REST || b.belowId >= 0) continue;
        Cap* c = findCap(b.capH);
        if (!c) { b.state = B_FLY; b.vx = b.vy = 0; continue; }
        b.x = c->r.left + b.relX;
        int j = (int)(b.relX / CW);
        if (j < 0 || j >= c->n()) { b.state = B_FLY; b.vx = b.vy = 0; continue; }
        b.y = c->surfY(j) - b.r * 0.8f;
    }
    for (int pass = 0; pass < 6; ++pass) {
        for (auto& b : gBalls) {
            if (b.dead || b.state != B_REST || b.belowId < 0) continue;
            Ball* d = ballById(b.belowId);
            if (!d || d->state != B_REST) { b.state = B_FLY; b.vx = 0; b.vy = 0; b.belowId = -1; continue; }
            b.x = d->x + b.relX;
            b.y = d->y - d->r - b.r * 0.78f;
        }
    }

    // тает, если снегопад выключен
    if (!gSnowOn) {
        for (auto& b : gBalls) {
            if (b.dead || b.state == B_HELD) continue;
            b.r -= 0.3f * S * dt;
            if (b.r < 1.5f * S) b.dead = true;
        }
    }

    // летящие
    float bottom = (float)(gVY + gH);
    for (size_t bi = 0; bi < gBalls.size(); ++bi) {
        Ball& b = gBalls[bi];
        if (b.dead || b.state != B_FLY) continue;
        float y0 = b.y;
        b.vy += 950 * S * dt;
        b.vx *= (1.0f - 0.25f * dt);
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        float speedOk = (b.vy < 650 * S && std::fabs(b.vx) < 380 * S);

        // края экрана: отскок или плевок по стеклу
        float L = (float)gVX + b.r, Rr = (float)(gVX + gW) - b.r;
        if (b.x < L || b.x > Rr) {
            if (std::fabs(b.vx) > 700 * S) {
                addSplat(b.x < L ? (float)gVX + b.r * 0.6f : (float)(gVX + gW) - b.r * 0.6f, b.y, b.r * 1.5f + 4 * S);
                b.dead = true;
                continue;
            }
            b.x = clampf(b.x, L, Rr);
            b.vx = -b.vx * 0.45f;
        }
        if (b.y - b.r > bottom) { b.dead = true; continue; }

        // на другой лежащий шар
        bool done = false;
        if (b.vy > 0) {
            for (auto& o : gBalls) {
                if (o.dead || o.state != B_REST || o.id == b.id) continue;
                float dx = b.x - o.x, dy = b.y - o.y;
                float rr = (b.r + o.r) * 0.92f;
                if (dx * dx + dy * dy < rr * rr && b.y < o.y) {
                    if (speedOk) {
                        Ball* top = &o;
                        while (Ball* a = ballAbove(top->id)) top = a;
                        b.state = B_REST;
                        b.belowId = top->id;
                        b.relX = clampf(b.x - top->x, -top->r * 0.5f, top->r * 0.5f) * 0.25f;
                        b.vx = b.vy = 0;
                    } else {
                        burstBall(b, b.vx, 0);
                        b.dead = true;
                    }
                    done = true;
                    break;
                }
            }
        }
        if (done) continue;

        // на сугроб
        if (b.vy > 0) {
            Cap* c; int j;
            if (capAt(b.x, c, j)) {
                float surf = c->surfY(j);
                float b0 = y0 + b.r * 0.8f, b1 = b.y + b.r * 0.8f;
                if (b0 <= surf + 1 && b1 > surf) {
                    if (speedOk) {
                        b.state = B_REST;
                        b.capH = c->h;
                        b.relX = b.x - c->r.left;
                        b.belowId = -1;
                        b.vx = b.vy = 0;
                    } else {
                        splatBallOnCap(b, c, j);
                    }
                }
            }
        }
    }

    gBalls.erase(std::remove_if(gBalls.begin(), gBalls.end(), [](const Ball& b) { return b.dead; }), gBalls.end());

    for (auto& s : gSplats) s.age += dt;
    gSplats.erase(std::remove_if(gSplats.begin(), gSplats.end(), [](const Splat& s) { return s.age > 9.0f; }), gSplats.end());
}

static int stackBaseCount(const Cap& c, bool onlyAuto) {
    int n = 0;
    for (auto& b : gBalls)
        if (!b.dead && b.state == B_REST && b.belowId < 0 && b.capH == c.h && (!onlyAuto || b.autoMan)) ++n;
    return n;
}

static void spawnAutoSnowman(Cap& c, float mx) {
    float sc = frange(0.85f, 1.15f) * S;
    Ball& b1 = newBall(mx, 0, 5.6f * sc, B_REST);
    b1.capH = c.h; b1.relX = mx - c.r.left; b1.autoMan = true;
    int id1 = b1.id;
    Ball& b2 = newBall(mx, 0, 4.1f * sc, B_REST);
    b2.belowId = id1; b2.relX = 0; b2.autoMan = true;
    int id2 = b2.id;
    Ball& b3 = newBall(mx, 0, 3.0f * sc, B_REST);
    b3.belowId = id2; b3.relX = 0; b3.autoMan = true;
}

static void updateCapsTime(float dt) {
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap& c = *gCapPtr[i];
        if (c.noSnow) continue;
        int n = c.n();
        float md = maxDepth(c);

        if (gSeason != SEA_WINTER) { capGrow(c, dt); continue; }
        if (!gSnowOn) {   // снег тает
            float melt = 0.9f * S * dt;
            for (float& v : c.d) v = std::max(0.0f, v - melt);
        }

        float sum = 0; int visN = 0;
        for (int j = 0; j < n; ++j) if (c.vis[j]) { sum += c.d[j]; ++visN; }
        float avg = visN ? sum / visN : 0;

        if (!gMenOn || !gSnowOn) continue;
        int maxMen = (visN * CW > 900 * S) ? 2 : 1;
        if (visN * CW > 170 * S && avg > 0.72f * md && stackBaseCount(c, true) < maxMen) {
            c.manTimer += dt;
            if (c.manTimer >= c.manDelay) {
                c.manTimer = 0;
                c.manDelay = frange(10, 30);
                int margin = (int)(14 * S / CW) + 2;
                for (int tries = 0; tries < 12; ++tries) {
                    int j = margin + (int)(frand() * std::max(1, n - 2 * margin));
                    if (j - margin < 0 || j + margin >= n) continue;
                    bool ok = true;
                    for (int k = j - margin; k <= j + margin; ++k)
                        if (!c.vis[k] || c.d[k] < 0.6f * md) { ok = false; break; }
                    float mx = c.r.left + (j + 0.5f) * CW;
                    for (auto& b : gBalls)
                        if (!b.dead && b.state == B_REST && b.belowId < 0 && b.capH == c.h &&
                            std::fabs(b.x - mx) < 60 * S) ok = false;
                    if (ok) { spawnAutoSnowman(c, mx); break; }
                }
            }
        }
    }
}

// ================================================================ бульдозер
static Cap* dozerCap() {
    for (size_t i = 0; i < gWins.size(); ++i) {
        Cap* c = gCapPtr[i];
        if (!c || !c->taskbar || c->noSnow) continue;
        int w = c->r.right - c->r.left, h = c->r.bottom - c->r.top;
#ifndef SUGROB_DEBUG
        if (w < h * 3) continue;   // вертикальная панель — не катаемся
#endif
        int v = 0;
        for (auto x : c->vis) v += x;
        if (v * CW < 200 * S) continue;
        return c;
    }
    return nullptr;
}

static bool dozerMows() { return gSeason == SEA_SPRING || gSeason == SEA_SUMMER; }

// комок снега или подброшенный лист — смотря по сезону
static void spawnPileBit(float x, float y, float r, float vx, float vy) {
    if (gSeason == SEA_AUTUMN) {
        if (gP.size() >= kMaxParticles) return;
        P p = makeP(T_LEAF);
        p.r = frange(3.0f, 5.2f) * S; p.col = (uint8_t)(xr() % 5);
        p.x = x; p.y = y; p.vx = vx; p.vrot = std::min(vy, -60 * S); p.life = -1;
        p.vy = frange(30, 55) * S; p.amp = frange(25, 50) * S; p.freq = frange(0.35f, 0.7f);
        p.ph = frange(0, 6.28f); p.rot = frange(0, 6.28f); p.z = frand();
        gP.push_back(p);
    } else spawnClump(x, y, r, vx, vy);
}

static void dumpPile(float x, float y, int dir) {
    float area = gDozer.pile;
    int cnt = (int)clampf(area / (6 * S * S), 0, 60);
    if (gSeason == SEA_AUTUMN) cnt = std::min(cnt, 35);
    for (int i = 0; i < cnt; ++i)
        spawnPileBit(x + frange(-4, 4) * S, y - frange(0, 10) * S, frange(1.4f, 3.4f) * S,
                     dir * frange(30, 140) * S, frange(-120, 0) * S);
    gDozer.pile = 0;
}

static void updateDozer(float dt) {
    const float D = 1.25f * S;   // масштаб бульдозера
    for (auto& p : gPuffs) { p.age += dt; p.y -= 14 * S * dt; p.r += 3 * S * dt; p.x -= gDozer.dir * 6 * S * dt; }
    gPuffs.erase(std::remove_if(gPuffs.begin(), gPuffs.end(), [](const Puff& p) { return p.age > 1.3f; }), gPuffs.end());

    Cap* c = dozerCap();
    if (!gDozer.active) {
        gDozer.cooldown -= dt;
        gDozerTimer += dt;
        if (!c) { gDozerRequested = false; return; }
        bool go = gDozerRequested;
        if (!go && gDozerOn && gDozerEvery > 0 && gDozerTimer >= gDozerEvery) go = true;
        if (!go && gDozerOn && gDozerEvery == 0 && gDozer.cooldown <= 0) {
            float sum = 0; int v = 0;
            for (int j = 0; j < c->n(); ++j) if (c->vis[j]) { sum += c->d[j]; ++v; }
            if (v && sum / v > (dozerMows() ? 0.8f : 0.5f) * maxDepth(*c)) go = true;
        }
        if (!go) return;
        gDozerRequested = false;
        gDozerTimer = 0;
        gDozer.active = true;
        gDozer.dir = gDozerNextDir;
        gDozerNextDir = -gDozerNextDir;
        gDozer.x = gDozer.dir > 0 ? c->r.left - 40 * S : c->r.right + 40 * S;
        gDozer.pile = 0;
        gDozer.dumped = false;
        gDozer.capH = c->h;
        return;
    }
    if (!c || c->h != gDozer.capH) { gDozer.active = false; gDozer.pile = 0; return; }

    int dir = gDozer.dir;
    float front0 = gDozer.x + dir * 16.5f * D;
    gDozer.x += dir * 75 * S * dt;
    float front = gDozer.x + dir * 16.5f * D;
    float rear = gDozer.x - dir * 13 * D;

    // сгребаем снег: всё, что под отвалом и корпусом
    float lo = std::min(rear, front), hi = std::max(rear, front);
    lo = std::min(lo, std::min(front0, front));
    hi = std::max(hi, std::max(front0, front));
    int j0 = std::max(0, (int)((lo - c->r.left) / CW));
    int j1 = std::min(c->n() - 1, (int)((hi - c->r.left) / CW));
    if (dozerMows()) {   // газонокосилка: стрижёт траву, цветы — в лепестки, обрезки летят
        bool cut = false;
        for (int j = j0; j <= j1; ++j)
            if (c->d[j] > 1.2f * S) { c->d[j] = 1.0f * S; cut = true; }
        for (size_t fi = 0; fi < c->flowers.size();) {
            float fx = c->r.left + c->flowers[fi].rx;
            if (fx >= lo && fx <= hi) popFlower(*c, fi); else ++fi;
        }
        c->decor.erase(std::remove_if(c->decor.begin(), c->decor.end(), [&](const Decor& d) {
            float x = c->r.left + d.rx; return x >= lo && x <= hi; }), c->decor.end());
        if (cut && gP.size() < kMaxParticles) {
            for (int k = 0; k < 2; ++k) {
                P p = makeP(T_BIT);
                p.col = (uint8_t)(17 + xr() % 2);
                p.x = rear; p.y = (float)c->r.top - 3 * S;
                p.vx = -dir * frange(40, 160) * S; p.vy = frange(-240, -90) * S;
                p.vrot = frange(-14, 14); p.life = 1.4f;
                gP.push_back(p);
            }
        }
    } else
    for (int j = j0; j <= j1; ++j) {
        gDozer.pile += c->d[j] * CW;
        c->d[j] = 0;
    }
    if (gSeason == SEA_AUTUMN)
        c->decor.erase(std::remove_if(c->decor.begin(), c->decor.end(), [&](const Decor& d) {
            float x = c->r.left + d.rx; return x >= lo && x <= hi; }), c->decor.end());
    // снеговики и снежки на пути — в сторону
    for (auto& b : gBalls) {
        if (b.dead || b.state != B_REST || b.belowId >= 0 || b.capH != c->h) continue;
        if ((dir > 0 && b.x > front - b.r && b.x < front + b.r) || (dir < 0 && b.x < front + b.r && b.x > front - b.r)) {
            b.state = B_FLY; b.capH = nullptr;
            b.vx = dir * frange(250, 420) * S; b.vy = frange(-380, -220) * S;
        }
    }
    float maxPile = PI * (15 * S) * (15 * S);
    if (gDozer.pile > maxPile) {   // куча слишком большая — сыплется через край
        float extra = gDozer.pile - maxPile;
        gDozer.pile = maxPile;
        int cnt = (int)std::min(6.0f, extra / (5 * S * S));
        for (int i = 0; i < cnt; ++i)
            spawnPileBit(front + dir * frange(4, 12) * S, c->r.top - frange(14, 22) * S, frange(1.2f, 2.6f) * S,
                         dir * frange(20, 90) * S, frange(-140, -60) * S);
    }
    // доехал до края
    bool past = dir > 0 ? front > c->r.right : front < c->r.left;
    if (past && !gDozer.dumped && !dozerMows()) {
        dumpPile(dir > 0 ? (float)c->r.right : (float)c->r.left, (float)c->r.top, dir);
        gDozer.dumped = true;
    }
    bool gone = dir > 0 ? rear > c->r.right + 10 * S : rear < c->r.left - 10 * S;
    if (gone) {
        gDozer.active = false;
        gDozer.cooldown = dozerMows() ? 120 : 45;
        gDozerTimer = 0;
        gDozer.pile = 0;
    }
    // дымок из трубы
    gDozer.puffT += dt;
    if (gDozer.puffT > 0.16f) {
        gDozer.puffT = 0;
        gPuffs.push_back({gDozer.x + dir * 4.7f * D, c->r.top - 18 * D, 1.6f * D, 0});
    }
}

static void drawDozer() {
    if (!gDozer.active) return;
    const float D = 1.25f * S;
    Cap* c = findCap(gDozer.capH);
    if (!c) return;
    int dir = gDozer.dir;
    float gx = gDozer.x - gVX;
    float gy = (float)(c->r.top - gVY);
    auto X = [&](float lx) { return gx + dir * lx * D; };
    auto Y = [&](float ly) { return gy + ly * D; };
    auto rect = [&](float lx0, float ly0, float lx1, float ly1, float R, float G, float B) {
        fillRect(X(lx0), Y(ly0), X(lx1), Y(ly1), R, G, B);
    };
    gClipY = (int)gy + 1;
    // дым
    for (auto& p : gPuffs)
        drawDisc(p.x - gVX, p.y - gVY, p.r, 205, 205, 210, 0.28f * (1.0f - p.age / 1.3f), 1.5f, 0);
    if (dozerMows()) {   // газонокосилка с водителем
        drawDisc(X(-7), Y(-4.6f), 4.6f * D, 38, 38, 42, 1, 1, 0);
        drawDisc(X(-7), Y(-4.6f), 1.7f * D, 160, 160, 165, 1, 1, 0);
        drawDisc(X(9), Y(-3.0f), 3.0f * D, 38, 38, 42, 1, 1, 0);
        drawDisc(X(9), Y(-3.0f), 1.1f * D, 160, 160, 165, 1, 1, 0);
        rect(-6, -3.4f, 11, -0.6f, 28, 92, 40);                 // дека с ножами
        rect(-3, -10, 13, -4.2f, 64, 176, 72);                  // корпус
        rect(-3, -10, 13, -9.0f, 120, 214, 120);                // блик
        rect(12, -9, 13.6f, -5, 30, 60, 30);                    // решётка
        rect(-10, -12.5f, -3, -9.5f, 30, 30, 32);               // сиденье
        rect(-11, -17, -9.4f, -10, 30, 30, 32);                 // спинка
        drawLine(X(3), Y(-10), X(0.5f), Y(-16), 0.6f * D, 40, 40, 44, 0.9f);
        drawLine(X(-1.2f), Y(-16.3f), X(2.4f), Y(-16.6f), 0.6f * D, 40, 40, 44, 0.9f);
        rect(-8.5f, -18.5f, -4.5f, -12, 66, 120, 210);          // водитель
        drawLine(X(-5), Y(-17), X(0.5f), Y(-16.2f), 0.7f * D, 66, 120, 210, 0.9f);
        drawDisc(X(-6.5f), Y(-21), 2.3f * D, 242, 204, 166, 1, 1, 0);
        rect(-9, -24, -4, -22, 220, 50, 50);                    // кепка
        rect(-4.5f, -23, -2.2f, -22.2f, 220, 50, 50);
        gClipY = INT_MAX;
        return;
    }
    bool autumn = gSeason == SEA_AUTUMN;
    // куча снега/листьев перед отвалом
    if (gDozer.pile > 1) {
        float pr = std::min(15.0f * S, std::sqrt(gDozer.pile / PI) * 1.25f);
        int saved = gClipY;
        gClipY = (int)gy;
        if (autumn) {
            drawDisc(X(16.5f) + dir * pr * 0.55f, gy, pr, 190, 100, 40, 1.0f, 1.0f, 0.25f);
            for (int i = 0; i < 7; ++i) {
                const RGB8& cc = kPal[i % 5];
                float a = i * 0.9f;
                drawLeaf(X(16.5f) + dir * pr * 0.55f + std::cos(a) * pr * 0.5f, gy - std::fabs(std::sin(a)) * pr * 0.6f,
                         7 * S, 4 * S, a, cc.r, cc.g, cc.b, 1, true);
            }
        } else drawDisc(X(16.5f) + dir * pr * 0.55f, gy, pr, 250, 252, 255, 1.0f, 1.0f, 0.2f);
        gClipY = saved;
    }
    float bR = autumn ? 226 : 238, bG = autumn ? 108 : 178, bB = autumn ? 34 : 22;
    // гусеница
    rect(-13.5f, -6.5f, 10.5f, 0, 45, 45, 50);
    rect(-13, -6.5f, 10, -5.5f, 75, 75, 80);
    for (float wx : {-10.0f, -4.5f, 1.0f, 6.5f}) drawDisc(X(wx), Y(-3.1f), 2.3f * D, 105, 105, 112, 1, 1, 0);
    for (float wx : {-10.0f, -4.5f, 1.0f, 6.5f}) drawDisc(X(wx), Y(-3.1f), 0.8f * D, 60, 60, 65, 1, 1, 0);
    // корпус
    rect(-12, -12.5f, 9, -6.5f, bR, bG, bB);
    rect(-12, -7.6f, 9, -6.5f, 196, 140, 14);
    rect(1, -11.5f, 9, -10.7f, 255, 214, 90);     // блик на капоте
    // кабина
    rect(-11, -22, -0.5f, -12.5f, bR, bG, bB);
    rect(-12, -23, 0.5f, -21.8f, 200, 145, 15);   // крыша
    rect(-9, -20.2f, -2.5f, -14, 160, 210, 240);  // стекло
    rect(-8.4f, -19.6f, -6.8f, -15, 215, 238, 252);
    // выхлопная труба
    rect(4, -18, 5.4f, -12.5f, 55, 55, 58);
    // рычаги и отвал
    rect(8.5f, -9.5f, 13.5f, -7.5f, 70, 70, 76);
    rect(13, -14.5f, 16.5f, 0.5f, 150, 156, 166);
    rect(15.6f, -14.5f, 16.5f, 0.5f, 105, 110, 120);
    rect(13, -14.5f, 16.5f, -13.7f, 190, 195, 205);
    // мигалка
    float blink = 0.5f + 0.5f * (float)std::sin(gTime * 9.0);
    drawDisc(X(-6), Y(-24.2f), 1.4f * D, 255, 120, 20, 0.6f + 0.4f * blink, 1, 0);
    drawDisc(X(-6), Y(-24.2f), 3.2f * D, 255, 150, 40, 0.18f * blink, 2.0f, 0);
    gClipY = INT_MAX;
}

// ================================================================ отрисовка кадра
static void drawCaps() {
    if (gSeason != SEA_WINTER) {
        for (size_t ii = gWins.size(); ii-- > 0;) {
            if (gCapPtr[ii]->noSnow) continue;
            if (gSeason == SEA_AUTUMN) drawLitterCap(*gCapPtr[ii]);
            else drawGrassCap(*gCapPtr[ii]);
        }
        return;
    }
    for (size_t ii = gWins.size(); ii-- > 0;) {
        Cap& c = *gCapPtr[ii];
        if (c.noSnow) continue;
        int n = c.n();
        int left = c.r.left - gVX;
        for (int j = 0; j < n; ++j) {
            if (!c.vis[j]) continue;
            float d0 = c.smoothD(j);
            float d1 = (j + 1 < n && c.vis[j + 1]) ? c.smoothD(j + 1) : d0;
            if (d0 < 0.2f && d1 < 0.2f) continue;
            float e0 = c.edgeY(j) - gVY;
            float e1 = (j + 1 < n) ? c.edgeY(j + 1) - gVY : e0;
            for (int px = 0; px < CW; ++px) {
                int X = left + j * CW + px;
                if (X < 0 || X >= gW) continue;
                float t = (px + 0.5f) / CW;
                float h = d0 * (1 - t) + d1 * t;
                if (h < 0.2f) continue;
                float edge = e0 * (1 - t) + e1 * t;      // край окна (с учётом скругления)
                float yTop = edge - h;
                int ys = (int)std::floor(yTop);
                int ye = (int)std::ceil(edge);
                for (int Y = ys; Y < ye; ++Y) {
                    if (Y < 0 || Y >= gH) continue;
                    float a = 1.0f;
                    if (Y == ys) a = 1.0f - (yTop - ys);
                    if (Y == ye - 1) a = std::min(a, edge - (float)Y);   // дробный низ на скруглении
                    if (a <= 0) continue;
                    float f = clampf((Y - yTop) / std::max(h, 1.0f), 0.0f, 1.0f);
                    float k = f * f;
                    blendPx(X, Y, 253 - 32 * k, 254 - 24 * k, 255 - 10 * k, a * 0.98f);
                }
                // лёгкая тень под сугробом на крае окна
                int sy = (int)std::floor(edge);
                if (h > 1.0f && sy >= 0 && sy < gH) blendPx(X, sy, 20, 30, 50, 0.12f);
            }
        }
    }
}

static bool ballVisible(const Ball& b) {
    if (b.state != B_REST) return true;
    const Ball* base = &b;
    for (int guard = 0; base->belowId >= 0 && guard < 20; ++guard) {
        const Ball* d = ballById(base->belowId);
        if (!d) break;
        base = d;
    }
    Cap* c = findCap(base->capH);
    if (!c) return true;
    int j = (int)(base->relX / CW);
    return j >= 0 && j < c->n() && c->vis[j];
}

struct Man { Ball* base; Ball* mid; Ball* top; };

static void drawBalls() {
    // найти снеговиков: стопка из 2–3 шаров, каждый следующий меньше
    std::vector<Man> men;
    for (auto& b : gBalls) {
        if (b.dead || b.state != B_REST || b.belowId >= 0) continue;
        Ball* a1 = ballAbove(b.id);
        if (!a1 || a1->r >= b.r * 0.97f) continue;
        Ball* a2 = ballAbove(a1->id);
        if (a2 && a2->r < a1->r * 0.97f && !ballAbove(a2->id)) men.push_back({&b, a1, a2});
        else if (!a2) men.push_back({&b, nullptr, a1});
    }

    // руки — за шарами
    for (auto& m : men) {
        if (!ballVisible(*m.base)) continue;
        Ball* body = m.mid ? m.mid : m.base;
        float cx = body->x - gVX, cy = body->y - gVY, r = body->r;
        float w = std::max(0.45f * S, r * 0.11f);
        drawLine(cx - r * 0.75f, cy - r * 0.1f, cx - r * 1.9f, cy - r * 0.75f, w, 95, 62, 35);
        drawLine(cx + r * 0.75f, cy - r * 0.1f, cx + r * 1.9f, cy - r * 0.65f, w, 95, 62, 35);
        drawLine(cx - r * 1.55f, cy - r * 0.55f, cx - r * 1.75f, cy - r * 1.05f, w * 0.8f, 95, 62, 35);
    }

    // лежащие шары: снизу вверх
    std::vector<Ball*> order;
    for (auto& b : gBalls) if (!b.dead && b.state == B_REST && ballVisible(b)) order.push_back(&b);
    std::sort(order.begin(), order.end(), [](Ball* a, Ball* b) { return a->y > b->y; });
    for (Ball* b : order)
        drawDisc(b->x - gVX, b->y - gVY, b->r, 250, 252, 255, 1.0f, 1.0f, 0.22f);

    // лица, пуговицы, шапки
    for (auto& m : men) {
        if (!ballVisible(*m.base)) continue;
        Ball* t = m.top;
        float cx = t->x - gVX, cy = t->y - gVY, r = t->r;
        float u = r / 3.0f;
        int f = m.base->face;
        drawDisc(cx - 1.05f * u + f * 0.4f * u, cy - 0.5f * u, std::max(0.5f * S, 0.55f * u), 25, 25, 35, 1, 1, 0);
        drawDisc(cx + 1.05f * u + f * 0.4f * u, cy - 0.5f * u, std::max(0.5f * S, 0.55f * u), 25, 25, 35, 1, 1, 0);
        drawLine(cx + f * 0.7f * u, cy + 0.45f * u, cx + f * 2.3f * u, cy + 0.65f * u, std::max(0.45f * S, 0.42f * u), 255, 130, 30, 0.9f);
        drawDisc(cx + f * 0.8f * u, cy + 0.45f * u, std::max(0.6f * S, 0.7f * u), 255, 130, 30, 1, 1, 0);
        if (r > 6 * S)   // улыбка у больших
            for (int i = -2; i <= 2; ++i)
                drawDisc(cx + f * 0.3f * u + i * 0.55f * u, cy + 1.5f * u - (2 - std::abs(i)) * 0.18f * u,
                         std::max(0.4f * S, 0.25f * u), 30, 30, 40, 1, 1, 0);
        Ball* body = m.mid ? m.mid : m.base;
        float br = body->r;
        float bs = std::max(0.45f * S, br * 0.11f);
        drawDisc(body->x - gVX, body->y - gVY - br * 0.35f, bs, 40, 40, 50, 1, 1, 0);
        drawDisc(body->x - gVX, body->y - gVY + br * 0.15f, bs, 40, 40, 50, 1, 1, 0);
        // шапка-ведёрко
        float hb = cy - r * 0.72f;
        fillRect(cx - r * 0.95f, hb - std::max(1.0f, r * 0.16f), cx + r * 0.95f, hb, 190, 35, 42);
        fillRect(cx - r * 0.62f, hb - r * 0.95f, cx + r * 0.62f, hb, 212, 48, 55);
        fillRect(cx - r * 0.62f, hb - r * 0.95f, cx - r * 0.35f, hb, 232, 92, 98);
    }

    // летящие и в руке
    for (auto& b : gBalls) {
        if (b.dead || b.state == B_REST) continue;
        drawDisc(b.x - gVX, b.y - gVY, b.r, 250, 252, 255, 1.0f, 1.0f, 0.22f);
    }
}

static void drawSplats() {
    for (auto& s : gSplats) {
        float fade = s.age < 5.0f ? 1.0f : clampf(1.0f - (s.age - 5.0f) / 4.0f, 0.0f, 1.0f);
        float cx = s.x - gVX, cy = s.y - gVY, r = s.r;
        // проход 0 — серая тень (видно на белом), проход 1 — снег
        for (int pass = 0; pass < 2; ++pass) {
            uint32_t seed = s.seed;
            auto rnd = [&]() { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return (seed >> 8) * (1.0f / 16777216.0f); };
            float grow = pass == 0 ? 1.3f * S : 0.0f;
            float oy = pass == 0 ? 0.8f * S : 0.0f;
            float a = (pass == 0 ? 0.32f : 0.94f) * fade;
            float R = pass == 0 ? 120.0f : 246.0f, G = pass == 0 ? 132.0f : 249.0f, B = pass == 0 ? 150.0f : 255.0f;
            int drips = 2 + (int)(rnd() * 3);
            for (int i = 0; i < drips; ++i) {
                float ox = (rnd() * 1.4f - 0.7f) * r;
                float sp = 6 + rnd() * 10, lim = 0.8f + rnd() * 1.4f;
                float len = std::min(s.age * sp * S, r * lim);
                float w = r * (0.09f + rnd() * 0.07f);
                drawLine(cx + ox, cy + oy + r * 0.3f, cx + ox, cy + oy + r * 0.5f + len, w + grow * 0.6f, R, G, B, a * 0.8f);
                drawDisc(cx + ox, cy + oy + r * 0.5f + len, w * 1.35f + grow * 0.6f, R, G, B, a, 1, 0);
            }
            drawDisc(cx, cy + oy, r * 0.82f + grow, R, G, B, a, 1.2f, 0);
            int lobes = 7 + (int)(rnd() * 4);
            for (int i = 0; i < lobes; ++i) {
                float ang = (i + rnd() * 0.6f) * 2 * PI / lobes;
                float dist = r * (0.65f + rnd() * 0.5f);
                float lr = r * (0.22f + rnd() * 0.25f);
                drawDisc(cx + std::cos(ang) * dist, cy + oy + std::sin(ang) * dist, lr + grow, R, G, B, a, 1.0f, 0);
            }
            for (int i = 0; i < 9; ++i) {
                float ang = rnd() * 2 * PI;
                float dist = r * (1.3f + rnd() * 1.0f);
                float dr = std::max(0.7f * S, r * (0.05f + rnd() * 0.1f));
                drawDisc(cx + std::cos(ang) * dist, cy + oy + std::sin(ang) * dist, dr + grow * 0.5f, R, G, B, a, 1.0f, 0);
            }
            if (pass == 1) drawDisc(cx - r * 0.25f, cy - r * 0.25f, r * 0.35f, 255, 255, 255, a * 0.6f, 2.0f, 0);
        }
    }
}

static void drawParticles() {
    for (const P& p : gP) {
        if (p.type >= T_LEAF) { seasonDrawP(p); continue; }
        float x = p.x - gVX, y = p.y - gVY;
        if (p.clump)
            drawDisc(x, y, p.r, 248, 250, 255, 1.0f, 1.0f, 0.25f);
        else
            drawDisc(x, y, p.r, 255, 255, 255, p.a, p.r > 2.0f * S ? 1.6f : 1.0f, 0);
    }
}

static bool anySnow() {
    if (!gP.empty() || !gBalls.empty() || !gSplats.empty() || gDozer.active || !gPuffs.empty() || !gCritters.empty()) return true;
    for (auto& kv : gCaps) {
        if (!kv.second.decor.empty() || !kv.second.flowers.empty()) return true;
        for (float v : kv.second.d) if (v > 0.2f) return true;
    }
    return false;
}

// смена сезона: всё старое убираем, новое начнёт появляться само
static void applySeason(int sea) {
    if (sea == gSeason) return;
    gSeason = sea;
    gP.clear();
    gBalls.clear();
    gSplats.clear();
    gCritters.clear();
    gCaps.clear();
    gPuffs.clear();
    gDozer.active = false;
    gDozer.pile = 0;
    gHeldId = -1;
    gRaking = false;
    gRainLevel = 0;
    gRaining = false;
    gRainTimer = frange(20, 60);
}
static bool weatherSnowNow();
static int effectiveSeason() { return gSeasonMode >= 4 ? (weatherSnowNow() ? SEA_WINTER : autoSeason()) : gSeasonMode; }
static void onSeasonChanged();   // обои меняются вместе с сезоном (см. ниже)

static void wpTick();
static void tick() {
#ifdef SUGROB_PROF
    struct TickProf { LARGE_INTEGER t0; TickProf() { QueryPerformanceCounter(&t0); } ~TickProf() {
        LARGE_INTEGER t1; QueryPerformanceCounter(&t1); static double ms = 0; static int n = 0;
        ms += (t1.QuadPart - t0.QuadPart) * 1000.0 / gFreq.QuadPart;
        if (++n >= 150) { alogFwd("prof tick %.3f ms avg, pace %u ms, parts %zu", ms / n, gTickMs, gP.size()); ms = 0; n = 0; } } } _tp;
#endif
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    float dt = (float)((now.QuadPart - gLast.QuadPart) / (double)gFreq.QuadPart);
    gLast = now;
    dt = clampf(dt, 0.0f, 0.05f);
    gTime += dt;
    if (!gPix) return;

    // в полноэкранных играх и видео снег прячем (проверяем 4 раза в секунду)
    {
        static double fsT = 1;
        fsT += dt;
        if (fsT >= 0.25) { fsT = 0; gHiddenFS = isFullscreenForeground(); }
    }
    GetCursorPos(&gCursor);
    wpTick();
    musicSetPaused(gHiddenFS);   // в полноэкранной игре/видео музыка на паузе
    radioSetPaused(gHiddenFS);
    if (gHiddenFS) {
        if (gDrewLast) {
            memset(gPix, 0, (size_t)gW * gH * 4);
            std::fill(gTilePrev.begin(), gTilePrev.end(), 0);
            gFrameHash = 0;
            present();
            gDrewLast = false;
        }
        setPace(250);
        return;
    }

    {   // сезон по календарю проверяем раз в минуту
        static double seaT = 0;
        seaT += dt;
        if (seaT > 60 || effectiveSeason() != gSeason) {
            seaT = 0;
            int sea = effectiveSeason();
            if (sea != gSeason) { applySeason(sea); onSeasonChanged(); }
        }
    }
    gTopmostTimer += dt;
    if (gTopmostTimer > 2.0) {
        gTopmostTimer = 0;
        SetWindowPos(gOverlay, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        if (gVolWnd && IsWindowVisible(gVolWnd))   // окно громкости — поверх снега
            SetWindowPos(gVolWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }

    holidayUpdate(dt);
    // ничего не происходит — не тратим процессор
    if (!gSnowOn && !anySnow() && !gDozerRequested && !holidayBusy() && gPetHearts.empty() && gBolts.empty() && !petActive()) {
        if (gDrewLast) {
            memset(gPix, 0, (size_t)gW * gH * 4);
            std::fill(gTilePrev.begin(), gTilePrev.end(), 0);
            gFrameHash = 0;
            present();
            gDrewLast = false;
        }
        gCaps.clear();
        setPace(250);
        return;
    }

    gatherWindows(dt);
    updateWeather(dt);
    spawnFlakes(dt);
    updateParticles(dt);
    updateCapsTime(dt);
    if (gSeason == SEA_WINTER) updateBalls(dt);
    updateDozer(dt);
    updateCritters(dt, gCursor);
    seasonRake();
    seasonBrush((float)dt);
    updatePet(dt);
    updateSky(dt);

#ifdef SUGROB_DEBUG
    { static double acc = 0; acc += dt; if (acc > 3) { acc = 0; FILE* f = _wfopen(L"C:\\sugrob_dbg.txt", L"a");
      if (f) { fprintf(f, "t=%.1f wins=%zu parts=%zu balls=%zu splats=%zu dozer=%d x=%.0f pile=%.0f held=%d\n",
                       gTime, gWins.size(), gP.size(), gBalls.size(), gSplats.size(), gDozer.active, gDozer.x, gDozer.pile, gHeldId);
        for (size_t i = 0; i < gWins.size(); ++i) { Cap& c = *gCapPtr[i]; int v = 0; float mx = 0;
          for (int j = 0; j < c.n(); ++j) { v += c.vis[j]; mx = std::max(mx, c.d[j]); }
          wchar_t cls[64] = {0}; GetClassNameW(gWins[i].h, cls, 63);
          fprintf(f, "  %ls tb=%d r=%ld,%ld,%ld,%ld vis=%d/%d maxd=%.1f R=%.0f\n", cls, gWins[i].tb, c.r.left, c.r.top, c.r.right, c.r.bottom, v, c.n(), mx, c.roundR); }
        fclose(f); } } }
#endif

    clearDirtyTiles();
    drawCaps();
    holidayDrawOnWindows();
    drawBalls();
    drawDozer();
    drawPet();
    drawParticles();
    drawCritters();
    drawSplats();
    drawSky();
    holidayDrawOver();
    // пока что-то падает, кадр точно меняется; сравниваем, только когда всё улеглось
    bool changed = presentFrame(gP.empty());
    gDrewLast = true;
    // ничего не меняется — проверяем окна реже, пока что-нибудь не сдвинется
    gStaticFrames = changed ? 0 : gStaticFrames + 1;
    if (gStaticFrames > 20) setPace(100); else applyActivePace();
}

// ================================================================ реестр / автозапуск
static DWORD regGet(const wchar_t* name, DWORD def) {
    if (gPortable) {
        wchar_t b[32] = {0};
        if (!GetPrivateProfileStringW(L"Settings", name, L"", b, 32, gIniPath.c_str()) || !b[0]) return def;
        return (DWORD)wcstoul(b, nullptr, 10);
    }
    DWORD v = def, sz = sizeof(v);
    if (RegGetValueW(HKEY_CURRENT_USER, kRegKey, name, RRF_RT_REG_DWORD, nullptr, &v, &sz) != ERROR_SUCCESS)
        return def;
    return v;
}
static std::vector<std::wstring>* gRegCollect = nullptr;   // сброс настроек: собрать имена вместо записи
static void regSet(const wchar_t* name, DWORD v) {
    if (gRegCollect) { gRegCollect->push_back(name); return; }
    if (gPortable) { WritePrivateProfileStringW(L"Settings", name, std::to_wstring(v).c_str(), gIniPath.c_str()); return; }
    RegSetKeyValueW(HKEY_CURRENT_USER, kRegKey, name, REG_DWORD, &v, sizeof(v));
}
static void saveSettings2();
static void loadSettings2();
static void saveSettings() {
    regSet(L"IntensityPct", (DWORD)gIntensityPct);
    regSet(L"WindPct", (DWORD)gWindPct);
    regSet(L"SeasonMode", (DWORD)gSeasonMode);
    regSet(L"RainMode", (DWORD)gRainMode);
    regSet(L"Critters", gCrittersOn);
    regSet(L"Fireflies", (DWORD)gFireflyMode);
    regSet(L"WpMode", (DWORD)gWpMode);
    regSet(L"WpMuted", gWpMuted);
    regSet(L"WpPauseMax", gWpPauseMax);
    regSet(L"WpFollowSeason", gWpFollowSeason);
    regSet(L"Snow", gSnowOn);
    regSet(L"Caps", gCapsOn);
    regSet(L"CapsTaskbar", gCapsTaskbar);
    regSet(L"HideFullscreen", gHideFullscreen);
    regSet(L"Snowmen", gMenOn);
    regSet(L"Interact", gInteract);
    regSet(L"Dozer", gDozerOn);
    regSet(L"DozerEvery", (DWORD)gDozerEvery);
    regSet(L"Fps", (DWORD)gFps);
    regSet(L"MusicVolume", (DWORD)gMusicVol);
    regSet(L"Track", (DWORD)gTrack);
    regSet(L"MusicPl", (DWORD)gPl);
    regSet(L"MusicFollow", gMusicFollow);
    regSet(L"Holiday", (DWORD)gHolidayMode);
    regSet(L"Countdown", gCountdownOn);
    saveSettings2();
}
static void loadSettings() {
    {   // старая настройка «лёгкий/обычный/метель» → проценты
        DWORD old = regGet(L"Intensity", 1);
        gIntensityPct = (int)std::min<DWORD>(100, regGet(L"IntensityPct", old == 0 ? 25 : old == 2 ? 90 : 50));
    }
    gWindPct    = (int)std::min<DWORD>(100, regGet(L"WindPct", 50));
    gSeasonMode = (int)std::min<DWORD>(4, regGet(L"SeasonMode", 4));
    gRainMode   = (int)std::min<DWORD>(2, regGet(L"RainMode", 1));
    gCrittersOn = regGet(L"Critters", 0) != 0;
    gFireflyMode = (int)std::min<DWORD>(2, regGet(L"Fireflies", 0));
    gWpMode     = (int)std::min<DWORD>(2, regGet(L"WpMode", 0));
    gWpMuted    = regGet(L"WpMuted", 1) != 0;
    gWpPauseMax = regGet(L"WpPauseMax", 1) != 0;
    gWpFollowSeason = regGet(L"WpFollowSeason", 1) != 0;
    gSnowOn   = regGet(L"Snow", 1) != 0;
    gCapsOn   = regGet(L"Caps", 0) != 0;
    gCapsTaskbar = regGet(L"CapsTaskbar", 0) != 0;
    gHideFullscreen = regGet(L"HideFullscreen", 1) != 0;
    gMenOn    = regGet(L"Snowmen", 0) != 0;
    gInteract = regGet(L"Interact", 0) != 0;
    gDozerOn  = regGet(L"Dozer", 0) != 0;
    gDozerEvery = (int)regGet(L"DozerEvery", 0);
    gFps = (int)regGet(L"Fps", 0);   // по умолчанию — как у монитора, максимум плавности
    if (!validFps(gFps)) gFps = 0;
    if (gDozerEvery != 0 && gDozerEvery != 30 && gDozerEvery != 60 && gDozerEvery != 300) gDozerEvery = 0;
    gMusicVol = (int)std::min<DWORD>(100, regGet(L"MusicVolume", 50));
    gTrack    = (int)regGet(L"Track", 0);
    gPl       = (int)std::min<DWORD>(4, regGet(L"MusicPl", 0));
    gMusicFollow = regGet(L"MusicFollow", 1) != 0;
    gHolidayMode = (int)std::min<DWORD>(10, regGet(L"Holiday", 0));
    gCountdownOn = regGet(L"Countdown", 0) != 0;
    loadSettings2();
}
static bool autostartOn() {
    wchar_t buf[MAX_PATH * 2];
    DWORD sz = sizeof(buf);
    if (RegGetValueW(HKEY_CURRENT_USER, kRunKey, kRunValue, RRF_RT_REG_SZ, nullptr, buf, &sz) == ERROR_SUCCESS) return true;
    sz = sizeof(buf);
    return RegGetValueW(HKEY_CURRENT_USER, kRunKey, kRunValueOld, RRF_RT_REG_SZ, nullptr, buf, &sz) == ERROR_SUCCESS;
}
static void setAutostart(bool on) {
    if (on) {
        HKEY ko;   // старое имя автозапуска («Сугроб») убираем
        if (RegOpenKeyExW(HKEY_CURRENT_USER, kRunKey, 0, KEY_SET_VALUE, &ko) == ERROR_SUCCESS) { RegDeleteValueW(ko, kRunValueOld); RegCloseKey(ko); }
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(nullptr, path, MAX_PATH);
        wchar_t val[MAX_PATH + 4];
        swprintf(val, MAX_PATH + 4, L"\"%ls\"", path);
        RegSetKeyValueW(HKEY_CURRENT_USER, kRunKey, kRunValue, REG_SZ, val,
                        (DWORD)((wcslen(val) + 1) * sizeof(wchar_t)));
    } else {
        HKEY k;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, kRunKey, 0, KEY_SET_VALUE, &k) == ERROR_SUCCESS) {
            RegDeleteValueW(k, kRunValue);
            RegDeleteValueW(k, kRunValueOld);
            RegCloseKey(k);
        }
    }
}

// ================================================================ музыка
// Лёгкие инструментальные мелодии Kevin MacLeod (incompetech.com, CC BY) с Wikimedia Commons.
// Скачиваются один раз в %LOCALAPPDATA%\Sugrob\music и играют через MCI.
struct Track { const wchar_t* name; const wchar_t* path; DWORD size; int season; };
static const Track kTracks[] = {
    {L"Jingle Bells", L"/wikipedia/commons/4/4d/Jingle_Bells_%28ISRC_USUAN1100187%29.mp3", 4186274, 0},
    {L"We Wish You a Merry Christmas", L"/wikipedia/commons/a/a6/We_Wish_you_a_Merry_Christmas_%28ISRC_USUAN1100369%29.mp3", 5643283, 0},
    {L"Танец Феи Драже («Щелкунчик»)", L"/wikipedia/commons/d/d1/Dance_of_the_Sugar_Plum_Fairy_%28ISRC_USUAN1100625%29.mp3", 4800178, 0},
    {L"Up on a Housetop", L"/wikipedia/commons/3/35/Up_on_a_Housetop_%28ISRC_USUAN1100365%29.mp3", 2820567, 0},
    {L"O Tannenbaum (О ёлочка)", L"/wikipedia/commons/9/99/Oh%2C_Christmas_Tree_%28ISRC_USUAN1100366%29.mp3", 2070347, 0},
    {L"Deck the Halls", L"/wikipedia/commons/a/a6/Deck_the_Halls_A_%28ISRC_USUAN1100263%29.mp3", 9738607, 0},
    {L"Jingle Bells (спокойная)", L"/wikipedia/commons/8/8a/Jingle_Bells_%28Calm%29_%28ISRC_USUAN1100188%29.mp3", 4836673, 0},
    {L"Holiday Weasel", L"/wikipedia/commons/c/ce/Kevin_MacLeod_-_Holiday_Weasel_%28cc-by%29_%28filmmusic%29.mp3", 3053280, 0},
    {L"Greensleeves (What Child Is This)", L"/wikipedia/commons/4/48/What_Child_is_This_%28ISRC_USUAN1100012%29.mp3", 5717008, 0},
    {L"Тихая ночь (Silent Night)", L"/wikipedia/commons/0/0f/Silent_Night_%28ISRC_USUAN1100075%29.mp3", 5369410, 0},
    {L"O Little Town of Bethlehem", L"/wikipedia/commons/f/fd/Oh%2C_Little_Town_of_Bethlehem_%28ISRC_USUAN1100307%29.mp3", 4365144, 0},
    {L"It Came Upon a Midnight Clear", L"/wikipedia/commons/1/1d/It_Came_Upon_a_Midnight_Clear_%28ISRC_USUAN1100191%29.mp3", 9567470, 0},
    {L"Winter Chimes", L"/wikipedia/commons/0/0a/Winter_Chimes_%28ISRC_USUAN1100009%29.mp3", 2617123, 0},
    {L"Winter Reflections", L"/wikipedia/commons/9/9e/Winter_Reflections_%28ISRC_USUAN1100580%29.mp3", 5781640, 0},
    {L"Frost Waltz", L"/wikipedia/commons/6/62/Frost_Waltz_%28ISRC_USUAN1100516%29.mp3", 5526812, 0},
    {L"Shades of Spring", L"/wikipedia/commons/1/13/Shades_of_Spring_%28ISRC_USUAN1100080%29.mp3", 7220629, 1},
    {L"Cherry Blossom", L"/wikipedia/commons/a/a8/Cherry_Blossom_%28ISRC_USUAN1100382%29.mp3", 5297320, 1},
    {L"Spring Thaw", L"/wikipedia/commons/9/94/Spring_Thaw_%28ISRC_USUAN1100652%29.mp3", 2167035, 1},
    {L"Plucky Daisy", L"/wikipedia/commons/1/15/Plucky_Daisy_%28ISRC_USUAN1100110%29.mp3", 6948884, 1},
    {L"Daybreak", L"/wikipedia/commons/b/b1/Daybreak_%28ISRC_USUAN1100266%29.mp3", 6864771, 1},
    {L"Water Lily", L"/wikipedia/commons/b/b3/Water_Lily_%28ISRC_USUAN1400035%29.mp3", 4612305, 1},
    {L"Village Dawn", L"/wikipedia/commons/2/29/Village_Dawn_%28ISRC_USUAN1100025%29.mp3", 2973351, 1},
    {L"Fresh Air", L"/wikipedia/commons/d/dc/Fresh_Air_%28ISRC_USUAN1500084%29.mp3", 9412181, 1},
    {L"Summer Day", L"/wikipedia/commons/4/4c/Summer_Day_%28ISRC_USUAN1200083%29.mp3", 7924620, 2},
    {L"Midsummer Sky", L"/wikipedia/commons/b/b9/Midsummer_Sky_%28ISRC_USUAN1100158%29.mp3", 3841216, 2},
    {L"Somewhere Sunny", L"/wikipedia/commons/0/0c/Somewhere_Sunny_%28ISRC_USUAN1100493%29.mp3", 2482004, 2},
    {L"Sunshine", L"/wikipedia/commons/0/08/Sunshine_%28ISRC_USUAN1100517%29.mp3", 8206216, 2},
    {L"Happy Bee", L"/wikipedia/commons/8/8a/Happy_Bee_%28ISRC_USUAN1300014%29.mp3", 12082281, 2},
    {L"Carefree", L"/wikipedia/commons/f/f5/Carefree_%28ISRC_USUAN1400037%29.mp3", 6566713, 2},
    {L"Porch Swing Days", L"/wikipedia/commons/6/6f/Porch_Swing_Days_-_slower_%28ISRC_USUAN1100715%29.mp3", 8653643, 2},
    {L"Fireflies and Stardust", L"/wikipedia/commons/8/84/Fireflies_and_Stardust_%28ISRC_USUAN1600061%29.mp3", 8164148, 2},
    {L"Autumn Day", L"/wikipedia/commons/7/71/Autumn_Day_%28ISRC_USUAN1100765%29.mp3", 7395072, 3},
    {L"Evening Fall (фортепиано)", L"/wikipedia/commons/f/fd/Evening_Fall_%28Piano%29_%28ISRC_USUAN1100235%29.mp3", 5397796, 3},
    {L"Evening Fall (арфа)", L"/wikipedia/commons/e/e2/Evening_Fall_%28Harp%29_%28ISRC_USUAN1100236%29.mp3", 4759305, 3},
    {L"Luminous Rain", L"/wikipedia/commons/2/2e/Luminous_Rain_%28ISRC_USUAN1100169%29.mp3", 3744555, 3},
    {L"Lone Harvest", L"/wikipedia/commons/a/a3/Lone_Harvest_%28ISRC_USUAN1100409%29.mp3", 2502138, 3},
    {L"Гимнопедия № 1 (Эрик Сати)", L"/wikipedia/commons/2/2a/Gymnopedie_No._1_%28ISRC_USUAN1100787%29.mp3", 7487656, 3},
    {L"Reminiscing", L"/wikipedia/commons/3/3d/Reminiscing_%28ISRC_USUAN1100097%29.mp3", 6217924, 3},
    {L"Wallpaper", L"/wikipedia/commons/1/1e/Wallpaper_%28ISRC_USUAN1100843%29.mp3", 8804339, 3},
};
static const int kTrackCount = (int)(sizeof(kTracks) / sizeof(kTracks[0]));
static volatile LONG gTrackReady[kTrackCount] = {0};
static volatile LONG gDlQuit = 0, gDlWant = 0, gDlPl = 0, gDlActive = -1;
static HANDLE gDlThread = nullptr, gDlEvent = nullptr;
static wchar_t gMusicDir[MAX_PATH] = {0};
static int  gPlaying = -1;          // номер в плейлисте, открытый в MCI
static int  gPlayingPl = -1;
static bool gMusicPausedNow = false;
static bool gDlFailed = false;
static std::vector<int> gPlIdx[4];          // встроенные мелодии по сезонам
static std::vector<std::wstring> gMyMusic;  // своя музыка (пути к файлам)
static int  gMyFails = 0;
#define WM_TRACKREADY (WM_APP + 3)
#define PL_MY 4

static int plCount(int pl) { return pl == PL_MY ? (int)gMyMusic.size() : (pl >= 0 && pl < 4 ? (int)gPlIdx[pl].size() : 0); }
static std::wstring plName(int pl, int i) {
    if (pl == PL_MY) {
        const std::wstring& p = gMyMusic[i];
        size_t s = p.find_last_of(L"\\/");
        std::wstring n = s == std::wstring::npos ? p : p.substr(s + 1);
        size_t d = n.find_last_of(L'.');
        return d == std::wstring::npos ? n : n.substr(0, d);
    }
    return kTracks[gPlIdx[pl][i]].name;
}
static bool plReady(int pl, int i) {
    if (pl == PL_MY) return GetFileAttributesW(gMyMusic[i].c_str()) != INVALID_FILE_ATTRIBUTES;
    return gTrackReady[gPlIdx[pl][i]] != 0;
}
static void trackFile(int i, wchar_t* out, size_t n) {
    swprintf(out, n, L"%ls\\track%02d.mp3", gMusicDir, i + 1);
}

static bool fileSizeIs(const wchar_t* path, DWORD expect) {
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExW(path, GetFileExInfoStandard, &fa)) return false;
    if (fa.nFileSizeHigh) return false;
    return expect ? fa.nFileSizeLow == expect : fa.nFileSizeLow > 50000;
}

// журнал музыки: %LOCALAPPDATA%\Sugrob\music\log.txt
static void mlog(const char* fmt, ...) {
    if (!gMusicDir[0]) return;
    wchar_t p[MAX_PATH + 16];
    swprintf(p, MAX_PATH + 16, L"%ls\\log.txt", gMusicDir);
    FILE* f = _wfopen(p, L"a");
    if (!f) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    fprintf(f, "%02d:%02d:%02d ", st.wHour, st.wMinute, st.wSecond);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static const wchar_t* kUaApp = L"Sugrob/1.5 (desktop snow app; +https://commons.wikimedia.org/wiki/Category:Holiday_music_from_Incompetech)";
static const wchar_t* kUaBrowser = L"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";

// способ 1: WinHTTP
static bool winhttpDownload(const wchar_t* path, const wchar_t* dst, DWORD expect, const wchar_t* ua, DWORD access) {
    HINTERNET ses = WinHttpOpen(ua, access, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) { mlog("  winhttp open(access=%lu) failed err=%lu", access, GetLastError()); return false; }
    WinHttpSetTimeouts(ses, 15000, 15000, 20000, 30000);
    // TLS 1.2/1.3 явно (на старых Windows 10 по умолчанию может быть выключен)
    DWORD proto = 0x00000800 /*TLS1_2*/ | 0x00002000 /*TLS1_3*/;
    if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) {
        proto = 0x00000800;
        WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto));
    }
    bool ok = false;
    DWORD status = 0, total = 0;
    HINTERNET con = WinHttpConnect(ses, L"upload.wikimedia.org", INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!con) mlog("  winhttp connect failed err=%lu", GetLastError());
    HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", path, nullptr, WINHTTP_NO_REFERER,
                                             WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE) : nullptr;
    if (con && !req) mlog("  winhttp openrequest failed err=%lu", GetLastError());
    if (req) {
        if (!WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0))
            mlog("  winhttp send failed err=%lu", GetLastError());
        else if (!WinHttpReceiveResponse(req, nullptr))
            mlog("  winhttp receive failed err=%lu", GetLastError());
        else {
            DWORD sz = sizeof(status);
            WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
            if (status != 200) mlog("  winhttp http status %lu", status);
            else {
                wchar_t part[MAX_PATH + 8];
                swprintf(part, MAX_PATH + 8, L"%ls.part", dst);
                HANDLE f = CreateFileW(part, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
                if (f == INVALID_HANDLE_VALUE) mlog("  cannot create file err=%lu", GetLastError());
                else {
                    std::vector<char> buf(64 * 1024);
                    DWORD got = 0;
                    bool err = false;
                    for (;;) {
                        if (gDlQuit) { err = true; break; }
                        if (!WinHttpReadData(req, buf.data(), (DWORD)buf.size(), &got)) {
                            mlog("  winhttp read failed err=%lu after %lu bytes", GetLastError(), total);
                            err = true; break;
                        }
                        if (got == 0) break;
                        DWORD wr = 0;
                        if (!WriteFile(f, buf.data(), got, &wr, nullptr) || wr != got) { err = true; break; }
                        total += got;
                    }
                    CloseHandle(f);
                    if (!err && (expect ? total == expect : total > 50000))
                        ok = MoveFileExW(part, dst, MOVEFILE_REPLACE_EXISTING) != 0;
                    else if (!err) mlog("  size mismatch: got %lu expected %lu", total, expect);
                    if (!ok) DeleteFileW(part);
                }
            }
        }
    }
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return ok;
}

// способ 2: системный загрузчик (те же настройки интернета/прокси/VPN, что у Windows)
typedef HRESULT (WINAPI *URLDownloadToFileW_t)(void*, LPCWSTR, LPCWSTR, DWORD, void*);
static bool urlmonDownload(const wchar_t* path, const wchar_t* dst, DWORD expect) {
    static URLDownloadToFileW_t fn = nullptr;
    if (!fn) {
        HMODULE m = LoadLibraryW(L"urlmon.dll");
        if (m) fn = (URLDownloadToFileW_t)(void*)GetProcAddress(m, "URLDownloadToFileW");
    }
    if (!fn) { mlog("  urlmon not available"); return false; }
    wchar_t url[1024], part[MAX_PATH + 8];
    swprintf(url, 1024, L"https://upload.wikimedia.org%ls", path);
    swprintf(part, MAX_PATH + 8, L"%ls.part", dst);
    DeleteFileW(part);
    HRESULT hr = fn(nullptr, url, part, 0, nullptr);
    if (FAILED(hr)) { mlog("  urlmon failed hr=0x%08lx", (unsigned long)hr); DeleteFileW(part); return false; }
    if (!fileSizeIs(part, expect)) { mlog("  urlmon size mismatch"); DeleteFileW(part); return false; }
    return MoveFileExW(part, dst, MOVEFILE_REPLACE_EXISTING) != 0;
}

static bool httpDownload(const wchar_t* path, const wchar_t* dst, DWORD expect) {
    if (winhttpDownload(path, dst, expect, kUaApp, 4 /*AUTOMATIC_PROXY, Win8.1+*/)) return true;
    if (gDlQuit) return false;
    if (winhttpDownload(path, dst, expect, kUaBrowser, WINHTTP_ACCESS_TYPE_DEFAULT_PROXY)) return true;
    if (gDlQuit) return false;
    return urlmonDownload(path, dst, expect);
}

// качает недостающие мелодии: сначала ту, что нужна сейчас, потом следующие
static DWORD WINAPI DownloadThread(LPVOID) {
    while (!gDlQuit) {
        int want = (int)gDlWant, pl = (int)gDlPl;
        int pick = -1;
        if (pl >= 0 && pl < 4) {
            int n = (int)gPlIdx[pl].size();
            for (int k = 0; k < n; ++k) {
                int i = gPlIdx[pl][(want + k) % n];
                if (!gTrackReady[i]) { pick = i; break; }
            }
        }
        if (pick < 0) { WaitForSingleObject(gDlEvent, INFINITE); continue; }
        wchar_t dst[MAX_PATH];
        trackFile(pick, dst, MAX_PATH);
        gDlActive = pick;
        mlog("download track %d start", pick + 1);
        bool ok = false;
        for (int attempt = 0; attempt < 3 && !ok && !gDlQuit; ++attempt) {
            ok = httpDownload(kTracks[pick].path, dst, kTracks[pick].size);
            if (!ok) WaitForSingleObject(gDlEvent, 3000);
        }
        gDlActive = -1;
        mlog("download track %d %s", pick + 1, ok ? "OK" : "FAILED");
        if (ok) {
            gTrackReady[pick] = 1;
            PostMessageW(gMsgWnd, WM_TRACKREADY, pick, 1);
        } else {
            PostMessageW(gMsgWnd, WM_TRACKREADY, pick, 0);
            WaitForSingleObject(gDlEvent, 60000);   // нет интернета — попробуем позже
        }
    }
    return 0;
}

static void mci(const wchar_t* cmd, HWND cb = nullptr) { mciSendStringW(cmd, nullptr, 0, cb); }

static void musicApplyVolume() {
    radioVolume();
    if (gPlaying < 0) return;
    wchar_t c[96];
    // квадратичная кривая — ползунок ощущается равномерно
    int v = (int)(1000.0f * (gMusicVol / 100.0f) * (gMusicVol / 100.0f) + 0.5f);
    swprintf(c, 96, L"setaudio sugrobmus volume to %d", v);
    mci(c);
}

static void musicClose() {
    if (gPlaying >= 0) mci(L"close sugrobmus");
    gPlaying = -1;
    gMusicPausedNow = false;
}

static void updateTip();

// включить мелодию idx текущего плейлиста (встроенная ещё не скачана — заиграет, когда скачается)
static void musicPlay(int idx) {
    int n = plCount(gPl);
    musicClose();
    if (n == 0) { updateTip(); return; }
    idx = ((idx % n) + n) % n;
    gTrack = idx;
    if (gPl < 4) {
        gDlPl = gPl;
        gDlWant = idx;
        if (gDlEvent) SetEvent(gDlEvent);
    }
    if (!gMusicOn) { updateTip(); return; }
    if (plReady(gPl, idx)) {
        wchar_t f[MAX_PATH * 2], c[MAX_PATH * 2 + 64];
        if (gPl == PL_MY) wcsncpy(f, gMyMusic[idx].c_str(), MAX_PATH * 2 - 1), f[MAX_PATH * 2 - 1] = 0;
        else trackFile(gPlIdx[gPl][idx], f, MAX_PATH);
        swprintf(c, MAX_PATH * 2 + 64, L"open \"%ls\" type mpegvideo alias sugrobmus", f);
        MCIERROR me = mciSendStringW(c, nullptr, 0, nullptr);
        if (me != 0) {   // запасной вариант: без явного типа (например, MIDI)
            char eb[256] = {0};
            mciGetErrorStringA(me, eb, sizeof(eb));
            mlog("mci open (mpegvideo) pl %d track %d failed: %lu %s", gPl, idx + 1, (unsigned long)me, eb);
            swprintf(c, MAX_PATH * 2 + 64, L"open \"%ls\" alias sugrobmus", f);
            me = mciSendStringW(c, nullptr, 0, nullptr);
            if (me != 0) {
                mciGetErrorStringA(me, eb, sizeof(eb));
                mlog("mci open (auto) pl %d track %d failed: %lu %s", gPl, idx + 1, (unsigned long)me, eb);
            }
        }
        if (me == 0) {
            mlog("playing pl %d track %d", gPl, idx + 1);
            gPlaying = idx;
            gPlayingPl = gPl;
            gMyFails = 0;
            musicApplyVolume();
            MCIERROR pe = mciSendStringW(L"play sugrobmus notify", nullptr, 0, gMsgWnd);
            if (pe) { char eb[256] = {0}; mciGetErrorStringA(pe, eb, sizeof(eb)); mlog("mci play failed: %lu %s", (unsigned long)pe, eb); }
            if (gHiddenFS) { mci(L"pause sugrobmus"); gMusicPausedNow = true; }
        } else if (gPl == PL_MY) {
            // формат не поддерживается — пробуем следующую (но не бесконечно)
            if (++gMyFails < plCount(PL_MY)) { musicPlay(idx + 1); return; }
            gMyFails = 0;
        } else {
            gTrackReady[gPlIdx[gPl][idx]] = 0;   // файл испорчен — скачаем заново
            DeleteFileW(f);
            if (gDlEvent) SetEvent(gDlEvent);
        }
    } else if (gPl == PL_MY) {
        if (++gMyFails < plCount(PL_MY)) { musicPlay(idx + 1); return; }
        gMyFails = 0;
    }
    updateTip();
}

// выбрать плейлист (0..3 — сезоны, 4 — своя музыка) и мелодию в нём
static void musicSelect(int pl, int idx) {
    gPl = std::max(0, std::min(PL_MY, pl));
    musicPlay(idx);
}

// плейлист меняется вместе с сезоном
static void musicFollowSeason() {
    if (!gMusicFollow || gPl == PL_MY || gPl == gSeason) return;
    gPl = gSeason;
    gTrack = 0;
    if (gMusicOn) musicPlay(0);
}

static void loadMyMusic();
static void musicSetPaused(bool p) {
    if (gPlaying < 0 || p == gMusicPausedNow) return;
    mci(p ? L"pause sugrobmus" : L"resume sugrobmus");
    gMusicPausedNow = p;
}

static int readyCount();
static void musicSetOn(bool on) {
    if (on) radioStop();
    gMusicOn = on;
    mlog("music %s (track %d, ready %d)", on ? "ON" : "OFF", gTrack + 1, readyCount());
    if (on) musicPlay(gTrack);
    else { musicClose(); updateTip(); }
}

static void musicInit() {
    swprintf(gMusicDir, MAX_PATH, L"%ls", baseDataDir().c_str());
    CreateDirectoryW(gMusicDir, nullptr);
    wcscat(gMusicDir, L"\\music");
    CreateDirectoryW(gMusicDir, nullptr);
    for (int i = 0; i < kTrackCount; ++i) {
        wchar_t f[MAX_PATH];
        trackFile(i, f, MAX_PATH);
        gTrackReady[i] = fileSizeIs(f, kTracks[i].size) ? 1 : 0;
        gPlIdx[kTracks[i].season & 3].push_back(i);
    }
    loadMyMusic();
    if (gMusicFollow && gPl != PL_MY) gPl = gSeason;
    if (gPl < 0 || gPl > PL_MY) gPl = gSeason;
    if (gTrack < 0 || gTrack >= std::max(1, plCount(gPl))) gTrack = 0;
    gDlEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
}

// своя музыка: список путей, по одному на строке (UTF-8)
static std::wstring myMusicFile() { return std::wstring(gMusicDir) + L"\\mymusic.txt"; }
static void loadMyMusic() {
    gMyMusic.clear();
    FILE* f = _wfopen(myMusicFile().c_str(), L"rb");
    if (!f) return;
    std::string all;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) all.append(buf, n);
    fclose(f);
    size_t p = 0;
    while (p < all.size()) {
        size_t e = all.find('\n', p);
        if (e == std::string::npos) e = all.size();
        std::string line = all.substr(p, e - p);
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (!line.empty()) {
            int wn = MultiByteToWideChar(CP_UTF8, 0, line.c_str(), -1, nullptr, 0);
            std::wstring w(wn > 0 ? wn - 1 : 0, L'\0');
            if (wn > 1) MultiByteToWideChar(CP_UTF8, 0, line.c_str(), -1, &w[0], wn);
            gMyMusic.push_back(w);
        }
        p = e + 1;
    }
}
static void saveMyMusic() {
    FILE* f = _wfopen(myMusicFile().c_str(), L"wb");
    if (!f) return;
    for (auto& w : gMyMusic) {
        int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr);
        std::string u(n > 0 ? n - 1 : 0, '\0');
        if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &u[0], n, nullptr, nullptr);
        fprintf(f, "%s\n", u.c_str());
    }
    fclose(f);
}

// качать начинаем только когда музыку впервые включили
static void musicEnsureDownloader() {
    if (!gDlThread) gDlThread = CreateThread(nullptr, 0, DownloadThread, nullptr, 0, nullptr);
    SetEvent(gDlEvent);
}

static void musicShutdown() {
    musicClose();
    gDlQuit = 1;
    if (gDlEvent) SetEvent(gDlEvent);
    if (gDlThread) { WaitForSingleObject(gDlThread, 3000); CloseHandle(gDlThread); gDlThread = nullptr; }
}

static int readyCount() {
    int n = 0;
    for (int i = 0; i < kTrackCount; ++i) n += gTrackReady[i] ? 1 : 0;
    return n;
}

// ---------------------------------------------------------------- ползунок громкости
static HWND gVolSlider = nullptr, gVolLabel = nullptr;
static HFONT gUiFont = nullptr;

static void volLabelUpdate() {
    wchar_t t[64];
    swprintf(t, 64, L"Громкость музыки: %d%%", gMusicVol);
    if (gVolLabel) SetWindowTextW(gVolLabel, t);
}

static LRESULT CALLBACK VolProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_HSCROLL:
        if ((HWND)lp == gVolSlider) {
            gMusicVol = (int)SendMessageW(gVolSlider, TBM_GETPOS, 0, 0);
            musicApplyVolume();
            volLabelUpdate();
            if (LOWORD(wp) == TB_ENDTRACK) regSet(L"MusicVolume", (DWORD)gMusicVol);
        }
        return 0;
    case WM_CTLCOLORSTATIC:
        SetBkColor((HDC)wp, GetSysColor(COLOR_WINDOW));
        SetTextColor((HDC)wp, GetSysColor(COLOR_WINDOWTEXT));
        return (LRESULT)GetSysColorBrush(COLOR_WINDOW);
    case WM_ACTIVATE:
        if (LOWORD(wp) == WA_INACTIVE) {
            regSet(L"MusicVolume", (DWORD)gMusicVol);
            ShowWindow(h, SW_HIDE);
        }
        return 0;
    case WM_KEYDOWN:
        if (wp == VK_ESCAPE || wp == VK_RETURN) ShowWindow(h, SW_HIDE);
        return 0;
    case WM_CLOSE:
        ShowWindow(h, SW_HIDE);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

static void showVolume() {
    int W = (int)(300 * S), H = (int)(78 * S);
    if (!gVolWnd) {
        WNDCLASSEXW vc{};
        vc.cbSize = sizeof(vc);
        vc.lpfnWndProc = VolProc;
        vc.hInstance = gInst;
        vc.lpszClassName = L"SugrobVolume";
        vc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        vc.hbrBackground = GetSysColorBrush(COLOR_WINDOW);
        RegisterClassExW(&vc);
        gVolWnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, L"SugrobVolume", L"Громкость",
                                  WS_POPUP | WS_BORDER, 0, 0, W, H, nullptr, nullptr, gInst, nullptr);
        gUiFont = CreateFontW(-(int)(13 * S), 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0,
                              CLEARTYPE_QUALITY, 0, L"Segoe UI");
        gVolLabel = CreateWindowExW(0, L"STATIC", L"", WS_CHILD | WS_VISIBLE,
                                    (int)(14 * S), (int)(10 * S), W - (int)(28 * S), (int)(20 * S),
                                    gVolWnd, nullptr, gInst, nullptr);
        gVolSlider = CreateWindowExW(0, TRACKBAR_CLASSW, L"", WS_CHILD | WS_VISIBLE | TBS_HORZ | TBS_NOTICKS | WS_TABSTOP,
                                     (int)(8 * S), (int)(34 * S), W - (int)(16 * S), (int)(32 * S),
                                     gVolWnd, nullptr, gInst, nullptr);
        SendMessageW(gVolLabel, WM_SETFONT, (WPARAM)gUiFont, TRUE);
        SendMessageW(gVolSlider, TBM_SETRANGE, TRUE, MAKELPARAM(0, 100));
        SendMessageW(gVolSlider, TBM_SETPAGESIZE, 0, 10);
        SendMessageW(gVolSlider, TBM_SETLINESIZE, 0, 2);
    }
    SendMessageW(gVolSlider, TBM_SETPOS, TRUE, gMusicVol);
    volLabelUpdate();
    POINT pt;
    GetCursorPos(&pt);
    MONITORINFO mi{};
    mi.cbSize = sizeof(mi);
    GetMonitorInfoW(MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST), &mi);
    int x = std::max((int)mi.rcWork.left + 8, std::min((int)pt.x - W / 2, (int)mi.rcWork.right - W - 8));
    int y = std::max((int)mi.rcWork.top + 8, std::min((int)pt.y - H - 12, (int)mi.rcWork.bottom - H - 8));
    SetWindowPos(gVolWnd, HWND_TOPMOST, x, y, W, H, SWP_SHOWWINDOW);
    SetForegroundWindow(gVolWnd);
    SetFocus(gVolSlider);
}

static void showCredits() {
    MessageBoxW(nullptr,
        L"Музыка: Kevin MacLeod (incompetech.com)\n"
        L"Лицензия Creative Commons «С указанием авторства» (CC BY 3.0 / CC BY 2.0)\n"
        L"Записи взяты с Wikimedia Commons (commons.wikimedia.org),\n"
        L"категория «Holiday music from Incompetech».\n\n"
        L"Мелодии скачиваются один раз и хранятся в папке\n%LOCALAPPDATA%\\Sugrob\\music.",
        L"Подоконник — авторы музыки", MB_ICONINFORMATION);
}

static DWORD windowsBuild();
static int effectiveSeason();
static void applySeason(int sea);
// обновление: состояние нужно окну настроек, сама логика — в update.h
static const char*    kAppVersion = "2.7";
static const wchar_t* kUpdHost    = L"aleksandrkrasnikov97-dot.github.io";
static const wchar_t* kUpdJson    = L"/podokonnik/version.json";

enum { UPD_IDLE, UPD_CHECKING, UPD_LATEST, UPD_AVAILABLE, UPD_LOADING, UPD_ERROR, UPD_RESTART };
static int gUpdState = UPD_IDLE;
static int gUpdPct = 0;
static std::string gUpdVersion, gUpdNotes;
static void updCheck(bool manual);
static void updInstall();
static DWORD gUpdLastTry = 0;              // когда последний раз проверяли обновления
static std::string gAppPage;               // какую страницу открыть в окне программы
static void showApp();
static void showAppPage(const char* page);
static void resetSettings();
static bool isFav(const std::string& id);
static void toggleFav(const std::string& id);
static void rotNext(int dir);
static void hotkeysApply();
static void weatherRequest(bool geocode);
static std::string weatherText();
static void powerApply();
#include "app.h"
static void alogFwd(const char* fmt, ...) {
    char b[600];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(b, sizeof b, fmt, ap);
    va_end(ap);
    alog("%s", b);
}
#include "update.h"
#include "features.h"
#include "extras.h"

// ================================================================ трей
static void updateTip() {
    gNid.uFlags = NIF_TIP;
    if (gMusicOn && gPlaying >= 0 && gPlaying < plCount(gPlayingPl))
        swprintf(gNid.szTip, 128, L"Подоконник — ♪ %ls", plName(gPlayingPl, gPlaying).c_str());
    else if (gMusicOn)
        wcscpy(gNid.szTip, L"Подоконник — загружаю музыку…");
    else if (!radioTitle().empty())
        swprintf(gNid.szTip, 128, L"Подоконник — 📻 %ls", wv::toWide(radioTitle()).c_str());
    else
    {
        static const wchar_t* names[4] = {L"зима", L"весна", L"лето", L"осень"};
        swprintf(gNid.szTip, 128, gSnowOn ? L"Подоконник — %ls" : L"Подоконник — эффекты выключены", names[gSeason & 3]);
    }
    Shell_NotifyIconW(NIM_MODIFY, &gNid);
}

static void addTray(bool balloon) {
    gNid = {};
    gNid.cbSize = sizeof(gNid);
    gNid.hWnd = gMsgWnd;
    gNid.uID = 1;
    gNid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    gNid.uCallbackMessage = WM_TRAY;
    gNid.hIcon = (HICON)LoadImageW(gInst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON,
                                   GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), 0);
    if (!gNid.hIcon) gNid.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wcscpy(gNid.szTip, L"Подоконник — идёт снег");
    if (balloon) {
        gNid.uFlags |= NIF_INFO;
        wcscpy(gNid.szInfoTitle, L"Подоконник запущен");
        wcscpy(gNid.szInfo, L"Нажми на значок Подоконника в трее — откроются настройки, сезоны, обои и музыка.");
        gNid.dwInfoFlags = NIIF_INFO;
    }
    Shell_NotifyIconW(NIM_ADD, &gNid);
}

static void showHelp() {
    MessageBoxW(nullptr,
        L"Как играть со снегом:\n\n"
        L"• Зажми левую кнопку мыши на сугробе — наберёшь снежок.\n"
        L"• Веди снежок по сугробам — он катится и растёт.\n"
        L"• Отпусти с размахом — бросок. Отпусти аккуратно над сугробом — снежок ляжет.\n"
        L"• Правая кнопка, пока держишь снежок, — бросок прямо в экран.\n"
        L"• Сложи шары друг на друга, от большего к меньшему — получится снеговик.\n"
        L"• Лежащие шары и снеговиков можно брать и переносить.\n\n"
        L"Бульдозер сам приезжает чистить панель задач, когда там много снега.\n\n"
        L"Музыка — в меню значка в трее (правая кнопка). "
        L"При первом включении мелодии скачиваются из интернета (около 60 МБ).",
        L"Подоконник", MB_ICONINFORMATION);
}

enum { ID_OPEN = 300, ID_SEASON0 = 310, ID_WP_STOP = 320, ID_CAPS_TB = 330, ID_HIDE_FS = 331, ID_SUPPORT = 332, ID_UPDATE = 333,
       ID_HOL0 = 340, ID_WP_NEXT = 352, ID_WP_PAUSE = 353, ID_LIGHT = 354, ID_FIREWORKS = 355, ID_RADIO = 356,
       ID_PET0 = 360, ID_SLEEP0 = 370, ID_COUNTDOWN = 380, ID_SETTINGS = 385, ID_STATION0 = 400 };
static const wchar_t* kSupportUrl = L"https://www.donationalerts.com/r/aleshikat";
#include "tray.h"
static void showMenu() {
    HMENU m = CreatePopupMenu();
    auto chk = [](bool b) { return b ? MF_CHECKED : MF_UNCHECKED; };
    AppendMenuW(m, MF_STRING | MF_DEFAULT, ID_OPEN, TW(L"Открыть Подоконник", L"Open Podokonnik"));
    AppendMenuW(m, MF_STRING, ID_SETTINGS, TW(L"Настройки", L"Settings"));
    if (gUpdState == UPD_AVAILABLE) {
        std::wstring u = std::wstring(TW(L"Обновить до версии ", L"Update to version ")) + W16(gUpdVersion);
        AppendMenuW(m, MF_STRING, ID_UPDATE, u.c_str());
    }
    AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(m, MF_STRING | chk(gSnowOn), ID_TOGGLE, gHotkeys ? TW(L"Эффекты включены\tCtrl+Alt+H", L"Effects on\tCtrl+Alt+H") : TW(L"Эффекты включены", L"Effects on"));
    HMENU sm = CreatePopupMenu();
    static const wchar_t* sn[2][5] = {{L"Зима", L"Весна", L"Лето", L"Осень", L"По календарю"}, {L"Winter", L"Spring", L"Summer", L"Autumn", L"By calendar"}};
    for (int i = 0; i < 5; ++i) {
        if (i == 4) AppendMenuW(sm, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(sm, MF_STRING | chk(gSeasonMode == i), ID_SEASON0 + i, sn[gLang][i]);
    }
    AppendMenuW(m, MF_POPUP, (UINT_PTR)sm, TW(L"Сезон", L"Season"));
    HMENU mm = CreatePopupMenu();
    AppendMenuW(mm, MF_STRING | chk(gMusicOn), ID_MUSIC, TW(L"Музыка по сезону", L"Seasonal music"));
    AppendMenuW(mm, MF_STRING | (gMusicOn ? 0 : MF_GRAYED), ID_MUSIC_NEXT, TW(L"Следующая мелодия", L"Next track"));
    {
        AppendMenuW(mm, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(mm, MF_STRING | chk(gRadioOn), ID_RADIO, TW(L"Интернет-радио", L"Internet radio"));
        for (int i = 0; i < kStationCount && i < 20; ++i)   // переключение станций
            AppendMenuW(mm, MF_STRING | (gRadioOn && gRadioIdx == i ? MF_CHECKED : 0), ID_STATION0 + i,
                        (L"    " + wv::toWide(gLang ? kStations[i].nameEn : kStations[i].name)).c_str());
    }
    AppendMenuW(m, MF_POPUP | (gMusicOn || gRadioOn ? MF_CHECKED : 0), (UINT_PTR)mm, TW(L"Музыка", L"Music"));
    if (!gWpCurrent.empty()) {
        HMENU wm = CreatePopupMenu();
        AppendMenuW(wm, MF_STRING, ID_WP_NEXT, TW(L"Следующие обои\tCtrl+Alt+→", L"Next wallpaper\tCtrl+Alt+→"));
        AppendMenuW(wm, MF_STRING | chk(gWpUserPause), ID_WP_PAUSE, TW(L"Пауза\tCtrl+Alt+P", L"Pause\tCtrl+Alt+P"));
        AppendMenuW(wm, MF_STRING, ID_WP_STOP, TW(L"Выключить живые обои", L"Turn off live wallpaper"));
        AppendMenuW(m, MF_POPUP, (UINT_PTR)wm, TW(L"Живые обои", L"Live wallpaper"));
    }
    if (anyCaps()) AppendMenuW(m, MF_STRING, ID_SHAKE, TW(L"Стряхнуть с окон", L"Shake off windows"));
    AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(m, MF_STRING, ID_SUPPORT, TW(L"Поддержать автора", L"Support the author"));
    AppendMenuW(m, MF_STRING, ID_EXIT, TW(L"Выход", L"Exit"));
    POINT pt;
    GetCursorPos(&pt);
    SetForegroundWindow(gMsgWnd);
    TrackPopupMenu(m, TPM_RIGHTBUTTON | TPM_BOTTOMALIGN, pt.x, pt.y, 0, gMsgWnd, nullptr);
    PostMessageW(gMsgWnd, WM_NULL, 0, 0);
    DestroyMenu(m);
}

static LRESULT CALLBACK MsgProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == gTaskbarCreated && gTaskbarCreated) { addTray(false); wpRestart(); return 0; }
    if (appMsg(msg, wp, lp)) return 0;
    if (updMsg(msg, wp, lp)) return 0;
    if (featuresMsg(msg, wp, lp)) return 0;
    if (extrasMsg(msg, wp, lp)) return 0;
    switch (msg) {
    case WM_FASTTICK:
        InterlockedExchange(&gTickPending, 0);
        tick();
        return 0;
    case WM_TIMER:
        if (wp == 2) { wpMouseTick(); return 0; }
        if (wp == 7) { updCheck(false); SetTimer(gMsgWnd, 7, 6 * 3600 * 1000, nullptr); return 0; }
        if (wp != 1) return 0;
        tick();
        return 0;
    case MM_MCINOTIFY:
        // мелодия доиграла — следующая
        if (wp == MCI_NOTIFY_SUCCESSFUL && gMusicOn && gPlaying >= 0) musicPlay(gTrack + 1);
        return 0;
    case WM_TRACKREADY:
        if (lp == 1 && gMusicOn && gPlaying < 0 && gPl < 4 && gTrack < plCount(gPl) && gPlIdx[gPl][gTrack] == (int)wp) musicPlay(gTrack);
        if (lp == 0 && gMusicOn && gPlaying < 0 && !gDlFailed && readyCount() == 0) {
            gDlFailed = true;
            gNid.uFlags = NIF_INFO;
            wcscpy(gNid.szInfoTitle, L"Подоконник — музыка");
            wcscpy(gNid.szInfo, L"Не получается скачать мелодии. Проверь интернет — попробую ещё раз через минуту.");
            gNid.dwInfoFlags = NIIF_WARNING;
            Shell_NotifyIconW(NIM_MODIFY, &gNid);
        }
        if (lp == 1) gDlFailed = false;
        updateTip();
        return 0;
    case WM_TRAY:
        if (lp == WM_RBUTTONUP || lp == WM_CONTEXTMENU) trayPopup();
        else if (lp == WM_LBUTTONUP || lp == NIN_BALLOONUSERCLICK) showApp();
        return 0;
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_TOGGLE: gSnowOn = !gSnowOn; break;
        case ID_OPEN: showApp(); break;
        case ID_SETTINGS: showAppPage("settings"); break;
        case ID_STATION0: case ID_STATION0 + 1: case ID_STATION0 + 2: case ID_STATION0 + 3: case ID_STATION0 + 4:
        case ID_STATION0 + 5: case ID_STATION0 + 6: case ID_STATION0 + 7: case ID_STATION0 + 8: case ID_STATION0 + 9:
            if (gMusicOn) musicSetOn(false);
            radioPlay(LOWORD(wp) - ID_STATION0);
            break;
        case ID_WP_STOP: wpStop(); break;
        case ID_SEASON0: case ID_SEASON0 + 1: case ID_SEASON0 + 2: case ID_SEASON0 + 3: case ID_SEASON0 + 4: {
            gSeasonMode = LOWORD(wp) - ID_SEASON0;
            int sea = effectiveSeason();
            if (sea != gSeason) { applySeason(sea); onSeasonChanged(); }
            break;
        }
        case ID_CAPS: gCapsOn = !gCapsOn; break;
        case ID_CAPS_TB: gCapsTaskbar = !gCapsTaskbar; break;
        case ID_HIDE_FS: gHideFullscreen = !gHideFullscreen; break;
        case ID_MEN: gMenOn = !gMenOn; break;
        case ID_INTERACT: gInteract = !gInteract; setHook(gInteract); break;
        case ID_DOZER: gDozerOn = !gDozerOn; break;
        case ID_DOZER_NOW: gDozerRequested = true; gDozer.cooldown = 0; break;
        case ID_SHAKE:
            for (auto& kv : gCaps) shakeAll(kv.second);
            break;
        case ID_AUTO: setAutostart(!autostartOn()); break;
        case ID_HELP: showHelp(); break;
#ifdef UPDTEST
        case ID_UPDATE: updInstall(); break;
#else
        case ID_UPDATE: updInstall(); showApp(); break;
#endif
        case ID_SUPPORT: ShellExecuteW(nullptr, L"open", kSupportUrl, nullptr, nullptr, SW_SHOWNORMAL); break;
        case ID_WP_NEXT: rotNext(1); break;
        case ID_WP_PAUSE: gWpUserPause = !gWpUserPause; gWpTickLast = -1; wpTick(); break;
        case ID_LIGHT: gLightMode = !gLightMode; powerApply(); break;
        case ID_HOL0: case ID_HOL0 + 1: case ID_HOL0 + 2: case ID_HOL0 + 3: case ID_HOL0 + 4: case ID_HOL0 + 5:
        case ID_HOL0 + 6: case ID_HOL0 + 7: case ID_HOL0 + 8: case ID_HOL0 + 9: case ID_HOL0 + 10:
            gHolidayMode = LOWORD(wp) - ID_HOL0; gHolChk = 99; break;
        case ID_COUNTDOWN: gCountdownOn = !gCountdownOn; break;
        case ID_FIREWORKS: gFwManual = 25; gFwNext = 0; break;
        case ID_RADIO: if (gRadioOn) radioStop(); else radioPlay(gRadioIdx); break;
        case ID_PET0: case ID_PET0 + 1: case ID_PET0 + 2: gPetMode = LOWORD(wp) != ID_PET0; gPet.alive = false; break;
        case ID_SLEEP0: case ID_SLEEP0 + 1: case ID_SLEEP0 + 2: case ID_SLEEP0 + 3: case ID_SLEEP0 + 4: {
            static const int sm_[5] = {0, 15, 30, 60, 90};
            sleepSet(sm_[LOWORD(wp) - ID_SLEEP0]);
            break;
        }
        case ID_MUSIC:
            if (!gMusicOn) musicEnsureDownloader();
            musicSetOn(!gMusicOn);
            break;
        case ID_MUSIC_NEXT: musicPlay(gTrack + 1); break;
        case ID_MUSIC_VOL: showVolume(); break;
        case ID_MUSIC_CREDITS: showCredits(); break;
        default:
            if (LOWORD(wp) >= ID_SONG0 && LOWORD(wp) < ID_SONG0 + 5) {
                musicEnsureDownloader();
                gMusicOn = true;
                if (LOWORD(wp) - ID_SONG0 != gSeason) gMusicFollow = LOWORD(wp) - ID_SONG0 == gSeason;
                musicSelect(LOWORD(wp) - ID_SONG0, 0);
            } else if (LOWORD(wp) == ID_SONG0 + 10) { gMusicFollow = !gMusicFollow; musicFollowSeason(); }

            break;
        case ID_EXIT: DestroyWindow(h); return 0;
        }
        saveSettings();
        appPushState();
        return 0;
    case WM_DISPLAYCHANGE:
        updateMonitorHz();
        if (gPaceThread) applyActivePace();
    case WM_SETTINGCHANGE:
        if (msg == WM_DISPLAYCHANGE || wp == SPI_SETWORKAREA) { setupScreen(); if (msg == WM_DISPLAYCHANGE) wpRestart(); }
        return 0;
    case WM_DESTROY:
        KillTimer(h, 1);
        setHook(false);
        musicShutdown();
        appShutdown();
        Shell_NotifyIconW(NIM_DELETE, &gNid);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

static LRESULT CALLBACK OverlayProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_NCHITTEST) return HTTRANSPARENT;
    if (msg == WM_MOUSEACTIVATE) return MA_NOACTIVATE;
    return DefWindowProcW(h, msg, wp, lp);
}

// ================================================================ DPI / версия
static void enableDpi() {
    HMODULE u = GetModuleHandleW(L"user32.dll");
    typedef BOOL (WINAPI *SetCtx)(HANDLE);
    auto f = (SetCtx)(void*)GetProcAddress(u, "SetProcessDpiAwarenessContext");
    if (!(f && f((HANDLE)(LONG_PTR)-4))) SetProcessDPIAware();
    typedef UINT (WINAPI *GetSysDpi)();
    auto g = (GetSysDpi)(void*)GetProcAddress(u, "GetDpiForSystem");
    UINT dpi = 96;
    if (g) dpi = g();
    else { HDC dc = GetDC(nullptr); dpi = GetDeviceCaps(dc, LOGPIXELSX); ReleaseDC(nullptr, dc); }
    S = std::max(1.0f, dpi / 96.0f);
}

static DWORD windowsBuild() {
    typedef LONG (WINAPI *RtlGetVersionFn)(OSVERSIONINFOW*);
    auto f = (RtlGetVersionFn)(void*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
    OSVERSIONINFOW v{};
    v.dwOSVersionInfoSize = sizeof(v);
    if (f && f(&v) == 0) return v.dwBuildNumber;
    return 0;
}

// ---- окно эффектов: через видеокарту (DirectComposition) или обычное слоёное окно
static HWND makeOverlay(bool gpuStyle) {
    DWORD ex = WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | (gpuStyle ? 0x00200000 /*WS_EX_NOREDIRECTIONBITMAP*/ : 0);
    HWND h = CreateWindowExW(ex, L"SugrobOverlay", L"", WS_POPUP, gVX, gVY, std::max(1, gW), std::max(1, gH), nullptr, nullptr, gInst, nullptr);
    if (h && gpuStyle) SetLayeredWindowAttributes(h, 0, 255, LWA_ALPHA);
    return h;
}
// клики проходят сквозь окно? Проверяем из другого потока — так же, как Windows решает, кому отдать мышь
static DWORD WINAPI HitThread(LPVOID p) { POINT pt = *(POINT*)p; return WindowFromPoint(pt) == gOverlay ? 1 : 0; }
static bool overlayClickThrough() {
    POINT pt{(gMons.empty() ? 200 : (gMons[0].left + gMons[0].right) / 2), (gMons.empty() ? 200 : (gMons[0].top + gMons[0].bottom) / 2)};
    HANDLE t = CreateThread(nullptr, 0, HitThread, &pt, 0, nullptr);
    if (!t) return true;
    WaitForSingleObject(t, 2000);
    DWORD code = 0;
    GetExitCodeThread(t, &code);
    CloseHandle(t);
    return code == 0;
}
static void createOverlayWindow() {
    gpu::shutdown();
    if (gOverlay) { DestroyWindow(gOverlay); gOverlay = nullptr; }
    if (gGpuWanted) {
        gOverlay = makeOverlay(true);
        if (gOverlay && gpu::init(gOverlay, std::max(1, gW), std::max(1, gH))) {
            ShowWindow(gOverlay, SW_SHOWNOACTIVATE);
            if (overlayClickThrough()) { alogFwd("render: GPU (DirectComposition)"); return; }
            gGpuWhy = "window not click-through";
        }
        alogFwd("render: GPU unavailable (%s), using CPU", gGpuWhy.c_str());
        gpu::shutdown();
        if (gOverlay) DestroyWindow(gOverlay);
    }
    gOverlay = makeOverlay(false);
    ShowWindow(gOverlay, SW_SHOWNOACTIVATE);
}
static void overlayRebuild() {
    createOverlayWindow();
    setupScreen();
    present();
}
static void gpuFallback() {
    alogFwd("render: GPU failed, switching to CPU");
    gGpuWanted = false;   // до перезапуска — обычным способом
    overlayRebuild();
    gGpuWanted = true;
}
static void gpuSetWanted(bool on) {
    if (on == gGpuWanted && on == gGpuOn) return;
    gGpuWanted = on;
    overlayRebuild();
}

static bool gScrMode = false;   // запущены как заставка (.scr /s) — показать её и выйти
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int) {
    gInst = hInst;
    detectPortable();
    {   // заставка Windows: Подоконник.scr /s — показать, /p — превью (не показываем), /c — настройки
        int argc = 0;
        LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
        std::wstring a1 = argc > 1 ? argv[1] : L"";
        for (auto& c : a1) c = towlower(c);
        std::wstring self = argv && argc > 0 ? argv[0] : L"";
        for (auto& c : self) c = towlower(c);
        if (argv) LocalFree(argv);
        bool isScr = self.size() > 4 && self.compare(self.size() - 4, 4, L".scr") == 0;
        if (a1.rfind(L"/p", 0) == 0 || a1.rfind(L"-p", 0) == 0 || a1.rfind(L"/l", 0) == 0) return 0;
        if (a1.rfind(L"/c", 0) == 0 || a1.rfind(L"-c", 0) == 0 || (isScr && a1.empty())) {
            if (HWND main = FindWindowW(L"SugrobMsg", nullptr)) { PostMessageW(main, WM_APP + 42, 0, 0); return 0; }
            std::wstring exe;
            if (cfgGetStr(L"ExePath", exe) && !exe.empty()) ShellExecuteW(nullptr, L"open", exe.c_str(), L"--settings", nullptr, SW_SHOWNORMAL);
            return 0;
        }
        if (a1.rfind(L"/s", 0) == 0 || a1.rfind(L"-s", 0) == 0) {
            if (HWND main = FindWindowW(L"SugrobMsg", nullptr)) {
                // Подоконник уже работает — заставку показывает он, а мы ждём, пока она идёт
                DWORD_PTR r = 0;
                SendMessageTimeoutW(main, WM_APP + 40, 0, 0, SMTO_ABORTIFHUNG, 3000, &r);
                Sleep(1500);
                for (;;) {
                    Sleep(300);
                    r = 0;
                    if (!IsWindow(main) || !SendMessageTimeoutW(main, WM_APP + 41, 0, 0, SMTO_ABORTIFHUNG, 2000, &r) || r == 0) break;
                }
                return 0;
            }
            gScrMode = true;
        }
    }
    HANDLE mutex = CreateMutexW(nullptr, TRUE, L"Sugrob_SnowDesktop_SingleInstance");
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        // уже запущен (например, старая версия) — закрываем его и запускаемся сами
        if (HWND old = FindWindowW(L"SugrobMsg", nullptr)) PostMessageW(old, WM_CLOSE, 0, 0);
        DWORD w = mutex ? WaitForSingleObject(mutex, 6000) : WAIT_FAILED;
        if (w != WAIT_OBJECT_0 && w != WAIT_ABANDONED) {
            MessageBoxW(nullptr, L"Подоконник уже запущен — его значок в трее (возле часов).",
                        L"Подоконник", MB_ICONINFORMATION);
            return 0;
        }
    }
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    enableDpi();
    CreateDirectoryW(baseDataDir().c_str(), nullptr);
    loadSettings();
    if (!gScrMode && regGet(L"Launched3", 0) == 0 && regGet(L"AutoInit", 0) == 0) {
        setAutostart(true);              // при первом запуске — сразу в автозагрузку
        regSet(L"AutoInit", 1);
    }
    if (autostartOn() && !gScrMode) setAutostart(true);   // автозапуск — на эту версию программы
    gSeason = effectiveSeason();
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_BAR_CLASSES};
    InitCommonControlsEx(&icc);
    // Windows 11 скругляет углы окон (8 px при 100%)
    if (windowsBuild() >= 22000) gCornerR = 8.0f * S;
#ifdef SUGROB_DEBUG
    gCornerR = 8.0f * S;
#endif
    gRs ^= GetTickCount() * 2654435761u;
    if (!gRs) gRs = 1;

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = MsgProc;
    wc.hInstance = hInst;
    wc.lpszClassName = L"SugrobMsg";
    wc.hIcon = LoadIconW(hInst, MAKEINTRESOURCEW(IDI_APP));
    RegisterClassExW(&wc);

    WNDCLASSEXW oc{};
    oc.cbSize = sizeof(oc);
    oc.lpfnWndProc = OverlayProc;
    oc.hInstance = hInst;
    oc.lpszClassName = L"SugrobOverlay";
    oc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    RegisterClassExW(&oc);

    gMsgWnd = CreateWindowExW(WS_EX_TOOLWINDOW, L"SugrobMsg", L"Подоконник", WS_POPUP,
                              0, 0, 0, 0, nullptr, nullptr, hInst, nullptr);
    if (!gMsgWnd) return 1;
    gVX = GetSystemMetrics(SM_XVIRTUALSCREEN); gVY = GetSystemMetrics(SM_YVIRTUALSCREEN);
    gW = std::max(1, GetSystemMetrics(SM_CXVIRTUALSCREEN)); gH = std::max(1, GetSystemMetrics(SM_CYVIRTUALSCREEN));
    gMons.clear();
    EnumDisplayMonitors(nullptr, nullptr, MonEnum, 0);
    createOverlayWindow();
    if (!gOverlay) return 1;

    setupScreen();
    present();

    gTaskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");
    bool first = regGet(L"Launched3", 0) == 0;
    addTray(first);
    if (first) regSet(L"Launched3", 1);

    setHook(gInteract);
    musicInit();
    appInit();
#ifdef SUGROB_DEBUG
    musicEnsureDownloader();
    musicSetOn(true);
#endif

    QueryPerformanceFrequency(&gFreq);
    QueryPerformanceCounter(&gLast);
    updateMonitorHz();
    applyActivePace();
    if (!gScrMode) SetTimer(gMsgWnd, 7, 2500, nullptr);   // сразу после запуска — проверить обновления
    gScrExitAfter = gScrMode;
    featuresInit();
    if (gScrMode) scrStart(true);
    else if (wcsstr(GetCommandLineW(), L"--settings")) showAppPage("settings");
    if (wcsstr(GetCommandLineW(), L"--updated")) {
        std::wstring t = L"Теперь у тебя версия " + W16(kAppVersion) + L".";
        updBalloon(L"Подоконник обновлён", t.c_str());
    }

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    stopFastPace();
    setHook(false);
    freeBuffer();
    if (mutex) { ReleaseMutex(mutex); CloseHandle(mutex); }
    return 0;
}
