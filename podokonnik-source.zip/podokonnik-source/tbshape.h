// Форма панели задач, когда её поменяла своя тема (док, трей отдельной «таблеткой»): сугробы копятся на верхних краях
// этих фигур, а не на прямоугольнике старой панели. Фигуры берём из UI Automation (элементы XAML панели задач:
// их рамки на экране) — в отдельном потоке раз в секунду, без внедрения в Проводник.
#pragma once
#include <uiautomation.h>
#include <mutex>
static DWORD regGet(const wchar_t* name, DWORD def);
static std::string U8(const std::wstring& w);
static bool writeFile(const std::wstring& p, const std::string& data);

struct TbShape { RECT r; float radius; };
static std::mutex gTbShapeMx;
static std::unordered_map<HWND, std::vector<TbShape>> gTbShapes;   // панель (Shell_TrayWnd / Shell_SecondaryTrayWnd) → фигуры
static volatile LONG gTbShapeWanted = 0;   // форма нужна (стоит док), поток работает
static float gTbShapeRadius = 0;   // из своей темы: скругление дока (px без масштаба)
static bool gTbShapeVisible = true;   // у дока есть видимый фон или кромка

static std::wstring tbBstr(BSTR b) { std::wstring s = b ? b : L""; if (b) SysFreeString(b); return s; }

struct TbElem { std::wstring cls, id, name; RECT r; CONTROLTYPEID type; };
static void tbCollect(IUIAutomation* ua, HWND tray, std::vector<TbElem>& out) {
    IUIAutomationElement* root = nullptr;
    if (FAILED(ua->ElementFromHandle(tray, &root)) || !root) return;
    IUIAutomationCacheRequest* cr = nullptr;
    IUIAutomationCondition* all = nullptr;
    ua->CreateCacheRequest(&cr);
    ua->CreateTrueCondition(&all);
    if (cr && all) {
        cr->AddProperty(UIA_BoundingRectanglePropertyId);
        cr->AddProperty(UIA_ClassNamePropertyId);
        cr->AddProperty(UIA_AutomationIdPropertyId);
        cr->AddProperty(UIA_NamePropertyId);
        cr->AddProperty(UIA_ControlTypePropertyId);
        IUIAutomationElementArray* arr = nullptr;
        if (SUCCEEDED(root->FindAllBuildCache(TreeScope_Descendants, all, cr, &arr)) && arr) {
            int n = 0; arr->get_Length(&n);
            for (int i = 0; i < n && i < 400; ++i) {
                IUIAutomationElement* e = nullptr;
                if (FAILED(arr->GetElement(i, &e)) || !e) continue;
                TbElem t{};
                BSTR b = nullptr;
                if (SUCCEEDED(e->get_CachedClassName(&b))) t.cls = tbBstr(b);
                b = nullptr; if (SUCCEEDED(e->get_CachedAutomationId(&b))) t.id = tbBstr(b);
                b = nullptr; if (SUCCEEDED(e->get_CachedName(&b))) t.name = tbBstr(b);
                e->get_CachedBoundingRectangle(&t.r);
                e->get_CachedControlType(&t.type);
                out.push_back(t);
                e->Release();
            }
            arr->Release();
        }
    }
    if (all) all->Release();
    if (cr) cr->Release();
    root->Release();
}

// фигуры дока по элементам: сам док — рамка TaskbarFrame (без неё — по кнопкам), трей — «таблетка» вокруг его кнопок
// (верх «таблетки» — по верху её кнопок)
static void tbShapesFrom(const std::vector<TbElem>& els, const RECT& tray, std::vector<TbShape>& out, float dpi) {
    auto inTray = [&](const RECT& r) { return r.right - r.left >= 8 && r.bottom - r.top >= 8 && r.top >= tray.top - 4 && r.bottom <= tray.bottom + 4 && r.left >= tray.left && r.right <= tray.right; };
    RECT dock{}, tr{};
    bool hasDock = false, hasTray = false;
    for (auto& e : els)
        if (e.id == L"TaskbarFrame" && inTray(e.r)) { dock = e.r; hasDock = true; }
    for (auto& e : els) {
        if (e.type != UIA_ButtonControlTypeId || !inTray(e.r)) continue;
        bool sys = e.cls.rfind(L"SystemTray.", 0) == 0;
        if (sys) {
            if (e.cls == L"SystemTray.ShowDesktopButton") continue;   // узкая полоска у края — не часть «таблетки»
            if (!hasTray) { tr = e.r; hasTray = true; } else UnionRect(&tr, &tr, &e.r);
        } else if (!hasDock || e.id == L"StartButton") {
            if (!hasDock && dock.right == 0) dock = e.r; else if (!hasDock) UnionRect(&dock, &dock, &e.r);
        }
    }
    float R = gTbShapeRadius * dpi;
    if (dock.right > dock.left) {
        if (!hasDock) { LONG pad = (LONG)(6 * dpi); dock.left -= pad; dock.right += pad; }
        out.push_back(TbShape{dock, R});
    }
    if (hasTray) {
        // фон трея у DockLike — ровно под кнопками (поля сделаны прозрачной рамкой), верх — по кнопкам, как у дока
        tr.right = std::min(tr.right, tray.right);
        out.push_back(TbShape{tr, std::max(R, 4 * dpi)});
    }
    if (!gTbShapeVisible) out.clear();   // док без фона и кромки — снегу не на чем лежать
}

static DWORD WINAPI TbShapeThread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    IUIAutomation* ua = nullptr;
    CoCreateInstance(__uuidof(CUIAutomation), nullptr, CLSCTX_INPROC_SERVER, __uuidof(IUIAutomation), (void**)&ua);
    bool dumped = regGet(L"XsLog", 0) == 0;   // разбор элементов панели — в tbuia.txt, только для отладки
    while (ua && gTbShapeWanted) {
        std::unordered_map<HWND, std::vector<TbShape>> now;
        std::vector<HWND> trays;
        if (HWND t = FindWindowW(L"Shell_TrayWnd", nullptr)) trays.push_back(t);
        for (HWND t = nullptr; (t = FindWindowExW(nullptr, t, L"Shell_SecondaryTrayWnd", nullptr));) trays.push_back(t);
        std::string dump;
        for (HWND t : trays) {
            RECT tr; if (!GetWindowRect(t, &tr)) continue;
            std::vector<TbElem> els;
            tbCollect(ua, t, els);
            UINT d = GetDpiForWindow(t); float dpi = d ? d / 96.0f : 1.0f;
            tbShapesFrom(els, tr, now[t], dpi);
            if (!dumped) {
                char b[512];
                snprintf(b, sizeof b, "tray %p %ld,%ld,%ld,%ld dpi %.2f\n", (void*)t, tr.left, tr.top, tr.right, tr.bottom, dpi); dump += b;
                for (auto& e : els) {
                    snprintf(b, sizeof b, "  %d %ld,%ld,%ld,%ld cls=%s id=%s name=%s\n", (int)e.type, e.r.left, e.r.top, e.r.right, e.r.bottom,
                             U8(e.cls).c_str(), U8(e.id).c_str(), U8(e.name).c_str());
                    dump += b;
                }
                for (auto& s : now[t]) { snprintf(b, sizeof b, "  SHAPE %ld,%ld,%ld,%ld R=%.0f\n", s.r.left, s.r.top, s.r.right, s.r.bottom, s.radius); dump += b; }
            }
        }
        if (!dumped) { writeFile(baseDataDir() + L"\\tbuia.txt", dump); dumped = true; }
        bool changed;
        {
            std::lock_guard<std::mutex> lk(gTbShapeMx);
            changed = now.size() != gTbShapes.size();
            if (!changed)
                for (auto& kv : now) {
                    auto it = gTbShapes.find(kv.first);
                    if (it == gTbShapes.end() || it->second.size() != kv.second.size()) { changed = true; break; }
                    for (size_t i = 0; i < kv.second.size(); ++i)
                        if (memcmp(&it->second[i].r, &kv.second[i].r, sizeof(RECT)) || it->second[i].radius != kv.second[i].radius) { changed = true; break; }
                }
            if (changed) gTbShapes.swap(now);
        }
        if (changed) gWinsDirty = true;
        for (int i = 0; i < 10 && gTbShapeWanted; ++i) Sleep(100);
    }
    if (ua) ua->Release();
    { std::lock_guard<std::mutex> lk(gTbShapeMx); gTbShapes.clear(); }
    gWinsDirty = true;
    CoUninitialize();
    return 0;
}
static void tbShapeWant(bool on) {
    if (on == (gTbShapeWanted != 0)) return;
    InterlockedExchange(&gTbShapeWanted, on ? 1 : 0);
    if (on) if (HANDLE h = CreateThread(nullptr, 0, TbShapeThread, nullptr, 0, nullptr)) CloseHandle(h);
}
// фигуры этой панели (копия под замком); пусто — формы ещё нет
static std::vector<TbShape> tbShapesOf(HWND tray) {
    std::lock_guard<std::mutex> lk(gTbShapeMx);
    auto it = gTbShapes.find(tray);
    return it == gTbShapes.end() ? std::vector<TbShape>{} : it->second;
}
