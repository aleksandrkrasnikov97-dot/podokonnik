// «Оформление»: тёмная/светлая тема Windows, прозрачность, цвет акцента (на панели задач, в «Пуске», на заголовках окон),
// эффект панели задач (прозрачная, размытие, акрил — SetWindowCompositionAttribute, как TranslucentTB),
// «ещё прозрачнее» для Windows 11 (UseOLEDTaskbarTransparency, нужен администратор), прозрачные окна Проводника,
// выравнивание и кнопки панели задач, автоскрытие. Всё, что меняем впервые, запоминаем — «Вернуть как было».
#pragma once
static void myAllOff();
static void myMaxApply(int mode);
static void myKeepTaskbarTop();

static const wchar_t* kPersKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize";
static const wchar_t* kDwmKey = L"Software\\Microsoft\\Windows\\DWM";
static const wchar_t* kAccKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent";
static const wchar_t* kAdvKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced";
static const wchar_t* kSearchKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Search";

static int gTbFx = 0;          // эффект панели задач: 0 — как в Windows, 1 — прозрачная, 2 — размытие, 3 — акрил, 4 — цветная
static DWORD gTbTint = 0x80202020;   // цвет и непрозрачность для «цветной» и «акрил» (AARRGGBB)
static int gExpAlpha = 100;    // непрозрачность окон Проводника, % (100 — как обычно)
static std::vector<HWND> gExpLayered;   // окна, которым мы включили прозрачность

static DWORD thRegGet(HKEY root, const wchar_t* key, const wchar_t* name, DWORD def) {
    DWORD v = def, sz = sizeof(v), type = 0;
    if (RegGetValueW(root, key, name, RRF_RT_REG_DWORD, &type, &v, &sz) != ERROR_SUCCESS) return def;
    return v;
}
static bool thRegHas(HKEY root, const wchar_t* key, const wchar_t* name) {
    DWORD sz = 0; return RegGetValueW(root, key, name, RRF_RT_ANY, nullptr, nullptr, &sz) == ERROR_SUCCESS;
}
// первое изменение значения — запомнить, как было (theme-backup.txt: ключ<TAB>имя<TAB>значение или «-» если не было)
static void thBackup(const wchar_t* key, const wchar_t* name) {
    std::wstring f = baseDataDir() + L"\\theme-backup.txt", line = std::wstring(key) + L"\t" + name + L"\t";
    std::string t; readFile(f, t);
    std::wstring w = W16(t);
    if (w.find(L"\n" + line) != std::wstring::npos || w.compare(0, line.size(), line) == 0) return;
    if (std::wstring(name) == L"AccentPalette") {
        BYTE b[64]; DWORD sz = sizeof b;
        std::wstring hex = L"-";
        if (RegGetValueW(HKEY_CURRENT_USER, key, name, RRF_RT_REG_BINARY, nullptr, b, &sz) == ERROR_SUCCESS) {
            hex = L"b"; wchar_t h[4]; for (DWORD i = 0; i < sz; ++i) { swprintf(h, 4, L"%02x", b[i]); hex += h; }
        }
        w += line + hex + L"\n";
    } else w += line + (thRegHas(HKEY_CURRENT_USER, key, name) ? std::to_wstring(thRegGet(HKEY_CURRENT_USER, key, name, 0)) : L"-") + L"\n";
    writeFile(f, U8(w));
}
static void thSet(const wchar_t* key, const wchar_t* name, DWORD v) {
    thBackup(key, name);
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, key, 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr) == ERROR_SUCCESS) {
        RegSetValueExW(k, name, 0, REG_DWORD, (const BYTE*)&v, sizeof v);
        RegCloseKey(k);
    }
}
static void thRestoreOne(const wchar_t* key, const wchar_t* name) {   // одно значение — как было до первого изменения
    std::string t;
    if (!readFile(baseDataDir() + L"\\theme-backup.txt", t)) return;
    std::wstring w = W16(t), line = std::wstring(key) + L"\t" + name + L"\t";
    size_t p = w.compare(0, line.size(), line) == 0 ? 0 : w.find(L"\n" + line);
    if (p == std::wstring::npos) return;
    if (p) ++p;
    size_t e = w.find(L'\n', p);
    std::wstring val = w.substr(p + line.size(), (e == std::wstring::npos ? w.size() : e) - p - line.size());
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, key, 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr) != ERROR_SUCCESS) return;
    if (val == L"-") RegDeleteValueW(k, name);
    else if (!val.empty() && val[0] != L'b') { DWORD v = (DWORD)wcstoul(val.c_str(), nullptr, 10); RegSetValueExW(k, name, 0, REG_DWORD, (const BYTE*)&v, sizeof v); }
    RegCloseKey(k);
}
static void thBroadcast(const wchar_t* what) {
    DWORD_PTR r;
    SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, (LPARAM)what, SMTO_ABORTIFHUNG, 1000, &r);
}

// ---------------------------------------------------------------- цвет акцента
// оттенки для AccentPalette: светлее и темнее основного
static DWORD thShade(DWORD rgb, float k) {   // k > 0 — к белому, k < 0 — к чёрному
    int c[3] = {(int)(rgb >> 16) & 255, (int)(rgb >> 8) & 255, (int)rgb & 255};
    for (int& x : c) x = k > 0 ? (int)(x + (255 - x) * k) : (int)(x * (1 + k));
    return (DWORD)((c[0] << 16) | (c[1] << 8) | c[2]);
}
static DWORD thAbgr(DWORD rgb) { return 0xFF000000 | ((rgb & 255) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 255); }
struct DwmColorParams { UINT color, afterglow, colorBalance, afterglowBalance, blurBalance, glassReflection, opaqueBlend; };
static void thSetAccent(DWORD rgb) {
    DWORD pal[8] = {thShade(rgb, 0.55f), thShade(rgb, 0.35f), thShade(rgb, 0.17f), rgb, thShade(rgb, -0.2f), thShade(rgb, -0.4f), thShade(rgb, -0.6f), 0x888888};
    BYTE b[32];
    for (int i = 0; i < 8; ++i) { b[i * 4] = (BYTE)(pal[i] >> 16); b[i * 4 + 1] = (BYTE)(pal[i] >> 8); b[i * 4 + 2] = (BYTE)pal[i]; b[i * 4 + 3] = 0; }
    thBackup(kAccKey, L"AccentPalette");
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kAccKey, 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr) == ERROR_SUCCESS) {
        RegSetValueExW(k, L"AccentPalette", 0, REG_BINARY, b, sizeof b);
        RegCloseKey(k);
    }
    thSet(kAccKey, L"AccentColorMenu", thAbgr(pal[4]));
    thSet(kAccKey, L"StartColorMenu", thAbgr(pal[5]));
    thSet(kDwmKey, L"AccentColor", thAbgr(rgb));
    thSet(kDwmKey, L"ColorizationColor", 0xC4000000 | rgb);
    thSet(kDwmKey, L"ColorizationAfterglow", 0xC4000000 | rgb);
    thSet(L"Control Panel\\Desktop", L"AutoColorization", 0);
    // применить сразу (то же делает «Параметры»): DwmSetColorizationParameters — функция dwmapi без имени, номер 131
    if (HMODULE dm = GetModuleHandleW(L"dwmapi.dll")) {
        typedef HRESULT(WINAPI * SetP)(DwmColorParams*, UINT);
        if (SetP f = (SetP)GetProcAddress(dm, MAKEINTRESOURCEA(131))) { DwmColorParams p{0xC4000000 | rgb, 0xC4000000 | rgb, 89, 10, 1, 0, 0}; f(&p, 0); }
    }
    thBroadcast(L"ImmersiveColorSet");
}
static DWORD thAccentNow() {
    DWORD a = thRegGet(HKEY_CURRENT_USER, kDwmKey, L"AccentColor", 0xFFD47800);   // ABGR
    return ((a & 255) << 16) | (a & 0xFF00) | ((a >> 16) & 255);
}

// ---------------------------------------------------------------- панель задач: эффект (прозрачная, размытие, акрил)
struct ThAccentPolicy { int state; int flags; DWORD color; int anim; };
struct ThCompData { int attr; PVOID data; SIZE_T size; };
static void thApplyTaskbar(bool reset = false) {
    static auto swca = (BOOL(WINAPI*)(HWND, ThCompData*))GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowCompositionAttribute");
    if (!swca) return;
    int st = reset ? 0 : gTbFx == 1 ? 2 : gTbFx == 2 ? 3 : gTbFx == 3 ? 4 : gTbFx == 4 ? 2 : 0;
    DWORD c = gTbTint;   // AARRGGBB → ABGR
    DWORD abgr = (c & 0xFF000000) | ((c & 255) << 16) | (c & 0xFF00) | ((c >> 16) & 255);
    ThAccentPolicy ap{st, 2, gTbFx == 1 ? 0 : abgr, 0};
    if (gTbFx == 3 && (abgr >> 24) == 0) ap.color = (abgr & 0xFFFFFF) | 0x01000000;   // акрил не любит полностью прозрачный цвет
    ThCompData d{19, &ap, sizeof ap};   // WCA_ACCENT_POLICY
    for (HWND h = FindWindowW(L"Shell_TrayWnd", nullptr); h; h = nullptr) swca(h, &d);
    HWND s = nullptr;
    while ((s = FindWindowExW(nullptr, s, L"Shell_SecondaryTrayWnd", nullptr))) swca(s, &d);
}

// ---------------------------------------------------------------- прозрачные окна Проводника
static void thExplorerTick() {
    if (gExpAlpha >= 100) {
        for (HWND h : gExpLayered) if (IsWindow(h)) { SetWindowLongPtrW(h, GWL_EXSTYLE, GetWindowLongPtrW(h, GWL_EXSTYLE) & ~WS_EX_LAYERED); RedrawWindow(h, nullptr, nullptr, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN); }
        gExpLayered.clear();
        return;
    }
    gExpLayered.erase(std::remove_if(gExpLayered.begin(), gExpLayered.end(), [](HWND h) { return !IsWindow(h); }), gExpLayered.end());
    HWND h = nullptr;
    BYTE a = (BYTE)(gExpAlpha * 255 / 100);
    while ((h = FindWindowExW(nullptr, h, L"CabinetWClass", nullptr))) {
        LONG_PTR ex = GetWindowLongPtrW(h, GWL_EXSTYLE);
        bool ours = std::find(gExpLayered.begin(), gExpLayered.end(), h) != gExpLayered.end();
        if (!(ex & WS_EX_LAYERED)) { SetWindowLongPtrW(h, GWL_EXSTYLE, ex | WS_EX_LAYERED); if (!ours) gExpLayered.push_back(h); ours = true; }
        if (ours) SetLayeredWindowAttributes(h, 0, a, LWA_ALPHA);
    }
}

// ---------------------------------------------------------------- Windows 11: «ещё прозрачнее» (HKLM, через администратора)
static const wchar_t* kOledKey = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced";
static bool thOledOn() { return thRegGet(HKEY_LOCAL_MACHINE, kOledKey, L"UseOLEDTaskbarTransparency", 0) != 0; }
static int thAdminMain(bool on) {   // «Подоконник.exe --theme-oled 1|0»
    HKEY k;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, kOledKey, 0, nullptr, 0, KEY_WRITE | KEY_WOW64_64KEY, nullptr, &k, nullptr) != ERROR_SUCCESS) return 2;
    if (on) { DWORD v = 1; RegSetValueExW(k, L"UseOLEDTaskbarTransparency", 0, REG_DWORD, (const BYTE*)&v, sizeof v); }
    else RegDeleteValueW(k, L"UseOLEDTaskbarTransparency");
    RegCloseKey(k);
    return 0;
}

// ---------------------------------------------------------------- состояние, команды, настройки
static void themeSave() { regSet(L"TbFx", (DWORD)gTbFx); regSet(L"TbTint", gTbTint); regSet(L"ExpAlpha", (DWORD)gExpAlpha); }
static bool gTbFxWasOn = false;
static void themeLoad() {
    // фон панели через SetWindowCompositionAttribute и прозрачность окон из вкладки убраны: под темами панели
    // этот фон рисовался во всю ширину за доком. Если раньше был включён — один раз сбрасываем
    gTbFxWasOn = regGet(L"TbFx", 0) != 0 || regGet(L"ExpAlpha", 100) < 100;
    gTbFx = 0; gExpAlpha = 100;
    gTbTint = regGet(L"TbTint", 0x80202020);
    if (gTbFxWasOn) { regSet(L"TbFx", 0); regSet(L"ExpAlpha", 100); }
}
// Тема панели (xstyle) делает саму панель прозрачной, но под ней у окна Shell_TrayWnd остаётся своя подложка DWM —
// чёрная или акриловая полоса во всю ширину. Пока тема стоит, подложку держим полностью прозрачной.
static bool gTbClearOn = false;
static void thTaskbarClear(bool on) {
    static auto swca = (BOOL(WINAPI*)(HWND, ThCompData*))GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowCompositionAttribute");
    static auto gwca = (BOOL(WINAPI*)(HWND, ThCompData*))GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetWindowCompositionAttribute");
    if (!swca) return;
    auto apply = [&](HWND h) {
        if (on) {
            ThAccentPolicy cur{};
            ThCompData q{19, &cur, sizeof cur};
            if (gwca && gwca(h, &q) && cur.state == 2 && cur.color == 0) return;   // уже прозрачная — не трогаем, без мигания
            ThAccentPolicy ap{2, 2, 0, 0};   // ACCENT_ENABLE_TRANSPARENTGRADIENT с прозрачным цветом
            ThCompData d{19, &ap, sizeof ap};
            swca(h, &d);
        }
    };
    if (HWND h = FindWindowW(L"Shell_TrayWnd", nullptr)) apply(h);
    HWND s = nullptr;
    while ((s = FindWindowExW(nullptr, s, L"Shell_SecondaryTrayWnd", nullptr))) apply(s);
    if (!on && gTbClearOn) {   // тему сняли — пусть Проводник сам вернёт свою подложку
        ThAccentPolicy ap{0, 0, 0, 0};
        ThCompData d{19, &ap, sizeof ap};
        if (HWND h = FindWindowW(L"Shell_TrayWnd", nullptr)) swca(h, &d);
        while ((s = FindWindowExW(nullptr, s, L"Shell_SecondaryTrayWnd", nullptr))) swca(s, &d);
        thBroadcast(L"ImmersiveColorSet");
        if (HWND h = FindWindowW(L"Shell_TrayWnd", nullptr)) PostMessageW(h, 0x0320, 0, 0);   // WM_DWMCOLORIZATIONCHANGED
    }
    gTbClearOn = on;
}
static void themeTick() {   // таймер 41, раз в 0,25 с: Проводник сбрасывает подложку панели (открыли «Пуск», сменили тему) — ставим снова
    if (gXsTbOn || gTbClearOn) thTaskbarClear(gXsTbOn);
    myKeepTaskbarTop();
    if (gTbFx) thApplyTaskbar();
    static int n = 0;
    if (++n % 3 == 0) thExplorerTick();
}
static void thRefreshTaskbar();
static void themeStart() {
    if (gTbFxWasOn) { thApplyTaskbar(true); thBroadcast(L"ImmersiveColorSet"); thRefreshTaskbar(); }   // старая «подложка» — вернуть Windows
    SetTimer(gMsgWnd, 41, 250, nullptr);
}
static void themeState(js::Value& v) {
    auto num = [&](const char* k, double n) { js::Value x; x.type = js::Value::Num; x.n = n; v.o.emplace_back(k, x); };
    auto bl = [&](const char* k, bool b) { js::Value x; x.type = js::Value::Bool; x.b = b; v.o.emplace_back(k, x); };
    bool appsLight = thRegGet(HKEY_CURRENT_USER, kPersKey, L"AppsUseLightTheme", 1) != 0, sysLight = thRegGet(HKEY_CURRENT_USER, kPersKey, L"SystemUsesLightTheme", 0) != 0;
    num("thMode", appsLight && sysLight ? 0 : !appsLight && !sysLight ? 1 : 2);   // 0 светлая, 1 тёмная, 2 тёмная панель
    bl("thTransp", thRegGet(HKEY_CURRENT_USER, kPersKey, L"EnableTransparency", 1) != 0);
    num("thAccent", thAccentNow());
    bl("thAccentAuto", thRegGet(HKEY_CURRENT_USER, L"Control Panel\\Desktop", L"AutoColorization", 0) != 0);
    bl("thAccentBar", thRegGet(HKEY_CURRENT_USER, kPersKey, L"ColorPrevalence", 0) != 0);
    bl("thAccentTitle", thRegGet(HKEY_CURRENT_USER, kDwmKey, L"ColorPrevalence", 0) != 0);
    num("thTbFx", gTbFx); num("thTbTint", gTbTint); num("thExpAlpha", gExpAlpha);
    num("thAlign", thRegGet(HKEY_CURRENT_USER, kAdvKey, L"TaskbarAl", 1));
    num("thSearch", thRegGet(HKEY_CURRENT_USER, kSearchKey, L"SearchboxTaskbarMode", 1));
    bl("thTaskView", thRegGet(HKEY_CURRENT_USER, kAdvKey, L"ShowTaskViewButton", 1) != 0);
    APPBARDATA ab{sizeof ab};
    bl("thAutoHide", (SHAppBarMessage(ABM_GETSTATE, &ab) & ABS_AUTOHIDE) != 0);
    bl("thOled", thOledOn());
    {
        OSVERSIONINFOW ov{sizeof ov};
        typedef LONG(WINAPI * RtlGV)(OSVERSIONINFOW*);
        if (RtlGV f = (RtlGV)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion")) f(&ov);
        num("thBuild", ov.dwBuildNumber);
    }
    std::string t; bl("thHasBackup", readFile(baseDataDir() + L"\\theme-backup.txt", t) && !t.empty());
}
static void thRestore() {
    std::string t;
    if (!readFile(baseDataDir() + L"\\theme-backup.txt", t)) return;
    std::wstring w = W16(t);
    for (size_t p = 0; p < w.size();) {
        size_t e = w.find(L'\n', p); if (e == std::wstring::npos) e = w.size();
        std::wstring line = w.substr(p, e - p); p = e + 1;
        size_t a = line.find(L'\t'), b = line.find(L'\t', a + 1);
        if (a == std::wstring::npos || b == std::wstring::npos) continue;
        std::wstring key = line.substr(0, a), name = line.substr(a + 1, b - a - 1), val = line.substr(b + 1);
        HKEY k;
        if (RegCreateKeyExW(HKEY_CURRENT_USER, key.c_str(), 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr) != ERROR_SUCCESS) continue;
        if (val == L"-") RegDeleteValueW(k, name.c_str());
        else if (val[0] == L'b') {
            std::vector<BYTE> bin;
            for (size_t i = 1; i + 1 < val.size(); i += 2) bin.push_back((BYTE)wcstol(val.substr(i, 2).c_str(), nullptr, 16));
            RegSetValueExW(k, name.c_str(), 0, REG_BINARY, bin.data(), (DWORD)bin.size());
        } else { DWORD v = (DWORD)wcstoul(val.c_str(), nullptr, 10); RegSetValueExW(k, name.c_str(), 0, REG_DWORD, (const BYTE*)&v, sizeof v); }
        RegCloseKey(k);
    }
    DeleteFileW((baseDataDir() + L"\\theme-backup.txt").c_str());
    DWORD acc = thAccentNow();
    if (HMODULE dm = GetModuleHandleW(L"dwmapi.dll")) {
        typedef HRESULT(WINAPI * SetP)(DwmColorParams*, UINT);
        if (SetP f = (SetP)GetProcAddress(dm, MAKEINTRESOURCEA(131))) { DwmColorParams pr{0xC4000000 | acc, 0xC4000000 | acc, 89, 10, 1, 0, 0}; f(&pr, 0); }
    }
    gTbFx = 0; gExpAlpha = 100; thApplyTaskbar(true); thExplorerTick();
    thBroadcast(L"ImmersiveColorSet"); thBroadcast(L"TraySettings");
}
static void thRefreshTaskbar() {   // кнопки и выравнивание: Проводник перечитывает их по этому сообщению
    thBroadcast(L"TraySettings");
    if (HWND tb = FindWindowW(L"Shell_TrayWnd", nullptr)) PostMessageW(tb, WM_SETTINGCHANGE, 0, (LPARAM)L"TraySettings");
}
static bool themeUi(const std::string& cmd, const js::Value& m) {
    if (cmd.rfind("th", 0) != 0) return false;
    double v = m.num("value");
    if (cmd == "thMode") {
        int md = (int)v;
        thSet(kPersKey, L"AppsUseLightTheme", md == 1 ? 0 : 1);      // 2 — светлые окна, тёмные панель и «Пуск»
        thSet(kPersKey, L"SystemUsesLightTheme", md == 0 ? 1 : 0);
        thBroadcast(L"ImmersiveColorSet");
    } else if (cmd == "thTransp") { thSet(kPersKey, L"EnableTransparency", v ? 1 : 0); thBroadcast(L"ImmersiveColorSet"); }
    else if (cmd == "thAccent") thSetAccent((DWORD)v & 0xFFFFFF);
    else if (cmd == "thAccentAuto") { thSet(L"Control Panel\\Desktop", L"AutoColorization", v ? 1 : 0); thBroadcast(L"ImmersiveColorSet"); }
    else if (cmd == "thAccentBar") { thSet(kPersKey, L"ColorPrevalence", v ? 1 : 0); thBroadcast(L"ImmersiveColorSet"); }
    else if (cmd == "thAccentTitle") {
        thSet(kDwmKey, L"ColorPrevalence", v ? 1 : 0);
        thSetAccent(thAccentNow());   // заголовки перекрашиваются, когда DWM получает цвет заново
    }
    else if (cmd == "thTbFx") { gTbFx = (int)clampf((float)v, 0, 4); thApplyTaskbar(gTbFx == 0); themeSave(); }
    else if (cmd == "thTbTint") { gTbTint = (DWORD)v; thApplyTaskbar(); themeSave(); }
    else if (cmd == "thExpAlpha") { gExpAlpha = (int)clampf((float)v, 40, 100); thExplorerTick(); themeSave(); }
    else if (cmd == "thAlign") { thSet(kAdvKey, L"TaskbarAl", v ? 1 : 0); thRefreshTaskbar(); }
    else if (cmd == "thSearch") { thSet(kSearchKey, L"SearchboxTaskbarMode", (DWORD)clampf((float)v, 0, 3)); thRefreshTaskbar(); }
    else if (cmd == "thTaskView") { thSet(kAdvKey, L"ShowTaskViewButton", v ? 1 : 0); thRefreshTaskbar(); }
    else if (cmd == "thAutoHide") {
        APPBARDATA ab{sizeof ab};
        ab.hWnd = FindWindowW(L"Shell_TrayWnd", nullptr);
        ab.lParam = v ? ABS_AUTOHIDE : ABS_ALWAYSONTOP;
        SHAppBarMessage(ABM_SETSTATE, &ab);
    }
    else if (cmd == "thOled") {
        wchar_t self[MAX_PATH * 2] = {0}; GetModuleFileNameW(nullptr, self, MAX_PATH * 2);
        std::wstring prm = v ? L"--theme-oled 1" : L"--theme-oled 0";
        SHELLEXECUTEINFOW ei{sizeof(ei)};
        ei.fMask = SEE_MASK_NOCLOSEPROCESS; ei.lpVerb = L"runas"; ei.lpFile = self; ei.lpParameters = prm.c_str(); ei.nShow = SW_HIDE;
        if (ShellExecuteExW(&ei) && ei.hProcess) {
            WaitForSingleObject(ei.hProcess, 30000); CloseHandle(ei.hProcess);
            icoRestartExplorer();   // панель перечитывает это только при запуске Проводника
        } else appToast(T8("Windows не дала разрешение администратора", "Windows didn't grant administrator rights"));
    }
    else if (cmd == "thPreset") {   // готовый вид одной кнопкой
        int md = (int)m.num("mode"); DWORD acc = (DWORD)m.num("accent");
        thSet(kPersKey, L"AppsUseLightTheme", md == 1 ? 0 : 1);
        thSet(kPersKey, L"SystemUsesLightTheme", md == 0 ? 1 : 0);
        thSet(kPersKey, L"EnableTransparency", 1);
        thSet(kPersKey, L"ColorPrevalence", m.num("bar") ? 1 : 0);
        thSet(kDwmKey, L"ColorPrevalence", m.num("title") ? 1 : 0);
        thSetAccent(acc & 0xFFFFFF);
        gTbFx = (int)m.num("tbfx"); gTbTint = (DWORD)m.num("tint", (double)gTbTint); gExpAlpha = (int)clampf((float)m.num("exp", 100), 40, 100);
        thApplyTaskbar(gTbFx == 0); thExplorerTick(); themeSave();
        thBroadcast(L"ImmersiveColorSet");
    }
    else if (cmd == "thRestore") {
        thRestore();
        myAllOff();   // своя тема: панель, «Пуск», стекло, рамки — выключить
        WhkJob* j = new WhkJob;   // темы Windhawk — тоже убрать (сам Windhawk остаётся)
        if (!whkTheme(gWhk, kWhkTbMod).empty()) { j->tbSet = true; }
        if (!whkTheme(gWhk, kWhkSmMod).empty()) { j->smSet = true; }
        if (j->tbSet || j->smSet) whkStart(j); else delete j;
    }
    else return false;
    appPushState();
    return true;
}
static void winLookStop();
static void themeStop() {   // выход: панель и окна Проводника — как было у Windows
    KillTimer(gMsgWnd, 41);
    winLookStop();
    myMaxApply(0);   // развёрнутые окна — снова до панели, автоскрытие — как было (при запуске вернём)
    if (gTbFx) { thApplyTaskbar(true); thRefreshTaskbar(); }
    int a = gExpAlpha; gExpAlpha = 100; thExplorerTick(); gExpAlpha = a;
}
