# Чтение картинок из .cur/.ani (PNG и BMP внутри) — для превью в tools/cursors.py
import io, struct
from PIL import Image
def dib(data):
    hs, w, h2, planes, bpp = struct.unpack_from('<IiiHH', data, 0)
    h = abs(h2) // 2
    ncol = struct.unpack_from('<I', data, 32)[0] if hs >= 36 else 0
    if bpp <= 8 and ncol == 0: ncol = 1 << bpp
    pal_off = hs; pix_off = hs + 4 * (ncol if bpp <= 8 else 0)
    stride = ((w * bpp + 31) // 32) * 4
    mstride = ((w + 31) // 32) * 4
    moff = pix_off + stride * h
    im = Image.new('RGBA', (w, h)); px = im.load()
    pal = [struct.unpack_from('<BBBB', data, pal_off + 4 * i) for i in range(ncol)] if bpp <= 8 else []
    anyalpha = False
    rows = []
    for y in range(h):
        row = pix_off + y * stride
        for x in range(w):
            if bpp == 32: b, g, r, a = data[row + 4*x: row + 4*x + 4]; anyalpha |= a != 0
            elif bpp == 24: b, g, r = data[row + 3*x: row + 3*x + 3]; a = 255
            else:
                bit = x * bpp; byte = data[row + bit // 8]; idx = (byte >> (8 - bpp - bit % 8)) & ((1 << bpp) - 1)
                b, g, r, _ = pal[idx]; a = 255
            rows.append((x, h - 1 - y, r, g, b, a))
    for x, y, r, g, b, a in rows:
        if bpp != 32 or not anyalpha:
            yy = h - 1 - y; mb = data[moff + yy * mstride + x // 8] if moff + yy * mstride + x // 8 < len(data) else 0
            a = 0 if (mb >> (7 - x % 8)) & 1 else 255
        px[x, y] = (r, g, b, a)
    return im
def ico_image(b, want=48):
    n = struct.unpack_from('<H', b, 4)[0]; best = None
    for i in range(n):
        w, h, _, _, hx, hy, sz, off = struct.unpack_from('<BBBBHHII', b, 6 + 16 * i); w = w or 256
        if best is None or abs(w - want) < abs(best[0] - want): best = (w, off, sz)
    w, off, sz = best; data = b[off:off + sz]
    if data[:8] == b'\x89PNG\r\n\x1a\n': return Image.open(io.BytesIO(data)).convert('RGBA')
    return dib(data)
def first_frame(b):
    if b[:4] != b'RIFF': return b
    i = 12
    while i < len(b) - 8:
        cid = b[i:i+4]; ln = struct.unpack_from('<I', b, i + 4)[0]
        if cid == b'LIST': i += 12; continue
        if cid == b'icon': return b[i+8:i+8+ln]
        i += 8 + ln + (ln & 1)
    raise ValueError('no frame')
def cursor_image(path, want=48):
    return ico_image(first_frame(open(path, 'rb').read()), want)
