#!/usr/bin/env python3
# Каталог наборов курсоров из проекта Cursors (https://github.com/rohzzn/cursors, MIT; у каждого
# набора свой автор и лицензия — они в pack.ini и packs/NOTICE.md). Сами курсоры в Подоконник
# не встраиваются: программа скачивает выбранный набор с raw.githubusercontent.com по закреплённому
# коммиту. Здесь собираем:
#   build/cursors.txt — для программы: какие файлы у набора, их размер и роль в Windows;
#   ui/cursors.js     — для окна настроек: названия, разделы, авторы и маленькие картинки.
# Запуск: python3 tools/cursors.py <папка git clone rohzzn/cursors>
import sys, os, io, json, base64, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from curimg import cursor_image

SRC = sys.argv[1]
SHA = subprocess.run(['git', '-C', SRC, 'rev-parse', 'HEAD'], capture_output=True, text=True, check=True).stdout.strip()
ROLES = ['Arrow', 'Help', 'AppStarting', 'Wait', 'Crosshair', 'IBeam', 'NWPen', 'No',
         'SizeNS', 'SizeWE', 'SizeNWSE', 'SizeNESW', 'SizeAll', 'UpArrow', 'Hand', 'Pin', 'Person']
CATS = {'Minimal': 'Простые', 'macOS': 'Как на Mac', 'Retro': 'Ретро', 'Pixel & Gaming': 'Пиксельные',
        'Neon': 'Неон', 'Glass': 'Стекло', 'Cute': 'Милые', 'Animated': 'Анимированные'}

def ini(p):
    d = {}
    for line in open(p, encoding='utf-8-sig'):
        if '=' in line:
            k, v = line.rstrip('\r\n').split('=', 1); d[k] = v
    return d

packs = []
for d in sorted(os.listdir(f'{SRC}/packs')):
    pd = f'{SRC}/packs/{d}'
    if not os.path.isfile(f'{pd}/pack.ini'): continue
    m = ini(f'{pd}/pack.ini')
    files = []
    for r in ROLES:
        fn = m.get(r, '')
        if fn and os.path.isfile(f'{pd}/{fn}'):
            files.append((r, fn, os.path.getsize(f'{pd}/{fn}')))
    imgs = []
    for r in ('Arrow', 'Hand', 'IBeam'):
        im = cursor_image(f'{pd}/{m[r]}', 48)
        bb = im.getbbox()
        if bb: im = im.crop(bb)
        im.thumbnail((40, 40))
        b = io.BytesIO(); im.save(b, 'PNG', optimize=True)
        imgs.append('data:image/png;base64,' + base64.b64encode(b.getvalue()).decode())
    packs.append({'id': d, 'name': m.get('name', d), 'cat': CATS.get(m.get('category', ''), m.get('category', '')),
                  'order': int(m.get('order', '999') or 999), 'author': m.get('author', ''), 'license': m.get('license', ''),
                  'url': m.get('url', ''), 'size': sum(f[2] for f in files), 'img': imgs, 'files': files})
packs.sort(key=lambda p: p['order'])

with open('build/cursors.txt', 'w', encoding='utf-8', newline='\n') as f:
    f.write(f'sha\t{SHA}\n')
    for p in packs:
        f.write('pack\t%s\t%s\t%s\t%s\t%s\n' % (p['id'], p['name'], p['author'], p['license'], p['url']))
        for r, fn, sz in p['files']:
            f.write('file\t%s\t%s\t%d\n' % (r, fn, sz))
ui = [{k: p[k] for k in ('id', 'name', 'cat', 'author', 'license', 'size', 'img')} for p in packs]
with open('ui/cursors.js', 'w', encoding='utf-8') as f:
    f.write('// собрано tools/cursors.py из github.com/rohzzn/cursors@%s — не править руками\n' % SHA[:7])
    f.write('const CURSOR_PACKS = ' + json.dumps(ui, ensure_ascii=False) + ';\n')
print(len(packs), 'packs,', os.path.getsize('ui/cursors.js') // 1024, 'KB js,', sum(p['size'] for p in packs) // 1024, 'KB all files')

# ---- сообщество: 11 тысяч наборов с rw-designer.com (только названия и ссылки — сами наборы
# программа скачивает с сайта, когда их выбирают; картинки грузит окно настроек прямо с сайта)
import re
rows, lic = [], []
hdr = None
for line in open(f'{SRC}/packs/catalog.tsv', encoding='utf-8'):
    line = line.rstrip('\r\n')
    if not line or line[0] == '#': continue
    f = line.split('\t')
    if hdr is None: hdr = f; continue
    g = lambda c: f[hdr.index(c)].strip() if hdr.index(c) < len(f) else ''
    slug, arrow = g('slug'), g('arrow')
    if not re.fullmatch(r'[\w.~-]+', slug) or not arrow.isdigit(): continue
    L = g('license')
    if L not in lic: lic.append(L)
    num = lambda c: int(g(c)) if g(c).isdigit() else 0
    rows.append([slug, g('name'), g('author'), num('downloads'), lic.index(L), num('roles'), num('animated'), 1 if g('toprated') == '1' else 0,
                 int(arrow), num('link'), num('text'), num('busy')])
with open('ui/cursors-web.js', 'w', encoding='utf-8') as f:
    f.write('// собрано tools/cursors.py из github.com/rohzzn/cursors (packs/catalog.tsv) — не править руками\n')
    f.write('// [slug, название, автор, скачиваний, лицензия, ролей, анимированных, лучший, картинки: стрелка, ссылка, текст, занят]\n')
    f.write('const CURSOR_WEB_LIC = ' + json.dumps(lic, ensure_ascii=False) + ';\n')
    f.write('const CURSOR_WEB = ' + json.dumps(rows, ensure_ascii=False, separators=(',', ':')) + ';\n')
print(len(rows), 'community sets,', os.path.getsize('ui/cursors-web.js') // 1024, 'KB')
