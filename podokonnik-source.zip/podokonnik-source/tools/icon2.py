import sys
from PIL import Image, ImageDraw, ImageFilter
def make(sz):
    S=sz*4
    im=Image.new("RGBA",(S,S),(0,0,0,0))
    mask=Image.new("L",(S,S),0); ImageDraw.Draw(mask).rounded_rectangle([0,0,S-1,S-1],radius=int(S*0.22),fill=255)
    bg=Image.new("RGBA",(S,S))
    d=ImageDraw.Draw(bg)
    for y in range(S):
        t=y/S
        d.line([(0,y),(S,y)],fill=(int(26+40*t),int(36+56*t),int(78+70*t),255))
    im.paste(bg,(0,0),mask)
    d=ImageDraw.Draw(im)
    # окно
    x0,x1=int(S*.22),int(S*.78); y0,y1=int(S*.16),int(S*.70)
    fw=max(2,int(S*.045))
    d.rounded_rectangle([x0,y0,x1,y1],radius=int(S*.06),fill=(236,241,250,255))
    ix0,iy0,ix1,iy1=x0+fw,y0+fw,x1-fw,y1-fw
    glow=Image.new("RGBA",(S,S),(0,0,0,0)); gd=ImageDraw.Draw(glow)
    for i in range(iy1-iy0):
        t=i/(iy1-iy0)
        gd.line([(ix0,iy0+i),(ix1,iy0+i)],fill=(255,int(214-40*t),int(122-50*t),255))
    im.alpha_composite(glow)
    cx=(x0+x1)//2; cy=(y0+y1)//2
    d.rectangle([cx-fw//2,y0,cx+fw//2,y1],fill=(236,241,250,255))
    d.rectangle([x0,cy-fw//2,x1,cy+fw//2],fill=(236,241,250,255))
    # подоконник
    sy=y1-int(S*.01)
    d.rounded_rectangle([int(S*.12),sy,int(S*.88),sy+int(S*.09)],radius=int(S*.03),fill=(250,252,255,255))
    # снег на подоконнике
    if sz>=24:
        for i,(px,r) in enumerate([(.2,.07),(.32,.085),(.46,.075),(.6,.09),(.74,.075),(.84,.06)]):
            d.ellipse([int(S*px-S*r),sy-int(S*r*0.9),int(S*px+S*r),sy+int(S*r*0.6)],fill=(255,255,255,255))
    out=Image.new("RGBA",(S,S),(0,0,0,0)); out.paste(im,(0,0),mask)
    return out.resize((sz,sz),Image.LANCZOS)
sizes=[16,20,24,32,40,48,64,256]
imgs=[make(s) for s in sizes]
imgs[-1].save(sys.argv[1],sizes=[(s,s) for s in sizes],append_images=imgs[:-1])
imgs[-1].save(sys.argv[2])
big=Image.new("RGBA",(256*2+48+32+20,256),(40,40,40,255)); x=0
for im in [imgs[-1],imgs[3].resize((128,128),Image.NEAREST),imgs[0].resize((64,64),Image.NEAREST)]:
    big.paste(im,(x,0),im); x+=im.size[0]+20
big.save(sys.argv[3])
