#!/usr/bin/env python3
# Собрать icons/catalog.txt (свои паки + темы) и icons/previews.txt (все превью одним файлом).
# Запуск: python3 tools/iconcat.py <папка icons> <строки своих паков>
import os, sys, base64
d = sys.argv[1]
own = [l for l in open(sys.argv[2]).read().splitlines() if l.startswith("pack\t")]
themes = open(sys.argv[3] if len(sys.argv) > 3 else os.path.join(d, "catalog-themes.txt")).read().splitlines()
head = [l for l in themes if not l.startswith("pack\t")]
packs = own + [l for l in themes if l.startswith("pack\t")]
# какие имена значка искать в теме (для тем с сайта gnome-look.org — их Подоконник разбирает сам)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import iconpacks
names = ["names\t%s\t%s" % (pid, " ".join(c)) for pid, c in iconpacks.PLACES] + ["names\t%s\t%s" % (aid, " ".join(c)) for aid, _, c in iconpacks.APPS]
open(os.path.join(d, "catalog.txt"), "w").write("\n".join(head + names + packs) + "\n")
prev = []
for l in packs:
    pid = l.split("\t")[1]
    f = os.path.join(d, pid, "preview.png")
    if os.path.isfile(f):
        import io
        from PIL import Image
        im = Image.open(f).convert("RGBA").quantize(256, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.NONE)
        b = io.BytesIO(); im.save(b, "PNG", optimize=True)
        data = min(b.getvalue(), open(f, "rb").read(), key=len)
        prev.append(pid + "\t" + base64.b64encode(data).decode())
open(os.path.join(d, "previews.txt"), "w").write("\n".join(prev) + "\n")
print("паков:", len(packs), "превью:", len(prev), "КБ:", os.path.getsize(os.path.join(d, "previews.txt")) // 1024)
