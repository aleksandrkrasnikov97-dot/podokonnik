#!/usr/bin/env python3
# Паки иконок для Подоконника из открытых тем значков (GPL-3.0).
# Запуск: python3 tools/iconpacks.py <папка с темами> <папка сайта>/icons
# Темы: git clone --filter=blob:none и checkout нужных папок (см. THEMES).
# Результат: icons/catalog.txt (паки и правила «программа → значок»), icons/<пак>/<значок>.png (256×256),
# icons/<пак>/list.txt (какие значки есть), icons/<пак>/preview.png, icons/<пак>/LICENSE.
import os, subprocess, sys, io, shutil
from PIL import Image

# семейства тем: id, имя, имя (en), папка клона, авторы, лицензия, адрес, папки значков (по порядку), файл лицензии, варианты
# вариант: (суффикс id, имя-добавка ru, en, цвет для кнопки, как получить)
#   {}                       — основной (со значками программ)
#   {"overlay": [папки]}     — свои значки папок поверх основных
#   {"recolor": (было, стало)} — перекрасить значки папок
#   {"papirus": цвет}        — цветные папки Papirus
def _col(pairs, how):
    return [(k, ru, en, hx, how(k, hx)) for k, ru, en, hx in pairs]

RU_COL = {"red": ("красный", "red"), "pink": ("розовый", "pink"), "purple": ("фиолетовый", "purple"), "blue": ("синий", "blue"),
          "green": ("зелёный", "green"), "yellow": ("жёлтый", "yellow"), "orange": ("оранжевый", "orange"), "brown": ("коричневый", "brown"),
          "grey": ("серый", "grey"), "black": ("чёрный", "black"), "teal": ("бирюзовый", "teal"), "cyan": ("голубой", "cyan"),
          "lightblue": ("светло-голубой", "light blue"), "nord": ("Nord", "Nord"), "white": ("белый", "white"), "turquoise": ("бирюзовый", "turquoise"),
          "special": ("особый", "special"), "manjaro": ("Manjaro", "Manjaro"), "ubuntu": ("Ubuntu", "Ubuntu"), "dracula": ("Dracula", "Dracula")}
def C(k, hx):
    ru, en = RU_COL.get(k, (k, k))
    return (k, ru, en, hx)

PAPIRUS_COLORS = [("adwaita", "Adwaita", "Adwaita", "#93c0ea"), ("black", "чёрный", "black", "#4f4f4f"), ("bluegrey", "сине-серый", "blue grey", "#607d8b"),
    ("breeze", "Breeze", "Breeze", "#57b8ec"), ("brown", "коричневый", "brown", "#ae8e6c"), ("carmine", "кармин", "carmine", "#a30002"),
    ("cyan", "голубой", "cyan", "#00bcd4"), ("darkcyan", "тёмно-голубой", "dark cyan", "#45abb7"), ("deeporange", "морковный", "deep orange", "#eb6637"),
    ("green", "зелёный", "green", "#87b158"), ("grey", "серый", "grey", "#8e8e8e"), ("indigo", "индиго", "indigo", "#5c6bc0"),
    ("magenta", "пурпурный", "magenta", "#ca71df"), ("nordic", "северный", "nordic", "#81a1c1"), ("orange", "оранжевый", "orange", "#ee923a"),
    ("palebrown", "бежевый", "pale brown", "#d1bfae"), ("paleorange", "персиковый", "pale orange", "#eeca8f"), ("pink", "розовый", "pink", "#f06292"),
    ("red", "красный", "red", "#e25252"), ("teal", "бирюзовый", "teal", "#16a085"), ("violet", "фиолетовый", "violet", "#7e57c2"),
    ("white", "белый", "white", "#e4e4e4"), ("yaru", "Yaru", "Yaru", "#676767"), ("yellow", "жёлтый", "yellow", "#f9bd30")]
TELA_COLORS = [C("black", "#4d4d4d"), C("blue", "#5677fc"), C("brown", "#795548"), C("green", "#66bb6a"), C("grey", "#bdbdbd"), C("orange", "#ff9800"),
    C("pink", "#f06292"), C("purple", "#7e57c2"), C("red", "#ef5350"), C("yellow", "#ffca28"), C("manjaro", "#16a085"), C("ubuntu", "#fb8441"),
    C("dracula", "#44475a"), C("nord", "#4d576a")]
COLLOID = [C("purple", "#BA68C8"), C("pink", "#F06292"), C("red", "#F44336"), C("orange", "#FB8C00"), C("yellow", "#FFD600"), C("green", "#66BB6A"),
    C("teal", "#4DB6AC"), C("grey", "#888888")]
COLLOID_NORD = [("nord", "Nord синий", "Nord blue", "#89a3c2"), ("nord-purple", "Nord фиолетовый", "Nord purple", "#c89dbf"), ("nord-pink", "Nord розовый", "Nord pink", "#dc98b1"),
    ("nord-red", "Nord красный", "Nord red", "#d4878f"), ("nord-orange", "Nord оранжевый", "Nord orange", "#dca493"), ("nord-yellow", "Nord жёлтый", "Nord yellow", "#eac985"),
    ("nord-green", "Nord зелёный", "Nord green", "#a0c082"), ("nord-teal", "Nord бирюзовый", "Nord teal", "#83b9b8"),
    ("dracula", "Dracula синий", "Dracula blue", "#6272a4"), ("dracula-purple", "Dracula фиолетовый", "Dracula purple", "#bd93f9"), ("dracula-pink", "Dracula розовый", "Dracula pink", "#ff79c6"),
    ("dracula-red", "Dracula красный", "Dracula red", "#ff5555"), ("dracula-orange", "Dracula оранжевый", "Dracula orange", "#ffb86c"),
    ("dracula-yellow", "Dracula жёлтый", "Dracula yellow", "#f1fa8c"), ("dracula-green", "Dracula зелёный", "Dracula green", "#50fa7b")]
FLUENT = [C("green", "#67cb6b"), C("grey", "#808080"), C("orange", "#ff9c33"), C("pink", "#ff5c93"), C("purple", "#dc63ee"), C("red", "#ff6666"),
    C("yellow", "#ffcb52"), C("teal", "#32c8ba")]
VIMIX = [("amber", "янтарь", "amber", "#f89406"), ("amethyst", "аметист", "amethyst", "#ab47bc"), ("axinite", "аксинит", "axinite", "#8b6039"),
    ("beryl", "берилл", "beryl", "#2eb398"), ("doder", "синий", "doder", "#4285f4"), ("ruby", "рубин", "ruby", "#f0544c"),
    ("jade", "нефрит", "jade", "#86be43"), ("black", "чёрный", "black", "#686868")]

FAMILIES = [
    dict(id="papirus", ru="Papirus", en="Papirus", folder="papirus-icon-theme", author="Papirus Development Team", lic="GPL-3.0",
         url="https://github.com/PapirusDevelopmentTeam/papirus-icon-theme", licfile="LICENSE", color="#5294e2",
         dirs=["Papirus/64x64/apps", "Papirus/64x64/places", "Papirus/64x64/devices"],
         variants=[(k, ru, en, hx, {"papirus": k}) for k, ru, en, hx in PAPIRUS_COLORS]),
    dict(id="candy", ru="Candy — неон", en="Candy — neon", folder="candy-icons", author="EliverLara", lic="GPL-3.0",
         url="https://github.com/EliverLara/candy-icons", licfile="LICENSE", color="#ff4fb5",
         dirs=["apps/scalable", "places/48", "preferences/scalable", "devices/scalable"], variants=[]),
    dict(id="numix", ru="Numix Circle — круглые", en="Numix Circle — round", folder="numix-icon-theme-circle", author="Numix Project", lic="GPL-3.0",
         url="https://github.com/numixproject/numix-icon-theme-circle", licfile="LICENSE", color="#f0544c", dirs=["Numix-Circle/48/apps"], variants=[]),
    dict(id="whitesur", ru="WhiteSur — как на Mac", en="WhiteSur — Mac style", folder="WhiteSur-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/WhiteSur-icon-theme", licfile="COPYING", color="#5fa8f5",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col([C(k, h) for k, h in [("green", "#66bb6a"), ("grey", "#9e9e9e"), ("nord", "#81a1c1"), ("orange", "#ff9800"), ("pink", "#f06292"),
                        ("purple", "#ab47bc"), ("red", "#ef5350"), ("yellow", "#ffca28")]], lambda k, hx: {"overlay": ["colors/color-" + k]})),
    dict(id="win11", ru="Win11", en="Win11", folder="Win11-icon-theme", author="yeyushengfan258", lic="GPL-3.0",
         url="https://github.com/yeyushengfan258/Win11-icon-theme", licfile="COPYING", color="#ffc94d",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col([C(k, h) for k, h in [("black", "#555555"), ("blue", "#3d8ee8"), ("green", "#43a047"), ("nord", "#81a1c1"), ("purple", "#8e5bd6"),
                        ("red", "#e53935")]], lambda k, hx: {"overlay": ["colors/color-" + k]})),
    dict(id="we10x", ru="We10X", en="We10X", folder="We10X-icon-theme", author="yeyushengfan258", lic="GPL-3.0",
         url="https://github.com/yeyushengfan258/We10X-icon-theme", licfile="COPYING", color="#ffca28",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col([C(k, h) for k, h in [("black", "#555555"), ("blue", "#3d8ee8"), ("green", "#43a047"), ("orange", "#fb8c00"), ("purple", "#8e5bd6"),
                        ("red", "#e53935"), ("special", "#26c6da")]], lambda k, hx: {"overlay": ["colors/color-" + k]})),
    dict(id="reversal", ru="Reversal", en="Reversal", folder="Reversal-icon-theme", author="yeyushengfan258", lic="GPL-3.0",
         url="https://github.com/yeyushengfan258/Reversal-icon-theme", licfile="COPYING", color="#5294e2",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col([C(k, h) for k, h in [("black", "#555555"), ("blue", "#3d8ee8"), ("brown", "#8d6e63"), ("cyan", "#26c6da"), ("green", "#43a047"),
                        ("grey", "#9e9e9e"), ("lightblue", "#64b5f6"), ("orange", "#fb8c00"), ("pink", "#ec407a"), ("purple", "#8e5bd6"), ("red", "#e53935")]],
                       lambda k, hx: {"overlay": ["colors/color-" + k]})),
    dict(id="mcmojave", ru="McMojave — круглые", en="McMojave Circle", folder="McMojave-circle", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/McMojave-circle", licfile="COPYING", color="#2f9cf0",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col([C(k, h) for k, h in [("red", "#ef5350"), ("pink", "#f06292"), ("purple", "#ab47bc"), ("blue", "#3d8ee8"), ("green", "#66bb6a"),
                        ("yellow", "#ffca28"), ("orange", "#ff9800"), ("brown", "#8d6e63"), ("grey", "#9e9e9e"), ("black", "#555555")]],
                       lambda k, hx: {"overlay": ["colorful-folder/folder-" + k]})),
    dict(id="fluent", ru="Fluent", en="Fluent", folder="Fluent-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/Fluent-icon-theme", licfile="COPYING", color="#198ee6",
         dirs=["src/scalable/apps", "links/scalable/apps", "src/scalable/places", "links/scalable/places", "src/scalable/devices", "links/scalable/devices"],
         variants=_col(FLUENT, lambda k, hx: {"recolor": ("#198ee6", hx)})),
    dict(id="tela", ru="Tela", en="Tela", folder="Tela-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/Tela-icon-theme", licfile="COPYING", color="#5294e2", tela=True,
         dirs=["src/scalable/apps", "links/scalable/apps", "src/scalable/places", "links/scalable/places", "src/scalable/devices", "links/scalable/devices"],
         variants=_col(TELA_COLORS, lambda k, hx: {"recolor": ("#5294e2", hx)})),
    dict(id="telacircle", ru="Tela Circle — круглые", en="Tela Circle", folder="Tela-circle-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/Tela-circle-icon-theme", licfile="COPYING", color="#5294e2", tela=True,
         dirs=["src/scalable/apps", "links/scalable/apps", "src/scalable/places-normal", "links/scalable/places", "src/scalable/devices", "links/scalable/devices"],
         variants=_col(TELA_COLORS, lambda k, hx: {"recolor": ("#5294e2", hx)})),
    dict(id="colloid", ru="Colloid", en="Colloid", folder="Colloid-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/Colloid-icon-theme", licfile="LICENSE", color="#60c0f0",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col(COLLOID + COLLOID_NORD, lambda k, hx: {"recolor": ("#60c0f0", hx)})),
    dict(id="vimix", ru="Vimix", en="Vimix", folder="Vimix-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/Vimix-icon-theme", licfile="COPYING", color="#f4be70",
         dirs=["src/scalable/apps", "links/scalable/apps", "src/scalable/places", "links/scalable/places", "src/scalable/devices", "links/scalable/devices"],
         variants=_col(VIMIX, lambda k, hx: {"recolor": ("#f4be70", hx)})),
    dict(id="qogir", ru="Qogir", en="Qogir", folder="Qogir-icon-theme", author="Vince Liuice", lic="GPL-3.0",
         url="https://github.com/vinceliuice/Qogir-icon-theme", licfile="COPYING", color="#5294e2",
         dirs=["src/scalable/apps", "links/scalable/apps", "src/scalable/places", "links/scalable/places", "src/scalable/devices", "links/scalable/devices"],
         variants=[("manjaro", "Manjaro", "Manjaro", "#2eb398", {"overlay": ["src/theme-Manjaro/scalable/places"]}),
                   ("ubuntu", "Ubuntu", "Ubuntu", "#fb8441", {"overlay": ["src/theme-Ubuntu/scalable/places"]})]),
    dict(id="nordzy", ru="Nordzy — северные", en="Nordzy", folder="Nordzy-icon", author="alvatip", lic="GPL-3.0",
         url="https://github.com/alvatip/Nordzy-icon", licfile="COPYING", color="#81a1c1",
         dirs=["src/apps/scalable", "links/apps/scalable", "src/places/scalable", "links/places/scalable", "src/devices/scalable", "links/devices/scalable"],
         variants=_col([C(k, h) for k, h in [("cyan", "#88c0d0"), ("green", "#a3be8c"), ("orange", "#d08770"), ("pink", "#b48ead"), ("purple", "#9b7fc0"),
                        ("red", "#bf616a"), ("turquoise", "#8fbcbb"), ("yellow", "#ebcb8b")]], lambda k, hx: {"overlay": ["colors/color-" + k]})),
    dict(id="kora", ru="Kora", en="Kora", folder="kora", author="bikass", lic="GPL-3.0",
         url="https://github.com/bikass/kora", licfile="LICENSE", color="#2d9cdb",
         dirs=["kora/apps/scalable", "kora/places/scalable", "kora/devices/scalable"],
         variants=[("grey", "серый", "grey", "#9aa0a6", {"overlay": ["kora-pgrey/places/scalable"]})]),
]

# значки папок и системы: id → имена в теме
PLACES = [
    ("folder", ["folder"]),
    ("folder-open", ["folder-open"]),
    ("folder-desktop", ["user-desktop", "folder-desktop"]),
    ("folder-documents", ["folder-documents"]),
    ("folder-download", ["folder-download", "folder-downloads"]),
    ("folder-music", ["folder-music"]),
    ("folder-pictures", ["folder-pictures", "folder-images"]),
    ("folder-videos", ["folder-videos", "folder-video"]),
    ("user-home", ["user-home", "folder-home"]),
    ("computer", ["computer", "system", "computer-laptop"]),
    ("trash", ["user-trash", "trashcan_empty", "trash-empty"]),
    ("trash-full", ["user-trash-full", "trashcan_full", "trash-full"]),
]

# программы и игры: id значка, как узнать ярлык (e: exe без .exe, n: название ярлыка целиком, p: кусок пути), имена в темах
# всё в нижнем регистре
APPS = [
    ("chrome", "e:chrome n:google chrome", ["google-chrome", "chrome", "chromium-browser"]),
    ("firefox", "e:firefox n:firefox n:mozilla firefox", ["firefox", "org.mozilla.firefox"]),
    ("edge", "e:msedge n:microsoft edge", ["microsoft-edge", "com.microsoft.Edge"]),
    ("yandex-browser", "p:\\yandexbrowser\\ n:yandex n:яндекс n:yandex browser n:яндекс браузер", ["yandex-browser", "yandex-browser-beta"]),
    ("opera", "p:\\programs\\opera\\ n:opera n:браузер opera", ["opera", "com.opera.Opera"]),
    ("opera-gx", "p:\\programs\\opera gx\\ n:opera gx n:браузер opera gx", ["opera-gx", "opera", "com.opera.Opera"]),
    ("brave", "e:brave n:brave", ["brave-browser", "brave", "com.brave.Browser"]),
    ("vivaldi", "e:vivaldi n:vivaldi", ["vivaldi", "com.vivaldi.Vivaldi"]),
    ("tor", "p:\\tor browser\\ n:tor browser n:start tor browser", ["tor-browser", "torbrowser", "torbrowser-launcher"]),
    ("telegram", "e:telegram n:telegram n:telegram desktop e:ayugram", ["telegram", "org.telegram.desktop", "telegram-desktop"]),
    ("discord", "e:discord p:\\discord\\ n:discord", ["discord", "com.discordapp.Discord"]),
    ("whatsapp", "e:whatsapp n:whatsapp", ["whatsapp", "whatsapp-desktop", "com.github.eneshecan.WhatsAppForLinux"]),
    ("viber", "e:viber n:viber", ["viber", "com.viber.Viber"]),
    ("skype", "e:skype n:skype", ["skype", "skypeforlinux", "ms-skype", "com.skype.Client"]),
    ("zoom", "e:zoom n:zoom n:zoom workplace", ["Zoom", "zoom", "zoom-desktop", "us.zoom.Zoom"]),
    ("slack", "e:slack n:slack", ["slack", "com.slack.Slack"]),
    ("teams", "e:ms-teams e:teams n:microsoft teams n:teams", ["teams", "teams-for-linux", "microsoft-teams"]),
    ("vk", "n:vk n:vk messenger n:вконтакте e:vk messenger", ["vk", "vk-messenger"]),
    ("max", "n:max e:max", ["MAX", "max-messenger"]),
    ("steam", "e:steam n:steam", ["steam", "steam-launcher", "com.valvesoftware.Steam"]),
    ("epic", "e:epicgameslauncher n:epic games launcher n:epic games", ["epic-games", "epic-games-launcher", "09BE_EpicGamesLauncher.0", "com.heroicgameslauncher.hgl", "heroic"]),
    ("battlenet", "e:battle.net launcher e:battle.net n:battle.net", ["battle.net", "battlenet", "blizzard"]),
    ("ea", "e:eadesktop e:ealauncher n:ea n:ea app", ["ea-app", "origin", "ea"]),
    ("gog", "e:galaxyclient n:gog galaxy", ["gog-galaxy", "gog", "com.gog.Galaxy", "minigalaxy"]),
    ("ubisoft", "e:ubisoftconnect e:upc n:ubisoft connect", ["ubisoft-connect", "uplay", "ubisoft"]),
    ("xbox", "n:xbox e:xboxpcapp", ["xbox", "xbox-app", "io.github.mimbrero.XboxGamePass"]),
    ("minecraft", "e:minecraftlauncher e:minecraft n:minecraft n:minecraft launcher", ["minecraft-launcher", "minecraft", "com.mojang.Minecraft"]),
    ("tlauncher", "e:tlauncher n:tlauncher", ["tlauncher", "ru.turikhay.tlauncher", "minecraft-launcher", "minecraft"]),
    ("lunar", "e:lunar client n:lunar client", ["lunar-client", "lunarclient"]),
    ("roblox", "e:robloxplayerbeta e:robloxplayerlauncher e:robloxplayerlauncherbeta n:roblox player n:roblox", ["CE93_RobloxPlayerLauncher.0", "grapejuice-roblox-player", "net.brinkervii.grapejuice.robloxplayer", "roblox"]),
    ("roblox-studio", "e:robloxstudiobeta e:robloxstudiolauncherbeta n:roblox studio", ["631F_RobloxStudioLauncherBeta.0", "grapejuice-roblox-studio", "net.brinkervii.grapejuice.robloxstudio"]),
    ("league", "e:leagueclient e:riotclientservices n:league of legends", ["league-of-legends", "leagueoflegends"]),
    ("gta5", "e:gta5 e:playgtav e:gta5_enhanced n:grand theft auto v n:gta v n:gta 5", ["gta-5", "steam_icon_271590"]),
    ("cyberpunk", "e:cyberpunk2077 n:cyberpunk 2077", ["cyberpunk-2077", "steam_icon_1091500"]),
    ("wot", "e:worldoftanks e:wgc n:мир танков n:world of tanks n:wargaming.net game center n:lesta game center", ["world-of-tanks", "com.worldoftanks.Client"]),
    ("warthunder", "p:\\war thunder\\ n:war thunder", ["war-thunder", "lutris_war-thunder"]),
    ("warframe", "n:warframe", ["warframe", "lutris_warframe"]),
    ("osu", "e:osu! n:osu! n:osu", ["osu", "osu-lazer", "sh.ppy.osu"]),
    ("geforcenow", "e:geforcenow n:geforce now n:nvidia geforce now", ["geforcenow", "com.nvidia.geforcenow"]),
    ("nvidia", "n:nvidia app n:geforce experience n:nvidia control panel", ["nvidia", "nvidia-settings"]),
    ("amd", "e:radeonsoftware n:amd software", ["amd", "amd-radeon"]),
    ("spotify", "e:spotify n:spotify", ["spotify", "spotify-client", "com.spotify.Client"]),
    ("yandex-music", "n:яндекс музыка n:yandex music p:\\yandexmusic", ["yandex-music", "yandexmusic"]),
    ("vlc", "e:vlc n:vlc media player n:vlc", ["vlc", "org.videolan.VLC"]),
    ("obs", "e:obs64 e:obs n:obs studio", ["com.obsproject.Studio", "obs", "obs-studio"]),
    ("aimp", "e:aimp n:aimp", ["aimp"]),
    ("audacity", "e:audacity n:audacity", ["audacity", "org.audacityteam.Audacity"]),
    ("itunes", "e:itunes n:itunes", ["itunes"]),
    ("twitch", "n:twitch", ["twitch", "com.vinszent.GnomeTwitch", "gnome-twitch"]),
    ("youtube", "n:youtube", ["youtube", "youtube-music"]),
    ("netflix", "n:netflix", ["netflix"]),
    ("tiktok", "n:tiktok", ["tiktok"]),
    ("instagram", "n:instagram", ["instagram"]),
    ("photoshop", "e:photoshop n:adobe photoshop", ["AdobePhotoshop", "photoshop", "adobe-photoshop"]),
    ("illustrator", "e:illustrator n:adobe illustrator", ["AdobeIllustrator", "illustrator", "adobe-illustrator"]),
    ("premiere", "e:adobe premiere pro n:adobe premiere pro", ["AdobePremierePro", "adobe-premiere-pro"]),
    ("aftereffects", "e:afterfx n:adobe after effects", ["AdobeAfterEffect", "adobe-after-effects"]),
    ("lightroom", "e:lightroom n:adobe lightroom n:adobe lightroom classic", ["AdobeLightroom", "AdobeLightroomClassic"]),
    ("audition", "e:adobe audition n:adobe audition", ["AdobeAudition"]),
    ("animate", "e:animate n:adobe animate", ["AdobeAnimate"]),
    ("mediaencoder", "e:adobe media encoder n:adobe media encoder", ["AdobeMediaEncoder"]),
    ("acrobat", "e:acrobat e:acrord32 n:adobe acrobat n:adobe acrobat reader", ["com.adobe.Reader", "AdobeReader9", "acroread", "adobe-reader"]),
    ("blender", "e:blender e:blender-launcher n:blender", ["blender", "org.blender.Blender"]),
    ("gimp", "e:gimp-2.10 e:gimp-3.0 e:gimp n:gimp", ["gimp", "org.gimp.GIMP"]),
    ("krita", "e:krita n:krita", ["krita", "org.kde.krita"]),
    ("inkscape", "e:inkscape n:inkscape", ["inkscape", "org.inkscape.Inkscape"]),
    ("resolve", "e:resolve n:davinci resolve", ["davinci-resolve", "resolve", "com.blackmagic.Resolve"]),
    ("capcut", "e:capcut n:capcut", ["capcut"]),
    ("figma", "e:figma n:figma", ["figma", "figma-linux"]),
    ("flstudio", "e:fl64 e:fl n:fl studio", ["fl-studio", "flstudio"]),
    ("unityhub", "e:unity hub n:unity hub", ["unityhub", "com.unity.UnityHub", "appimagekit-unityhub", "unity-editor-icon"]),
    ("unreal", "e:unrealeditor n:unreal engine", ["unreal-engine", "unrealengine", "ue4editor"]),
    ("godot", "e:godot n:godot n:godot engine", ["godot", "org.godotengine.Godot"]),
    ("aseprite", "e:aseprite n:aseprite", ["aseprite"]),
    ("shotcut", "e:shotcut n:shotcut", ["shotcut", "org.shotcut.Shotcut"]),
    ("kdenlive", "e:kdenlive n:kdenlive", ["kdenlive", "org.kde.kdenlive"]),
    ("handbrake", "e:handbrake n:handbrake", ["fr.handbrake.ghb", "handbrake"]),
    ("vscode", "e:code n:visual studio code", ["visual-studio-code", "code", "vscode", "com.visualstudio.code"]),
    ("cursor", "e:cursor n:cursor", ["cursor"]),
    ("vstudio", "e:devenv n:visual studio 2022 n:visual studio 2019 n:visual studio", ["visual-studio", "vstudio"]),
    ("idea", "e:idea64 n:intellij idea n:intellij idea community edition", ["intellij-idea", "idea", "com.jetbrains.IntelliJ-IDEA-Community", "intellij-idea-community"]),
    ("pycharm", "e:pycharm64 n:pycharm n:pycharm community edition", ["pycharm", "com.jetbrains.PyCharm-Community", "pycharm-community"]),
    ("webstorm", "e:webstorm64 n:webstorm", ["webstorm", "com.jetbrains.WebStorm"]),
    ("rider", "e:rider64 n:rider n:jetbrains rider", ["rider", "com.jetbrains.Rider"]),
    ("clion", "e:clion64 n:clion", ["clion", "com.jetbrains.CLion"]),
    ("androidstudio", "e:studio64 n:android studio", ["android-studio", "com.google.AndroidStudio"]),
    ("git", "e:git-bash n:git bash n:git gui e:git-gui", ["git", "git-gui", "gitg"]),
    ("terminal", "e:windowsterminal e:wt n:terminal n:windows terminal", ["utilities-terminal", "terminal", "org.gnome.Terminal"]),
    ("cmd", "e:cmd n:командная строка n:command prompt", ["utilities-terminal", "terminal"]),
    ("powershell", "e:powershell e:pwsh n:windows powershell n:powershell", ["powershell", "utilities-terminal"]),
    ("notepadpp", "e:notepad++ n:notepad++", ["notepad++", "notepadqq", "com.notepadqq.Notepadqq"]),
    ("notepad", "e:notepad n:блокнот n:notepad", ["accessories-text-editor", "notepad", "org.gnome.TextEditor"]),
    ("sublime", "e:sublime_text n:sublime text", ["sublime-text", "com.sublimetext.three", "sublime_text"]),
    ("githubdesktop", "e:githubdesktop n:github desktop", ["github-desktop", "io.github.shiftey.Desktop"]),
    ("docker", "e:docker desktop n:docker desktop", ["docker-desktop", "docker"]),
    ("postman", "e:postman n:postman", ["postman", "com.getpostman.Postman"]),
    ("python", "e:python e:pythonw e:idle n:idle n:python", ["python", "idle", "python3"]),
    ("word", "e:winword n:word", ["ms-word", "com.wps.Office.wpsmain", "libreoffice-writer"]),
    ("excel", "e:excel n:excel", ["ms-excel", "com.wps.Office.etmain", "libreoffice-calc"]),
    ("powerpoint", "e:powerpnt n:powerpoint", ["ms-powerpoint", "com.wps.Office.wppmain", "libreoffice-impress"]),
    ("outlook", "e:outlook e:olk n:outlook n:outlook (classic)", ["ms-outlook", "outlook"]),
    ("onenote", "e:onenote n:onenote", ["ms-onenote", "onenote"]),
    ("onedrive", "e:onedrive n:onedrive", ["ms-onedrive", "onedrive"]),
    ("wps", "e:wps n:wps office", ["wps-office-wpsmain", "com.wps.Office.wpsmain", "wps-office2019-kprometheus"]),
    ("libreoffice", "e:soffice n:libreoffice", ["libreoffice-startcenter", "libreoffice-main", "org.libreoffice.LibreOffice"]),
    ("notion", "e:notion n:notion", ["notion", "notion-app", "notion-desktop"]),
    ("obsidian", "e:obsidian n:obsidian", ["obsidian", "md.obsidian.Obsidian"]),
    ("evernote", "e:evernote n:evernote", ["evernote"]),
    ("gdrive", "n:google drive e:googledrivefs", ["google-drive", "web-google-drive"]),
    ("yandex-disk", "n:яндекс диск n:yandex disk p:\\yandex.disk", ["yandex-disk"]),
    ("dropbox", "e:dropbox n:dropbox", ["dropbox", "com.dropbox.Client"]),
    ("anki", "e:anki n:anki", ["anki", "net.ankiweb.Anki"]),
    ("7zip", "e:7zfm n:7-zip file manager n:7-zip", ["7zip", "p7zip", "7z"]),
    ("winrar", "e:winrar n:winrar", ["winrar", "rar", "archive-manager", "file-roller"]),
    ("qbittorrent", "e:qbittorrent n:qbittorrent", ["qbittorrent", "org.qbittorrent.qBittorrent"]),
    ("utorrent", "e:utorrent n:utorrent n:µtorrent", ["utorrent", "qbittorrent"]),
    ("calc", "e:calc n:калькулятор n:calculator", ["accessories-calculator", "gnome-calculator", "calculator"]),
    ("explorer", "e:explorer n:проводник n:file explorer", ["system-file-manager", "file-manager", "org.gnome.Nautilus"]),
    ("control", "e:control n:панель управления n:control panel", ["preferences-system", "gnome-control-center", "systemsettings"]),
    ("taskmgr", "e:taskmgr n:диспетчер задач n:task manager", ["utilities-system-monitor", "gnome-system-monitor"]),
    ("anydesk", "e:anydesk n:anydesk", ["anydesk", "com.anydesk.Anydesk"]),
    ("teamviewer", "e:teamviewer n:teamviewer", ["teamviewer", "com.teamviewer.TeamViewer"]),
    ("rustdesk", "e:rustdesk n:rustdesk", ["rustdesk", "com.rustdesk.RustDesk"]),
    ("virtualbox", "e:virtualbox n:oracle vm virtualbox n:virtualbox", ["virtualbox", "org.virtualbox.VirtualBox"]),
    ("vmware", "e:vmware n:vmware workstation pro n:vmware workstation", ["vmware", "vmware-workstation"]),
    ("keepass", "e:keepassxc e:keepass n:keepassxc n:keepass", ["keepassxc", "keepass", "org.keepassxc.KeePassXC"]),
    ("bitwarden", "e:bitwarden n:bitwarden", ["bitwarden", "com.bitwarden.desktop"]),
    ("1password", "e:1password n:1password", ["1password"]),
    ("thunderbird", "e:thunderbird n:thunderbird n:mozilla thunderbird", ["thunderbird", "org.mozilla.Thunderbird"]),
    ("filezilla", "e:filezilla n:filezilla", ["filezilla", "org.filezillaproject.Filezilla"]),
    ("putty", "e:putty n:putty", ["putty"]),
    ("protonvpn", "e:protonvpn n:proton vpn n:protonvpn", ["protonvpn", "proton-vpn-logo", "com.protonvpn.www"]),
    ("flameshot", "e:flameshot n:flameshot", ["flameshot", "org.flameshot.Flameshot"]),
    ("calibre", "e:calibre n:calibre", ["calibre", "com.calibre_ebook.calibre", "calibre-gui"]),
    ("terraria", "e:terraria n:terraria", ["terraria", "steam_icon_105600"]),
    ("csgo", "e:cs2 e:csgo n:counter-strike 2 n:counter-strike global offensive", ["csgo", "steam_icon_730"]),
    ("dota2", "e:dota2 n:dota 2", ["dota2", "steam_icon_570"]),
    ("rust", "e:rustclient n:rust", ["rust", "steam_icon_252490"]),
    ("amongus", "e:among us n:among us", ["among-us", "steam_icon_945360"]),
    ("stardew", "e:stardew valley n:stardew valley", ["stardew-valley", "steam_icon_413150"]),
    ("hollowknight", "e:hollow_knight n:hollow knight", ["hollow-knight", "steam_icon_367520"]),
    ("lutris", "n:lutris", ["lutris"]),
    ("itch", "e:itch n:itch", ["itch", "io.itch.itch"]),
    ("playnite", "e:playnite.desktopapp n:playnite", ["playnite"]),
    ("wallpaperengine", "e:wallpaper32 e:wallpaper64 n:wallpaper engine", ["wallpaper-engine", "livewallpaper", "preferences-desktop-wallpaper"]),
]


# рамка для программ, у которых в теме нет значка: их собственный значок кладём на неё
TILES = {   # форма, цвет сверху, цвет снизу, обводка, доля значка внутри
    "papirus": ("round", (247, 248, 250), (226, 231, 238), None, 0.6),
    "candy": ("round", (30, 32, 52), (16, 17, 30), "neon", 0.56),
    "numix": ("circle", (245, 245, 245), (222, 222, 222), None, 0.56),
    "whitesur": ("squircle", (255, 255, 255), (234, 237, 242), None, 0.62),
    "fluent": ("round", (253, 253, 253), (230, 235, 242), None, 0.6),
    "tela": ("circle", (246, 248, 251), (220, 227, 238), None, 0.56),
    "colloid": ("round", (241, 243, 246), (225, 229, 235), None, 0.6),
    "kora": ("squircle", (52, 58, 72), (30, 34, 44), None, 0.6),
    "win11": ("round", (250, 251, 253), (232, 236, 243), None, 0.6),
    "we10x": ("round", (248, 249, 251), (228, 232, 239), None, 0.6),
    "reversal": ("squircle", (250, 250, 252), (230, 233, 240), None, 0.6),
    "mcmojave": ("circle", (250, 250, 252), (226, 230, 238), None, 0.56),
    "telacircle": ("circle", (246, 248, 251), (220, 227, 238), None, 0.56),
    "vimix": ("round", (252, 248, 240), (238, 230, 214), None, 0.6),
    "qogir": ("circle", (245, 247, 250), (222, 228, 236), None, 0.56),
    "nordzy": ("round", (59, 66, 82), (46, 52, 64), None, 0.6),
}


def make_tile(tid, out):
    from PIL import ImageDraw, ImageFilter
    shape, c0, c1, ring, inner = TILES[tid]
    S = 1024
    grad = Image.new("RGBA", (S, S))
    for y in range(S):
        t = y / (S - 1)
        grad.paste(tuple(int(c0[i] + (c1[i] - c0[i]) * t) for i in range(3)) + (255,), (0, y, S, y + 1))
    m = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(m)
    pad = 56
    if shape == "circle":
        d.ellipse((pad, pad, S - pad, S - pad), fill=255)
    else:
        r = {"round": 0.2, "squircle": 0.28}[shape] * (S - 2 * pad)
        d.rounded_rectangle((pad, pad, S - pad, S - pad), radius=r, fill=255)
    sh = m.filter(ImageFilter.GaussianBlur(18)).point(lambda v: v * 0.35)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 255)); shadow.putalpha(sh)
    img.paste(shadow, (0, 14), shadow)
    tile = grad.copy(); tile.putalpha(m)
    img = Image.alpha_composite(img, tile)
    if ring == "neon":
        rg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        for x in range(S):
            t = x / (S - 1)
            rg.paste((int(255 * (1 - t) + 40 * t), int(80 * (1 - t) + 220 * t), int(200 * (1 - t) + 255 * t), 255), (x, 0, x + 1, S))
        inner_m = m.filter(ImageFilter.MinFilter(41))
        ringm = Image.eval(Image.merge("L", [m]), lambda v: v)
        ringm = Image.composite(Image.new("L", (S, S), 0), m, inner_m)
        rg.putalpha(ringm)
        img = Image.alpha_composite(img, rg)
    img.resize((256, 256), Image.LANCZOS).save(os.path.join(out, "tile.png"), optimize=True)
    open(os.path.join(out, "style.txt"), "w").write("inner %.2f\noffy 0\n" % inner)


def git_ls(root, dirs):
    ent = {}
    for d in dirs:
        out = subprocess.run(["git", "-C", root, "ls-tree", "HEAD", d + "/"], capture_output=True, text=True).stdout
        for line in out.splitlines():
            meta, path = line.split("\t", 1)
            if not path.endswith(".svg"):
                continue
            n = os.path.basename(path)[:-4]
            ent.setdefault(n, path)
    return ent


ALL = {}


def fetch_needed(root, dirs, licfile, extra_names=()):
    """достать из частичного клона только нужные значки (и то, на что указывают их ссылки)"""
    ent = git_ls(root, dirs)
    ALL[root] = set(subprocess.run(["git", "-C", root, "ls-tree", "-r", "--name-only", "HEAD"], capture_output=True, text=True).stdout.split("\n"))
    want = set(extra_names)
    for _, c in PLACES:
        want.update(c)
        want.update("default-" + x for x in c)
    for _, _, c in APPS:
        want.update(c)
    paths = {ent[n] for n in ent if n in want or (n.startswith("steam_icon_") and n[11:].isdigit())}
    if licfile in ALL[root]:
        paths.add(licfile)
    paths = {p for p in paths if p in ALL[root]}
    for _ in range(6):
        missing = sorted(p for p in paths if not os.path.lexists(os.path.join(root, p)))
        if missing:
            subprocess.run(["git", "-C", root, "checkout", "HEAD", "--pathspec-from-file=-"], input="\n".join(missing), text=True, capture_output=True)
        nxt = set()
        for p in paths:
            f = os.path.join(root, p)
            if os.path.islink(f):
                t = os.path.normpath(os.path.join(os.path.dirname(p), os.readlink(f)))
                if not os.path.exists(os.path.join(root, t)):
                    if t in ALL.get(root, set()):
                        nxt.add(t)
                    b = os.path.basename(t)[:-4] if t.endswith(".svg") else ""
                    if b in ent and not os.path.exists(os.path.join(root, ent[b])):
                        nxt.add(ent[b])   # ссылка на файл, который тема кладёт рядом при установке
        if not nxt:
            break
        paths |= nxt


def index_theme(root, dirs):
    idx = {}
    for d in dirs:
        p = os.path.join(root, d)
        if not os.path.isdir(p):
            continue
        for f in os.listdir(p):
            if not f.endswith(".svg"):
                continue
            n = f[:-4]
            if n in idx:
                continue
            idx[n] = os.path.join(p, f)
    # ссылки: по пути, а если файла там нет — по имени в любой папке темы (как после установки)
    out = {}
    for n, f in idx.items():
        cur, seen = f, 0
        while seen < 8:
            seen += 1
            if os.path.islink(cur):
                t = os.path.join(os.path.dirname(cur), os.readlink(cur))
                if os.path.lexists(t):
                    cur = t; continue
                b = os.path.basename(t)[:-4]
                if b in idx and idx[b] != cur:
                    cur = idx[b]; continue
                cur = None
            break
        if cur and os.path.isfile(cur):
            out[n] = os.path.realpath(cur)
    return out


def render(svg, out, size=256, recolor=None):
    if recolor:
        import re
        t = open(svg, encoding="utf-8", errors="replace").read()
        t = re.sub(re.escape(recolor[0]), recolor[1], t, flags=re.I)
        lines = []
        for ln in t.split("\n"):   # Tela: цвета через ColorScheme-Highlight / Background
            if "ColorScheme-Highlight" in ln: ln = ln.replace("currentColor", recolor[1])
            if "ColorScheme-Background" in ln: ln = ln.replace("currentColor", "#ffffff")
            lines.append(ln)
        png = subprocess.run(["rsvg-convert", "-w", str(size), "-h", str(size), "-a", "-"], input="\n".join(lines).encode(), capture_output=True).stdout
    else:
        png = subprocess.run(["rsvg-convert", "-w", str(size), "-h", str(size), "-a", svg], capture_output=True).stdout
    if not png:
        return False
    im = Image.open(io.BytesIO(png)).convert("RGBA")
    if im.size != (size, size):   # вписать в квадрат
        c = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        c.paste(im, ((size - im.width) // 2, (size - im.height) // 2))
        im = c
    if im.getbbox() is None:
        return False
    q = im.quantize(256, method=Image.Quantize.FASTOCTREE, dither=Image.Dither.NONE)
    buf = io.BytesIO()
    q.save(buf, "PNG", optimize=True)
    raw = io.BytesIO()
    im.save(raw, "PNG", optimize=True)
    data = buf.getvalue() if len(buf.getvalue()) < len(raw.getvalue()) * 0.8 else raw.getvalue()
    open(out, "wb").write(data)
    return True


def preview(out, base_out, tiles_ids):
    prev = Image.new("RGBA", (6 * 44, 44), (0, 0, 0, 0))
    for i, t in enumerate(tiles_ids[:6]):
        f = os.path.join(out, t + ".png")
        if not os.path.isfile(f):
            f = os.path.join(base_out, t + ".png")
        im = Image.open(f).convert("RGBA").resize((40, 40), Image.LANCZOS)
        prev.paste(im, (i * 44 + 2, 2), im)
    prev.save(os.path.join(out, "preview.png"), optimize=True)


def build_family(src, dst, fam, cat):
    root = os.path.join(src, fam["folder"])
    extra = set()
    for v in fam["variants"]:
        how = v[4]
        if "papirus" in how:
            c = how["papirus"]
            extra.update(["folder-" + c, "folder-%s-open" % c, "folder-%s-desktop" % c, "user-%s-desktop" % c, "folder-%s-documents" % c,
                          "folder-%s-download" % c, "folder-%s-music" % c, "folder-%s-pictures" % c, "folder-%s-videos" % c, "user-%s-home" % c])
    overlay_dirs = [d for v in fam["variants"] for d in v[4].get("overlay", [])]
    fetch_needed(root, fam["dirs"], fam["licfile"], extra)
    for d in overlay_dirs:
        fetch_needed(root, [d], fam["licfile"])
    base_rc = ("#5294e2", "#5294e2") if fam.get("tela") else None
    idx = index_theme(root, fam["dirs"])
    tid = fam["id"]
    out = os.path.join(dst, tid)
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out)
    have = []
    for pid, cands in PLACES:
        for c in cands:
            for n in (c, "default-" + c):
                if n in idx and render(idx[n], os.path.join(out, pid + ".png"), recolor=base_rc if n.startswith("default-") else None):
                    have.append(pid); break
            if pid in have: break
    for aid, _, cands in APPS:
        for c in cands:
            if c in idx and render(idx[c], os.path.join(out, aid + ".png")):
                have.append(aid); break
    steam = 0
    for n, path in idx.items():
        if n.startswith("steam_icon_") and n[11:].isdigit():
            if render(path, os.path.join(out, "steam_" + n[11:] + ".png")):
                have.append("steam_" + n[11:]); steam += 1
    make_tile(tid, out)
    have.append("tile")
    open(os.path.join(out, "list.txt"), "w").write("\n".join(have) + "\n")
    lf = os.path.join(root, fam["licfile"])
    if os.path.isfile(lf):
        shutil.copy(lf, os.path.join(out, "LICENSE.txt"))
    places_ids = dict(PLACES)
    napps = len([h for h in have if not h.startswith("steam_") and h not in places_ids and h != "tile"])
    show = [x for x in ["folder", "folder-download", "computer", "chrome", "telegram", "discord", "steam", "spotify", "trash"] if x in have]
    preview(out, out, show)
    cat.append("pack\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%s\t%s" % (tid, fam["ru"], fam["en"], fam["author"], fam["lic"], fam["url"], len(have), napps, steam, tid, fam["color"]))
    print(tid, "значков:", len(have), "программ:", napps, "steam:", steam, "папок:", len([h for h in have if h in places_ids]))
    # варианты: только значки папок, остальное — из основного
    for vk, vru, ven, hx, how in fam["variants"]:
        vid = tid + "-" + vk
        vout = os.path.join(dst, vid)
        if os.path.isdir(vout):
            shutil.rmtree(vout)
        os.makedirs(vout)
        vh = []
        if "papirus" in how:
            c = how["papirus"]
            names = {"folder": ["folder-" + c], "folder-open": ["folder-%s-open" % c], "folder-desktop": ["user-%s-desktop" % c, "folder-%s-desktop" % c],
                     "folder-documents": ["folder-%s-documents" % c], "folder-download": ["folder-%s-download" % c], "folder-music": ["folder-%s-music" % c],
                     "folder-pictures": ["folder-%s-pictures" % c], "folder-videos": ["folder-%s-videos" % c], "user-home": ["user-%s-home" % c]}
            for pid, cands in names.items():
                for n in cands:
                    if n in idx and render(idx[n], os.path.join(vout, pid + ".png")):
                        vh.append(pid); break
        elif "overlay" in how:
            vidx = index_theme(root, how["overlay"] + fam["dirs"])
            oidx = index_theme(root, how["overlay"])
            for pid, cands in PLACES:
                for c in cands:
                    hit = [n for n in (c, "default-" + c) if n in oidx]
                    if hit and render(vidx[hit[0]], os.path.join(vout, pid + ".png")):
                        vh.append(pid); break
        elif "recolor" in how:
            for pid, cands in PLACES:
                if pid in ("computer", "trash", "trash-full"):
                    continue
                for c in cands:
                    hit = [n for n in (c, "default-" + c) if n in idx]
                    if hit and render(idx[hit[0]], os.path.join(vout, pid + ".png"), recolor=how["recolor"]):
                        vh.append(pid); break
        if not vh:
            shutil.rmtree(vout)
            print("  нет папок у", vid)
            continue
        open(os.path.join(vout, "list.txt"), "w").write("base " + tid + "\n" + "\n".join(vh) + "\n")
        preview(vout, out, show)
        cat.append("pack\t%s\t%s — %s\t%s — %s\t%s\t%s\t%s\t%d\t%d\t%d\t%s\t%s" % (vid, fam["ru"], vru, fam["en"], ven, fam["author"], fam["lic"], fam["url"], len(have), napps, steam, tid, hx))
    print("  вариантов:", len(fam["variants"]))


def main():
    src, dst = sys.argv[1], sys.argv[2]
    only = sys.argv[3].split(",") if len(sys.argv) > 3 else None
    os.makedirs(dst, exist_ok=True)
    cat = ["# Паки иконок Подоконника. pack: id, имя, имя (en), авторы, лицензия, адрес, значков, программ, игр Steam, семейство, цвет. rule: id значка, признаки ярлыка"]
    for aid, keys, _ in APPS:
        cat.append("rule\t%s\t%s" % (aid, keys))
    for fam in FAMILIES:
        if only and fam["id"] not in only:
            continue
        build_family(src, dst, fam, cat)
    open(os.path.join(dst, "catalog-themes.txt"), "w").write("\n".join(cat) + "\n")


if __name__ == "__main__":
    main()
