# Каталог тем Windhawk (Windows 11 Taskbar Styler / Start Menu Styler) для вкладки «Оформление»:
# id темы из настроек мода + картинка из репозитория styling-guide. Пишет ui/whkthemes.js
import re, json, sys, subprocess, os
W = '/tmp/whk'
def opts(src):
    s = open(src, encoding='utf-8').read()
    blk = s[s.index('==WindhawkModSettings=='):]
    blk = blk[blk.index('$options:'):]
    blk = blk[:blk.index('\n- ', 10)]
    out = []
    lines = blk.split('\n')
    i = 0
    while i < len(lines):
        m = re.match(r'\s+- "?([^":]*)"?: (.*)$', lines[i])
        if m:
            k, v = m.group(1), m.group(2).strip()
            if v == '>-': v = lines[i + 1].strip(); i += 1
            if k: out.append((k, v))
        i += 1
    return out
def files(repo):
    return [l.strip() for l in open(f'{W}/{repo}.files', encoding='utf-8') if l.strip()]
SPEC = {   # вариант → своя картинка
    'OS26_Liquid_Glass_variant_ClearMacDock': 'screenshot-dock.png', 'OS26_Liquid_Glass_variant_ClearMacDockCompact': 'screenshot-dock-1.png',
    'OS26_Liquid_Glass_variant_DarkMacDock': 'screenshot-dock-dark.png', 'OS26_Liquid_Glass_variant_DarkMacDockCompact': 'screenshot-dock-dark-1.png',
    'OS26_Liquid_Glass_variant_ClearTaskbar': 'screenshot-taskbar.png', 'OS26_Liquid_Glass_variant_DarkTaskbar': 'screenshot-taskbar-dark.png',
    'Luminosity_variant_Dock': 'dock.png', 'Luminosity_variant_Classic': 'normal.png', 'Luminosity_variant_Compact': 'compact.png',
    'WindowGlass_variant_Split': 'screenshot_split.png', 'WindowGlass_variant_FullLength': 'screenshot_full.png',
    'CleanSlate': 'screenshot.png', '21996Taskbar': 'screenshot_legacy.png', 'SunValley': 'screenshot.png',
}
def build(repo, src):
    fl = files(repo)
    dirs = sorted({f.split('/')[1] for f in fl})
    res = []
    for k, v in opts(src):
        base = k.split('_variant_')[0]
        cand = [base, base.replace('_', ' '), base.replace('One_UI_8_5', 'One UI 8.5'), base.replace('_', ' ').replace('8 5', '8.5')]
        d = next((c for c in cand if c in dirs), None)
        pic = None
        if d:
            imgs = [f for f in fl if f.startswith(f'Themes/{d}/') and f.count('/') == 2 and re.search(r'\.(png|jpe?g|gif|webp)$', f, re.I)]
            want = SPEC.get(k)
            if want and f'Themes/{d}/{want}' in imgs: pic = f'Themes/{d}/{want}'
            if not pic:
                vs = k.split('_variant_')[1].lower() if '_variant_' in k else ''
                pick = [f for f in imgs if vs and vs in f.lower()]
                pic = pick[0] if pick else next((f for f in imgs if re.search(r'/screenshot\.(png|jpe?g|gif|webp)$', f, re.I)), imgs[0] if imgs else None)
        res.append({'id': k, 'name': v, 'dir': d or '', 'pic': pic or ''})
    return res
tb = build('windows-11-taskbar-styling-guide', f'{W}/styler.wh.cpp')
sm = build('windows-11-start-menu-styling-guide', f'{W}/smstyler.wh.cpp')
for x in tb + sm:
    if not x['pic']: print('no pic', x, file=sys.stderr)
out = '// создано tools/whkcat.py: темы из Windows 11 Taskbar Styler и Start Menu Styler (Windhawk) с картинками из styling-guide\n'
out += 'const WHK_TB = ' + json.dumps(tb, ensure_ascii=False) + ';\nconst WHK_SM = ' + json.dumps(sm, ensure_ascii=False) + ';\n'
open(os.path.join(os.path.dirname(__file__), '..', 'ui', 'whkthemes.js'), 'w', encoding='utf-8').write(out)
print(len(tb), len(sm))
