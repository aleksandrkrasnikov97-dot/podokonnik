// След за курсором: снежинки, листья, лепестки, искры или радуга тянутся за мышкой.
// Рисуется на том же прозрачном слое, что и снег; мышь он не перехватывает.
#pragma once
#include <map>
#include <set>

static int gCursorTrail = 0;            // 0 — нет, 1 — как сезон, 2 — искры, 3 — радуга, 4 — звёздочки
static std::string gCursorPack;         // выбранный набор курсоров ("" — не трогаем курсор Windows), cursors.h
static bool gCursorSeason = false;      // курсор сам меняется по сезону
static std::string gCursorApplied;      // какой набор сейчас прописан в Windows ("" — свой у пользователя)
static void cursorSaveSettings();
static void cursorLoadSettings();
static void cursorSync();
static void cursorRestore();
static bool cursorPackExists(const std::string& id);
static void cursorDownloaded(bool ok);
static int cursorSizeGet();
static void cursorSizeSet(int n);
static std::map<std::string, std::string> gCurWebNames;   // названия наборов сообщества (присылает окно)
static std::string gCurLoading;            // какой набор курсоров сейчас скачивается

enum { TR_SNOW = 0, TR_LEAF, TR_PETAL, TR_GLOW, TR_SPARK, TR_RAINBOW, TR_STAR };
struct TrailP { float x, y, vx, vy, age, life, r, rot, vrot, ph; uint8_t kind, col; };
static std::vector<TrailP> gTrail;
static POINT gTrailPrev{INT_MIN, INT_MIN}, gTrailRaw{INT_MIN, INT_MIN};
static float gTrailAcc = 0, gTrailHue = 0;
static int gCursorPx = 32;              // размер курсора Windows в пикселях — след выходит из-под стрелки
static double gTrailMoved = -100;       // когда мышь последний раз двигалась (gTime)

static bool trailWanted() { return gCursorTrail != 0; }
// есть что рисовать или мышь сдвинулась с прошлого кадра (в «спящем» режиме кадры редкие, но курсор смотрим)
static bool trailBusy() {
    if (!gTrail.empty()) return true;
    if (!gCursorTrail) return false;
    return gCursor.x != gTrailRaw.x || gCursor.y != gTrailRaw.y || gTime - gTrailMoved < 0.5;
}

static void hsv2rgb(float h, float s, float v, float& r, float& g, float& b) {
    h = std::fmod(h, 1.0f) * 6; int i = (int)h; float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
    switch (i % 6) { case 0: r = v; g = t; b = p; break; case 1: r = q; g = v; b = p; break; case 2: r = p; g = v; b = t; break;
                     case 3: r = p; g = q; b = v; break; case 4: r = t; g = p; b = v; break; default: r = v; g = p; b = q; }
}

static void trailSpawn(float x, float y, float mvx, float mvy) {
    if (gTrail.size() >= 260) return;
    TrailP t{};
    t.x = x + frange(-3, 3) * S; t.y = y + frange(-3, 3) * S;
    t.ph = frange(0, 6.283f);
    t.rot = frange(0, 6.283f);
    t.vrot = frange(-3, 3);
    int mode = gCursorTrail;
    if (mode == 1) {   // по сезону
        if (gSeason == SEA_WINTER) { t.kind = TR_SNOW; t.r = frange(1.1f, 2.6f) * S; t.life = frange(0.9f, 1.5f); t.vy = frange(10, 30) * S; t.vx = frange(-12, 12) * S; }
        else if (gSeason == SEA_AUTUMN) { t.kind = TR_LEAF; t.r = frange(2.6f, 4.0f) * S; t.life = frange(1.0f, 1.6f); t.vy = frange(20, 45) * S; t.vx = frange(-15, 15) * S; t.col = (uint8_t)(xr() % 5); }
        else if (gSeason == SEA_SPRING) { t.kind = TR_PETAL; t.r = frange(2.2f, 3.4f) * S; t.life = frange(1.0f, 1.6f); t.vy = frange(15, 35) * S; t.vx = frange(-15, 15) * S; t.col = (uint8_t)(5 + xr() % 4); }
        else { t.kind = TR_GLOW; t.r = frange(1.4f, 2.4f) * S; t.life = frange(0.8f, 1.3f); t.vy = frange(-25, -5) * S; t.vx = frange(-10, 10) * S; }
    } else if (mode == 2) {
        t.kind = TR_SPARK; t.r = frange(1.0f, 2.2f) * S; t.life = frange(0.45f, 0.9f);
        float a = frange(0, 6.283f), sp = frange(30, 90) * S;
        t.vx = std::cos(a) * sp - mvx * 0.15f; t.vy = std::sin(a) * sp - mvy * 0.15f;
    } else if (mode == 3) {
        t.kind = TR_RAINBOW; t.r = frange(2.6f, 3.6f) * S; t.life = 0.7f;
        t.col = (uint8_t)((int)(gTrailHue * 255) & 255);
        t.vx = frange(-6, 6) * S; t.vy = frange(-6, 6) * S;
    } else {
        t.kind = TR_STAR; t.r = frange(2.2f, 4.0f) * S; t.life = frange(0.7f, 1.2f);
        t.vx = frange(-20, 20) * S; t.vy = frange(5, 30) * S;
        t.col = (uint8_t)(xr() % 3);
    }
    gTrail.push_back(t);
}

static void updateTrail(float dt) {
    if (!gCursorTrail) { gTrail.clear(); gTrailPrev = {INT_MIN, INT_MIN}; return; }
    gTrailRaw = gCursor;
    POINT c = gCursor;
    // след идёт не из острия, а из-под курсора: сдвигаем точку вниз под стрелку (с учётом размера курсора)
    float k0 = gCursorPx * S / 32.0f;
    c.x += (LONG)(7 * k0); c.y += (LONG)(24 * k0);
    if (gTrailPrev.x == INT_MIN) gTrailPrev = c;
    float dx = (float)(c.x - gTrailPrev.x), dy = (float)(c.y - gTrailPrev.y);
    float dist = std::sqrt(dx * dx + dy * dy);
    if (dist > 400 * S) dist = 0;   // прыжок курсора (другой монитор, телепорт) — без шлейфа через весь экран
    if (dist > 0.5f) gTrailMoved = gTime;
    gTrailHue += dist / (900.0f * S);
    float step = (gCursorTrail == 3 ? 4.0f : gCursorTrail == 2 ? 9.0f : 11.0f) * S;
    gTrailAcc += dist / step;
    int n = std::min(10, (int)gTrailAcc);
    gTrailAcc -= (float)(int)gTrailAcc;
    float mvx = dt > 0 ? dx / dt : 0, mvy = dt > 0 ? dy / dt : 0;
    for (int i = 0; i < n; ++i) {
        float k = (i + 1.0f) / n;   // раскладываем по пройденному пути, чтобы при быстром движении не было пробелов
        if (gCursorTrail == 3) gTrailHue += 0.004f;
        trailSpawn(gTrailPrev.x + dx * k, gTrailPrev.y + dy * k, mvx, mvy);
    }
    gTrailPrev = c;

    float wind = baseWind() * 0.3f;
    size_t w = 0;
    for (size_t i = 0; i < gTrail.size(); ++i) {
        TrailP t = gTrail[i];
        t.age += dt;
        if (t.age >= t.life) continue;
        t.ph += dt * 3;
        switch (t.kind) {
        case TR_SNOW: t.x += (t.vx + wind + std::cos(t.ph) * 10 * S) * dt; t.y += t.vy * dt; t.vx *= 1 - 1.5f * dt; break;
        case TR_LEAF: case TR_PETAL:
            t.x += (t.vx + wind + std::sin(t.ph) * 18 * S) * dt; t.y += t.vy * dt; t.rot += t.vrot * dt; break;
        case TR_GLOW: t.x += (t.vx + std::sin(t.ph * 1.3f) * 12 * S) * dt; t.y += t.vy * dt; break;
        case TR_SPARK: t.vx *= 1 - 3.0f * dt; t.vy = t.vy * (1 - 3.0f * dt) + 60 * S * dt; t.x += t.vx * dt; t.y += t.vy * dt; break;
        case TR_RAINBOW: t.x += t.vx * dt; t.y += t.vy * dt; break;
        default: t.x += t.vx * dt; t.y += t.vy * dt; t.vx *= 1 - 1.2f * dt; t.rot += t.vrot * 0.5f * dt; break;
        }
        gTrail[w++] = t;
    }
    gTrail.resize(w);
}

static void trailStar(float x, float y, float R, float rot, float r, float g, float b, float a) {
    // четырёхлучевая звёздочка: два тонких луча крестом и светлый центр
    for (int i = 0; i < 2; ++i) {
        float an = rot + i * PI * 0.5f, ca = std::cos(an) * R, sa = std::sin(an) * R;
        drawLine(x - ca, y - sa, x + ca, y + sa, std::max(1.0f, R * 0.22f), r, g, b, a);
    }
    drawDisc(x, y, R * 0.35f, 255, 255, 255, a, 1, 0);
}

static void drawTrail() {
    for (const TrailP& t : gTrail) {
        float x = t.x - gVX, y = t.y - gVY;
        float k = t.age / t.life, fade = k < 0.15f ? k / 0.15f : 1 - (k - 0.15f) / 0.85f;
        fade = clampf(fade, 0, 1);
        switch (t.kind) {
        case TR_SNOW: drawDisc(x, y, t.r, 255, 255, 255, 0.9f * fade, t.r > 2 * S ? 1.6f : 1.0f, 0); break;
        case TR_LEAF: { const RGB8& c = kPal[t.col % 5]; drawLeaf(x, y, t.r * 2.3f, t.r * 1.25f * (0.4f + 0.6f * std::fabs(std::cos(t.ph))), t.rot, c.r, c.g, c.b, fade, true); break; }
        case TR_PETAL: { const RGB8& c = kPal[t.col]; drawLeaf(x, y, t.r * 1.7f, t.r * 1.25f * (0.35f + 0.65f * std::fabs(std::cos(t.ph))), t.rot, c.r, c.g, c.b, fade, false); break; }
        case TR_GLOW: {
            float pulse = 0.6f + 0.4f * std::sin(t.ph * 2.5f);
            drawDisc(x, y, t.r * 3.2f, 255, 236, 120, 0.18f * fade * pulse, 1, 0);
            drawDisc(x, y, t.r, 255, 248, 190, 0.95f * fade, 1, 0);
            break;
        }
        case TR_SPARK: {
            drawDisc(x, y, t.r * 2.6f, 255, 196, 80, 0.22f * fade, 1, 0);
            drawDisc(x, y, t.r, 255, 240, 200, fade, 1, 0);
            break;
        }
        case TR_RAINBOW: {
            float r, g, b; hsv2rgb(t.col / 255.0f, 0.75f, 1.0f, r, g, b);
            drawDisc(x, y, t.r * (1 - 0.5f * k), r * 255, g * 255, b * 255, 0.85f * fade, 1, 0);
            break;
        }
        default: {
            static const RGB8 sc[3] = {{255, 236, 140}, {190, 225, 255}, {255, 200, 235}};
            const RGB8& c = sc[t.col % 3];
            trailStar(x, y, t.r * (0.6f + 0.4f * std::fabs(std::sin(t.ph * 2))), t.rot, c.r, c.g, c.b, fade);
            break;
        }
        }
    }
}
