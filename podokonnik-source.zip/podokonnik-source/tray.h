// Панель у значка в трее (правый клик): вместо системного меню — своё окно в стиле программы (ui/tray.html).
// Если WebView2 нет — остаётся обычное меню showMenu().
#pragma once

static void showMenu();
static HWND gFlyWnd = nullptr;
static bool gFlyReady = false;     // страница загрузилась и прислала размер
static bool gFlyFailed = false;    // WebView2 не завёлся — дальше обычное меню
static bool gFlyWant = false;      // показать, как только будет готова
static int gFlyH = 330;            // высота содержимого (CSS-пиксели), её присылает страница
static DWORD gFlyHidden = 0;       // когда спрятали (чтобы повторный клик по значку закрывал, а не открывал заново)
static bool gFlyActive = false;    // панель хоть раз получила фокус после показа

static void flyHide() {
    gFlyWant = false;
    if (gFlyWnd && IsWindowVisible(gFlyWnd)) {
        KillTimer(gFlyWnd, 1); ShowWindow(gFlyWnd, SW_HIDE); gFlyHidden = GetTickCount();
        SetTimer(gFlyWnd, 2, 60000, nullptr);   // через минуту без дела — выгрузить страницу (WebView2 держит память)
    }
}
// закрыть панель совсем; при следующем клике по значку она создастся заново
static void flyUnload() {
    if (!gFlyWnd || IsWindowVisible(gFlyWnd) || gFlyWant) return;
    HWND w = gFlyWnd;
    wv::Host* host = gFlyHost;
    gFlyWnd = nullptr; gFlyHost = nullptr; gFlyReady = false;
    wv::destroy(host);   // сам Host не удаляем: на него могут ссылаться асинхронные обработчики
    DestroyWindow(w);
}
// поставить панель у значка: над панелью задач (или рядом, если она сбоку/сверху)
static void flyPlace() {
    if (!gFlyWnd) return;
    POINT pt; GetCursorPos(&pt);
    NOTIFYICONIDENTIFIER ni{}; ni.cbSize = sizeof ni; ni.hWnd = gNid.hWnd; ni.uID = gNid.uID;
    RECT ir{};
    bool haveIcon = SUCCEEDED(Shell_NotifyIconGetRect(&ni, &ir));
    if (haveIcon) { pt.x = (ir.left + ir.right) / 2; pt.y = (ir.top + ir.bottom) / 2; }
    HMONITOR mon = MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi{}; mi.cbSize = sizeof mi; GetMonitorInfoW(mon, &mi);
    UINT dx = 96, dy = 96;
    using GetDpiForMonitorFn = HRESULT(WINAPI*)(HMONITOR, int, UINT*, UINT*);
    static auto gdm = (GetDpiForMonitorFn)GetProcAddress(LoadLibraryW(L"shcore.dll"), "GetDpiForMonitor");
    if (gdm) gdm(mon, 0, &dx, &dy);
    float k = dx / 96.0f;
    int W = (int)(264 * k), H = (int)(gFlyH * k);
    RECT wa = mi.rcWork, m = mi.rcMonitor;
    int gap = (int)(12 * k);
    int x = pt.x - W / 2, y;
    if (wa.bottom < m.bottom) y = wa.bottom - H - gap;            // панель задач снизу
    else if (wa.top > m.top) y = wa.top + gap;                    // сверху
    else { y = pt.y - H - gap; if (wa.left > m.left) x = wa.left + gap; else if (wa.right < m.right) x = wa.right - W - gap; }
    x = std::max((int)wa.left + gap, std::min(x, (int)wa.right - W - gap));
    y = std::max((int)wa.top + gap, std::min(y, (int)wa.bottom - H - gap));
    SetWindowPos(gFlyWnd, HWND_TOPMOST, x, y, W, H, SWP_NOACTIVATE);
}
static void flyShowNow() {
    if (!gFlyWnd || !gFlyReady) return;
    flyPlace();
    wv::post(gFlyHost, stateJson());
    wv::post(gFlyHost, "{\"type\":\"shown\"}");
    gFlyActive = false;
    KillTimer(gFlyWnd, 2);
    ShowWindow(gFlyWnd, SW_SHOW);
    SetForegroundWindow(gFlyWnd);
    SetTimer(gFlyWnd, 1, 120, nullptr);   // закрыть по клику мимо, даже если Windows не отдала фокус
    if (gFlyHost && gFlyHost->ctl) gFlyHost->ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
}
static LRESULT CALLBACK FlyProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_ACTIVATE:
        if (LOWORD(wp) == WA_INACTIVE) flyHide(); else gFlyActive = true;
        return 0;
    case WM_TIMER: {
        if (wp == 2) { KillTimer(h, 2); flyUnload(); return 0; }
        if (!IsWindowVisible(h)) { KillTimer(h, 1); return 0; }
        if (gFlyActive && GetForegroundWindow() != h) { flyHide(); return 0; }
        bool down = ((GetAsyncKeyState(VK_LBUTTON) | GetAsyncKeyState(VK_RBUTTON) | GetAsyncKeyState(VK_MBUTTON)) & 0x8000) != 0;
        if (down) {
            POINT pt; GetCursorPos(&pt);
            RECT r; GetWindowRect(h, &r);
            if (!PtInRect(&r, pt)) flyHide();
        }
        return 0;
    }
    case WM_NCCALCSIZE:
        if (wp) return 0;   // без рамки: вся площадь — страница (рамка нужна только ради тени Windows)
        break;
    case WM_NCHITTEST:
        return HTCLIENT;
    case WM_SIZE:
        wv::fit(gFlyHost);
        return 0;
    case WM_ERASEBKGND: {
        RECT rc; GetClientRect(h, &rc);
        HBRUSH b = CreateSolidBrush(RGB(20, 26, 46));
        FillRect((HDC)wp, &rc, b); DeleteObject(b);
        return 1;
    }
    case WM_CLOSE: flyHide(); return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}
// команды панели: часть — как пункты старого меню, остальное — как в окне программы
static void flyMessage(const std::string& raw) {
    js::Value m = js::parse(raw);
    std::string cmd = m.str("cmd");
    if (cmd == "flyReady" || cmd == "flySize") {
        int h = (int)m.num("h", gFlyH);
        if (h > 120 && h < 1400) gFlyH = h;
        if (cmd == "flyReady") { gFlyReady = true; if (gFlyWant) flyShowNow(); }
        else if (IsWindowVisible(gFlyWnd)) flyPlace();
        return;
    }
    if (cmd == "flyHello") { wv::post(gFlyHost, stateJson()); return; }
    if (cmd == "flyClose") { flyHide(); return; }
    if (cmd == "menu") {
        std::string a = m.str("id");
        static const struct { const char* n; int id; } map[] = {
            {"open", ID_OPEN}, {"settings", ID_SETTINGS}, {"wpNext", ID_WP_NEXT}, {"wpPause", ID_WP_PAUSE}, {"wpStop", ID_WP_STOP},
            {"support", ID_SUPPORT}, {"exit", ID_EXIT}, {"shake", ID_SHAKE}, {"update", ID_UPDATE}};
        for (auto& e : map)
            if (a == e.n) {
                if (e.id == ID_OPEN || e.id == ID_SETTINGS || e.id == ID_SUPPORT || e.id == ID_EXIT || e.id == ID_UPDATE) {
                    flyHide();
                    PostMessageW(gMsgWnd, WM_COMMAND, e.id, 0);
                } else {
                    SendMessageW(gMsgWnd, WM_COMMAND, e.id, 0);
                    wv::post(gFlyHost, stateJson());
                }
                break;
            }
        return;
    }
    handleUi(raw);
    wv::post(gFlyHost, stateJson());
}
static void flyCreate() {
    static bool reg = false;
    if (!reg) {
        WNDCLASSEXW wc{}; wc.cbSize = sizeof wc;
        wc.lpfnWndProc = FlyProc; wc.hInstance = gInst; wc.lpszClassName = L"PodokonnikTray";
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        RegisterClassExW(&wc);
        reg = true;
    }
    gFlyWnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, L"PodokonnikTray", L"Подоконник", WS_POPUP | WS_THICKFRAME,
                              0, 0, (int)(264 * S), (int)(gFlyH * S), nullptr, nullptr, gInst, nullptr);
    if (!gFlyWnd) { gFlyFailed = true; return; }
    int corner = 2;   // DWMWCP_ROUND — скруглённые углы в Windows 11
    DwmSetWindowAttribute(gFlyWnd, 33, &corner, sizeof corner);
    BOOL dark = TRUE;
    DwmSetWindowAttribute(gFlyWnd, 20, &dark, sizeof dark);
    COLORREF border = RGB(45, 54, 86);
    DwmSetWindowAttribute(gFlyWnd, 34 /*DWMWA_BORDER_COLOR*/, &border, sizeof border);
    MARGINS mg{0, 0, 0, 1};   // тень от Windows у окна без рамки
    DwmExtendFrameIntoClientArea(gFlyWnd, &mg);
    gFlyHost = new wv::Host();
    gFlyHost->hwnd = gFlyWnd;
    gFlyHost->onMessage = flyMessage;
    wv::Host* host = gFlyHost;
    wv::create(host, dataPath(L"WebView2"), fileUrl(dataPath(L"ui\\tray.html")), {}, false, [host](bool ok) {
        if (ok || host->closed) return;
        gFlyFailed = true;
        if (gFlyWant) { gFlyWant = false; showMenu(); }
    });
}
// правый клик по значку
static void trayPopup() {
    if (gFlyFailed) { showMenu(); return; }
    if (gFlyWnd && IsWindowVisible(gFlyWnd)) { flyHide(); return; }
    if (GetTickCount() - gFlyHidden < 250) return;   // этот же клик только что закрыл панель
    if (!gFlyWnd) flyCreate();
    if (gFlyFailed) { showMenu(); return; }
    gFlyWant = true;
    if (gFlyReady) flyShowNow();
}
