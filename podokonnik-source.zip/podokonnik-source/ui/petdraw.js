// Рисование питомца для предпросмотра — та же геометрия, что в pet.h (программа рисует так же).
// cfg: {kind, body, face, ears, tail, eyes, pattern, acc, size, c1..c4 ('#rrggbb')}
// st: {state:'walk'|'sit'|'sleep'|'love'|'fly', anim, dir, look}
(function () {
  const PI = Math.PI;
  let ctx = null, Z = 1;
  const hex = h => { const n = parseInt(String(h || '#888888').slice(1), 16) || 0; return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const css = (c, a = 1) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
  function mix(c, k) {
    if (k <= 1) return [c[0] * k, c[1] * k, c[2] * k];
    const t = Math.min(1, k - 1);
    return [c[0] + (255 - c[0]) * t, c[1] + (255 - c[1]) * t, c[2] + (255 - c[2]) * t];
  }
  function disc(x, y, r, c, a = 1) { ctx.fillStyle = css(c, a); ctx.beginPath(); ctx.arc(x, y, Math.max(0.1, r), 0, 2 * PI); ctx.fill(); }
  function ell(x, y, rx, ry, c, a = 1) { ctx.fillStyle = css(c, a); ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.3, rx), Math.max(0.3, ry), 0, 0, 2 * PI); ctx.fill(); }
  function thick(x0, y0, x1, y1, r, c) { ctx.strokeStyle = css(c); ctx.lineWidth = 2 * r; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
  function line(x0, y0, x1, y1, c, a = 1) { ctx.strokeStyle = css(c, a); ctx.lineWidth = Z; ctx.lineCap = 'butt'; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
  function poly(xs, ys, c, a = 1) { ctx.fillStyle = css(c, a); ctx.beginPath(); ctx.moveTo(xs[0], ys[0]); for (let i = 1; i < xs.length; i++) ctx.lineTo(xs[i], ys[i]); ctx.closePath(); ctx.fill(); }
  function leaf(x, y, len, wid, ang, c, a = 1) {
    const L = len / 2, W = wid / 2;
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.fillStyle = css(c, a);
    ctx.beginPath(); ctx.moveTo(-L, 0); ctx.bezierCurveTo(-L * 0.4, -W * 1.35, L * 0.4, -W * 1.2, L, 0); ctx.bezierCurveTo(L * 0.4, W * 1.2, -L * 0.4, W * 1.35, -L, 0); ctx.fill();
    ctx.restore();
  }
  const BRX = [1.25, 1.35, 1.42, 1.18], BRY = [0.55, 0.64, 0.46, 0.70], LEG = [1.0, 0.95, 1.18, 0.72];
  const PINK = [240, 160, 170], NOSE = [50, 38, 40], WHITE = [250, 250, 250], GOLD = [246, 196, 64];
  let g, C1, C2, C3, C4;

  function earsBack(hx, hy, hr, s, dir, c) {
    for (let side = -1; side <= 1; side += 2) {
      if (g.ears === 0 || g.ears === 2) {
        const k = g.ears === 2 ? 1.45 : 1.0;
        const bx = hx + side * s * 0.32 * (g.ears === 2 ? 1.1 : 1.0);
        poly([bx - s * 0.22 * k, bx + s * 0.22 * k, bx + side * s * 0.05 * k], [hy - s * 0.28, hy - s * 0.28, hy - s * 0.28 - s * 0.54 * k], c);
        poly([bx - s * 0.1 * k, bx + s * 0.1 * k, bx + side * s * 0.04 * k], [hy - s * 0.34, hy - s * 0.34, hy - s * 0.34 - s * 0.32 * k], PINK, 0.9);
      } else if (g.ears === 3) {
        const ex = hx + side * hr * 0.32, ey = hy - hr * 1.25;
        leaf(ex, ey, hr * 1.9, hr * 0.62, -PI / 2 + side * 0.2, c);
        leaf(ex, ey + hr * 0.08, hr * 1.45, hr * 0.3, -PI / 2 + side * 0.2, PINK, 0.9);
      } else if (g.ears === 4) {
        disc(hx + side * hr * 0.66, hy - hr * 0.68, hr * 0.36, c);
        disc(hx + side * hr * 0.66, hy - hr * 0.68, hr * 0.2, mix(c, 0.75));
      }
    }
  }
  function earsFront(hx, hy, hr, dir, c) {
    if (g.ears !== 1) return;
    const d = mix(c, 0.72);
    for (let side = -1; side <= 1; side += 2) leaf(hx + side * hr * 0.8 - dir * hr * 0.1, hy + hr * 0.12, hr * 1.25, hr * 0.6, PI / 2 - side * 0.35, d);
  }
  function headAcc(hx, hy, hr, dir) {
    const a = C4;
    if (g.acc === 1) {
      const bx = hx - dir * hr * 0.42, by = hy - hr * 0.78;
      poly([bx, bx - hr * 0.42, bx - hr * 0.42], [by, by - hr * 0.26, by + hr * 0.26], a);
      poly([bx, bx + hr * 0.42, bx + hr * 0.42], [by, by - hr * 0.26, by + hr * 0.26], a);
      disc(bx, by, hr * 0.12, mix(a, 0.8));
    } else if (g.acc === 3) {
      const cy = hy - hr * 0.42, rx = hr * 0.9, ry = hr * 0.66, px = [], py = [];
      for (let i = 0; i <= 12; i++) { const t = PI + PI * i / 12; px.push(hx + Math.cos(t) * rx); py.push(cy + Math.sin(t) * ry); }
      poly(px, py, a);
      thick(hx - rx * 0.95, cy, hx + rx * 0.95, cy, hr * 0.13, WHITE);
      disc(hx, cy - ry - hr * 0.08, hr * 0.2, WHITE);
    } else if (g.acc === 5) {
      const by = hy - hr * 0.72, w = hr * 0.5, h = hr * 0.5;
      poly([hx - w, hx - w, hx - w * 0.5, hx, hx + w * 0.5, hx + w, hx + w], [by, by - h, by - h * 0.5, by - h * 1.1, by - h * 0.5, by - h, by], GOLD);
      disc(hx, by - h * 0.35, hr * 0.08, a);
    }
  }
  function neckAcc(hx, hy, hr, s, dir) {
    if (g.acc === 2) {
      thick(hx - hr * 0.55, hy + hr * 0.86, hx + hr * 0.55, hy + hr * 0.9, s * 0.08, C4);
      disc(hx + dir * hr * 0.12, hy + hr * 1.04, s * 0.1, GOLD);
    } else if (g.acc === 4) {
      thick(hx - hr * 0.62, hy + hr * 0.86, hx + hr * 0.62, hy + hr * 0.92, s * 0.13, C4);
      thick(hx - dir * hr * 0.3, hy + hr * 0.95, hx - dir * hr * 0.5, hy + hr * 1.55, s * 0.1, mix(C4, 0.85));
    }
  }
  const headR = s => s * (g.face === 3 ? 0.62 : g.face === 2 ? 0.5 : 0.56);
  function head(hx, hy, s, dir, look, closed, happy) {
    const c = C1, d = C2, hr = headR(s);
    earsBack(hx, hy, hr, s, dir, c);
    disc(hx, hy, hr, c);
    const light = g.pattern === 4 ? d : mix(c, 1.18);
    if (g.pattern === 1) for (let k = -1; k <= 1; k++) line(hx + k * s * 0.14, hy - hr * 0.93, hx + k * s * 0.12, hy - hr * 0.54, d, 0.9);
    if (g.pattern === 2) disc(hx - dir * hr * 0.35, hy - hr * 0.35, hr * 0.28, d);
    let nx = hx + dir * s * 0.18, ny = hy + s * 0.16, nr = s * 0.07, nc = PINK, eyeX = hx + dir * s * 0.12;
    if (g.face === 1) {
      ell(hx + dir * hr * 0.72, hy + hr * 0.32, hr * 0.55, hr * 0.38, light);
      nx = hx + dir * hr * 1.18; ny = hy + hr * 0.2; nr = s * 0.11; nc = NOSE; eyeX = hx + dir * s * 0.04;
      if (happy) ell(hx + dir * hr * 0.85, hy + hr * 0.72, hr * 0.14, hr * 0.2, [230, 100, 120]);
    } else if (g.face === 2) {
      poly([hx + dir * hr * 0.2, hx + dir * hr * 1.42, hx + dir * hr * 0.2], [hy - hr * 0.1, hy + hr * 0.32, hy + hr * 0.7], c);
      poly([hx - dir * hr * 0.2, hx + dir * hr * 1.3, hx + dir * hr * 0.1], [hy + hr * 0.35, hy + hr * 0.4, hy + hr * 0.85], g.pattern === 4 ? d : WHITE);
      nx = hx + dir * hr * 1.38; ny = hy + hr * 0.3; nr = s * 0.08; nc = NOSE; eyeX = hx + dir * s * 0.06;
    } else if (g.face === 3) {
      disc(hx + dir * hr * 0.32, hy + hr * 0.34, hr * 0.4, light);
      nx = hx + dir * hr * 0.48; ny = hy + hr * 0.18; nr = s * 0.09; nc = NOSE;
    } else if (g.pattern === 4) {
      ell(hx + dir * s * 0.12, hy + s * 0.2, hr * 0.55, hr * 0.38, d);
    }
    const ex = eyeX + look * s * 0.06;
    for (let sd = -1; sd <= 1; sd += 2) {
      const x = ex + sd * s * 0.22, y = hy - s * 0.06;
      if (closed) { line(x - s * 0.1, y, x + s * 0.1, y + s * 0.03, [40, 30, 30]); continue; }
      if (g.eyes === 3) { disc(x, y, s * 0.065, [25, 22, 26]); continue; }
      const er = g.eyes === 1 ? s * 0.16 : s * 0.11;
      disc(x, y, er, C3);
      disc(x + er * 0.3, y - er * 0.35, er * (g.eyes === 1 ? 0.42 : 0.32), WHITE, 0.9);
      if (g.eyes === 2) ell(x, y - er * 0.55, er * 1.25, er * 0.62, c);
    }
    disc(nx, ny, nr, nc);
    if (g.face === 0)
      for (let sd = -1; sd <= 1; sd += 2) for (let k = 0; k < 2; k++)
        line(hx + sd * s * 0.25, hy + s * 0.2 + k * s * 0.08, hx + sd * s * 0.75, hy + s * 0.12 + k * s * 0.18, WHITE, 0.55);
    earsFront(hx, hy, hr, dir, c);
    headAcc(hx, hy, hr, dir);
  }
  function tail(bx, by, ex, ey, s, dir) {
    const dk = g.pattern === 1 ? C2 : mix(C1, 0.82);
    if (g.tail === 0) thick(bx, by, ex, ey, s * 0.16, dk);
    else if (g.tail === 1) {
      for (let i = 0; i <= 8; i++) {
        const t = i / 8, r = s * (0.16 + 0.26 * Math.sin(t * PI * 0.85));
        disc(bx + (ex - bx) * t, by + (ey - by) * t - Math.sin(t * PI) * s * 0.18, r, i >= 7 ? (g.pattern === 4 ? C2 : WHITE) : C1);
      }
    } else if (g.tail === 2) disc(bx - dir * s * 0.1, by - s * 0.05, s * 0.26, mix(g.pattern === 4 ? C2 : C1, 1.1));
    else if (g.tail === 3) {
      const cx = bx - dir * s * 0.05, cy = by - s * 0.42, r = s * 0.34;
      let px = bx, py = by;
      for (let i = 1; i <= 14; i++) {
        const a = PI * 0.5 + dir * (PI * 1.75 * i / 14);
        const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
        thick(px, py, x, y, s * 0.15, C1); px = x; py = y;
      }
    }
  }
  function bodyPattern(x, y, rx, ry, dir) {
    if (g.pattern === 1) for (let k = -2; k <= 2; k++) line(x + k * rx * 0.26, y - ry * 0.95, x + k * rx * 0.29, y - ry * 0.25, C2, 0.85);
    else if (g.pattern === 2) for (const q of [[-0.45, -0.25, 0.3], [0.22, -0.4, 0.24], [0.05, 0.28, 0.22], [0.55, 0.08, 0.2]]) disc(x + dir * q[0] * rx, y + q[1] * ry, q[2] * Math.min(rx, ry), C2);
    else if (g.pattern === 4) ell(x + dir * rx * 0.12, y + ry * 0.38, rx * 0.66, ry * 0.42, C2);
  }
  function beast(X, Y, st) {
    const c = C1, farC = mix(c, 0.8), paw = g.pattern === 3 ? C2 : c;
    const s = 15 * Z * g.size / 100, dir = st.dir, love = st.state === 'love';
    const brx = BRX[g.body] * s, bry = BRY[g.body] * s, leg = LEG[g.body];
    const fluff = (x, y, rx, ry) => { if (g.body !== 1) return; for (let i = 0; i < 14; i++) { const a = PI + PI * i / 13; disc(x + Math.cos(a) * rx * 0.95, y + Math.sin(a) * ry * 0.95, s * 0.13, c); } };
    if (st.state === 'sleep') {
      const br = 1 + 0.04 * Math.sin(st.anim * 2.2), rx = brx, ry = bry * br, cy = Y - ry * 0.92;
      if (g.tail === 0 || g.tail === 1) tail(X - dir * rx * 0.85, Y - s * 0.2, X + dir * rx * 0.5, Y - s * 0.1, s, dir);
      else if (g.tail === 2) disc(X - dir * rx * 0.95, cy, s * 0.24, mix(c, 1.1));
      fluff(X, cy, rx, ry); ell(X, cy, rx, ry, c); bodyPattern(X, cy, rx, ry, dir);
      head(X + dir * rx * 0.68, Y - s * 0.55, s * 0.86, dir, 0, true, false);
      return;
    }
    if (st.state === 'sit' || love) {
      const tw = Math.sin(st.anim * (love ? 1.0 : 2.4)) * 0.5;
      const rx = s * 0.62 * BRX[g.body], ry = s * 0.86 * (0.6 + 0.4 * BRY[g.body] / 0.55);
      const cx = X - dir * s * 0.15, cy = Y - ry * 0.99, tx = X - dir * rx * 0.9, ty = Y - s * 0.12;
      tail(tx, ty, tx - dir * s * 0.9, ty - s * (0.2 + 0.5 * tw), s, dir);
      fluff(cx, cy, rx, ry); ell(cx, cy, rx, ry, c);
      if (g.pattern === 1) for (let k = -1; k <= 1; k++) line(cx - dir * rx * 0.35 + k * rx * 0.25, cy - ry * 0.7 + Math.abs(k) * ry * 0.1, cx - dir * rx * 0.6 + k * rx * 0.25, cy - ry * 0.2, C2, 0.85);
      if (g.pattern === 2) { disc(cx - dir * rx * 0.45, cy - ry * 0.2, rx * 0.28, C2); disc(cx - dir * rx * 0.2, cy + ry * 0.45, rx * 0.22, C2); }
      ell(X + dir * s * 0.2, Y - ry * 0.87, rx * 0.5, ry * 0.7, g.pattern === 4 ? C2 : mix(c, 1.08), 0.92);
      const legTop = Y - ry * 0.6;
      thick(X + dir * s * 0.12, legTop, X + dir * s * 0.12, Y - s * 0.05, s * 0.14, c);
      thick(X + dir * s * 0.42, legTop, X + dir * s * 0.42, Y - s * 0.05, s * 0.14, c);
      if (g.pattern === 3) { disc(X + dir * s * 0.12, Y - s * 0.08, s * 0.15, paw); disc(X + dir * s * 0.42, Y - s * 0.08, s * 0.15, paw); }
      const hx = X + dir * s * 0.25, hy = Y - 2 * ry - s * 0.1;
      head(hx, hy, s, dir, st.look, love && g.face !== 1, love);
      neckAcc(hx, hy, headR(s), s, dir);
      return;
    }
    const run = 1, ph = st.anim * 9 * run, bob = Math.abs(Math.sin(ph)) * s * 0.06;
    const legLen = s * 0.61 * leg, by = Y - s * 0.06 - legLen - s * 0.25 - bob, tw = Math.sin(st.anim * 3) * 0.3;
    tail(X - dir * brx * 0.88, by - s * 0.15, X - dir * (brx + s * 0.5), by - s * (0.95 + tw), s, dir);
    for (let k = 0; k < 4; k++) {
      const lx = X + dir * (k < 2 ? brx * 0.6 : -brx * 0.6) + (k & 1 ? s * 0.18 : -s * 0.18) * dir;
      const sw = Math.sin(ph + (k & 1 ? PI : 0) + (k < 2 ? 0 : PI * 0.5)) * s * 0.28 * run * leg;
      thick(lx, by + s * 0.25, lx + sw * dir, Y - s * 0.06, s * 0.13, (k & 1) ? c : farC);
      if (g.pattern === 3) disc(lx + sw * dir, Y - s * 0.08, s * 0.14, (k & 1) ? paw : mix(paw, 0.88));
    }
    fluff(X, by, brx, bry); ell(X, by, brx, bry, c); bodyPattern(X, by, brx, bry, dir);
    const hx = X + dir * brx, hy = by - bry;
    head(hx, hy, s, dir, st.look, false, false);
    neckAcc(hx - dir * headR(s) * 0.35, hy - headR(s) * 0.12, headR(s), s, dir);
  }
  function bird(X, Y, st) {
    const s = 9 * Z * g.size / 100, dir = st.dir, fly = st.state === 'fly';
    const hop = st.state === 'walk' ? Math.abs(Math.sin((st.anim % 0.45) / 0.45 * PI)) * s * 0.9 : 0;
    const by = Y - s * 1.05 - hop - (fly ? s * 1.5 : 0);
    if (!fly) { line(X - s * 0.2, by + s * 0.8, X - s * 0.25, Y - hop, [60, 50, 50]); line(X + s * 0.2, by + s * 0.8, X + s * 0.25, Y - hop, [60, 50, 50]); }
    const peck = st.state === 'sit' ? Math.max(0, Math.sin(st.anim * 3)) * s * 0.35 : 0;
    poly([X - dir * s * 0.8, X - dir * s * 1.9, X - dir * s * 1.7], [by - s * 0.1, by - s * 0.5, by + s * 0.15], mix(C1, 0.4));
    disc(X, by, s, C1);
    ell(X + dir * s * 0.2, by + s * 0.25, s * 0.75, s * 0.68, C2);
    const wing = mix(C1, 0.6);
    if (fly) { const w = Math.sin(st.anim * 22) * 0.9; for (let sd = -1; sd <= 1; sd += 2) leaf(X - dir * s * 0.1, by - s * 0.3 - s * 0.6 * w * sd * 0.5, s * 1.8, s * 0.7, -PI / 2 + sd * (0.6 + w * 0.6), wing); }
    else ell(X - dir * s * 0.25, by - s * 0.05, s * 0.6, s * 0.4, wing);
    const hx = X + dir * s * 0.75, hy = by - s * 0.7 + peck;
    disc(hx, hy, s * 0.55, C3);
    disc(hx + dir * s * 0.1, hy + s * 0.22, s * 0.35, C2);
    disc(hx + dir * s * 0.12, hy - s * 0.1, s * 0.09, WHITE);
    poly([hx + dir * s * 0.45, hx + dir * s * 0.8, hx + dir * s * 0.45], [hy - s * 0.08, hy + s * 0.05, hy + s * 0.18], [40, 40, 40]);
    if (g.acc === 1 || g.acc === 3 || g.acc === 5) headAcc(hx, hy, s * 0.55, dir);
  }
  // рисует питомца, стоящего в точке (x, y) — y это поверхность под лапами; zoom — размер «пикселя»
  window.drawPetPreview = function (c2d, cfg, st, x, y, zoom) {
    ctx = c2d; Z = zoom; g = cfg;
    C1 = hex(cfg.c1); C2 = hex(cfg.c2); C3 = hex(cfg.c3); C4 = hex(cfg.c4);
    if (cfg.kind === 1) bird(x, y, st); else beast(x, y, st);
  };
})();
