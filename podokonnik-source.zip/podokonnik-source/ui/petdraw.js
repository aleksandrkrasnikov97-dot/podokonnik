// Питомец из картинок, нарисованных ChatGPT (атлас petatlas.js). Та же раскладка частей — в pet.h.
// cfg: {kind, body, face, ears, tail, eyes, pattern, acc, size, c1..c4 ('#rrggbb')}
// st: {state:'walk'|'sit'|'sleep'|'love'|'fly', anim, dir, look}
(function () {
  const PI = Math.PI;
  const A = window.PET_ATLAS, M = A.meta, SP = M.sprites;
  let data = null;                                   // Float32 каналы атласа
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const x = c.getContext('2d'); x.drawImage(img, 0, 0);
    data = x.getImageData(0, 0, img.width, img.height).data;
  };
  img.src = A.png;
  const hex = h => { const n = parseInt(String(h || '#888888').slice(1), 16) || 0; return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const cache = new Map();
  // спрайт, перекрашенный в цвета питомца (k — затемнение для дальних лап и уха)
  function baked(name, cols, k) {
    const key = name + cols.join() + k;
    let c = cache.get(key);
    if (c) return c;
    const s = SP[name]; if (!s || !data) return null;
    c = document.createElement('canvas'); c.width = s.w; c.height = s.h;
    const x = c.getContext('2d'), id = x.createImageData(s.w, s.h), o = id.data;
    const W = M.w, B = M.band, K = M.kmax;
    for (let yy = 0; yy < s.h; yy++) for (let xx = 0; xx < s.w; xx++) {
      const i0 = ((s.y + yy) * W + s.x + xx) * 4, i1 = i0 + B * W * 4, i2 = i1 + B * W * 4;
      const a = data[i1 + 1] / 255;
      if (a <= 0.003) continue;
      const w1 = data[i0] / 255 * K, w2 = data[i0 + 1] / 255 * K, w3 = data[i0 + 2] / 255 * K, w4 = data[i1] / 255 * K;
      const j = (yy * s.w + xx) * 4;
      for (let ch = 0; ch < 3; ch++) {
        const v = (w1 * cols[0][ch] + w2 * cols[1][ch] + w3 * cols[2][ch] + w4 * cols[3][ch]) * k + data[i2 + ch] * k;
        o[j + ch] = Math.min(255, v / a);
      }
      o[j + 3] = a * 255;
    }
    x.putImageData(id, 0, 0);
    if (cache.size > 300) cache.clear();
    cache.set(key, c);
    return c;
  }
  let ctx, cols;
  // нарисовать спрайт: точка крепления piv попадает в (x, y); size — высота (или ширина при byW); rot — поворот вокруг точки
  function spr(name, x, y, size, o = {}) {
    const s = SP[name]; if (!s) return;
    const b = baked(name, cols, o.k || 1); if (!b) return;
    const piv = s[o.piv || 'c'] || [0.5, 0.5];
    const sc = o.byW ? size / s.w : size / s.h;
    ctx.save();
    ctx.translate(x, y);
    if (o.rot) ctx.rotate(o.rot);
    ctx.scale(o.flip ? -sc : sc, sc);
    ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.drawImage(b, -piv[0] * s.w, -piv[1] * s.h);
    ctx.restore();
  }
  const aspect = n => SP[n] ? SP[n].h / SP[n].w : 1;
  const PAT = [0, 1, 2, 0, 4], SITPAT = [0, 1, 2, 3, 4];
  const TW = [2.5, 2.6, 2.9, 2.3], LEG = [1.0, 0.95, 1.15, 0.72], SITH = [2.15, 2.2, 2.4, 2.05], LW = [2.6, 2.7, 2.95, 2.4];
  let g;

  function ears(hx, hy, hr, dir, front) {
    const e = g.ears;
    if (e === 1) {   // висячие — поверх головы
      if (!front) return;
      spr('ear1', hx - dir * hr * 0.12, hy - hr * 0.7, hr * 1.55, {flip: dir < 0, k: 0.82});
      return;
    }
    if (front) return;
    const H = [hr * 1.0, 0, hr * 1.5, hr * 2.0, hr * 0.62][e];
    const by = hy - hr * (e === 4 ? 0.62 : 0.55);
    spr('ear' + e, hx - dir * hr * 0.42, by, H, {rot: -dir * 0.32, k: 0.8, flip: dir < 0});
    spr('ear' + e, hx + dir * hr * 0.18, by - hr * 0.08, H, {rot: dir * 0.12, flip: dir < 0});
  }
  function eyes(hx, hy, hr, dir, look, closed) {
    const n = closed ? 'eyeC' : 'eye' + g.eyes;
    const W = closed ? hr * 0.42 : [hr * 0.36, hr * 0.46, hr * 0.4, hr * 0.24][g.eyes];
    const lx = look * hr * 0.05;
    if (g.face === 1 || g.face === 2) {
      spr(n, hx + dir * hr * 0.42 + lx, hy - hr * 0.22, W, {byW: 1, flip: dir < 0});
    } else {
      const ey = hy - hr * (g.face === 3 ? 0.18 : 0.12);
      spr(n, hx + dir * hr * 0.08 + lx, ey, W * 0.9, {byW: 1, flip: dir < 0});
      spr(n, hx + dir * hr * 0.58 + lx, ey, W, {byW: 1, flip: dir < 0});
    }
  }
  function headAcc(hx, hy, hr, dir) {
    if (g.acc === 1) spr('acc1', hx - dir * hr * 0.45, hy - hr * 0.78, hr * 0.85, {byW: 1, rot: -dir * 0.35, flip: dir < 0});
    else if (g.acc === 3) spr('acc3', hx + dir * hr * 0.05, hy - hr * 0.38, hr * 1.75, {byW: 1, rot: dir * 0.08, flip: dir < 0});
    else if (g.acc === 5) spr('acc5', hx, hy - hr * 0.82, hr * 1.0, {byW: 1, rot: dir * 0.1, flip: dir < 0});
  }
  function neckAcc(nx, ny, hr, dir, rot) {
    if (g.acc === 2) spr('acc2', nx, ny, hr * 1.25, {byW: 1, rot: rot, flip: dir < 0});
    else if (g.acc === 4) spr('acc4', nx, ny, hr * 1.4, {byW: 1, rot: rot, flip: dir < 0});
  }
  function head(hx, hy, hr, dir, look, closed) {
    ears(hx, hy, hr, dir, false);
    spr(`head${g.face}_${PAT[g.pattern]}`, hx, hy, hr * 2, {flip: dir < 0});
    eyes(hx, hy, hr, dir, look, closed);
    ears(hx, hy, hr, dir, true);
    headAcc(hx, hy, hr, dir);
  }
  // хвост: основание в (x, y), растёт вверх и назад
  function tail(x, y, s, dir, wag, rot0) {
    const t = g.tail;
    if (t === 4) return;
    if (t === 2) { spr('tail2', x - dir * s * 0.1, y, s * 0.62, {flip: dir < 0}); return; }
    const H = [s * 1.3, s * 1.5, 0, s * 0.95][t];
    spr('tail' + t, x, y, H, {flip: dir > 0, rot: -dir * ((rot0 || 0) + wag)});
  }
  function beast(X, Y, st, s) {
    const dir = st.dir, b = g.body, love = st.state === 'love';
    const hr = s * 0.62;
    if (st.state === 'sleep') {
      const n = `sleep${b}_${PAT[g.pattern]}`, W = s * LW[b], H = W * aspect(n);
      const br = 1 + 0.03 * Math.sin(st.anim * 2.2);
      if (g.tail === 2) spr('tail2', X - dir * W * 0.46, Y - H * 0.35, s * 0.55);
      spr(n, X, Y - H * br / 2, W, {byW: 1, flip: dir < 0});
      if (g.tail === 0 || g.tail === 1) spr('tail' + g.tail, X - dir * W * 0.42, Y - H * 0.06, [s * 1.15, s * 1.25][g.tail], {flip: dir < 0, rot: dir * (g.tail ? 0.85 : 1.0)});   // хвост обёрнут вокруг
      head(X + dir * W * 0.36, Y - H * 0.55, hr * 0.92, dir, 0, true);
      return;
    }
    if (st.state === 'sit' || love) {
      const n = `sit${b}_${SITPAT[g.pattern]}`, H = s * SITH[b], W = H / aspect(n), sp = SP[n];
      const neck = sp ? sp.neck : [0.75, 0];
      const nx = X + dir * (neck[0] - 0.5) * W, ny = Y - H + neck[1] * H;
      const tw = Math.sin(st.anim * (love ? 1.0 : 2.0)) * 0.12;
      tail(X - dir * W * 0.32, Y - H * 0.12, s, dir, tw, 0.35);
      spr(n, X, Y, H, {flip: dir < 0});
      const hx = nx + dir * hr * 0.05, hy = ny - hr * 0.6;
      head(hx, hy, hr, dir, st.look, love && g.face !== 1);
      neckAcc(hx - dir * hr * 0.1, hy + hr * 0.82, hr, dir, 0);
      return;
    }
    // идёт
    const n = `torso${b}_${PAT[g.pattern]}`, W = s * TW[b], H = W * aspect(n);
    const ph = st.anim * 9, bob = Math.abs(Math.sin(ph)) * s * 0.05;
    const legVis = s * 0.62 * LEG[b], bodyBot = Y - legVis - bob, cy = bodyBot - H / 2;
    const legTop = bodyBot - H * 0.32, legLen = Y - legTop, leg = g.pattern === 3 ? 'leg3' : 'leg0';
    const legW = legLen * (SP[leg].w / SP[leg].h);
    const lx = [W * 0.3, W * 0.3 - s * 0.32, -W * 0.3 + s * 0.3, -W * 0.3];
    for (const far of [true, false])
      for (let i = 0; i < 4; i++) {
        if ((i % 2 === 0) !== far) continue;
        const sw = Math.sin(ph + (i % 2 ? PI : 0) + (i < 2 ? 0 : PI * 0.5)) * 0.32;
        spr(leg, X + dir * lx[i], legTop, legLen, {rot: -dir * sw, k: far ? 0.78 : 1, flip: dir < 0});
      }
    tail(X - dir * W * 0.42, cy - H * 0.05, s, dir, Math.sin(st.anim * 3) * 0.12, 0.2);
    spr(n, X, cy, W, {byW: 1, flip: dir < 0});
    void legW;
    const hx = X + dir * W * 0.4, hy = cy - H * 0.42 - hr * 0.2;
    head(hx, hy, hr, dir, st.look, false);
    neckAcc(hx - dir * hr * 0.35, hy + hr * 0.78, hr, dir, dir * 0.45);
  }
  function bird(X, Y, st, sb) {
    const dir = st.dir, W = sb * 2.7;
    if (st.state === 'fly') { spr('bird_fly', X, Y - sb * 2.4 + Math.sin(st.anim * 10) * sb * 0.2, W, {byW: 1, flip: dir < 0}); return; }
    const hop = st.state === 'walk' ? Math.abs(Math.sin((st.anim % 0.45) / 0.45 * PI)) * sb * 0.8 : 0;
    const peck = st.state === 'sit' && Math.sin(st.anim * 3) > 0.2;
    const n = peck ? 'bird_peck' : 'bird_stand';
    spr(n, X, Y - hop, W, {byW: 1, flip: dir < 0});
    if (!peck && g.acc && g.acc !== 2 && g.acc !== 4) {
      const H = W * aspect('bird_stand'), hr = W * 0.17;
      headAcc(X + dir * W * 0.2, Y - hop - H * 0.8, hr, dir);
    }
  }
  // рисует питомца, стоящего в точке (x, y) — y это поверхность под лапами; zoom — размер «пикселя»
  window.drawPetPreview = function (c2d, cfg, st, x, y, zoom) {
    ctx = c2d; g = cfg;
    cols = [hex(cfg.c1), hex(cfg.c2), hex(cfg.c3), hex(cfg.c4)];
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    const k = zoom * cfg.size / 100;   // чуть ниже края — как в программе
    if (cfg.kind === 1) bird(x, y + 9 * k * 0.2, st, 9 * k);
    else beast(x, y + 15 * k * 0.22, st, 15 * k);
  };
  window.petAtlasReady = () => !!data;
})();
