// ---------------------------------------------------------------- шейдеры Wallpaper Engine как есть
// Эффекты из паков (pulse, spin, shake, godrays, waterripple, vhs, clouds, blur, tint…) написаны на
// диалекте Wallpaper Engine (смесь GLSL и HLSL). Переводим их в GLSL ES 3.0 и запускаем по проходам.
const WE_RESERVED = ['sample', 'input', 'output', 'filter', 'active', 'common', 'partition', 'superp', 'cast', 'namespace', 'using',
  'union', 'enum', 'typedef', 'template', 'this', 'resource', 'goto', 'inline', 'noinline', 'public', 'static', 'extern', 'external',
  'interface', 'long', 'short', 'double', 'half', 'fixed', 'unsigned', 'sizeof', 'packed', 'precise', 'coherent', 'volatile',
  'restrict', 'readonly', 'writeonly', 'buffer', 'shared', 'subroutine', 'patch', 'smooth', 'flat', 'centroid', 'invariant'];
const WE_DEFINES = {
  texSample2D: 'texture', texSample2DLod: 'textureLod', frac: 'fract', lerp: 'mix', atan2: 'atan', ddx: 'dFdx', ddy: 'dFdy',
  'saturate(x)': 'clamp((x), 0.0, 1.0)', 'mul(a, b)': '((b) * (a))', 'CAST2(x)': 'vec2(x)', 'CAST3(x)': 'vec3(x)', 'CAST4(x)': 'vec4(x)',
  'CAST3X3(x)': 'mat3(x)', 'log10(x)': '(log2(x) * 0.30102999566)', 'fmod(x, y)': '((x) - (y) * trunc((x) / (y)))',
  float2: 'vec2', float3: 'vec3', float4: 'vec4', float3x3: 'mat3', float4x4: 'mat4',
  M_PI: '3.14159265359', M_PI_HALF: '1.57079632679', M_PI_2: '6.28318530718', SQRT_2: '1.41421356237', GLSL: '1',
};
// вспомогательные функции стандартных include-файлов Wallpaper Engine (вставляются, только если нужны)
const WE_BLEND_FUNCS = `
vec3 BlendNormal(vec3 a, vec3 b){ return b; }
vec3 BlendDarken(vec3 a, vec3 b){ return min(a, b); }
vec3 BlendMultiply(vec3 a, vec3 b){ return a * b; }
float we_cburn(float a, float b){ return b <= 0.0 ? 0.0 : max(1.0 - (1.0 - a) / b, 0.0); }
vec3 BlendColorBurn(vec3 a, vec3 b){ return vec3(we_cburn(a.r, b.r), we_cburn(a.g, b.g), we_cburn(a.b, b.b)); }
vec3 BlendLinearBurn(vec3 a, vec3 b){ return max(a + b - 1.0, 0.0); }
vec3 BlendDarkerColor(vec3 a, vec3 b){ return dot(a, vec3(0.3, 0.59, 0.11)) < dot(b, vec3(0.3, 0.59, 0.11)) ? a : b; }
vec3 BlendLighten(vec3 a, vec3 b){ return max(a, b); }
vec3 BlendScreen(vec3 a, vec3 b){ return 1.0 - (1.0 - a) * (1.0 - b); }
float we_cdodge(float a, float b){ return b >= 1.0 ? 1.0 : min(a / (1.0 - b), 1.0); }
vec3 BlendColorDodge(vec3 a, vec3 b){ return vec3(we_cdodge(a.r, b.r), we_cdodge(a.g, b.g), we_cdodge(a.b, b.b)); }
vec3 BlendLinearDodge(vec3 a, vec3 b){ return min(a + b, 1.0); }
vec3 BlendLighterColor(vec3 a, vec3 b){ return dot(a, vec3(0.3, 0.59, 0.11)) > dot(b, vec3(0.3, 0.59, 0.11)) ? a : b; }
float we_ov(float a, float b){ return a < 0.5 ? 2.0 * a * b : 1.0 - 2.0 * (1.0 - a) * (1.0 - b); }
vec3 BlendOverlay(vec3 a, vec3 b){ return vec3(we_ov(a.r, b.r), we_ov(a.g, b.g), we_ov(a.b, b.b)); }
float we_sl(float a, float b){ return b < 0.5 ? 2.0 * a * b + a * a * (1.0 - 2.0 * b) : sqrt(a) * (2.0 * b - 1.0) + 2.0 * a * (1.0 - b); }
vec3 BlendSoftLight(vec3 a, vec3 b){ return vec3(we_sl(a.r, b.r), we_sl(a.g, b.g), we_sl(a.b, b.b)); }
vec3 BlendHardLight(vec3 a, vec3 b){ return BlendOverlay(b, a); }
float we_vl(float a, float b){ return b < 0.5 ? we_cburn(a, 2.0 * b) : we_cdodge(a, 2.0 * (b - 0.5)); }
vec3 BlendVividLight(vec3 a, vec3 b){ return vec3(we_vl(a.r, b.r), we_vl(a.g, b.g), we_vl(a.b, b.b)); }
vec3 BlendLinearLight(vec3 a, vec3 b){ return clamp(a + 2.0 * b - 1.0, 0.0, 1.0); }
vec3 BlendPinLight(vec3 a, vec3 b){ return mix(min(a, 2.0 * b), max(a, 2.0 * b - 1.0), step(0.5, b)); }
vec3 BlendHardMix(vec3 a, vec3 b){ return step(1.0, a + b); }
vec3 BlendDifference(vec3 a, vec3 b){ return abs(a - b); }
vec3 BlendExclusion(vec3 a, vec3 b){ return a + b - 2.0 * a * b; }
vec3 BlendSubtract(vec3 a, vec3 b){ return max(a - b, 0.0); }
vec3 BlendReflect(vec3 a, vec3 b){ return min(a * a / max(1.0 - b, 0.001), 1.0); }
vec3 BlendGlow(vec3 a, vec3 b){ return BlendReflect(b, a); }
vec3 BlendPhoenix(vec3 a, vec3 b){ return min(a, b) - max(a, b) + 1.0; }
vec3 BlendAverage(vec3 a, vec3 b){ return (a + b) * 0.5; }
vec3 BlendNegation(vec3 a, vec3 b){ return 1.0 - abs(1.0 - a - b); }
vec3 we_rgb2hsv(vec3 c){ vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0); vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
  vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r)); float d = q.x - min(q.w, q.y);
  return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + 1e-10)), d / (q.x + 1e-10), q.x); }
vec3 we_hsv2rgb(vec3 c){ vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0); return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y); }
vec3 BlendHue(vec3 a, vec3 b){ vec3 h = we_rgb2hsv(a); h.x = we_rgb2hsv(b).x; return we_hsv2rgb(h); }
vec3 BlendSaturation(vec3 a, vec3 b){ vec3 h = we_rgb2hsv(a); h.y = we_rgb2hsv(b).y; return we_hsv2rgb(h); }
vec3 BlendColor(vec3 a, vec3 b){ vec3 h = we_rgb2hsv(b); h.z = we_rgb2hsv(a).z; return we_hsv2rgb(h); }
vec3 BlendLuminosity(vec3 a, vec3 b){ vec3 h = we_rgb2hsv(a); h.z = we_rgb2hsv(b).z; return we_hsv2rgb(h); }
vec3 BlendTint(vec3 a, vec3 b){ return dot(a, vec3(0.3, 0.59, 0.11)) * b; }
#define BlendOpacity(base, blend, F, O) (F(base, blend) * (O) + (base) * (1.0 - (O)))
vec3 ApplyBlending(int m, vec3 A, vec3 B, float o){
  vec3 r = B;
  if (m == 1) r = BlendDarken(A, B); else if (m == 2) r = BlendMultiply(A, B); else if (m == 3) r = BlendColorBurn(A, B);
  else if (m == 4) r = BlendLinearBurn(A, B); else if (m == 5) r = BlendDarkerColor(A, B); else if (m == 6) r = BlendLighten(A, B);
  else if (m == 7) r = BlendScreen(A, B); else if (m == 8) r = BlendColorDodge(A, B); else if (m == 9) r = BlendLinearDodge(A, B);
  else if (m == 10) r = BlendLighterColor(A, B); else if (m == 11) r = BlendOverlay(A, B); else if (m == 12) r = BlendSoftLight(A, B);
  else if (m == 13) r = BlendHardLight(A, B); else if (m == 14) r = BlendVividLight(A, B); else if (m == 15) r = BlendLinearLight(A, B);
  else if (m == 16) r = BlendPinLight(A, B); else if (m == 17) r = BlendHardMix(A, B); else if (m == 18) r = BlendDifference(A, B);
  else if (m == 19) r = BlendExclusion(A, B); else if (m == 20) r = BlendSubtract(A, B); else if (m == 21) r = BlendReflect(A, B);
  else if (m == 22) r = BlendGlow(A, B); else if (m == 23) r = BlendPhoenix(A, B); else if (m == 24) r = BlendAverage(A, B);
  else if (m == 25) r = BlendNegation(A, B); else if (m == 26) r = BlendHue(A, B); else if (m == 27) r = BlendSaturation(A, B);
  else if (m == 28) r = BlendColor(A, B); else if (m == 29) r = BlendLuminosity(A, B); else if (m == 30) r = BlendTint(A, B);
  return mix(A, r, o);
}
vec3 ApplyBlending(float m, vec3 A, vec3 B, float o){ return ApplyBlending(int(m + 0.5), A, B, o); }
`;
const WE_HELPERS = {
  rotateVec2: { code: 'vec2 rotateVec2(vec2 v, float r){ vec2 cs = vec2(cos(r), sin(r)); return vec2(v.x * cs.x - v.y * cs.y, v.x * cs.y + v.y * cs.x); }' },
  greyscale: { code: 'float greyscale(vec3 c){ return dot(c, vec3(0.11, 0.59, 0.3)); }' },
  ApplyBlending: { code: WE_BLEND_FUNCS, provides: ['BlendOpacity', 'BlendNormal', 'BlendDarken', 'BlendMultiply', 'BlendScreen', 'BlendLinearDodge',
    'BlendOverlay', 'BlendSoftLight', 'BlendHardLight', 'BlendColorDodge', 'BlendLighten', 'BlendDifference', 'BlendAdd', 'BlendTint'] },
  squareToQuad: { code: `mat3 squareToQuad(vec2 p0, vec2 p1, vec2 p2, vec2 p3){
  float sx = p0.x - p1.x + p2.x - p3.x, sy = p0.y - p1.y + p2.y - p3.y;
  float dx1 = p1.x - p2.x, dx2 = p3.x - p2.x, dy1 = p1.y - p2.y, dy2 = p3.y - p2.y;
  float z = dx1 * dy2 - dy1 * dx2; if (abs(z) < 1e-6) z = 1e-6;
  float g = (sx * dy2 - sy * dx2) / z, h = (sy * dx1 - sx * dy1) / z;
  return mat3(p1.x - p0.x + g * p1.x, p1.y - p0.y + g * p1.y, g, p3.x - p0.x + h * p3.x, p3.y - p0.y + h * p3.y, h, p0.x, p0.y, 1.0); }` },
  blur13a: { code: `vec4 we_blurN(vec2 uv, vec2 o, int n){
  float w[7]; w[0] = 0.171834; w[1] = 0.156756; w[2] = 0.119007; w[3] = 0.075189; w[4] = 0.039533; w[5] = 0.017298; w[6] = 0.006299;
  if (n == 3) { w[0] = 0.214607; w[1] = 0.189879; w[2] = 0.131514; w[3] = 0.071303; }
  if (n == 1) { w[0] = 0.5; w[1] = 0.25; }
  vec4 s = texture(g_Texture0, uv) * w[0];
  for (int i = 1; i <= 6; i++) { if (i > n) break; s += (texture(g_Texture0, uv + o * float(i)) + texture(g_Texture0, uv - o * float(i))) * w[i]; }
  return s; }
vec4 blur13a(vec2 uv, vec2 o){ return we_blurN(uv, o, 6); }
vec4 blur7a(vec2 uv, vec2 o){ return we_blurN(uv, o, 3); }
vec4 blur3a(vec2 uv, vec2 o){ return we_blurN(uv, o, 1); }`, provides: ['blur7a', 'blur3a'] },
  ApplyComposite: { code: `vec2 ApplyCompositeOffset(vec2 c, vec2 r){ return c; }
vec4 ApplyComposite(vec4 base, vec4 b){
#if COMPOSITE == 1
  return vec4(ApplyBlending(BLENDMODE, base.rgb, b.rgb, b.a), max(base.a, b.a));
#elif COMPOSITE == 2
  return vec4(mix(b.rgb, base.rgb, base.a), max(base.a, b.a));
#elif COMPOSITE == 3
  return vec4(b.rgb, b.a * (1.0 - base.a));
#else
  return b;
#endif
}`, needs: ['ApplyBlending'], provides: ['ApplyCompositeOffset'] },
};

function weStrip(src) {   // убрать комментарии, сохранив переводы строк
  return src.replace(/\/\*[\s\S]*?\*\//g, m => m.replace(/[^\n]/g, ' ')).replace(/\/\/[^\n]*/g, '');
}
function weAnnotations(src, out) {   // uniform-ы с подсказками {"material":…,"default":…}
  for (const m of src.matchAll(/uniform\s+(\w+)\s+(\w+)\s*(?:\[\s*\d+\s*\])?\s*;[ \t]*\/\/[ \t]*(\{[^\n]*\})/g)) {
    let a = null;
    try { a = JSON.parse(m[3]); } catch (e) { try { a = JSON.parse(m[3].replace(/,\s*}/, '}')); } catch (e2) {} }
    if (a) out[m[2]] = Object.assign({}, a, { glsl: m[1] });
  }
}
function weCombos(src, out) {
  for (const m of src.matchAll(/\/\/\s*\[COMBO\]\s*(\{[^\n]*\})/g)) {
    try { const c = JSON.parse(m[1]); if (c.combo) out[c.combo] = c.default != null ? +c.default : 0; } catch (e) {}
  }
}
// целые числа → дробные (в HLSL 2 * 0.5 работает, в GLSL — ошибка)
function weFixTypes(code) {
  const keep = new Set();
  for (const m of code.matchAll(/\[([^\]\[]*)\]/g)) for (const id of m[1].matchAll(/[A-Za-z_]\w*/g)) keep.add(id[0]);
  const isId = c => /[A-Za-z0-9_]/.test(c);
  let out = '', i = 0, depth = 0, regionEnd = -1;
  const n = code.length;
  const skipWs = j => { while (j < n && /\s/.test(code[j])) j++; return j; };
  const matchParen = j => { let d = 0; for (; j < n; j++) { if (code[j] === '(') d++; else if (code[j] === ')') { d--; if (!d) return j; } } return n; };
  while (i < n) {
    const c = code[i];
    if ((c === '#') && /(^|\n)\s*$/.test(code.slice(Math.max(0, i - 40), i))) {   // строка препроцессора
      const e = code.indexOf('\n', i); const end = e < 0 ? n : e;
      out += code.slice(i, end); i = end; continue;
    }
    if (c === '[') depth++;
    if (c === ']') depth = Math.max(0, depth - 1);
    if (isId(c) && (i === 0 || !isId(code[i - 1]))) {
      let j = i; while (j < n && isId(code[j])) j++;
      const w = code.slice(i, j);
      if (/^\d/.test(w) || (w[0] === '.' )) { /* число — ниже */ }
      else {
        if (depth === 0 && i >= regionEnd) {
          if (w === 'for') {   // for (int i …) с индексом массива — заголовок оставляем целым
            const p = skipWs(j);
            if (code[p] === '(') {
              const head = code.slice(p, matchParen(p) + 1);
              const mm = /^\(\s*int\s+([A-Za-z_]\w*)/.exec(head);
              if (mm && keep.has(mm[1])) { const e = matchParen(p) + 1; out += code.slice(i, e); i = e; continue; }
            }
          }
          if (w === 'int') {
            const p = skipWs(j);
            const mm = /^([A-Za-z_]\w*)/.exec(code.slice(p));
            if (mm && code[skipWs(p + mm[1].length)] !== '(') {   // объявление переменной, не функции
              if (keep.has(mm[1])) { const e = code.indexOf(';', p); regionEnd = e < 0 ? n : e; out += w; i = j; continue; }
              out += 'float'; i = j; continue;
            }
          }
          if (keep.has(w) && code[i - 1] !== '.') {   // целый индекс в дробном выражении → float(i)
            const a = code.slice(skipWs(j), skipWs(j) + 2), b = out.replace(/\s+$/, '').slice(-2);
            const lhs = /^(\+\+|--|=[^=]|\+=|-=|\*=|\/=)/.test(a + ' ') || b === '++' || b === '--';
            const decl = /\b(int|float|vec\d|in|out|uniform)\s*$/.test(out.slice(-12));
            if (!lhs && !decl && !/^\s*\(/.test(code.slice(j))) { out += 'float(' + w + ')'; i = j; continue; }
          }
        }
        out += w; i = j; continue;
      }
    }
    if (/[0-9.]/.test(c) && (i === 0 || !isId(code[i - 1]))) {
      const m = /^(0[xX][0-9a-fA-F]+[uU]?|\d+\.\d*(?:[eE][+-]?\d+)?[fF]?|\.\d+(?:[eE][+-]?\d+)?[fF]?|\d+[eE][+-]?\d+[fF]?|\d+[uU]?)/.exec(code.slice(i, i + 40));
      if (m) {
        let t = m[1];
        if (/^\d+$/.test(t) && depth === 0 && i >= regionEnd) t += '.0';
        out += t; i += m[1].length; continue;
      }
    }
    out += c; i++;
  }
  return out;
}
function wePrepare(src, stage, combos) {
  const includes = [...src.matchAll(/^[ \t]*#include\s+"([^"]+)"/gm)].map(m => m[1]);
  let code = weStrip(src);
  code = code.replace(new RegExp('\\b(' + WE_RESERVED.join('|') + ')\\b', 'g'), '$1_we');
  code = code.replace(/^[ \t]*#include[^\n]*/m, '/*@INC@*/').replace(/^[ \t]*#include[^\n]*/gm, '');
  code = weFixTypes(code);
  if (stage === 'v') code = code.replace(/\battribute\b/g, 'in').replace(/\bvarying\b/g, 'out');
  else code = code.replace(/\bvarying\b/g, 'in').replace(/\bgl_FragColor\b/g, 'we_FragColor').replace(/\btexture2D\b/g, 'texture');
  // нужные вспомогательные функции
  const definedFn = name => new RegExp('\\b(?:void|float|int|bool|vec[234]|mat[234])\\s+' + name + '\\s*\\(').test(code);
  const used = new Set();
  const want = name => {
    if (used.has(name)) return;
    const h = WE_HELPERS[name];
    if (!h) return;
    used.add(name);
    for (const d of h.needs || []) want(d);
  };
  for (const name in WE_HELPERS) {
    const h = WE_HELPERS[name];
    const names = [name].concat(h.provides || []);
    if (names.some(x => new RegExp('\\b' + x + '\\b').test(code)) && !definedFn(name)) want(name);
  }
  let helpers = '';
  for (const name of Object.keys(WE_HELPERS)) if (used.has(name)) helpers += WE_HELPERS[name].code + '\n';
  // #define из шапки — только если шейдер не определяет сам
  let head = '#version 300 es\nprecision highp float;\nprecision highp int;\n';
  for (const k in WE_DEFINES) {
    const nm = k.replace(/\(.*/, '');
    if (new RegExp('#\\s*define\\s+' + nm + '\\b').test(code)) continue;
    head += '#define ' + k + ' ' + WE_DEFINES[k] + '\n';
  }
  const defined = new Set(Object.keys(combos));
  for (const k in combos) head += '#define ' + k + ' ' + (combos[k] | 0) + '\n';
  for (const m of code.matchAll(/#\s*define\s+(\w+)/g)) defined.add(m[1]);
  for (const k in WE_DEFINES) defined.add(k.replace(/\(.*/, ''));
  // все имена в #if должны быть определены (в GLSL ES неизвестное имя — ошибка)
  const testText = code + '\n' + helpers;
  for (const m of testText.matchAll(/^[ \t]*#\s*(?:if|elif)\b([^\n]*)/gm)) {
    for (const id of m[1].replace(/defined\s*\(?\s*\w+\s*\)?/g, '').matchAll(/[A-Za-z_]\w*/g)) {
      if (!defined.has(id[0])) { defined.add(id[0]); head += '#define ' + id[0] + ' 0\n'; }
    }
  }
  if (stage === 'f') head += 'out vec4 we_FragColor;\n';
  if (code.includes('/*@INC@*/')) code = code.replace('/*@INC@*/', helpers);
  else code = helpers + code;
  return head + '#line 1\n' + code;
}

const weProgCache = new Map();
async function weProgram(shader, combos) {
  const key = shader + '|' + JSON.stringify(Object.keys(combos).sort().map(k => [k, combos[k]]));
  if (weProgCache.has(key)) return weProgCache.get(key);
  const td = new TextDecoder();
  const vb = await getFile('shaders/' + shader + '.vert'), fb = await getFile('shaders/' + shader + '.frag');
  if (!vb || !fb) { weProgCache.set(key, null); log('no shader', shader); return null; }
  const vs = td.decode(vb), fs = td.decode(fb);
  let r = null;
  try {
    const p = gl.createProgram();
    const s1 = gl.createShader(gl.VERTEX_SHADER), s2 = gl.createShader(gl.FRAGMENT_SHADER);
    const vsrc = wePrepare(vs, 'v', combos), fsrc = wePrepare(fs, 'f', combos);
    gl.shaderSource(s1, vsrc); gl.compileShader(s1);
    if (!gl.getShaderParameter(s1, gl.COMPILE_STATUS)) throw new Error('vert: ' + gl.getShaderInfoLog(s1));
    gl.shaderSource(s2, fsrc); gl.compileShader(s2);
    if (!gl.getShaderParameter(s2, gl.COMPILE_STATUS)) throw new Error('frag: ' + gl.getShaderInfoLog(s2));
    gl.attachShader(p, s1); gl.attachShader(p, s2);
    gl.bindAttribLocation(p, 0, 'a_Position'); gl.bindAttribLocation(p, 1, 'a_TexCoord');
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('link: ' + gl.getProgramInfoLog(p));
    const u = {};
    const cnt = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < cnt; i++) {
      const info = gl.getActiveUniform(p, i);
      u[info.name.replace(/\[0\]$/, '')] = { loc: gl.getUniformLocation(p, info.name), type: info.type, size: info.size };
    }
    // проход рисуется сразу в пикселях слоя или в координатах экрана (-1..1)?
    const clip = !/gl_Position\s*=\s*mul\s*\(/.test(weStrip(vs)) && /gl_Position\s*=\s*vec4\s*\(\s*a_Position/.test(weStrip(vs));
    const ann = {};
    weAnnotations(vs, ann); weAnnotations(fs, ann);
    const dyn = { time: /g_Time\b/.test(vs + fs), mouse: /g_PointerPosition|g_ParallaxPosition/.test(vs + fs) };
    r = { p, u, clip, ann, dyn };
  } catch (e) {
    log('shader failed', shader, e.message.slice(0, 400));
  }
  weProgCache.set(key, r);
  return r;
}

// значения uniform-ов прохода: из сцены, из материала, по умолчанию из шейдера
function weValue(type, v) {
  if (v == null) return null;
  if (typeof v === 'boolean') v = v ? 1 : 0;
  const n = { [gl.FLOAT]: 1, [gl.INT]: 1, [gl.BOOL]: 1, [gl.FLOAT_VEC2]: 2, [gl.FLOAT_VEC3]: 3, [gl.FLOAT_VEC4]: 4 }[type];
  if (!n) return null;
  if (typeof v === 'string' && n === 1) return [parseFloat(v) || 0];
  return vec(v, n, 0).map(x => +x || 0);
}
function weFindCv(cv, mat) {
  if (!cv || mat == null) return undefined;
  if (cv[mat] !== undefined) return cv[mat];
  const lm = String(mat).toLowerCase();
  for (const k in cv) if (k.toLowerCase() === lm) return cv[k];
  return undefined;
}

// эффект слоя: проходы, материалы, текстуры, промежуточные буферы
async function weLoadEffect(e) {
  const ej = await getJson(e.file);
  if (!ej || !ej.passes) return null;
  const eff = { name: e.file, passes: [], fbos: {} };
  for (const f of ej.fbos || []) eff.fbos[f.name] = { scale: Math.max(1, num(f.scale, 1)), fit: num(f.fit, 0) };
  for (let i = 0; i < ej.passes.length; i++) {
    const ep = ej.passes[i];
    const sp = (e.passes && e.passes[i]) || {};
    const mat = ep.material ? await getJson(ep.material) : null;
    const mp = mat && mat.passes && mat.passes[0];
    if (!mp || !mp.shader) { log('effect pass without shader', e.file); return null; }
    const pass = await weLoadPass(mp, sp, ep.bind || [], ep.target || null, mp.shader);
    if (!pass) return null;
    eff.passes.push(pass);
  }
  return eff;
}
async function weLoadPass(mp, sp, binds, target, shader) {
  const td = new TextDecoder();
  const vb = await getFile('shaders/' + shader + '.vert'), fb = await getFile('shaders/' + shader + '.frag');
  if (!vb || !fb) { log('no shader', shader); return null; }
  const combos = {};
  weCombos(td.decode(vb), combos); weCombos(td.decode(fb), combos);
  const ann = {};
  weAnnotations(td.decode(vb), ann); weAnnotations(td.decode(fb), ann);
  Object.assign(combos, mp.combos || {}, sp.combos || {});
  // текстуры по слотам
  const slots = [];
  for (let k = 0; k < 8; k++) {
    const a = ann['g_Texture' + k] || {};
    let src = null, explicit = false;
    const b = binds.find(x => x.index === k);
    if (b) src = b.name;
    else if (sp.textures && sp.textures[k]) { src = sp.textures[k]; explicit = true; }
    else if (mp.textures && mp.textures[k]) { src = mp.textures[k]; explicit = true; }
    else if (k === 0) src = 'previous';
    else if (a.default) src = a.default;
    if (a.combo && explicit && src) combos[a.combo] = 1;
    slots.push(src);
  }
  for (const k in combos) combos[k] = +val(combos[k], 0) || 0;
  const prog = await weProgram(shader, combos);
  if (!prog) return null;
  const tex = [];
  for (let k = 0; k < 8; k++) {
    const s = slots[k];
    if (!s) { tex.push(null); continue; }
    if (s === 'previous' || /^_rt_/i.test(s)) tex.push({ rt: s });
    else tex.push({ t: await loadTexture(s) });
  }
  // значения
  const vals = [];
  const cvS = sp.constantshadervalues || {}, cvM = mp.constantshadervalues || {};
  for (const name in prog.u) {
    const a = ann[name];
    if (!a || a.material == null) continue;
    let v = weFindCv(cvS, a.material);
    if (v === undefined) v = weFindCv(cvM, a.material);
    if (v === undefined) v = a.default;
    v = val(v, a.default);
    const arr = weValue(prog.u[name].type, v);
    if (arr) vals.push([prog.u[name], arr]);
  }
  return { prog, tex, vals, target, blending: mp.blending || 'normal' };
}

// буфер кадра (RGBA8)
function weFbo(w, h) {
  const f = makeFbo(w, h);
  return f;
}
function weSetUniform(u, v) {
  const l = u.loc, t = u.type;
  if (t === gl.FLOAT) gl.uniform1fv(l, v.length >= u.size ? v : padArr(v, u.size));
  else if (t === gl.FLOAT_VEC2) gl.uniform2f(l, v[0], v[1] != null ? v[1] : v[0]);
  else if (t === gl.FLOAT_VEC3) gl.uniform3f(l, v[0], v[1] != null ? v[1] : v[0], v[2] != null ? v[2] : v[0]);
  else if (t === gl.FLOAT_VEC4) gl.uniform4f(l, v[0], v[1] != null ? v[1] : v[0], v[2] != null ? v[2] : v[0], v[3] != null ? v[3] : 1);
  else if (t === gl.INT || t === gl.BOOL) gl.uniform1i(l, v[0] | 0);
}
const padArr = (v, n) => { const a = new Float32Array(n); a.set(v.slice(0, n)); return a; };
const IDENT4 = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);

// четыре вершины прохода: позиция (x, y, z) и координаты текстуры
const weQuad = { clip: null, vaoClip: null };
function weMakeVao(pos, uv) {
  const vao = gl.createVertexArray();
  gl.bindVertexArray(vao);
  const b1 = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, b1); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pos), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
  const b2 = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, b2); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(uv), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 0, 0);
  gl.bindVertexArray(null);
  return { vao, bufs: [b1, b2] };
}
function weFreeVao(v) { if (v) { gl.deleteVertexArray(v.vao); for (const b of v.bufs) gl.deleteBuffer(b); } }
// строка 0 буфера = верх картинки (как у текстур Wallpaper Engine): v = 0 сверху
function weVaos(w, h, su = 1, sv = 1) {
  const uv = [0, 0, 1, 0, 0, 1, 1, 1];
  const uvs = [0, 0, su, 0, 0, sv, su, sv];
  const clip = [-1, -1, 0, 1, -1, 0, -1, 1, 0, 1, 1, 0];
  const px = [-w / 2, h / 2, 0, w / 2, h / 2, 0, -w / 2, -h / 2, 0, w / 2, -h / 2, 0];
  return { clip: weMakeVao(clip, uv), px: weMakeVao(px, uv), pxs: weMakeVao(px, uvs), clips: weMakeVao(clip, uvs) };
}
function weMvp(w, h) {   // пиксели слоя (y вверх) → буфер (строка 0 = верх)
  return new Float32Array([2 / w, 0, 0, 0, 0, -2 / h, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
}

// один проход: target — буфер, rt — именованные буферы, prev — текущая картинка слоя
function weRunPass(pass, target, rts, prev, g, base) {
  const P = pass.prog, U = P.u;
  gl.bindFramebuffer(gl.FRAMEBUFFER, target.fb);
  gl.viewport(0, 0, target.w, target.h);
  gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
  if (pass.blending === 'translucent') { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); }
  else if (pass.blending === 'additive') { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE); }
  else gl.disable(gl.BLEND);
  gl.useProgram(P.p);
  for (const [u, v] of pass.vals) weSetUniform(u, v);
  const set = (n, f) => { const u = U[n]; if (u) f(u.loc, u); };
  set('g_Time', l => gl.uniform1f(l, tNow));
  set('g_Frametime', l => gl.uniform1f(l, 1 / 30));
  set('g_Daytime', l => { const d = new Date(); gl.uniform1f(l, (d.getHours() * 60 + d.getMinutes()) / 1440); });
  set('g_ModelViewProjectionMatrix', l => gl.uniformMatrix4fv(l, false, g.mvp));
  for (const n of ['g_EffectModelViewProjectionMatrix', 'g_EffectTextureProjectionMatrix', 'g_EffectTextureProjectionMatrixInverse',
    'g_EffectModelViewProjectionMatrixInverse', 'g_ModelMatrix', 'g_ViewProjectionMatrix', 'g_ModelMatrixInverse']) set(n, l => gl.uniformMatrix4fv(l, false, IDENT4));
  set('g_PointerPosition', l => gl.uniform2f(l, mouse[0], mouse[1]));
  set('g_PointerPositionLast', l => gl.uniform2f(l, mouse[0], mouse[1]));
  set('g_ParallaxPosition', l => gl.uniform2f(l, 0.5 + (mouse[0] - 0.5) * PSTR, 0.5 + (mouse[1] - 0.5) * PSTR));
  set('g_Screen', l => gl.uniform3f(l, canvas.width, canvas.height, canvas.width / canvas.height));
  set('g_TexelSize', l => gl.uniform2f(l, 1 / target.w, 1 / target.h));
  set('g_TexelSizeHalf', l => gl.uniform2f(l, 0.5 / target.w, 0.5 / target.h));
  set('g_Alpha', l => gl.uniform1f(l, 1));
  set('g_UserAlpha', l => gl.uniform1f(l, 1));
  set('g_Color', l => gl.uniform3f(l, 1, 1, 1));
  set('g_Color4', l => gl.uniform4f(l, 1, 1, 1, 1));
  for (const n of ['g_AudioSpectrum16Left', 'g_AudioSpectrum16Right', 'g_AudioSpectrum32Left', 'g_AudioSpectrum32Right', 'g_AudioSpectrum64Left', 'g_AudioSpectrum64Right'])
    set(n, (l, u) => gl.uniform1fv(l, new Float32Array(u.size)));
  let unit = 0;
  for (let k = 0; k < 8; k++) {
    const t = pass.tex[k];
    const u = U['g_Texture' + k], ur = U['g_Texture' + k + 'Resolution'];
    if (!u && !ur) continue;
    let gt = null, w = 1, h = 1, iw = 1, ih = 1;
    if (t && t.rt) {
      const r = t.rt === 'previous' ? prev : (rts[t.rt] || (/fullframe/i.test(t.rt) ? SCN.copy : null) || prev);
      if (r) { gt = r.tex; w = iw = r.w; h = ih = r.h; }
    } else if (t && t.t) { gt = t.t.tex; w = t.t.w; h = t.t.h; iw = t.t.imgW; ih = t.t.imgH; }
    else if (base && k === 0) { gt = base.tex; w = base.w; h = base.h; iw = base.imgW; ih = base.imgH; }
    if (!gt) { const wt = builtinFor('util/white'); gt = wt.tex; w = h = iw = ih = 4; }
    if (u) { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, gt); gl.uniform1i(u.loc, unit); unit++; }
    if (ur) gl.uniform4f(ur.loc, w, h, iw, ih);
  }
  const v = base ? (P.clip ? g.vao.clips : g.vao.pxs) : (P.clip ? g.vao.clip : g.vao.px);
  gl.bindVertexArray(v.vao);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  gl.bindVertexArray(null);
}
