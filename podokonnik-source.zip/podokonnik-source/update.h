// Обновление программы прямо из неё: version.json и новый exe лежат на сайте (GitHub Pages)
#pragma once
#include <string>

#define WM_UPDCHECKED  (WM_APP + 8)    // wp: 0 — последняя версия, 1 — есть новая, 2 — ошибка; lp: 1 — проверка по кнопке
#define WM_UPDPROGRESS (WM_APP + 9)    // wp: проценты
#define WM_UPDLOADED   (WM_APP + 10)   // wp: 1 — скачано, 0 — ошибка

static std::wstring gUpdExePath;   // путь к exe на сайте
static DWORD gUpdSize = 0;
static bool gUpdNotified = false;
static volatile LONG gUpdBusy = 0;

static std::wstring exePath() {
    wchar_t p[MAX_PATH * 2] = {0};
    GetModuleFileNameW(nullptr, p, MAX_PATH * 2);
    return p;
}

static int versionCmp(const std::string& a, const std::string& b) {
    size_t i = 0, j = 0;
    while (i < a.size() || j < b.size()) {
        long x = 0, y = 0;
        while (i < a.size() && a[i] != '.') { if (isdigit((unsigned char)a[i])) x = x * 10 + (a[i] - '0'); ++i; }
        while (j < b.size() && b[j] != '.') { if (isdigit((unsigned char)b[j])) y = y * 10 + (b[j] - '0'); ++j; }
        if (x != y) return x < y ? -1 : 1;
        ++i; ++j;
    }
    return 0;
}

// GET с сайта: в строку (out) или в файл (dst); для файла шлёт проценты
static bool updGet(const std::wstring& path, std::string* out, const std::wstring* dst, DWORD expect) {
#ifdef UPDTEST
    if (out) { HANDLE f = CreateFileW(L"C:\\upd\\version.json", GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
        if (f == INVALID_HANDLE_VALUE) return false; char b[4096]; DWORD r = 0; ReadFile(f, b, sizeof b, &r, nullptr); CloseHandle(f); out->assign(b, r); return true; }
    PostMessageW(gMsgWnd, WM_UPDPROGRESS, 50, 0); Sleep(500);
    return CopyFileW(L"C:\\upd\\new.exe", dst->c_str(), FALSE) != 0;
#endif
    HINTERNET ses = WinHttpOpen(L"Podokonnik/1.1", 4, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) ses = WinHttpOpen(L"Podokonnik/1.1", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!ses) return false;
    WinHttpSetTimeouts(ses, 15000, 15000, 20000, 60000);
    DWORD proto = 0x00000800 | 0x00002000;
    if (!WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto))) {
        proto = 0x00000800;
        WinHttpSetOption(ses, WINHTTP_OPTION_SECURE_PROTOCOLS, &proto, sizeof(proto));
    }
    bool ok = false;
    HINTERNET con = WinHttpConnect(ses, kUpdHost, INTERNET_DEFAULT_HTTPS_PORT, 0);
    HINTERNET req = con ? WinHttpOpenRequest(con, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE | WINHTTP_FLAG_REFRESH) : nullptr;
    if (req && WinHttpSendRequest(req, L"Cache-Control: no-cache\r\n", (DWORD)-1L, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(req, nullptr)) {
        DWORD status = 0, sz = sizeof(status), clen = 0;
        WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
        sz = sizeof(clen);
        WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_LENGTH | WINHTTP_QUERY_FLAG_NUMBER, WINHTTP_HEADER_NAME_BY_INDEX, &clen, &sz, WINHTTP_NO_HEADER_INDEX);
        if (!clen) clen = expect;
        if (status == 200) {
            std::vector<char> buf(128 * 1024);
            DWORD got = 0, total = 0, lastPct = 0;
            HANDLE f = INVALID_HANDLE_VALUE;
            if (dst) f = CreateFileW(dst->c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
            bool err = dst && f == INVALID_HANDLE_VALUE;
            while (!err) {
                if (!WinHttpReadData(req, buf.data(), (DWORD)buf.size(), &got)) { err = true; break; }
                if (got == 0) break;
                if (dst) {
                    DWORD wr = 0;
                    if (!WriteFile(f, buf.data(), got, &wr, nullptr) || wr != got) { err = true; break; }
                } else {
                    out->append(buf.data(), got);
                    if (out->size() > 64 * 1024) { err = true; break; }
                }
                total += got;
                if (dst && clen) {
                    DWORD pct = (DWORD)((ULONGLONG)total * 100 / clen);
                    if (pct != lastPct) { lastPct = pct; PostMessageW(gMsgWnd, WM_UPDPROGRESS, pct, 0); }
                }
            }
            if (f != INVALID_HANDLE_VALUE) CloseHandle(f);
            ok = !err && (!clen || total == clen);
            if (!ok) alog("update: download error, got %lu of %lu", total, clen);
        } else alog("update: http status %lu", status);
    } else alog("update: request failed err=%lu", GetLastError());
    if (req) WinHttpCloseHandle(req);
    if (con) WinHttpCloseHandle(con);
    WinHttpCloseHandle(ses);
    return ok;
}

static DWORD WINAPI UpdCheckThread(LPVOID manual) {
    // остатки прошлого обновления
    std::wstring old = exePath() + L".old";
    for (int i = 0; i < 5 && GetFileAttributesW(old.c_str()) != INVALID_FILE_ATTRIBUTES; ++i) {
        if (DeleteFileW(old.c_str())) break;
        Sleep(1000);
    }
    std::string body;
    std::wstring path = std::wstring(kUpdJson) + L"?t=" + std::to_wstring(GetTickCount());
    int res = 2;
    if (updGet(path, &body, nullptr, 0)) {
        js::Value v = js::parse(body);
        std::string ver = v.str("version"), exe = v.str("exe");
        if (!ver.empty() && !exe.empty()) {
            gUpdVersion = ver;
            gUpdNotes = v.str("notes");
            gUpdExePath = std::wstring(exe.begin(), exe.end());
            gUpdSize = (DWORD)v.num("size", 0);
            res = versionCmp(kAppVersion, ver) < 0 ? 1 : 0;
        }
    }
    alog("update check: site has %s, this is %s, result %d", gUpdVersion.c_str(), kAppVersion, res);
    PostMessageW(gMsgWnd, WM_UPDCHECKED, res, manual ? 1 : 0);
    InterlockedExchange(&gUpdBusy, 0);
    return 0;
}

static void updCheck(bool manual) {
    if (gUpdState == UPD_LOADING || gUpdState == UPD_RESTART) return;
    if (InterlockedExchange(&gUpdBusy, 1)) return;
    gUpdLastTry = GetTickCount();
    if (manual) gUpdState = UPD_CHECKING;
    HANDLE t = CreateThread(nullptr, 0, UpdCheckThread, manual ? (LPVOID)1 : nullptr, 0, nullptr);
    if (t) CloseHandle(t); else InterlockedExchange(&gUpdBusy, 0);
}

static DWORD WINAPI UpdLoadThread(LPVOID) {
    std::wstring dst = exePath() + L".new";
    bool ok = updGet(gUpdExePath, nullptr, &dst, gUpdSize);
    if (ok) {
        // это точно программа для Windows, а не страница с ошибкой
        HANDLE f = CreateFileW(dst.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
        char mz[2] = {0, 0};
        DWORD rd = 0;
        LARGE_INTEGER size{};
        if (f != INVALID_HANDLE_VALUE) { ReadFile(f, mz, 2, &rd, nullptr); GetFileSizeEx(f, &size); CloseHandle(f); }
        ok = rd == 2 && mz[0] == 'M' && mz[1] == 'Z' && size.QuadPart > 200000 && (!gUpdSize || size.QuadPart == gUpdSize);
        if (!ok) alog("update: downloaded file is not a valid exe");
    }
    if (!ok) DeleteFileW(dst.c_str());
    PostMessageW(gMsgWnd, WM_UPDLOADED, ok ? 1 : 0, 0);
    return 0;
}

static void updInstall() {
    if (gUpdState != UPD_AVAILABLE && gUpdState != UPD_ERROR) return;
    if (gUpdExePath.empty()) { updCheck(true); return; }
    gUpdState = UPD_LOADING;
    gUpdPct = 0;
    HANDLE t = CreateThread(nullptr, 0, UpdLoadThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t); else gUpdState = UPD_ERROR;
}

// новый exe скачан: меняем файлы местами и перезапускаемся
static bool updSwapAndRestart() {
    std::wstring cur = exePath(), nw = cur + L".new", old = cur + L".old";
    DeleteFileW(old.c_str());
    if (!MoveFileExW(cur.c_str(), old.c_str(), MOVEFILE_REPLACE_EXISTING)) { alog("update: cannot rename running exe err=%lu", GetLastError()); return false; }
    if (!MoveFileExW(nw.c_str(), cur.c_str(), MOVEFILE_REPLACE_EXISTING)) {
        alog("update: cannot put new exe err=%lu", GetLastError());
        MoveFileExW(old.c_str(), cur.c_str(), MOVEFILE_REPLACE_EXISTING);
        return false;
    }
    std::wstring cmd = L"\"" + cur + L"\" --updated";
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(cur.c_str(), &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
        alog("update: cannot start new exe err=%lu", GetLastError());
        MoveFileExW(cur.c_str(), nw.c_str(), MOVEFILE_REPLACE_EXISTING);
        MoveFileExW(old.c_str(), cur.c_str(), MOVEFILE_REPLACE_EXISTING);
        return false;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return true;   // новая версия сама закроет эту
}

static void updBalloon(const wchar_t* title, const wchar_t* text) {
    gNid.uFlags = NIF_INFO;
    wcsncpy(gNid.szInfoTitle, title, 63);
    wcsncpy(gNid.szInfo, text, 255);
    gNid.dwInfoFlags = NIIF_INFO;
    Shell_NotifyIconW(NIM_MODIFY, &gNid);
}

static bool updMsg(UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_UPDCHECKED) {
        bool manual = lp == 1;
        if (wp == 1) {
            gUpdState = UPD_AVAILABLE;
            if (gAppWnd) appToast("Вышла новая версия " + gUpdVersion + " — нажми «Обновить»");
            if (!gUpdNotified) {
                gUpdNotified = true;
                std::wstring t = L"Вышла версия " + W16(gUpdVersion) + L". Открой Подоконник, чтобы обновиться.";
                updBalloon(L"Доступно обновление Подоконника", t.c_str());
            }
        } else if (wp == 0) {
            gUpdState = UPD_LATEST;
            if (manual) appToast("У тебя последняя версия");
        } else {
            gUpdState = manual ? UPD_ERROR : UPD_IDLE;
            if (manual) appToast("Не получилось проверить обновления. Проверь интернет.");
            static int fails = 0;   // при запуске интернета может ещё не быть — пробуем снова через 2 минуты
            if (!manual && ++fails <= 10) SetTimer(gMsgWnd, 7, 120000, nullptr);
        }
        appPushState();
        return true;
    }
    if (msg == WM_UPDPROGRESS) {
        gUpdPct = (int)wp;
        appPushState();
        return true;
    }
    if (msg == WM_UPDLOADED) {
        if (wp == 1) {
            gUpdState = UPD_RESTART;
            appPushState();
            if (!updSwapAndRestart()) {
                gUpdState = UPD_ERROR;
                appToast("Не получилось заменить файл программы. Скачай новую версию с сайта.");
                appPushState();
            }
        } else {
            gUpdState = UPD_ERROR;
            appToast("Не получилось скачать обновление. Проверь интернет и попробуй ещё раз.");
            appPushState();
        }
        return true;
    }
    return false;
}
