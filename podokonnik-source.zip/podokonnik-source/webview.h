// Обвязка WebView2 без WRL (mingw): обработчики-COM, окружение, контейнер страницы.
#pragma once
#include <objbase.h>
#include <functional>
#include <string>
#include <vector>
#include "third_party/wv2/WebView2.h"

namespace wv {

// GUID'ы нужных интерфейсов (из WebView2.h)
static const IID IID_EnvCompleted   = {0x4e8a3389, 0xc9d8, 0x4bd2, {0xb6, 0xb5, 0x12, 0x4f, 0xee, 0x6c, 0xc1, 0x4d}};
static const IID IID_CtlCompleted   = {0x6c4819f3, 0xc9b7, 0x4260, {0x81, 0x27, 0xc9, 0xf5, 0xbd, 0xe7, 0xf6, 0x8c}};
static const IID IID_MsgReceived    = {0x57213f19, 0x00e6, 0x49fa, {0x8e, 0x07, 0x89, 0x8e, 0xa0, 0x1e, 0xcb, 0xd2}};
static const IID IID_NavCompleted   = {0xd33a35bf, 0x1c49, 0x4f98, {0x93, 0xab, 0x00, 0x6e, 0x05, 0x33, 0xfe, 0x1c}};
static const IID IID_ScriptAdded    = {0xb99369f3, 0x9b11, 0x47b5, {0xbc, 0x6f, 0x8e, 0x78, 0x95, 0xfc, 0xea, 0x17}};
static const IID IID_ExecDone       = {0x49511172, 0xcc67, 0x4bca, {0x99, 0x23, 0x13, 0x71, 0x12, 0xf4, 0xc4, 0xcc}};
static const IID IID_NewWindow      = {0xd4c185fe, 0xc81c, 0x4989, {0x97, 0xaf, 0x2d, 0x3f, 0xa7, 0xab, 0x56, 0x51}};
static const IID IID_EnvOptions     = {0x2fde08a8, 0x1e9a, 0x4766, {0x8c, 0x05, 0x95, 0xa9, 0xce, 0xb9, 0xd1, 0xc5}};
static const IID IID_Unknown        = {0x00000000, 0x0000, 0x0000, {0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46}};

template <class I, class... A>
class Handler : public I {
    LONG ref_ = 1;
    IID iid_;
    std::function<HRESULT(A...)> fn_;
public:
    Handler(const IID& iid, std::function<HRESULT(A...)> fn) : iid_(iid), fn_(std::move(fn)) {}
    virtual ~Handler() {}
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
        if (IsEqualIID(riid, IID_Unknown) || IsEqualIID(riid, iid_)) { *ppv = static_cast<I*>(this); AddRef(); return S_OK; }
        *ppv = nullptr;
        return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return (ULONG)InterlockedIncrement(&ref_); }
    ULONG STDMETHODCALLTYPE Release() override {
        LONG r = InterlockedDecrement(&ref_);
        if (!r) delete this;
        return (ULONG)r;
    }
    HRESULT STDMETHODCALLTYPE Invoke(A... a) override { return fn_ ? fn_(a...) : S_OK; }
};

static LPWSTR coStr(const std::wstring& s) {
    size_t n = (s.size() + 1) * sizeof(wchar_t);
    LPWSTR p = (LPWSTR)CoTaskMemAlloc(n);
    if (p) memcpy(p, s.c_str(), n);
    return p;
}

// параметры окружения: доп. аргументы браузера (автозапуск видео со звуком)
class EnvOptions : public ICoreWebView2EnvironmentOptions {
    LONG ref_ = 1;
    std::wstring args_, lang_, ver_;
    BOOL sso_ = FALSE;
public:
    explicit EnvOptions(const std::wstring& args) : args_(args), ver_(L"86.0.616.0") {}
    virtual ~EnvOptions() {}
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
        if (IsEqualIID(riid, IID_Unknown) || IsEqualIID(riid, IID_EnvOptions)) { *ppv = static_cast<ICoreWebView2EnvironmentOptions*>(this); AddRef(); return S_OK; }
        *ppv = nullptr;
        return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return (ULONG)InterlockedIncrement(&ref_); }
    ULONG STDMETHODCALLTYPE Release() override { LONG r = InterlockedDecrement(&ref_); if (!r) delete this; return (ULONG)r; }
    HRESULT STDMETHODCALLTYPE get_AdditionalBrowserArguments(LPWSTR* v) override { *v = coStr(args_); return S_OK; }
    HRESULT STDMETHODCALLTYPE put_AdditionalBrowserArguments(LPCWSTR v) override { args_ = v ? v : L""; return S_OK; }
    HRESULT STDMETHODCALLTYPE get_Language(LPWSTR* v) override { *v = coStr(lang_); return S_OK; }
    HRESULT STDMETHODCALLTYPE put_Language(LPCWSTR v) override { lang_ = v ? v : L""; return S_OK; }
    HRESULT STDMETHODCALLTYPE get_TargetCompatibleBrowserVersion(LPWSTR* v) override { *v = coStr(ver_); return S_OK; }
    HRESULT STDMETHODCALLTYPE put_TargetCompatibleBrowserVersion(LPCWSTR v) override { ver_ = v ? v : L""; return S_OK; }
    HRESULT STDMETHODCALLTYPE get_AllowSingleSignOnUsingOSPrimaryAccount(BOOL* v) override { *v = sso_; return S_OK; }
    HRESULT STDMETHODCALLTYPE put_AllowSingleSignOnUsingOSPrimaryAccount(BOOL v) override { sso_ = v; return S_OK; }
};

typedef HRESULT (STDAPICALLTYPE *CreateEnvFn)(PCWSTR, PCWSTR, ICoreWebView2EnvironmentOptions*,
                                              ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler*);

static ICoreWebView2Environment* gEnv = nullptr;
static bool gEnvStarted = false;
static HRESULT gEnvError = S_OK;
static std::vector<std::function<void(ICoreWebView2Environment*)>> gEnvWaiters;
static std::function<void(const char*)> gLog;

static void log(const char* fmt, ...) {
    if (!gLog) return;
    char b[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(b, sizeof b, fmt, ap);
    va_end(ap);
    gLog(b);
}

// получить окружение (асинхронно); f(nullptr) — если WebView2 недоступен
static void withEnv(const std::wstring& userData, std::function<void(ICoreWebView2Environment*)> f) {
    if (gEnv) { f(gEnv); return; }
    if (gEnvStarted && FAILED(gEnvError)) { f(nullptr); return; }
    gEnvWaiters.push_back(std::move(f));
    if (gEnvStarted) return;
    gEnvStarted = true;
    wchar_t dir[MAX_PATH];
    GetModuleFileNameW(nullptr, dir, MAX_PATH);
    wchar_t* sl = wcsrchr(dir, L'\\');
    if (sl) *sl = 0;
    std::wstring dll = std::wstring(dir) + L"\\WebView2Loader.dll";
    HMODULE m = LoadLibraryW(dll.c_str());
    if (!m) m = LoadLibraryW(L"WebView2Loader.dll");
    CreateEnvFn create = m ? (CreateEnvFn)(void*)GetProcAddress(m, "CreateCoreWebView2EnvironmentWithOptions") : nullptr;
    auto fail = [](HRESULT hr) {
        gEnvError = FAILED(hr) ? hr : E_FAIL;
        auto w = std::move(gEnvWaiters);
        gEnvWaiters.clear();
        for (auto& fn : w) fn(nullptr);
    };
    if (!create) { log("WebView2Loader.dll not found (err=%lu)", GetLastError()); fail(HRESULT_FROM_WIN32(ERROR_MOD_NOT_FOUND)); return; }
    auto* opts = new EnvOptions(L"--autoplay-policy=no-user-gesture-required --disable-features=msSmartScreenProtection");
    auto* h = new Handler<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler, HRESULT, ICoreWebView2Environment*>(
        IID_EnvCompleted, [fail](HRESULT hr, ICoreWebView2Environment* env) -> HRESULT {
            if (FAILED(hr) || !env) { log("WebView2 environment failed hr=0x%08lx", (unsigned long)hr); fail(hr); return S_OK; }
            env->AddRef();
            gEnv = env;
            log("WebView2 environment ready");
            auto w = std::move(gEnvWaiters);
            gEnvWaiters.clear();
            for (auto& fn : w) fn(env);
            return S_OK;
        });
    HRESULT hr = create(nullptr, userData.c_str(), opts, h);
    h->Release();
    opts->Release();
    if (FAILED(hr)) { log("CreateCoreWebView2EnvironmentWithOptions hr=0x%08lx", (unsigned long)hr); fail(hr); }
}

// страница внутри окна
struct Host {
    HWND hwnd = nullptr;
    ICoreWebView2Controller* ctl = nullptr;
    ICoreWebView2* web = nullptr;
    bool closed = false;
    std::function<void(const std::string&)> onMessage;
    std::function<void()> onNavigated;
};

static std::string toUtf8(const wchar_t* w) {
    if (!w) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
    std::string s(n > 0 ? n - 1 : 0, '\0');
    if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w, -1, &s[0], n, nullptr, nullptr);
    return s;
}
static std::wstring toWide(const std::string& s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
    std::wstring w(n > 0 ? n - 1 : 0, L'\0');
    if (n > 1) MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n);
    return w;
}

static void fit(Host* h) {
    if (!h || !h->ctl || !h->hwnd) return;
    RECT rc;
    GetClientRect(h->hwnd, &rc);
    h->ctl->put_Bounds(rc);
}

// создаёт WebView в окне hwnd; scripts выполняются в начале каждой страницы
static void create(Host* host, const std::wstring& userData, const std::wstring& url,
                   const std::vector<std::wstring>& scripts, bool interactive,
                   std::function<void(bool ok)> done) {
    withEnv(userData, [host, url, scripts, interactive, done](ICoreWebView2Environment* env) {
        if (!env || host->closed) { if (done) done(false); return; }
        auto* h = new Handler<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, HRESULT, ICoreWebView2Controller*>(
            IID_CtlCompleted, [host, url, scripts, interactive, done](HRESULT hr, ICoreWebView2Controller* ctl) -> HRESULT {
                if (FAILED(hr) || !ctl) { log("controller failed hr=0x%08lx", (unsigned long)hr); if (done) done(false); return S_OK; }
                if (host->closed) { ctl->Close(); if (done) done(false); return S_OK; }
                ctl->AddRef();
                host->ctl = ctl;
                ctl->get_CoreWebView2(&host->web);
                ICoreWebView2Settings* st = nullptr;
                if (host->web && SUCCEEDED(host->web->get_Settings(&st)) && st) {
                    st->put_AreDevToolsEnabled(FALSE);
                    st->put_IsStatusBarEnabled(FALSE);
                    st->put_IsZoomControlEnabled(FALSE);
                    st->put_AreDefaultContextMenusEnabled(FALSE);
                    st->put_IsWebMessageEnabled(TRUE);
                    st->put_AreDefaultScriptDialogsEnabled(interactive ? TRUE : FALSE);
                    st->Release();
                }
                fit(host);
                if (host->web) {
                    EventRegistrationToken tok;
                    auto* mh = new Handler<ICoreWebView2WebMessageReceivedEventHandler, ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs*>(
                        IID_MsgReceived, [host](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* a) -> HRESULT {
                            LPWSTR m = nullptr;
                            if (SUCCEEDED(a->get_WebMessageAsJson(&m)) && m) {
                                if (host->onMessage) host->onMessage(toUtf8(m));
                                CoTaskMemFree(m);
                            }
                            return S_OK;
                        });
                    host->web->add_WebMessageReceived(mh, &tok);
                    mh->Release();
                    auto* nh = new Handler<ICoreWebView2NavigationCompletedEventHandler, ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs*>(
                        IID_NavCompleted, [host](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs* a) -> HRESULT {
                            BOOL ok = FALSE;
                            a->get_IsSuccess(&ok);
                            if (!ok) { COREWEBVIEW2_WEB_ERROR_STATUS st; a->get_WebErrorStatus(&st); log("navigation failed status=%d", (int)st); }
                            if (host->onNavigated) host->onNavigated();
                            return S_OK;
                        });
                    host->web->add_NavigationCompleted(nh, &tok);
                    nh->Release();
                    // ссылки «в новом окне» открываем в обычном браузере
                    auto* wh = new Handler<ICoreWebView2NewWindowRequestedEventHandler, ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs*>(
                        IID_NewWindow, [](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* a) -> HRESULT {
                            LPWSTR u = nullptr;
                            if (SUCCEEDED(a->get_Uri(&u)) && u) {
                                if (wcsncmp(u, L"https://", 8) == 0 || wcsncmp(u, L"http://", 7) == 0)
                                    ShellExecuteW(nullptr, L"open", u, nullptr, nullptr, SW_SHOWNORMAL);
                                CoTaskMemFree(u);
                            }
                            a->put_Handled(TRUE);
                            return S_OK;
                        });
                    host->web->add_NewWindowRequested(wh, &tok);
                    wh->Release();
                    for (auto& sc : scripts) host->web->AddScriptToExecuteOnDocumentCreated(sc.c_str(), nullptr);
                    host->web->Navigate(url.c_str());
                }
                ctl->put_IsVisible(TRUE);
                if (done) done(true);
                return S_OK;
            });
        HRESULT hr = env->CreateCoreWebView2Controller(host->hwnd, h);
        h->Release();
        if (FAILED(hr)) { log("CreateCoreWebView2Controller hr=0x%08lx", (unsigned long)hr); if (done) done(false); }
    });
}

static void post(Host* h, const std::string& json) {
    if (!h || !h->web) return;
    std::wstring w = toWide(json);
    h->web->PostWebMessageAsJson(w.c_str());
}

static void exec(Host* h, const std::wstring& js) {
    if (h && h->web) h->web->ExecuteScript(js.c_str(), nullptr);
}

static void destroy(Host* h) {
    if (!h) return;
    h->closed = true;
    if (h->web) { h->web->Release(); h->web = nullptr; }
    if (h->ctl) { h->ctl->Close(); h->ctl->Release(); h->ctl = nullptr; }
}

}  // namespace wv
