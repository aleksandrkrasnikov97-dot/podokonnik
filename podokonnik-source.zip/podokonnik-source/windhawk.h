// Темы панели задач и меню «Пуск» от сообщества Windhawk (windhawk.net):
// моды «Windows 11 Taskbar Styler» и «Windows 11 Start Menu Styler» + темы из styling-guide (DockLike, OS26 Liquid Glass как на Mac, Windows 7…).
// Сам Windhawk ставится тихо (официальный установщик v1.7.3, проверяем SHA-256), мод — как это делает сам Windhawk:
// исходник и готовая DLL с mods.windhawk.net, настройки — в HKLM\SOFTWARE\Windhawk\Engine\Mods\<мод>.
// Писать в HKLM может только администратор — это делает «Подоконник.exe --whk-apply <задание>» с одним запросом UAC.
#pragma once
#include <bcrypt.h>
#include <memory>

static const char* kWhkSetupUrl = "https://github.com/ramensoftware/windhawk/releases/download/v1.7.3/windhawk_setup.exe";
static const char* kWhkSetupSha = "5116cc1703384aac88b8d7a3b57f172aea5da32b6df7355fb2f8247d23813c8f";
static const char* kWhkTbMod = "windows-11-taskbar-styler";
static const char* kWhkSmMod = "windows-11-start-menu-styler";
#define WM_WHKPROG (WM_APP + 67)
#define WM_WHKDONE (WM_APP + 68)
static void xsReload();

struct WhkInfo { bool installed = false, portable = false; std::wstring dir, appData, regSub, ver; };
static WhkInfo whkFind() {
    WhkInfo w;
    const wchar_t* un[] = {L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Windhawk", L"SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Windhawk"};
    for (const wchar_t* k : un) {
        wchar_t b[MAX_PATH * 2] = {0}; DWORD sz = sizeof b;
        if (w.dir.empty() && RegGetValueW(HKEY_LOCAL_MACHINE, k, L"InstallLocation", RRF_RT_REG_SZ, nullptr, b, &sz) == ERROR_SUCCESS && *b) w.dir = b;
        sz = sizeof b; b[0] = 0;
        if (w.ver.empty() && RegGetValueW(HKEY_LOCAL_MACHINE, k, L"DisplayVersion", RRF_RT_REG_SZ, nullptr, b, &sz) == ERROR_SUCCESS) w.ver = b;
    }
    if (w.dir.empty()) { wchar_t pf[MAX_PATH] = {0}; ExpandEnvironmentStringsW(L"%ProgramFiles%\\Windhawk", pf, MAX_PATH); w.dir = pf; }
    while (!w.dir.empty() && (w.dir.back() == L'\\' || w.dir.back() == L'"')) w.dir.pop_back();
    if (!w.dir.empty() && w.dir[0] == L'"') w.dir.erase(0, 1);
    std::wstring ini = w.dir + L"\\windhawk.ini";
    if (GetFileAttributesW((w.dir + L"\\windhawk.exe").c_str()) == INVALID_FILE_ATTRIBUTES || GetFileAttributesW(ini.c_str()) == INVALID_FILE_ATTRIBUTES) return w;
    w.installed = true;
    w.portable = GetPrivateProfileIntW(L"Storage", L"Portable", 0, ini.c_str()) != 0;
    wchar_t b[1024] = {0}, e[1024] = {0};
    GetPrivateProfileStringW(L"Storage", L"AppDataPath", L"%ProgramData%\\Windhawk", b, 1024, ini.c_str());
    ExpandEnvironmentStringsW(b, e, 1024);
    w.appData = e;
    if (w.appData.size() < 2 || w.appData[1] != L':') w.appData = w.dir + L"\\" + w.appData;
    GetPrivateProfileStringW(L"Storage", L"RegistryKey", L"HKEY_LOCAL_MACHINE\\SOFTWARE\\Windhawk", b, 1024, ini.c_str());
    std::wstring rk = b;
    size_t p = rk.find(L'\\');
    w.regSub = p == std::wstring::npos ? L"SOFTWARE\\Windhawk" : rk.substr(p + 1);
    return w;
}
static std::wstring whkModKey(const WhkInfo& w, const std::string& mod) { return w.regSub + L"\\Engine\\Mods\\" + W16(mod); }
static bool whkModOn(const WhkInfo& w, const std::string& mod) {
    if (!w.installed || w.portable) return false;
    wchar_t b[512] = {0}; DWORD sz = sizeof b, dis = 0, dsz = sizeof dis;
    std::wstring k = whkModKey(w, mod);
    if (RegGetValueW(HKEY_LOCAL_MACHINE, k.c_str(), L"LibraryFileName", RRF_RT_REG_SZ | RRF_SUBKEY_WOW6464KEY, nullptr, b, &sz) != ERROR_SUCCESS || !*b) return false;
    RegGetValueW(HKEY_LOCAL_MACHINE, k.c_str(), L"Disabled", RRF_RT_REG_DWORD | RRF_SUBKEY_WOW6464KEY, nullptr, &dis, &dsz);
    return dis == 0;
}
static std::string whkTheme(const WhkInfo& w, const std::string& mod) {
    wchar_t b[512] = {0}; DWORD sz = sizeof b;
    std::wstring k = whkModKey(w, mod) + L"\\Settings";
    if (RegGetValueW(HKEY_LOCAL_MACHINE, k.c_str(), L"theme", RRF_RT_REG_SZ | RRF_SUBKEY_WOW6464KEY, nullptr, b, &sz) != ERROR_SUCCESS) return "";
    return U8(b);
}

// ---------------------------------------------------------------- состояние
static volatile LONG gWhkBusy = 0;
static int gWhkPct = 0;
static std::string gWhkStep, gWhkErr;
static WhkInfo gWhk;
static void whkRefresh() { gWhk = whkFind(); }
static void whkState(js::Value& v) {
    auto num = [&](const char* k, double n) { js::Value x; x.type = js::Value::Num; x.n = n; v.o.emplace_back(k, x); };
    auto str = [&](const char* k, const std::string& s) { js::Value x; x.type = js::Value::Str; x.s = s; v.o.emplace_back(k, x); };
    num("whk", !gWhk.installed ? 0 : gWhk.portable ? 2 : 1);
    str("whkVer", U8(gWhk.ver));
    bool tb = whkModOn(gWhk, kWhkTbMod), sm = whkModOn(gWhk, kWhkSmMod);
    str("whkTb", tb ? whkTheme(gWhk, kWhkTbMod) : "");
    str("whkSm", sm ? whkTheme(gWhk, kWhkSmMod) : "");
    num("whkTbOn", tb); num("whkSmOn", sm);
    num("whkBusy", gWhkBusy); num("whkPct", gWhkPct);
    str("whkStep", gWhkStep); str("whkErr", gWhkErr);
}

// ---------------------------------------------------------------- SHA-256 файла
static std::string whkSha256(const std::wstring& path) {
    std::string data;
    if (!readFile(path, data)) return "";
    BCRYPT_ALG_HANDLE alg = nullptr; BCRYPT_HASH_HANDLE h = nullptr;
    unsigned char out[32]; std::string hex;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) == 0) {
        if (BCryptCreateHash(alg, &h, nullptr, 0, nullptr, 0, 0) == 0) {
            BCryptHashData(h, (PUCHAR)data.data(), (ULONG)data.size(), 0);
            if (BCryptFinishHash(h, out, 32, 0) == 0) { char t[3]; for (unsigned char c : out) { snprintf(t, 3, "%02x", c); hex += t; } }
            BCryptDestroyHash(h);
        }
        BCryptCloseAlgorithmProvider(alg, 0);
    }
    return hex;
}

// ---------------------------------------------------------------- метаданные мода из исходника: // @version 1.2, // @include explorer.exe …
static std::vector<std::string> whkMeta(const std::string& src, const char* key) {
    std::vector<std::string> r;
    std::string k = std::string("// @") + key;
    size_t end = src.find("==/WindhawkMod==");
    for (size_t p = 0; (p = src.find(k, p)) != std::string::npos && p < end; p += k.size()) {
        size_t q = p + k.size();
        if (q < src.size() && src[q] != ' ' && src[q] != '\t') continue;
        size_t e = src.find('\n', q);
        std::string v = src.substr(q, e - q);
        while (!v.empty() && (v.back() == '\r' || v.back() == ' ')) v.pop_back();
        while (!v.empty() && (v[0] == ' ' || v[0] == '\t')) v.erase(0, 1);
        if (!v.empty()) r.push_back(v);
    }
    return r;
}
static std::string whkJoin(const std::vector<std::string>& v) { std::string s; for (auto& x : v) { if (!s.empty()) s += '|'; s += x; } return s; }
static int whkVerCmp(const std::string& a, const std::string& b) {   // 1.7.3 против 1.8
    int x[4] = {0}, y[4] = {0};
    sscanf(a.c_str(), "%d.%d.%d.%d", &x[0], &x[1], &x[2], &x[3]); sscanf(b.c_str(), "%d.%d.%d.%d", &y[0], &y[1], &y[2], &y[3]);
    for (int i = 0; i < 4; ++i) if (x[i] != y[i]) return x[i] < y[i] ? -1 : 1;
    return 0;
}

// ---------------------------------------------------------------- помощник с правами администратора: «--whk-apply <задание>»
// задание: строки через TAB — setup <файл> | mod <id> <версия> <include> <exclude> <arch> <исходник> <dll> | theme <id> <тема>
static int whkAdminMain(const std::wstring& job) {
    std::string t;
    if (!readFile(job, t)) return 2;
    std::vector<std::vector<std::string>> lines;
    for (size_t p = 0; p < t.size();) {
        size_t e = t.find('\n', p); if (e == std::string::npos) e = t.size();
        std::vector<std::string> f; std::string line = t.substr(p, e - p); p = e + 1;
        for (size_t a = 0; a <= line.size();) { size_t b = line.find('\t', a); if (b == std::string::npos) b = line.size(); f.push_back(line.substr(a, b - a)); a = b + 1; }
        if (!f.empty() && !f[0].empty()) lines.push_back(f);
    }
    for (auto& f : lines) if (f[0] == "setup" && f.size() > 1) {   // тихая установка Windhawk
        std::wstring exe = W16(f[1]), cmd = L"\"" + exe + L"\" /S /STANDARD";
        STARTUPINFOW si{sizeof si}; PROCESS_INFORMATION pi{};
        if (!CreateProcessW(exe.c_str(), &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) return 3;
        WaitForSingleObject(pi.hProcess, 10 * 60 * 1000);
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
        for (int i = 0; i < 40 && !whkFind().installed; ++i) Sleep(250);
    }
    WhkInfo w = whkFind();
    if (!w.installed) return 4;
    if (w.portable) return 5;
    auto setSz = [](HKEY k, const wchar_t* n, const std::string& v) { std::wstring x = W16(v); RegSetValueExW(k, n, 0, REG_SZ, (const BYTE*)x.c_str(), (DWORD)((x.size() + 1) * 2)); };
    auto setDw = [](HKEY k, const wchar_t* n, DWORD v) { RegSetValueExW(k, n, 0, REG_DWORD, (const BYTE*)&v, sizeof v); };
    auto stamp = [&](const std::string& id) {
        HKEY k;
        if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, whkModKey(w, id).c_str(), 0, nullptr, 0, KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &k, nullptr) == ERROR_SUCCESS) {
            setDw(k, L"SettingsChangeTime", (DWORD)(time(nullptr) & 0x7fffffff)); RegCloseKey(k);
        }
    };
    int rc = 0;
    for (auto& f : lines) if (f[0] == "theme" && f.size() > 2) {   // тему пишем до мода — новый мод сразу запустится с ней
        HKEY k;
        if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, (whkModKey(w, f[1]) + L"\\Settings").c_str(), 0, nullptr, 0, KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &k, nullptr) != ERROR_SUCCESS) { rc = 6; continue; }
        setSz(k, L"theme", f[2]);
        if (f[1] == kWhkTbMod) {
            // темы рассчитаны на панель без погоды и без процентов батареи — с ними на доке надписи обрезаются.
            // Прячем их своими стилями мода (поле «Стили элементов» Taskbar Styler), без темы — убираем
            static const wchar_t* fix[][2] = {{L"Taskbar.AugmentedEntryPointButton", L"Visibility=Collapsed"}, {L"TextBlock#BatteryTextBlock", L"Visibility=Collapsed"}};
            for (int i = 0; i < 2; ++i) {
                std::wstring t = L"controlStyles[" + std::to_wstring(i) + L"].target", st = L"controlStyles[" + std::to_wstring(i) + L"].styles[0]";
                if (f[2].empty()) { RegDeleteValueW(k, t.c_str()); RegDeleteValueW(k, st.c_str()); }
                else { setSz(k, t.c_str(), U8(fix[i][0])); setSz(k, st.c_str(), U8(fix[i][1])); }
            }
        }
        RegCloseKey(k);
        stamp(f[1]);
    }
    {   // Windhawk работает незаметно: без значка в трее (его окно открывать не нужно — темы ставит Подоконник)
        HKEY k;
        if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, (w.regSub + L"\\Settings").c_str(), 0, nullptr, 0, KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &k, nullptr) == ERROR_SUCCESS) {
            setDw(k, L"HideTrayIcon", 1); RegCloseKey(k);
        }
    }
    for (auto& f : lines) if (f[0] == "mod" && f.size() > 7) {
        const std::string& id = f[1];
        wchar_t rnd[16]; swprintf(rnd, 16, L"%06u", 100000 + (GetTickCount() * 7919u + (DWORD)id.size()) % 900000);
        std::wstring dllName = W16(id + "_" + f[2] + "_") + rnd + L".dll";
        std::wstring dir64 = w.appData + L"\\Engine\\Mods\\64", srcDir = w.appData + L"\\ModsSource";
        SHCreateDirectoryExW(nullptr, dir64.c_str(), nullptr);
        SHCreateDirectoryExW(nullptr, srcDir.c_str(), nullptr);
        if (!CopyFileW(W16(f[7]).c_str(), (dir64 + L"\\" + dllName).c_str(), FALSE)) { rc = 7; continue; }
        CopyFileW(W16(f[6]).c_str(), (srcDir + L"\\" + W16(id) + L".wh.cpp").c_str(), FALSE);
        HKEY k;
        if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, whkModKey(w, id).c_str(), 0, nullptr, 0, KEY_SET_VALUE | KEY_WOW64_64KEY, nullptr, &k, nullptr) != ERROR_SUCCESS) { rc = 6; continue; }
        setSz(k, L"Include", f[3]); setSz(k, L"Exclude", f[4]); setSz(k, L"IncludeCustom", ""); setSz(k, L"ExcludeCustom", "");
        setDw(k, L"IncludeExcludeCustomOnly", 0); setDw(k, L"PatternsMatchCriticalSystemProcesses", 0);
        setDw(k, L"LoggingEnabled", 0); setDw(k, L"DebugLoggingEnabled", 0);
        setSz(k, L"Architecture", f[5]); setSz(k, L"Version", f[2]);
        setDw(k, L"SettingsChangeTime", (DWORD)(time(nullptr) & 0x7fffffff));
        setDw(k, L"Disabled", 0);
        setSz(k, L"LibraryFileName", U8(dllName));   // последним: с этой строки Windhawk считает мод установленным
        RegCloseKey(k);
    }
    for (auto& f : lines) if (f[0] == "enable" && f.size() > 1) {   // мод стоял выключенным — включить
        HKEY k;
        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, whkModKey(w, f[1]).c_str(), 0, KEY_SET_VALUE | KEY_WOW64_64KEY, &k) == ERROR_SUCCESS) { setDw(k, L"Disabled", 0); RegCloseKey(k); }
    }
    {   // готовые моды загружаются только рядом с библиотеками компилятора (libc++, libunwind, shim) — Windhawk кладёт их
        // в Engine\\Mods при первом открытии своего окна; кладём сами, иначе мод в Проводнике не загрузится
        std::wstring bin = w.dir + L"\\Compiler\\x86_64-w64-mingw32\\bin\\", dst = w.appData + L"\\Engine\\Mods\\64\\";
        SHCreateDirectoryExW(nullptr, dst.c_str(), nullptr);
        const wchar_t* libs[][2] = {{L"libc++.dll", L"libc++.whl"}, {L"libunwind.dll", L"libunwind.whl"}, {L"windhawk-mod-shim.dll", L"windhawk-mod-shim.dll"}};
        for (auto& l : libs)
            if (GetFileAttributesW((dst + l[1]).c_str()) == INVALID_FILE_ATTRIBUTES) CopyFileW((bin + l[0]).c_str(), (dst + l[1]).c_str(), TRUE);
    }
    {   // перезапуск Windhawk: служба поднимет его в сеансе пользователя, он заново внедрит моды в Проводник и «Пуск».
        // Нужен после тихой установки (сам Windhawk не стартует) и чтобы мод, не загрузившийся раньше, загрузился
        std::wstring exe = w.dir + L"\\windhawk.exe", cmd = L"\"" + exe + L"\" -restart -tray-only -timeout 20000";
        STARTUPINFOW si{sizeof si}; PROCESS_INFORMATION pi{};
        if (CreateProcessW(exe.c_str(), &cmd[0], nullptr, nullptr, FALSE, 0, nullptr, w.dir.c_str(), &si, &pi)) {
            WaitForSingleObject(pi.hProcess, 45000);
            CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
        }
    }
    return rc;
}

// ---------------------------------------------------------------- работа в фоне: скачать, что нужно, и один раз попросить администратора
struct WhkJob { std::string tb, sm; bool tbSet = false, smSet = false; };
static void whkProg(int pct, const char* step) { gWhkPct = pct; gWhkStep = step; PostMessageW(gMsgWnd, WM_WHKPROG, 0, 0); }
static bool whkFetchMod(const std::string& id, const std::string& winVer, std::string& line, std::string& err) {
    std::string src;
    if (!httpsGet(L"mods.windhawk.net", L"/mods/" + W16(id) + L".wh.cpp", src, 8u << 20)) { err = "mods.windhawk.net: " + std::to_string(gHttpLastStatus); return false; }
    auto ver = whkMeta(src, "version"), inc = whkMeta(src, "include"), exc = whkMeta(src, "exclude"), arch = whkMeta(src, "architecture");
    if (ver.empty()) { err = "no version"; return false; }
    std::string vj;
    if (httpsGet(L"mods.windhawk.net", L"/mods/" + W16(id) + L"/versions.json", vj, 1u << 20)) {
        js::Value v = js::parse(vj);
        for (auto& x : v.a) if (x.str("version") == ver[0]) {
            std::string need = x.str("minWindhawkVersion");
            if (!need.empty() && whkVerCmp(winVer, need) < 0) { err = "Windhawk " + need; return false; }
        }
    }
    std::wstring dir = baseDataDir() + L"\\windhawk";
    CreateDirectoryW(dir.c_str(), nullptr);
    std::wstring srcPath = dir + L"\\" + W16(id) + L".wh.cpp", dllPath = dir + L"\\" + W16(id) + L"_64.dll";
    writeFile(srcPath, src);
    if (!icoDownload("https://mods.windhawk.net/mods/" + id + "/" + ver[0] + "_64.dll", dllPath, [](int) {})) { err = "dll"; return false; }
    line = "mod\t" + id + "\t" + ver[0] + "\t" + whkJoin(inc) + "\t" + whkJoin(exc) + "\t" + whkJoin(arch) + "\t" + U8(srcPath) + "\t" + U8(dllPath) + "\n";
    return true;
}
static DWORD WINAPI WhkThread(LPVOID p) {
    std::unique_ptr<WhkJob> job((WhkJob*)p);
    std::string err, task;
    WhkInfo w = whkFind();
    std::string winVer = w.installed ? U8(w.ver) : "1.7.3";
    if (winVer.empty()) winVer = "1.7.3";
    do {
        if (w.installed && w.portable) { err = T8("У тебя переносная версия Windhawk — поставь обычную с windhawk.net", "You have portable Windhawk — install the regular version from windhawk.net"); break; }
        if (!w.installed) {
            whkProg(5, T8("Скачиваю Windhawk…", "Downloading Windhawk…"));
            std::wstring dir = baseDataDir() + L"\\windhawk", setup = dir + L"\\windhawk_setup.exe";
            CreateDirectoryW(dir.c_str(), nullptr);
            if (whkSha256(setup) != kWhkSetupSha) {
                if (!icoDownload(kWhkSetupUrl, setup, [](int pc) { whkProg(5 + pc * 55 / 100, T8("Скачиваю Windhawk…", "Downloading Windhawk…")); })) { err = T8("Не удалось скачать Windhawk", "Couldn't download Windhawk"); break; }
                if (whkSha256(setup) != kWhkSetupSha) { DeleteFileW(setup.c_str()); err = T8("Установщик Windhawk не прошёл проверку", "Windhawk installer failed the check"); break; }
            }
            task += "setup\t" + U8(setup) + "\n";
        }
        struct { bool set; const std::string* theme; const char* id; } mods[2] = {{job->tbSet, &job->tb, kWhkTbMod}, {job->smSet, &job->sm, kWhkSmMod}};
        for (auto& m : mods) {
            if (!m.set) continue;
            bool have = w.installed && !w.portable;
            std::wstring k = whkModKey(w, m.id);
            wchar_t b[512] = {0}; DWORD sz = sizeof b;
            bool installed = have && RegGetValueW(HKEY_LOCAL_MACHINE, k.c_str(), L"LibraryFileName", RRF_RT_REG_SZ | RRF_SUBKEY_WOW6464KEY, nullptr, b, &sz) == ERROR_SUCCESS && *b;
            if (!installed && !m.theme->empty()) {
                whkProg(65, T8("Скачиваю мод с windhawk.net…", "Downloading the mod from windhawk.net…"));
                std::string line, e;
                if (!whkFetchMod(m.id, winVer, line, e)) {
                    err = e.rfind("Windhawk ", 0) == 0 ? std::string(T8("Нужна версия ", "Needs ")) + e + T8(" — обнови Windhawk", " — update Windhawk") : std::string(T8("Не удалось скачать мод: ", "Couldn't download the mod: ")) + e;
                    break;
                }
                task += line;
            } else if (installed && !whkModOn(w, m.id) && !m.theme->empty()) task += std::string("enable\t") + m.id + "\n";
            if (installed || !m.theme->empty()) task += std::string("theme\t") + m.id + "\t" + *m.theme + "\n";
        }
        if (!err.empty() || task.empty()) break;
        whkProg(85, T8("Ставлю — Windows спросит разрешение…", "Applying — Windows will ask for permission…"));
        std::wstring jf = baseDataDir() + L"\\windhawk\\job.txt";
        CreateDirectoryW((baseDataDir() + L"\\windhawk").c_str(), nullptr);
        writeFile(jf, task);
        wchar_t self[MAX_PATH * 2] = {0}; GetModuleFileNameW(nullptr, self, MAX_PATH * 2);
        std::wstring prm = L"--whk-apply \"" + jf + L"\"";
        SHELLEXECUTEINFOW ei{sizeof(ei)};
        ei.fMask = SEE_MASK_NOCLOSEPROCESS; ei.lpVerb = L"runas"; ei.lpFile = self; ei.lpParameters = prm.c_str(); ei.nShow = SW_HIDE;
        if (!ShellExecuteExW(&ei) || !ei.hProcess) { err = T8("Windows не дала разрешение администратора", "Windows didn't grant administrator rights"); break; }
        WaitForSingleObject(ei.hProcess, 12 * 60 * 1000);
        DWORD rc = 1; GetExitCodeProcess(ei.hProcess, &rc); CloseHandle(ei.hProcess);
        alog("windhawk: apply rc=%lu", rc);
        if (rc == 4) err = T8("Windhawk не установился", "Windhawk didn't install");
        else if (rc) err = T8("Не получилось поставить тему (код ", "Couldn't apply the theme (code ") + std::to_string(rc) + ")";
    } while (false);
    if (!err.empty()) alog("windhawk: %s", err.c_str());
    gWhkErr = err;
    PostMessageW(gMsgWnd, WM_WHKDONE, 0, 0);
    return 0;
}
static void whkSearchFix(const WhkJob* j) {
    if (!j->tbSet) return;
    // поиск на доке — только значком: широкое поле не помещается. Без темы — как было
    const wchar_t* sk = L"Software\\Microsoft\\Windows\\CurrentVersion\\Search";
    DWORD cur = 1, sz = sizeof cur;
    RegGetValueW(HKEY_CURRENT_USER, sk, L"SearchboxTaskbarMode", RRF_RT_REG_DWORD, nullptr, &cur, &sz);
    DWORD want = cur;
    if (!j->tb.empty()) { if (!regGet(L"WhkSearchSaved", 0)) { regSet(L"WhkSearchWas", cur); regSet(L"WhkSearchSaved", 1); } if (cur >= 2) want = 1; }
    else if (regGet(L"WhkSearchSaved", 0)) { want = regGet(L"WhkSearchWas", cur); regSet(L"WhkSearchSaved", 0); }
    if (want != cur) {
        HKEY k;
        if (RegCreateKeyExW(HKEY_CURRENT_USER, sk, 0, nullptr, 0, KEY_SET_VALUE, nullptr, &k, nullptr) == ERROR_SUCCESS) { RegSetValueExW(k, L"SearchboxTaskbarMode", 0, REG_DWORD, (const BYTE*)&want, sizeof want); RegCloseKey(k); }
        DWORD_PTR r; SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, (LPARAM)L"TraySettings", SMTO_ABORTIFHUNG, 1000, &r);
    }
}
static void whkStart(WhkJob* j) {
    whkSearchFix(j);
    if (InterlockedCompareExchange(&gWhkBusy, 1, 0)) { delete j; return; }
    gWhkErr.clear(); gWhkPct = 1; gWhkStep = T8("Готовлю…", "Preparing…");
    HANDLE h = CreateThread(nullptr, 0, WhkThread, j, 0, nullptr);
    if (h) CloseHandle(h); else { InterlockedExchange(&gWhkBusy, 0); delete j; }
}
static bool whkUi(const std::string& cmd, const js::Value& m) {
    if (cmd == "whkApply" && gPackaged) return true;   // версия из Microsoft Store ничего не скачивает и не ставит
    if (cmd == "whkApply") {   // {tb:"DockLike"} и/или {sm:"…"}; пустая строка — убрать тему
        WhkJob* j = new WhkJob;
        if (const js::Value* x = m.get("tb")) { j->tbSet = true; j->tb = x->s; }
        if (const js::Value* x = m.get("sm")) { j->smSet = true; j->sm = x->s; }
        whkStart(j);
    } else if (cmd == "whkRefresh") whkRefresh();
    else if (cmd == "whkUninstall") {   // темы теперь свои — Windhawk с его модами мешает (XAML-диагностика одна на процесс)
        if (gWhk.installed) {
            static std::wstring un; un = gWhk.dir + L"\\uninstall.exe";
            HANDLE th = CreateThread(nullptr, 0, [](LPVOID) -> DWORD {
                SHELLEXECUTEINFOW ei{sizeof(ei)};
                ei.fMask = SEE_MASK_NOCLOSEPROCESS; ei.lpVerb = L"runas"; ei.lpFile = un.c_str(); ei.lpParameters = L"/S"; ei.nShow = SW_SHOWNORMAL;
                if (ShellExecuteExW(&ei) && ei.hProcess) { WaitForSingleObject(ei.hProcess, 120000); CloseHandle(ei.hProcess); }
                Sleep(3000);
                PostMessageW(gMsgWnd, WM_WHKDONE, 0, 0);   // обновит состояние; темы внедрятся заново по таймеру
                return 0;
            }, nullptr, 0, nullptr);
            if (th) CloseHandle(th);
        }
    }
    else if (cmd == "whkOpen") { if (gWhk.installed) ShellExecuteW(nullptr, L"open", (gWhk.dir + L"\\windhawk.exe").c_str(), nullptr, nullptr, SW_SHOWNORMAL); }
    else return false;
    appPushState();
    return true;
}
static bool whkMsg(UINT msg) {
    if (msg == WM_WHKPROG) { appPushState(); return true; }
    if (msg == WM_WHKDONE) {
        InterlockedExchange(&gWhkBusy, 0);
        whkRefresh();
        if (!gWhk.installed) xsReload();   // Windhawk убрали — свои темы перезапускаем, теперь им никто не мешает
        if (!gWhkErr.empty()) appToast(gWhkErr);
        appPushState();
        return true;
    }
    return false;
}
