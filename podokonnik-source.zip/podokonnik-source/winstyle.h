// Окна под свою тему (конструктор, mytheme.h):
//  • стекло Проводника — ExplorerBlurMica 2.1.0 (Maplespe, LGPL-3.0, https://github.com/Maplespe/ExplorerBlurMica),
//    DLL лежит в ресурсах exe без изменений. Регистрируем её только для текущего пользователя (HKCU\Software\Classes) —
//    без прав администратора; программы с правами администратора такие регистрации не загружают, а сама DLL работает
//    только в explorer.exe. Вид — config.ini рядом с DLL; Проводник читает его один раз, когда загружает DLL,
//    поэтому новый вид — после перезапуска Проводника;
//  • рамки всех окон — атрибуты DWM снаружи (углы, цвет рамки, заголовка и его текста) + цвет выделения Windows.
#pragma once
#include <set>
static void thSetAccent(DWORD rgb);
static DWORD thAccentNow();

#define IDR_EBM 121
static const wchar_t* kEbmClsid = L"{887D3A6A-502E-4AF5-9CE6-D515E12AFE89}";

// ---------------------------------------------------------------- стекло Проводника
struct EbmLook { int effect; DWORD rgb; int alpha; };   // effect: 0 размытие, 1 акрил, 2 Mica, 3 прозрачное размытие, 4 MicaAlt
static std::wstring ebmDir() { return baseDataDir() + L"\\ebm"; }
static std::wstring ebmDll() { return ebmDir() + L"\\ExplorerBlurMica.dll"; }

static bool ebmExtract() {   // выложить DLL из ресурсов (если уже загружена в Проводник — файл тот же, не трогаем)
    std::string data = resourceText(IDR_EBM);
    if (data.empty()) return false;
    SHCreateDirectoryExW(nullptr, ebmDir().c_str(), nullptr);
    std::string cur;
    if (readFile(ebmDll(), cur) && cur == data) return true;
    return writeFile(ebmDll(), data);
}
static void ebmWriteConfig(const EbmLook& L) {
    int r = (L.rgb >> 16) & 255, g = (L.rgb >> 8) & 255, b = L.rgb & 255, a = std::max(0, std::min(255, L.alpha));
    char s[512];
    snprintf(s, sizeof s,
        "[config]\r\neffect=%d\r\nclearAddress=true\r\nclearBarBg=true\r\nclearWinUIBg=true\r\nshowLine=true\r\n"
        "[light]\r\nr=%d\r\ng=%d\r\nb=%d\r\na=%d\r\n[dark]\r\nr=%d\r\ng=%d\r\nb=%d\r\na=%d\r\n",
        std::max(0, std::min(4, L.effect)), r, g, b, a, r, g, b, a);
    writeFile(ebmDir() + L"\\config.ini", s);
}
static bool ebmRegSet(HKEY root, const std::wstring& key, const wchar_t* name, const std::wstring* sz, DWORD dw) {
    HKEY k;
    if (RegCreateKeyExW(root, key.c_str(), 0, nullptr, 0, KEY_SET_VALUE, nullptr, &k, nullptr) != ERROR_SUCCESS) return false;
    LONG r = sz ? RegSetValueExW(k, name, 0, REG_SZ, (const BYTE*)sz->c_str(), (DWORD)((sz->size() + 1) * sizeof(wchar_t)))
                : RegSetValueExW(k, name, 0, REG_DWORD, (const BYTE*)&dw, sizeof dw);
    RegCloseKey(k);
    return r == ERROR_SUCCESS;
}
static void ebmRegister(bool on) {
    std::wstring clsid = std::wstring(L"Software\\Classes\\CLSID\\") + kEbmClsid;
    std::wstring ext = std::wstring(L"Software\\Classes\\Drive\\shellex\\FolderExtensions\\") + kEbmClsid;
    if (on) {
        std::wstring path = ebmDll(), name = L"ExplorerBlurMica", apt = L"Apartment";
        ebmRegSet(HKEY_CURRENT_USER, clsid, nullptr, &name, 0);
        ebmRegSet(HKEY_CURRENT_USER, clsid + L"\\InProcServer32", nullptr, &path, 0);
        ebmRegSet(HKEY_CURRENT_USER, clsid + L"\\InProcServer32", L"ThreadingModel", &apt, 0);
        ebmRegSet(HKEY_CURRENT_USER, ext, L"DriveMask", nullptr, 0xFF);
    } else {
        RegDeleteTreeW(HKEY_CURRENT_USER, ext.c_str());
        RegDeleteTreeW(HKEY_CURRENT_USER, clsid.c_str());
    }
}
static DWORD ebmExplorerPid() {
    HWND tray = FindWindowW(L"Shell_TrayWnd", nullptr);
    DWORD pid = 0;
    if (tray) GetWindowThreadProcessId(tray, &pid);
    return pid;
}
static bool ebmLoaded() {   // стекло уже работает в Проводнике (DLL загружена)
    DWORD pid = ebmExplorerPid();
    if (!pid) return false;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
    if (snap == INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32W me{sizeof me};
    bool r = false;
    std::wstring dll = ebmDll();
    for (BOOL ok = Module32FirstW(snap, &me); ok && !r; ok = Module32NextW(snap, &me)) r = !_wcsicmp(me.szExePath, dll.c_str());
    CloseHandle(snap);
    return r;
}
// Перезапуск Проводника — чтобы стекло взяло новый вид или ушло совсем. Панель задач Windows поднимет сама,
// тему панели Подоконник внедрит заново (xsTick); защита от петли этот перезапуск не считает
static bool explorerRunning() {   // есть ли вообще процесс explorer.exe (Проводник мог упасть и не подняться)
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return true;
    PROCESSENTRY32W pe{sizeof pe};
    bool r = false;
    for (BOOL ok = Process32FirstW(snap, &pe); ok && !r; ok = Process32NextW(snap, &pe)) r = !_wcsicmp(pe.szExeFile, L"explorer.exe");
    CloseHandle(snap);
    return r;
}
static void ebmRestartExplorer() {
    DWORD pid = ebmExplorerPid();
    if (!pid) return;
    if (HANDLE h = OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, FALSE, pid)) {
        gXsOwnRestart[0] = GetTickCount64();
        TerminateProcess(h, 1);
        WaitForSingleObject(h, 5000);
        CloseHandle(h);
    }
    for (int i = 0; i < 40 && !FindWindowW(L"Shell_TrayWnd", nullptr); ++i) Sleep(150);   // до 6 с — Windows поднимает сама
    if (!FindWindowW(L"Shell_TrayWnd", nullptr) && !explorerRunning()) {   // AutoRestartShell выключен — запускаем сами
        wchar_t win[MAX_PATH]; GetWindowsDirectoryW(win, MAX_PATH);
        ShellExecuteW(nullptr, L"open", (std::wstring(win) + L"\\explorer.exe").c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    }
}
// включить (look) или выключить (nullptr) стекло; restart — сразу перезапустить Проводник, если стекло в нём уже загружено
static void ebmSet(const EbmLook* look, bool restart) {
    if (look) {
        if (!ebmExtract()) { alog("ebm: no dll"); return; }
        ebmWriteConfig(*look);
        ebmRegister(true);
    } else ebmRegister(false);
    if (restart && ebmLoaded()) ebmRestartExplorer();
}

// ---------------------------------------------------------------- рамки всех окон
// цвета DWM — 0x00BBGGRR; WF_DEF — как у Windows. corner: 0 как в системе, 1 прямые, 2 скруглённые, 3 чуть скруглённые
#define WF_DEF 0xFFFFFFFF
struct WinFrame { bool on = false; int corner = 0; DWORD border = WF_DEF, caption = WF_DEF, text = WF_DEF; };
static WinFrame gWinFrame;
static std::set<HWND> gWinFramed;
static HWINEVENTHOOK gWinFrameHook = nullptr;

static bool winFrameEligible(HWND h) {
    if (!IsWindowVisible(h) || GetAncestor(h, GA_ROOT) != h) return false;
    DWORD pid = 0; GetWindowThreadProcessId(h, &pid);
    if (pid == GetCurrentProcessId()) return false;   // свои окна не трогаем
    LONG_PTR st = GetWindowLongPtrW(h, GWL_STYLE), ex = GetWindowLongPtrW(h, GWL_EXSTYLE);
    if ((st & WS_CAPTION) != WS_CAPTION || (ex & WS_EX_TOOLWINDOW)) return false;
    wchar_t cls[64] = {0}; GetClassNameW(h, cls, 63);
    return wcscmp(cls, L"Shell_TrayWnd") && wcscmp(cls, L"Progman") && wcscmp(cls, L"WorkerW");
}
static void winFrameApply(HWND h, const WinFrame& F) {
    int cr = F.on ? F.corner : 0;
    DWORD b = F.on ? F.border : WF_DEF, c = F.on ? F.caption : WF_DEF, t = F.on ? F.text : WF_DEF;
    DwmSetWindowAttribute(h, 33, &cr, sizeof cr);   // DWMWA_WINDOW_CORNER_PREFERENCE
    DwmSetWindowAttribute(h, 34, &b, sizeof b);     // DWMWA_BORDER_COLOR
    DwmSetWindowAttribute(h, 35, &c, sizeof c);     // DWMWA_CAPTION_COLOR
    DwmSetWindowAttribute(h, 36, &t, sizeof t);     // DWMWA_TEXT_COLOR
}
static void winFrameOne(HWND h) {
    if (!gWinFrame.on || !winFrameEligible(h)) return;
    winFrameApply(h, gWinFrame);
    if (gWinFramed.size() > 400)
        for (auto it = gWinFramed.begin(); it != gWinFramed.end();) it = IsWindow(*it) ? std::next(it) : gWinFramed.erase(it);
    gWinFramed.insert(h);
}
static void CALLBACK WinFrameEvent(HWINEVENTHOOK, DWORD, HWND h, LONG obj, LONG child, DWORD, DWORD) {
    if (obj == OBJID_WINDOW && child == CHILDID_SELF && h) winFrameOne(h);   // программы ставят своё при создании — наше после
}
static BOOL CALLBACK WinFrameEnum(HWND h, LPARAM) { winFrameOne(h); return TRUE; }
static void winFrameRestoreAll() {
    WinFrame off;
    for (HWND h : gWinFramed) if (IsWindow(h)) winFrameApply(h, off);
    gWinFramed.clear();
}
static void winFrameSet(const WinFrame& f) {
    winFrameRestoreAll();
    gWinFrame = f;
    if (!f.on) return;
    if (!gWinFrameHook) {
        gWinFrameHook = SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND, nullptr, WinFrameEvent, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
        SetWinEventHook(EVENT_OBJECT_SHOW, EVENT_OBJECT_SHOW, nullptr, WinFrameEvent, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
    }
    EnumWindows(WinFrameEnum, 0);
}
// цвет выделения и ссылок Windows (rgb) или как было (-1)
static void winAccentSet(int rgb) {
    if (rgb >= 0) { if (thAccentNow() != (DWORD)rgb) thSetAccent((DWORD)rgb); return; }
    const wchar_t* dwm = L"Software\\Microsoft\\Windows\\DWM";
    const wchar_t* acc = L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent";
    thRestoreOne(dwm, L"AccentColor");
    thRestoreOne(acc, L"AccentColorMenu");
    thRestoreOne(acc, L"StartColorMenu");
    thRestoreOne(dwm, L"ColorizationColor");
    thRestoreOne(dwm, L"ColorizationAfterglow");
    thSetAccent(thAccentNow());   // палитра оттенков — заново от вернувшегося цвета
    thRestoreOne(L"Control Panel\\Desktop", L"AutoColorization");
}
static void winLookStop() { winFrameRestoreAll(); }   // выход: рамки окон — обычные

// разово снять то, что ставило оформление окон тестовых версий 4.6: цвет акцента, цветные заголовки, старое стекло
static void winLookLegacyCleanup() {
    if (regGet(L"XsWinLegacyClean2", 0)) return;
    regSet(L"XsWinLegacyClean2", 1);
    regSet(L"XsWinLook", 0);   // старый помощник администратора (если запущен) видит 0 и возвращает окна как было
    bool had = regGet(L"XsGlass", 0) || regGet(L"XsFrame", 0) || regGet(L"XsWinWanted", 0);
    regSet(L"XsGlass", 0); regSet(L"XsFrame", 0); regSet(L"XsWinWanted", 0);
    if (!had) return;
    thRestoreOne(L"Software\\Microsoft\\Windows\\DWM", L"ColorPrevalence");
    winAccentSet(-1);
    ebmRegister(false);
}

// аргументы старой задачи планировщика (тестовые версии) — помощник сразу выходит
static int winElevatedInstall() { return 0; }
static int winElevatedMain() { return 0; }
