// Что умеют обои: программа заглядывает в пак и понимает, что в нём должно происходить
// (движется за мышью, реагирует на музыку, какие эффекты, что включается в настройках).
#pragma once
#include <map>

struct WpInfo {
    std::vector<std::string> features;
    bool audio = false, mouse = false;
    bool text = false;            // в сцене есть текст (часы, дата) — его нельзя обрезать краями экрана
    int sceneW = 0, sceneH = 0;   // размер сцены
};

// файлы из scene.pkg: только нужные маленькие (json и шейдеры), без картинок и звуков
static void pkgSmallFiles(const std::wstring& path, std::map<std::string, std::string>& out) {
    FILE* f = _wfopen(path.c_str(), L"rb");
    if (!f) return;
    auto u32 = [&](uint32_t& v) { return fread(&v, 4, 1, f) == 1; };
    uint32_t n = 0, cnt = 0;
    std::vector<std::tuple<std::string, uint32_t, uint32_t>> ents;
    if (u32(n) && n < 64) {
        fseek(f, n, SEEK_CUR);
        if (u32(cnt) && cnt < 100000) {
            for (uint32_t i = 0; i < cnt; ++i) {
                uint32_t ln = 0, off = 0, sz = 0;
                if (!u32(ln) || ln > 4096) break;
                std::string name(ln, '\0');
                if (fread(&name[0], 1, ln, f) != ln || !u32(off) || !u32(sz)) break;
                for (auto& c : name) c = c == '\\' ? '/' : (char)tolower((unsigned char)c);
                ents.emplace_back(name, off, sz);
            }
            long base = ftell(f);
            for (auto& e : ents) {
                const std::string& name = std::get<0>(e);
                uint32_t sz = std::get<2>(e);
                bool want = sz < 512 * 1024 && (name.size() > 5 && (name.compare(name.size() - 5, 5, ".json") == 0 ||
                            name.compare(name.size() - 5, 5, ".frag") == 0 || name.compare(name.size() - 5, 5, ".vert") == 0));
                if (!want) { out[name] = ""; continue; }
                std::string d(sz, '\0');
                fseek(f, base + (long)std::get<1>(e), SEEK_SET);
                if (sz && fread(&d[0], 1, sz, f) != sz) d.clear();
                out[name] = d;
            }
        }
    }
    fclose(f);
}

static const char* fxName(const std::string& k) {
    static const std::pair<const char*, const char*> M[] = {
        {"foliagesway", "Качание листвы"}, {"waterripple", "Рябь воды"}, {"waterflow", "Течение воды"},
        {"depthparallax", "Объём за мышью"}, {"pulse", "Пульсация"}, {"spin", "Вращение"}, {"shake", "Дрожание"},
        {"godrays", "Лучи света"}, {"vhs", "VHS-помехи"}, {"crt_scan_line", "Полосы старого экрана"}, {"clouds", "Облака"},
        {"blur", "Размытие"}, {"tint", "Оттенок"}, {"scroll", "Прокрутка"}, {"waterwaves", "Волны"}, {"reflection", "Отражение"},
        {"shimmer", "Мерцание"}, {"iris", "Глаза за курсором"}, {"cursorripple", "Рябь от курсора"}, {"fire", "Огонь"},
        {"lightshafts", "Лучи света"}, {"bloom", "Свечение"}, {"chromaticaberration", "Цветной сдвиг"}, {"twirl", "Закрутка"},
        {"skew", "Наклон"}, {"waves", "Волны"}, {"swing", "Покачивание"}, {"advancedfluidsimulation", "Жидкость"},
    };
    for (auto& p : M) if (k == p.first) return p.second;
    return nullptr;
}

// visible: true/false или {"user":"имя","value":…} — выключено ли и можно ли включить в настройках
static bool visValue(const js::Value* v, const js::Value& props, bool& viaSetting) {
    viaSetting = false;
    if (!v) return true;
    if (v->type == js::Value::Bool) return v->b;
    if (v->type == js::Value::Obj) {
        std::string user;
        if (const js::Value* u = v->get("user")) user = u->type == js::Value::Str ? u->s : u->str("name");
        bool val = v->boolean("value", true);
        if (!user.empty()) {
            if (const js::Value* p = props.get(user.c_str())) { viaSetting = true; if (const js::Value* pv = p->get("value")) val = pv->type == js::Value::Bool ? pv->b : pv->n != 0; }
        }
        return val;
    }
    return true;
}

static void addFeature(WpInfo& r, const std::string& s) {
    for (auto& x : r.features) if (x == s) return;
    r.features.push_back(s);
}

static WpInfo analyzeScene(const std::wstring& folder, const std::string& file, const js::Value& props) {
    WpInfo r;
    std::map<std::string, std::string> files;
    std::wstring base = baseName(W16(file.empty() ? "scene.json" : file));
    std::wstring pkg = folder + L"\\" + base + L".pkg";
    if (!fileExists(pkg)) pkg = folder + L"\\scene.pkg";
    pkgSmallFiles(pkg, files);
    std::string sceneTxt = files.count(U8(base) + ".json") ? files[U8(base) + ".json"] : "";
    if (sceneTxt.empty()) readFile(folder + L"\\" + W16(file.empty() ? "scene.json" : file), sceneTxt);
    js::Value sc = js::parse(sceneTxt);
    if (U8(base) == "gifscene") addFeature(r, "Анимация");
    const js::Value* gen = sc.get("general");
    if (gen && gen->boolean("cameraparallax", false)) { addFeature(r, "Объём за мышью"); r.mouse = true; }
    if (const js::Value* op = gen ? gen->get("orthogonalprojection") : nullptr) { r.sceneW = (int)op->num("width", 0); r.sceneH = (int)op->num("height", 0); }
    std::string shaders;
    for (auto& kv : files) if (kv.first.rfind("shaders/", 0) == 0) shaders += kv.second;
    bool particles = false, clock = false, sound = false;
    if (const js::Value* objs = sc.get("objects")) for (auto& o : objs->a) {
        bool setting = false;
        bool vis = visValue(o.get("visible"), props, setting);
        if (!vis && !setting) continue;
        if (o.get("particle")) particles = true;
        if (const js::Value* t = o.get("text")) { r.text = true; if (t->type == js::Value::Obj && t->get("script")) clock = true; }
        if (o.get("sound")) sound = true;
        if (const js::Value* fx = o.get("effects")) for (auto& e : fx->a) {
            std::string fpath = e.str("file");
            size_t a = fpath.find("effects/");
            if (a == std::string::npos) continue;
            std::string rest = fpath.substr(a + 8);
            if (rest.rfind("workshop/", 0) == 0) { size_t s = rest.find('/', 9); rest = s == std::string::npos ? "" : rest.substr(s + 1); }
            std::string k = rest.substr(0, rest.find('/'));
            for (auto& c : k) c = (char)tolower((unsigned char)c);
            bool s2 = false;
            bool ev = visValue(e.get("visible"), props, s2);
            // звук: эффекты, которые слушают музыку (проверяем и у незнакомых эффектов)
            if (const js::Value* ps = e.get("passes")) for (auto& p : ps->a)
                if (const js::Value* cb = p.get("combos")) if (cb->num("AUDIOPROCESSING", 0) > 0) r.audio = true;
            const char* nm = fxName(k);
            if (!nm) continue;
            if (k == "depthparallax" || k == "iris" || k == "cursorripple") r.mouse = true;
            std::string label = nm;
            if ((!vis && setting) || (!ev && s2)) label += " (включается в настройках)";
            else if (!ev) continue;
            addFeature(r, label);
            // звук: эффекты, которые слушают музыку
            if (const js::Value* ps = e.get("passes")) for (auto& p : ps->a)
                if (const js::Value* cb = p.get("combos")) if (cb->num("AUDIOPROCESSING", 0) > 0) r.audio = true;
        }
        // своя «живая» картинка (например, текущая вода)
        std::string img = o.str("image");
        if (!img.empty() && files.count(img)) {
            js::Value model = js::parse(files[img]);
            std::string mat = model.str("material");
            if (files.count(mat)) {
                js::Value m = js::parse(files[mat]);
                if (const js::Value* ps = m.get("passes")) if (!ps->a.empty()) {
                    std::string sh = ps->a[0].str("shader");
                    if (sh == "flowimage" || sh.find("flow") != std::string::npos) addFeature(r, "Течение");
                    else if (!sh.empty() && sh.rfind("generic", 0) != 0) addFeature(r, "Живая картинка");
                }
            }
        }
    }
    if (shaders.find("g_PointerPosition") != std::string::npos) r.mouse = true;
    // скрипты (SceneScript), анимации, модели — всё, что видно в json сцены и моделей
    std::string all = sceneTxt;
    for (auto& kv : files) if (kv.first.rfind("models/", 0) == 0 || kv.first.rfind("scripts/", 0) == 0) all += kv.second;
    auto has = [&](const char* s) { return all.find(s) != std::string::npos; };
    if (has("registerAudioBuffers") || has("audioBuffers")) r.audio = true;
    {   // шейдеры и материалы, которые читают спектр звука
        std::string low;
        for (auto& kv : files) { low += kv.second; low += '\n'; }
        for (auto& ch : low) ch = (char)tolower((unsigned char)ch);
        if (low.find("g_audiospectrum") != std::string::npos || low.find("audioprocessing") != std::string::npos ||
            low.find("audiobuffers") != std::string::npos) r.audio = true;
    }
    if (has("cursorWorldPosition") || has("cursorScreenPosition") || has("input.cursor")) r.mouse = true;
    if (has("cursorClick") || has("cursorDown") || has("cursorUp")) { r.mouse = true; addFeature(r, "Реагирует на клики"); }
    if (has("mediaPlaybackChanged") || has("mediaPropertiesChanged") || has("mediaThumbnailChanged")) addFeature(r, "Показывает, что играет");
    if (has("getHours") || has("getMinutes")) addFeature(r, "Часы");
    if (has("\"script\"")) addFeature(r, "Скрипты");
    if (has("\"keyframes\"") || has("\"animationlayers\"")) addFeature(r, "Анимация по кадрам");
    if (has("\"puppet\"")) addFeature(r, "Ожившая фигура");
    if (has(".mdl\"")) addFeature(r, "3D-модель");
    if (gen && gen->boolean("camerashake", false)) addFeature(r, "Покачивание камеры");
    if (gen && gen->boolean("bloom", false)) addFeature(r, "Свечение");
    if (has("\"light\"")) addFeature(r, "Свет");
    if (particles) addFeature(r, "Частицы");
    if (clock) addFeature(r, "Часы");
    if (sound) addFeature(r, "Свой звук");
    return r;
}

static WpInfo analyzeWeb(const std::wstring& folder) {
    WpInfo r;
    addFeature(r, "Веб-анимация");
    std::string all;
    std::function<void(const std::wstring&, int)> walk = [&](const std::wstring& d, int depth) {
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((d + L"\\*").c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) return;
        do {
            if (fd.cFileName[0] == L'.') continue;
            std::wstring p = d + L"\\" + fd.cFileName;
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (depth < 2) walk(p, depth + 1); continue; }
            std::string e = lowerExt(p);
            if ((e == "js" || e == "html" || e == "htm") && fd.nFileSizeLow < 3 * 1024 * 1024 && all.size() < 12 * 1024 * 1024) {
                std::string t;
                if (readFile(p, t)) all += t;
            }
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    };
    walk(folder, 0);
    if (all.find("wallpaperRegisterAudioListener") != std::string::npos) { r.audio = true; }
    if (all.find("mousemove") != std::string::npos || all.find("pointermove") != std::string::npos || all.find("mousedown") != std::string::npos) r.mouse = true;
    return r;
}

static std::string infoJson(const WpInfo& r) {
    std::string o = "[";
    std::vector<std::string> f;
    if (r.mouse) f.push_back("Реагирует на мышь");
    if (r.audio) f.push_back("Реагирует на музыку");
    for (auto& x : r.features) f.push_back(x);
    for (size_t i = 0; i < f.size(); ++i) { if (i) o += ","; o += js::esc(f[i]); }
    return o + "]";
}
