// Темы панели задач и меню «Пуск» без Windhawk: свои DLL (xstyle/ — моды Taskbar Styler и Start Menu Styler
// с нашим «хозяином» вместо движка Windhawk) внедряем в explorer.exe и StartMenuExperienceHost.exe.
// DLL лежат в ресурсах exe, при запуске выкладываются в <данные>\xstyle (имя с хешем — новую версию можно положить,
// пока старая загружена). Настройки — <id мода>.txt в той же папке: «theme<TAB>DockLike». Пустая тема — DLL выгружается.
// «Пуск» работает в AppContainer, поэтому папке даём чтение для ALL APPLICATION PACKAGES, а storage — ещё и запись.
#pragma once
#include <aclapi.h>
#include <tlhelp32.h>
#include <sddl.h>

static void thSet(const wchar_t* key, const wchar_t* name, DWORD v);
static void thRestoreOne(const wchar_t* key, const wchar_t* name);
static void thBroadcast(const wchar_t* what);
static DWORD thRegGet(HKEY root, const wchar_t* key, const wchar_t* name, DWORD def);
static void ebmRestartExplorer();
static void myDisabledByGuard(int mod);
static void myWorkTick();
#define IDR_XS_TASKBAR 119
#define IDR_XS_START 120

struct XsMod {
    const char* id;          // id мода — по нему DLL ищет свой файл настроек
    int res;
    const wchar_t* dllBase;  // xstyle-taskbar
    const wchar_t* exe;      // куда внедрять
    std::wstring dllPath;    // выложенная DLL этой версии
    DWORD pid = 0;           // процесс, в который уже внедрили
    ULONGLONG created = 0;
};
static XsMod gXs[2] = {{"windows-11-taskbar-styler", IDR_XS_TASKBAR, L"xstyle-taskbar", L"explorer.exe"},
                       {"windows-11-start-menu-styler", IDR_XS_START, L"xstyle-start", L"StartMenuExperienceHost.exe"}};
static std::wstring xsDir() { return baseDataDir() + L"\\xstyle"; }

static void xsGrantAppContainers(const std::wstring& path, DWORD rights) {
    PSID all = nullptr, lpac = nullptr;
    ConvertStringSidToSidW(L"S-1-15-2-1", &all);    // ALL APPLICATION PACKAGES
    ConvertStringSidToSidW(L"S-1-15-2-2", &lpac);   // ALL RESTRICTED APPLICATION PACKAGES
    EXPLICIT_ACCESSW ea[2] = {};
    PSID sids[2] = {all, lpac};
    for (int i = 0; i < 2; ++i) {
        ea[i].grfAccessPermissions = rights;
        ea[i].grfAccessMode = GRANT_ACCESS;
        ea[i].grfInheritance = SUB_CONTAINERS_AND_OBJECTS_INHERIT;
        ea[i].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[i].Trustee.TrusteeType = TRUSTEE_IS_WELL_KNOWN_GROUP;
        ea[i].Trustee.ptstrName = (LPWSTR)sids[i];
    }
    PACL old = nullptr, acl = nullptr; PSECURITY_DESCRIPTOR sd = nullptr;
    if (GetNamedSecurityInfoW(path.c_str(), SE_FILE_OBJECT, DACL_SECURITY_INFORMATION, nullptr, nullptr, &old, nullptr, &sd) == ERROR_SUCCESS &&
        SetEntriesInAclW(2, ea, old, &acl) == ERROR_SUCCESS)
        SetNamedSecurityInfoW((LPWSTR)path.c_str(), SE_FILE_OBJECT, DACL_SECURITY_INFORMATION, nullptr, nullptr, acl, nullptr);
    if (acl) LocalFree(acl);
    if (sd) LocalFree(sd);
    if (all) LocalFree(all);
    if (lpac) LocalFree(lpac);
}
static void xsPrepare() {   // выложить DLL и выдать права — один раз за запуск
    static bool done = false;
    if (done) return;
    done = true;
    std::wstring dir = xsDir();
    SHCreateDirectoryExW(nullptr, (dir + L"\\storage").c_str(), nullptr);
    xsGrantAppContainers(dir, GENERIC_READ | GENERIC_EXECUTE);
    xsGrantAppContainers(dir + L"\\storage", GENERIC_READ | GENERIC_WRITE | GENERIC_EXECUTE | DELETE);
    for (auto& m : gXs) {
        std::string data = resourceText(m.res);
        if (data.empty()) continue;
        uint32_t h = 2166136261u;
        for (unsigned char c : data) h = (h ^ c) * 16777619u;
        wchar_t name[96]; swprintf(name, 96, L"%ls-%08x.dll", m.dllBase, h);
        m.dllPath = dir + L"\\" + name;
        if (fileSize(m.dllPath) != data.size()) writeFile(m.dllPath, data);
    }
}

// ---------------------------------------------------------------- настройки мода
static std::wstring xsSettingsPath(const XsMod& m) { return xsDir() + L"\\" + W16(m.id) + L".txt"; }
// стоит ли своя тема в этом процессе: «my» или пусто
static std::string xsTheme(const XsMod& m) {
    std::string t;
    if (!readFile(xsSettingsPath(m), t)) return "";
    if (t.find("unload\t1") != std::string::npos || t.find("xsName\tmy") == std::string::npos) return "";
    return "my";
}
// body — настройки мода (тема, стили) от конструктора; пусто — мод выгружается
static void xsWriteSettings(const XsMod& m, const std::string& body) {
    std::string s = body.empty() ? std::string("theme\t\nunload\t1\n") : body + "xsName\tmy\n";
    if (regGet(L"XsLog", 0)) s += "log\t1\n";   // журнал в xstyle\storage\<мод>.log — только для отладки, он подробный
    s += "xamlDiagnosticsHandling\tallow\n";      // без окон-вопросов; стекло Проводника (ExplorerBlurMica) тоже пользуется XAML-диагностикой
    std::string cur;
    if (readFile(xsSettingsPath(m), cur) && cur == s) return;   // без изменений — мод не перезагружает стили зря
    writeFile(xsSettingsPath(m), s);
}

// ---------------------------------------------------------------- внедрение
static ULONGLONG xsProcCreated(HANDLE h) {
    FILETIME c, e, k, u;
    return GetProcessTimes(h, &c, &e, &k, &u) ? ((ULONGLONG)c.dwHighDateTime << 32 | c.dwLowDateTime) : 0;
}
static DWORD xsFindPid(const XsMod& m) {
    if (&m == &gXs[0]) {   // explorer — тот, что держит панель задач
        DWORD pid = 0;
        if (HWND tb = FindWindowW(L"Shell_TrayWnd", nullptr)) GetWindowThreadProcessId(tb, &pid);
        return pid;
    }
    DWORD sess = 0, found = 0;
    ProcessIdToSessionId(GetCurrentProcessId(), &sess);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{sizeof pe};
    for (BOOL ok = Process32FirstW(snap, &pe); ok; ok = Process32NextW(snap, &pe)) {
        DWORD s = 0;
        if (!_wcsicmp(pe.szExeFile, m.exe) && ProcessIdToSessionId(pe.th32ProcessID, &s) && s == sess) { found = pe.th32ProcessID; break; }
    }
    CloseHandle(snap);
    return found;
}
// какая из наших DLL уже загружена в процесс (путь) — пусто, если ни одной
static std::wstring xsLoadedIn(DWORD pid, const XsMod& m) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
    if (snap == INVALID_HANDLE_VALUE) return L"";
    MODULEENTRY32W me{sizeof me};
    std::wstring r, dir = xsDir();
    (void)m;
    for (BOOL ok = Module32FirstW(snap, &me); ok; ok = Module32NextW(snap, &me))
        if (!_wcsnicmp(me.szExePath, dir.c_str(), dir.size()) && !wcschr(me.szExePath + dir.size() + 1, L'\\')) { r = me.szExePath; break; }   // любая DLL из нашей папки
    CloseHandle(snap);
    return r;
}
static bool xsInject(DWORD pid, const std::wstring& dll) {
    HANDLE p = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid);
    if (!p) { alog("xstyle: OpenProcess %lu failed %lu", pid, GetLastError()); return false; }
    size_t bytes = (dll.size() + 1) * 2;
    void* mem = VirtualAllocEx(p, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    bool ok = false;
    if (mem && WriteProcessMemory(p, mem, dll.c_str(), bytes, nullptr)) {
        auto ll = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
        if (HANDLE t = CreateRemoteThread(p, nullptr, 0, ll, mem, 0, nullptr)) {
            ok = true;   // «Пуск» может быть приостановлен — тогда поток отработает, когда меню откроют; не ждём долго
            if (WaitForSingleObject(t, 3000) == WAIT_OBJECT_0) VirtualFreeEx(p, mem, 0, MEM_RELEASE);
            CloseHandle(t);
        } else alog("xstyle: CreateRemoteThread failed %lu", GetLastError());
    }
    CloseHandle(p);
    return ok;
}
// когда Подоконник сам перезапускает Проводник или «Пуск» (смена темы, стекло) — это не падение, защита от петли не считает
static ULONGLONG gXsOwnRestart[2] = {};
// раз в 2 с: если тема выбрана, а в процессе нет нашей DLL (перезапуск Проводника, «Пуска», вход в систему) — внедрить
static void xsTick() {
    myWorkTick();
    gXsTbOn = !xsTheme(gXs[0]).empty();
    for (auto& m : gXs) {
        if (xsTheme(m).empty()) { m.pid = 0; continue; }
        DWORD pid = xsFindPid(m);
        if (!pid) continue;
        HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        ULONGLONG cr = h ? xsProcCreated(h) : 0;
        if (h) CloseHandle(h);
        if (pid == m.pid && cr == m.created) continue;
        xsPrepare();
        if (m.dllPath.empty()) continue;
        std::wstring loaded = xsLoadedIn(pid, m);
        if (!loaded.empty() && _wcsicmp(loaded.c_str(), m.dllPath.c_str()) != 0) {
            // там старая версия — пусть выгрузится, внедрим новую на следующем тике
            std::string body;
            readFile(xsSettingsPath(m), body);
            writeFile(xsSettingsPath(m), "theme\t\nunload\t1\n");
            Sleep(1200);
            writeFile(xsSettingsPath(m), body);
            continue;
        }
        if (loaded.empty()) {
            // защита от петли: если процесс падает после внедрения и перезапускается — после 3 раз за 2 минуты тему снимаем
            static ULONGLONG hist[2][3] = {};
            int mi = (int)(&m - gXs);
            ULONGLONG now = GetTickCount64();
            if (gXsOwnRestart[mi] && now - gXsOwnRestart[mi] < 30000) { gXsOwnRestart[mi] = 0; if (!xsInject(pid, m.dllPath)) continue; }
            else if (hist[mi][0] && now - hist[mi][0] < 120000) {
                alog("xstyle: %s keeps restarting — theme disabled", m.id);
                xsWriteSettings(m, "");
                myDisabledByGuard(mi);
                appToast(T8("Тема оформления несколько раз подряд роняла панель задач или «Пуск» — Подоконник её выключил", "The theme kept crashing the taskbar or Start and was turned off"));
                appPushState();
                continue;
            }
            else {
                hist[mi][0] = hist[mi][1]; hist[mi][1] = hist[mi][2]; hist[mi][2] = now;
                if (!xsInject(pid, m.dllPath)) continue;
            }
        }
        alog("xstyle: %s active in pid %lu", m.id, pid);
        m.pid = pid; m.created = cr;
    }
}
static void xsSearchFix(bool themed) {   // поиск на доке — значком (широкое поле не помещается); без темы — как было
    const wchar_t* sk = L"Software\\Microsoft\\Windows\\CurrentVersion\\Search";
    DWORD cur = 1, sz = sizeof cur;
    RegGetValueW(HKEY_CURRENT_USER, sk, L"SearchboxTaskbarMode", RRF_RT_REG_DWORD, nullptr, &cur, &sz);
    DWORD want = cur;
    if (themed) { if (!regGet(L"WhkSearchSaved", 0)) { regSet(L"WhkSearchWas", cur); regSet(L"WhkSearchSaved", 1); } if (cur >= 2) want = 1; }
    else if (regGet(L"WhkSearchSaved", 0)) { want = regGet(L"WhkSearchWas", cur); regSet(L"WhkSearchSaved", 0); }
    if (want == cur) return;
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, sk, 0, nullptr, 0, KEY_SET_VALUE, nullptr, &k, nullptr) == ERROR_SUCCESS) { RegSetValueExW(k, L"SearchboxTaskbarMode", 0, REG_DWORD, (const BYTE*)&want, sizeof want); RegCloseKey(k); }
    DWORD_PTR r; SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, (LPARAM)L"TraySettings", SMTO_ABORTIFHUNG, 1000, &r);
}
