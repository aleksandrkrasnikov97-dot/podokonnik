#!/bin/bash
# Сборка DLL оформления (xstyle-*.dll) из модов Windhawk + host.cpp. Нужен llvm-mingw (clang) и заголовки C++/WinRT.
set -e
cd "$(dirname "$0")"
TC=${TC:-/home/claude/tc/llvm-mingw-20261117-ucrt-ubuntu-22.04-x86_64}
WINRT=${WINRT:-/home/claude/tc/winrt-gen}
CXX=$TC/bin/x86_64-w64-mingw32-clang++
CC=$TC/bin/x86_64-w64-mingw32-clang
mkdir -p out obj
FLAGS="-O2 -include exception -DUNICODE -D_UNICODE -DWINVER=0x0A00 -D_WIN32_WINNT=0x0A00 -D_WIN32_IE=0x0A00 -DNTDDI_VERSION=0x0A000008 -D__USE_MINGW_ANSI_STDIO=0 -Wno-pragma-pack -Wno-pragma-system-header-outside-header"
for f in minhook/src/buffer.c minhook/src/hook.c minhook/src/trampoline.c minhook/src/hde/hde64.c; do
  o=obj/$(basename $f .c).o; [ $o -nt $f ] || $CC -O2 -c $f -o $o -Iminhook/include
done
build() {   # $1 — id мода, $2 — имя DLL, $3 — версия, $4 — доп. библиотеки
  local id=$1 out=$2 ver=$3 libs=$4
  local def="-DWH_MOD -DWH_MOD_ID=L\"$id\" -DWH_MOD_VERSION=L\"$ver\" -DXS_MOD_ID=L\"$id\""
  $CXX -std=c++23 $FLAGS $def -include inc/windhawk_api.h -Iinc -Icasefix -I$WINRT -Iminhook/include -c mods/$id.wh.cpp -o obj/$id.o
  $CXX -std=c++23 $FLAGS $def -include inc/windhawk_api.h -Iinc -Iminhook/include -c host.cpp -o obj/host-$id.o
  $CXX -shared -static -s -o out/$out obj/$id.o obj/host-$id.o obj/buffer.o obj/hook.o obj/trampoline.o obj/hde64.o \
    $libs -lwinhttp -lshell32 -Wl,--exclude-all-symbols
}
build windows-11-taskbar-styler xstyle-taskbar.dll 1.11.2 "-lcomctl32 -lgdi32 -lole32 -loleaut32 -lruntimeobject -lshlwapi"
build windows-11-start-menu-styler xstyle-start.dll 1.8 "-lcomctl32 -lole32 -loleaut32 -lruntimeobject -lshlwapi -lversion"
ls -la out
