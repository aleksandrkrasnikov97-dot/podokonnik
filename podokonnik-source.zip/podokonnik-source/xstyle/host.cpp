// Подоконник: «хозяин» для модов-стилизаторов Windows 11 Taskbar Styler / Start Menu Styler (m417z, GPL-3.0).
// Заменяет движок Windhawk: DLL внедряется Подоконником в explorer.exe / StartMenuExperienceHost.exe,
// здесь реализованы функции Wh_* (настройки, хранилище, перехват функций через MinHook, загрузка по URL),
// а сам мод компилируется из исходника без изменений. Исходник этого файла — GPL-3.0, как и моды.
//
// Настройки: <папка DLL>\<id мода>.txt — строки «имя<TAB>значение» в UTF-8. Подоконник меняет файл —
// мод получает Wh_ModSettingsChanged. Строка «unload<TAB>1» — мод выгружается, DLL освобождается.
#include <windows.h>
#include <winhttp.h>
#include <shlobj.h>
#include <cstdio>
#include <cwchar>
#include <map>
#include <mutex>
#include <string>
#include <vector>
#include "MinHook.h"

#ifndef XS_MOD_ID
#error XS_MOD_ID
#endif

BOOL Wh_ModInit();
void Wh_ModAfterInit();
void Wh_ModUninit();
void Wh_ModSettingsChanged();

namespace {
HMODULE gSelf;
std::wstring gDir, gSettingsPath, gStorage, gLogPath;
std::mutex gMx;
std::map<std::wstring, std::wstring> gSettings;
FILETIME gSettingsTime{};
bool gLog = false;

std::wstring U16(const std::string& s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
    return w;
}
std::string U8(const std::wstring& w) {
    if (w.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), &s[0], n, nullptr, nullptr);
    return s;
}
bool ReadAll(const std::wstring& p, std::string& out) {
    HANDLE h = CreateFileW(p.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER sz{}; GetFileSizeEx(h, &sz);
    out.resize((size_t)sz.QuadPart);
    DWORD rd = 0;
    bool ok = sz.QuadPart == 0 || ReadFile(h, &out[0], (DWORD)out.size(), &rd, nullptr);
    CloseHandle(h);
    out.resize(rd);
    return ok;
}
bool WriteAll(const std::wstring& p, const void* data, size_t n) {
    HANDLE h = CreateFileW(p.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD wr = 0;
    bool ok = n == 0 || WriteFile(h, data, (DWORD)n, &wr, nullptr);
    CloseHandle(h);
    return ok && wr == n;
}
FILETIME FileTime(const std::wstring& p) {
    WIN32_FILE_ATTRIBUTE_DATA a{};
    if (!GetFileAttributesExW(p.c_str(), GetFileExInfoStandard, &a)) return FILETIME{};
    return a.ftLastWriteTime;
}
void LoadSettingsFile() {
    std::string t;
    std::map<std::wstring, std::wstring> m;
    if (ReadAll(gSettingsPath, t)) {
        size_t p = 0;
        if (t.size() >= 3 && (unsigned char)t[0] == 0xEF) p = 3;
        while (p < t.size()) {
            size_t e = t.find('\n', p); if (e == std::string::npos) e = t.size();
            std::string line = t.substr(p, e - p); p = e + 1;
            if (!line.empty() && line.back() == '\r') line.pop_back();
            size_t tab = line.find('\t');
            if (tab == std::string::npos) continue;
            m[U16(line.substr(0, tab))] = U16(line.substr(tab + 1));
        }
    }
    std::lock_guard<std::mutex> lk(gMx);
    gSettings.swap(m);
    gLog = gSettings.count(L"log") && gSettings[L"log"] == L"1";
}
std::wstring Setting(const std::wstring& k, bool* found = nullptr) {
    std::lock_guard<std::mutex> lk(gMx);
    auto it = gSettings.find(k);
    if (found) *found = it != gSettings.end();
    return it == gSettings.end() ? L"" : it->second;
}
std::wstring ValuePath(PCWSTR name) {
    std::wstring n = name;
    for (auto& c : n) if (c == L'\\' || c == L'/' || c == L':' || c == L'*' || c == L'?' || c == L'"' || c == L'<' || c == L'>' || c == L'|') c = L'_';
    std::wstring dir = gStorage + L"\\values";
    CreateDirectoryW(dir.c_str(), nullptr);
    return dir + L"\\" + n;
}
}  // namespace

// ---------------------------------------------------------------- Wh_* (как в windhawk.dll)
extern "C" {
BOOL InternalWh_IsLogEnabled(void*) { return gLog; }
void InternalWh_Log(void*, PCWSTR format, va_list args) {
    if (!gLog) return;
    wchar_t buf[2048];
    _vsnwprintf(buf, 2047, format, args);
    buf[2047] = 0;
    SYSTEMTIME st; GetLocalTime(&st);
    wchar_t line[2200];
    swprintf(line, 2200, L"%02d:%02d:%02d.%03d [%lu] %s\r\n", st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, GetCurrentProcessId(), buf);
    std::string u = U8(line);
    std::lock_guard<std::mutex> lk(gMx);
    HANDLE h = CreateFileW(gLogPath.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, 0, nullptr);
    if (h != INVALID_HANDLE_VALUE) {
        LARGE_INTEGER sz{}; GetFileSizeEx(h, &sz);
        DWORD wr;
        if (sz.QuadPart < (4 << 20)) WriteFile(h, u.data(), (DWORD)u.size(), &wr, nullptr);
        CloseHandle(h);
    }
}

int InternalWh_GetIntValue(void*, PCWSTR valueName, int defaultValue) {
    std::string t;
    if (!ReadAll(ValuePath(valueName) + L".int", t) || t.empty()) return defaultValue;
    return atoi(t.c_str());
}
BOOL InternalWh_SetIntValue(void*, PCWSTR valueName, int value) {
    std::string t = std::to_string(value);
    return WriteAll(ValuePath(valueName) + L".int", t.data(), t.size());
}
size_t InternalWh_GetStringValue(void*, PCWSTR valueName, PWSTR stringBuffer, size_t bufferChars) {
    std::string t;
    if (!ReadAll(ValuePath(valueName) + L".str", t)) { if (bufferChars) stringBuffer[0] = 0; return 0; }
    std::wstring w = U16(t);
    if (!bufferChars) return 0;
    size_t n = std::min(w.size(), bufferChars - 1);
    wmemcpy(stringBuffer, w.c_str(), n); stringBuffer[n] = 0;
    return n;
}
BOOL InternalWh_SetStringValue(void*, PCWSTR valueName, PCWSTR value) {
    std::string t = U8(value);
    return WriteAll(ValuePath(valueName) + L".str", t.data(), t.size());
}
size_t InternalWh_GetBinaryValue(void*, PCWSTR valueName, void* buffer, size_t bufferSize) {
    std::string t;
    if (!ReadAll(ValuePath(valueName) + L".bin", t) || t.size() > bufferSize) return 0;
    memcpy(buffer, t.data(), t.size());
    return t.size();
}
BOOL InternalWh_SetBinaryValue(void*, PCWSTR valueName, const void* buffer, size_t bufferSize) {
    return WriteAll(ValuePath(valueName) + L".bin", buffer, bufferSize);
}
BOOL InternalWh_DeleteValue(void*, PCWSTR valueName) {
    std::wstring p = ValuePath(valueName);
    DeleteFileW((p + L".int").c_str()); DeleteFileW((p + L".str").c_str()); DeleteFileW((p + L".bin").c_str());
    return TRUE;
}
size_t InternalWh_GetModStoragePath(void*, PWSTR pathBuffer, size_t bufferChars) {
    if (!bufferChars) return 0;
    size_t n = std::min(gStorage.size(), bufferChars - 1);
    wmemcpy(pathBuffer, gStorage.c_str(), n); pathBuffer[n] = 0;
    return n;
}
int InternalWh_GetIntSetting(void*, PCWSTR valueName, va_list args) {
    wchar_t name[512];
    _vsnwprintf(name, 511, valueName, args); name[511] = 0;
    std::wstring v = Setting(name);
    return v.empty() ? 0 : _wtoi(v.c_str());
}
PCWSTR InternalWh_GetStringSetting(void*, PCWSTR valueName, va_list args) {
    wchar_t name[512];
    _vsnwprintf(name, 511, valueName, args); name[511] = 0;
    std::wstring v = Setting(name);
    wchar_t* r = new wchar_t[v.size() + 1];
    wmemcpy(r, v.c_str(), v.size() + 1);
    return r;
}
void InternalWh_FreeStringSetting(void*, PCWSTR string) { delete[] string; }

BOOL InternalWh_SetFunctionHook(void*, void* targetFunction, void* hookFunction, void** originalFunction) {
    if (MH_CreateHook(targetFunction, hookFunction, originalFunction) != MH_OK) return FALSE;
    return MH_QueueEnableHook(targetFunction) == MH_OK;
}
BOOL InternalWh_RemoveFunctionHook(void*, void* targetFunction) { return MH_QueueDisableHook(targetFunction) == MH_OK; }
BOOL InternalWh_ApplyHookOperations(void*) { return MH_ApplyQueued() == MH_OK; }

// символы и дизассемблер этим модам не нужны
HANDLE InternalWh_FindFirstSymbol4(void*, HMODULE, const WH_FIND_SYMBOL_OPTIONS*, WH_FIND_SYMBOL*) { return nullptr; }
BOOL InternalWh_FindNextSymbol2(void*, HANDLE, WH_FIND_SYMBOL*) { return FALSE; }
void InternalWh_FindCloseSymbol(void*, HANDLE) {}
BOOL InternalWh_HookSymbols(void*, HMODULE, const WH_SYMBOL_HOOK*, size_t, const WH_HOOK_SYMBOLS_OPTIONS*) { return FALSE; }
BOOL InternalWh_Disasm(void*, void*, WH_DISASM_RESULT*) { return FALSE; }

const WH_URL_CONTENT* InternalWh_GetUrlContent(void*, PCWSTR url, const WH_GET_URL_CONTENT_OPTIONS* options) {
    // статистику тем Windhawk не отправляем — это его счётчики
    if (wcsstr(url, L"/releases/download/stats-")) return nullptr;
    URL_COMPONENTSW uc{sizeof uc};
    wchar_t host[256] = {0}, path[2048] = {0};
    uc.lpszHostName = host; uc.dwHostNameLength = 255;
    uc.lpszUrlPath = path; uc.dwUrlPathLength = 2047;
    wchar_t extra[1024] = {0}; uc.lpszExtraInfo = extra; uc.dwExtraInfoLength = 1023;
    if (!WinHttpCrackUrl(url, 0, 0, &uc)) return nullptr;
    std::wstring fullPath = std::wstring(path) + extra;
    HINTERNET s = WinHttpOpen(L"Podokonnik", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, nullptr, nullptr, 0);
    if (!s) return nullptr;
    WH_URL_CONTENT* res = nullptr;
    HINTERNET c = WinHttpConnect(s, host, uc.nPort, 0);
    HINTERNET r = c ? WinHttpOpenRequest(c, L"GET", fullPath.c_str(), nullptr, nullptr, nullptr, uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0) : nullptr;
    if (r && WinHttpSendRequest(r, nullptr, 0, nullptr, 0, 0, 0) && WinHttpReceiveResponse(r, nullptr)) {
        DWORD status = 0, sz = sizeof status;
        WinHttpQueryHeaders(r, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER, nullptr, &status, &sz, nullptr);
        std::string body;
        for (;;) {
            DWORD avail = 0;
            if (!WinHttpQueryDataAvailable(r, &avail) || !avail) break;
            size_t o = body.size(); body.resize(o + avail);
            DWORD rd = 0;
            if (!WinHttpReadData(r, &body[o], avail, &rd)) break;
            body.resize(o + rd);
            if (body.size() > (64u << 20)) break;
        }
        res = new WH_URL_CONTENT{};
        res->statusCode = (int)status;
        if (options && options->targetFilePath) WriteAll(options->targetFilePath, body.data(), body.size());
        else {
            char* d = new char[body.size() + 1];
            memcpy(d, body.data(), body.size()); d[body.size()] = 0;
            res->data = d; res->length = body.size();
        }
    }
    if (r) WinHttpCloseHandle(r);
    if (c) WinHttpCloseHandle(c);
    WinHttpCloseHandle(s);
    return res;
}
void InternalWh_FreeUrlContent(void*, const WH_URL_CONTENT* content) {
    if (!content) return;
    delete[] content->data;
    delete content;
}
}  // extern "C"

// ---------------------------------------------------------------- жизнь мода внутри процесса
static DWORD WINAPI XsMain(LPVOID) {
    LoadSettingsFile();
    gSettingsTime = FileTime(gSettingsPath);
    bool unload = Setting(L"unload") == L"1";
    bool inited = false;
    if (!unload && MH_Initialize() == MH_OK) {
        Wh_Log(L"host: init in pid %lu", GetCurrentProcessId());
        if (Wh_ModInit()) {
            MH_ApplyQueued();
            Wh_ModAfterInit();
            inited = true;
        } else Wh_Log(L"host: Wh_ModInit failed");
    }
    // ждём изменений настроек; именованное событие «выход» — Подоконник может попросить выгрузиться сразу
    wchar_t evName[96];
    swprintf(evName, 96, L"SugrobXStyleQuit_%s_%lu", XS_MOD_ID, GetCurrentProcessId());
    HANDLE quit = CreateEventW(nullptr, TRUE, FALSE, evName);
    while (inited) {
        if (quit && WaitForSingleObject(quit, 400) == WAIT_OBJECT_0) break;
        if (!quit) Sleep(400);
        FILETIME t = FileTime(gSettingsPath);
        if (CompareFileTime(&t, &gSettingsTime) == 0) continue;
        gSettingsTime = t;
        Sleep(100);   // файл могли ещё дописывать
        LoadSettingsFile();
        if (Setting(L"unload") == L"1") break;
        Wh_Log(L"host: settings changed");
        Wh_ModSettingsChanged();
    }
    if (inited) {
        Wh_Log(L"host: unloading");
        Wh_ModUninit();
        MH_DisableHook(MH_ALL_HOOKS);
        Sleep(300);   // дать потокам выйти из перехваченных функций
        MH_Uninitialize();
    }
    if (quit) CloseHandle(quit);
    FreeLibraryAndExitThread(gSelf, 0);
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        gSelf = h;
        DisableThreadLibraryCalls(h);
        wchar_t p[MAX_PATH * 2] = {0};
        GetModuleFileNameW(h, p, MAX_PATH * 2);
        gDir = p;
        gDir = gDir.substr(0, gDir.find_last_of(L'\\'));
        gSettingsPath = gDir + L"\\" + XS_MOD_ID + L".txt";
        gStorage = gDir + L"\\storage\\" + XS_MOD_ID;
        SHCreateDirectoryExW(nullptr, gStorage.c_str(), nullptr);
        gLogPath = gDir + L"\\storage\\" + XS_MOD_ID + L".log";
        // ссылку от LoadLibrary (её делает Подоконник при внедрении) отпускает поток мода — FreeLibraryAndExitThread
        HANDLE t = CreateThread(nullptr, 0, XsMain, nullptr, 0, nullptr);
        if (t) CloseHandle(t);
    }
    return TRUE;
}
